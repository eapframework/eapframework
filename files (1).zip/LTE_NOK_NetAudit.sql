CREATE OR REPLACE MATERIALIZED VIEW ${catalog}.${schema}.LTE_NOK_NetAudit
AS
WITH src_e_ndr_nokia_lce8_nrb AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.e_ndr_nokia_lce8_nrb
),
src_k_nok_5gnr_cell_nrb AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.k_nok_5gnr_cell_nrb
),
select_21_cols AS (
  SELECT
    EDMARKET,
    MARKET,
    USID,
    ENBNAME,
    BBU_CONFIG,
    REMOTE_USID,
    FACE,
    LATITUDE,
    LONGITUDE,
    CELLNAME,
    DSS_NRCELL,
    CELL_TYPE,
    ON_AIR,
    BAND,
    DL_CH_BW,
    RRHTYPE,
    EARFCNDL,
    EARFCNUL,
    TAC,
    PULLDATE,
    PMAX
  FROM
    src_e_ndr_nokia_lce8_nrb
),
join_enbname AS (
  SELECT
    l.EDMARKET,
    l.MARKET,
    l.USID,
    l.ENBNAME,
    l.BBU_CONFIG,
    l.REMOTE_USID,
    l.FACE,
    l.LATITUDE,
    l.LONGITUDE,
    l.CELLNAME,
    l.DSS_NRCELL,
    l.CELL_TYPE,
    l.ON_AIR,
    l.BAND,
    l.DL_CH_BW,
    l.RRHTYPE,
    l.EARFCNDL,
    l.EARFCNUL,
    l.TAC,
    l.PMAX,
    r.county,
    r.fips,
    r.cma,
    r.pulldate
  FROM
    select_21_cols l
    LEFT JOIN src_k_nok_5gnr_cell_nrb r ON l.ENBNAME = r.enbname
),
cast_cma_int AS (
  SELECT
    * EXCEPT(cma),
    CAST(cma AS INT) AS cma
  FROM
    join_enbname
),
cast_cma_str AS (
  SELECT
    * EXCEPT(cma),
    CAST(cma AS STRING) AS cma
  FROM
    cast_cma_int
),
cast_cma_str2 AS (
  SELECT
    * EXCEPT(cma),
    CAST(cma AS STRING) AS cma
  FROM
    cast_cma_str
),
pulldate_to_str AS (
  SELECT
    * EXCEPT(pulldate),
    CAST(pulldate AS STRING) AS pulldate
  FROM
    cast_cma_str2
),
dedup_cellname AS (
  SELECT
    * EXCEPT(_rn)
  FROM
    (
      SELECT
        *,
        ROW_NUMBER() OVER (
          PARTITION BY CELLNAME
          ORDER BY CELLNAME
        ) AS _rn
      FROM
        pulldate_to_str
    ) t
  WHERE
    _rn = 1
),
construct_geo_point AS (
  SELECT
    *,
    CONCAT('POINT(', LONGITUDE, ' ', LATITUDE, ')') AS construct_geo_point
  FROM
    dedup_cellname
)
SELECT
  *
FROM
  construct_geo_point;

/*
nodes:
  src_e_ndr_nokia_lce8_nrb:
    x: 100
    y: 150
    dimensions:
      width: 180
      height: 95
    nodeId: 3d049174-41d3-4340-b6c0-942a3e53530c
    type: Source
    description:
      text: Source table for Nokia LTE cell configuration data.
      hash: a1010101
  src_k_nok_5gnr_cell_nrb:
    x: 100
    y: 350
    dimensions:
      width: 180
      height: 95
    nodeId: 7a691f68-4756-4aa5-ba39-57bcc5605c3f
    type: Source
    description:
      text: Source table for Nokia 5G NR site and county data.
      hash: a2020202
  select_21_cols:
    x: 350
    y: 150
    dimensions:
      width: 180
      height: 95
    nodeId: 7ea5b758-5fae-4349-9b91-0bd694349832
    description:
      text: Select 21 relevant columns from Nokia LTE source.
      hash: a3030303
  join_enbname:
    x: 600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 3843b394-3cee-4526-9c4a-100964e3c2a7
    description:
      text: Left join Nokia LTE cells with site county info on ENBNAME.
      hash: a4040404
  cast_cma_int:
    x: 850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: e1058a14-cf93-4f00-a253-671449dd856d
    description:
      text: Cast cma to integer to normalize values.
      hash: a5050505
  cast_cma_str:
    x: 1100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: f8d6815c-2978-4c9c-bf44-3f8702e82c5e
    description:
      text: Cast cma back to string after normalization.
      hash: a6060606
  cast_cma_str2:
    x: 1350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: f3305e45-37df-4fa9-ba94-a4950ad1ac14
    description:
      text: Cast cma to string (idempotent pass-through).
      hash: a7070707
  pulldate_to_str:
    x: 1600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 9c5ec3fe-80cf-46d2-a39d-6ff38a75a8b9
    description:
      text: Convert pulldate timestamp to string.
      hash: a8080808
  dedup_cellname:
    x: 1850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: cffdabb1-279e-4206-bcb9-1465fbd76337
    description:
      text: Remove duplicate rows based on CELLNAME.
      hash: a9090909
  construct_geo_point:
    x: 2100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: e99ed91a-87fd-45b0-8bdc-07be2e2714a2
    description:
      text: Construct WKT geo point from latitude and longitude.
      hash: b0101010
  ${catalog}.${schema}.LTE_NOK_NetAudit:
    x: 2350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 198fd345-b08a-4c6a-9a77-6c0c753e6a60
    type: Output
    description:
      text: LTE Nokia Net Audit final output table.
      hash: b1111111
*/
