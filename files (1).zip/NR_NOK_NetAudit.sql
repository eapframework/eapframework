CREATE OR REPLACE MATERIALIZED VIEW ${catalog}.${schema}.NR_NOK_NetAudit
AS
WITH src_ericssonite_nrcellbu AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.ERICSSONITE_NRCellBU
),
src_nodesite_nrcell AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.nodesite_NRCELL
),
src_rms_peas_cmas AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.RMS_PEAs_CMAs
),
-- ===== Main branch: ERICSSONITE_NRCellBU transforms =====
select_27_cols AS (
  SELECT
    MARKET,
    EDMARKET,
    NRCELL_NAME,
    DSS_LTECELL,
    CELL_TYPE,
    ON_AIR,
    BAND,
    BW_DL,
    RRH_PRODUCTNAME,
    NRARFCN,
    CELLBARRED,
    PHYSCELLID,
    LTE_CELLS_ON_SAME_RRH,
    FIPS,
    CMA,
    BBU_USID,
    CSS_SITE_NAME,
    BBU_CONFIG,
    GNB_NAME,
    REMOTE_USID,
    FACE,
    LATITUDE,
    LONGITUDE,
    PMAX,
    RFS_DSS_FEATURESTATE,
    CPRI_LINK_RATE,
    LOADDATE
  FROM
    src_ericssonite_nrcellbu
),
dedup_nrcell AS (
  SELECT
    * EXCEPT(_rn)
  FROM
    (
      SELECT
        *,
        ROW_NUMBER() OVER (
          PARTITION BY NRCELL_NAME
          ORDER BY NRCELL_NAME
        ) AS _rn
      FROM
        select_27_cols
    ) t
  WHERE
    _rn = 1
),
cast_cma_int AS (
  SELECT
    * EXCEPT(CMA),
    CAST(CMA AS INT) AS CMA
  FROM
    dedup_nrcell
),
cast_cma_str AS (
  SELECT
    * EXCEPT(CMA),
    CAST(CMA AS STRING) AS CMA
  FROM
    cast_cma_int
),
cast_fips_int AS (
  SELECT
    * EXCEPT(FIPS),
    CAST(FIPS AS INT) AS FIPS
  FROM
    cast_cma_str
),
cast_fips_str AS (
  SELECT
    * EXCEPT(FIPS),
    CAST(FIPS AS STRING) AS FIPS
  FROM
    cast_fips_int
),
epoch_to_date AS (
  SELECT
    * EXCEPT(LOADDATE),
    CAST(
      FROM_UNIXTIME(CAST(LOADDATE AS BIGINT) / 1000) AS DATE
    ) AS LOADDATE
  FROM
    cast_fips_str
),
date_to_str AS (
  SELECT
    * EXCEPT(LOADDATE),
    DATE_FORMAT(LOADDATE, 'yyyy-MM-dd') AS LOADDATE
  FROM
    epoch_to_date
),
loaddate_str AS (
  SELECT
    * EXCEPT(LOADDATE),
    CAST(LOADDATE AS STRING) AS LOADDATE
  FROM
    date_to_str
),
construct_geo_point AS (
  SELECT
    *,
    CONCAT('POINT(', LONGITUDE, ' ', LATITUDE, ')') AS construct_geo_point
  FROM
    loaddate_str
),
ontology_geo AS (
  SELECT
    *
  FROM
    construct_geo_point
),
-- ===== Nodesite branch: latest records only =====
agg_max_loaddate AS (
  SELECT
    MAX(loaddate_) AS loaddate_max
  FROM
    src_nodesite_nrcell
),
join5_nodesite_maxdate AS (
  SELECT
    l.*,
    r.loaddate_max
  FROM
    src_nodesite_nrcell l
    LEFT JOIN agg_max_loaddate r ON l.loaddate_ = r.loaddate_max
),
filter_latest_nodesite AS (
  SELECT
    *
  FROM
    join5_nodesite_maxdate
  WHERE
    loaddate_ = loaddate_max
),
-- ===== PEA reference branch =====
pea_fips_cast AS (
  SELECT
    CAST(FIPS AS STRING) AS FIPS,
    PEA_,
    PEA_Name
  FROM
    src_rms_peas_cmas
),
-- ===== Merge: Join (6) + Join (7) + Filter + Dedup =====
join6_nodesite AS (
  SELECT
    l.*,
    r.node_,
    r.pid_,
    r.cellname,
    r.lcrid
  FROM
    ontology_geo l
    LEFT JOIN filter_latest_nodesite r ON l.NRCELL_NAME = r.cellname
),
join7_pea AS (
  SELECT
    l.*,
    r.PEA_,
    r.PEA_Name
  FROM
    join6_nodesite l
    LEFT JOIN pea_fips_cast r ON l.FIPS = r.FIPS
),
filter_node_not_null AS (
  SELECT
    *
  FROM
    join7_pea
  WHERE
    node_ IS NOT NULL
    AND TRIM(node_) != ''
),
dedup_final AS (
  SELECT
    * EXCEPT(_rn)
  FROM
    (
      SELECT
        *,
        ROW_NUMBER() OVER (
          PARTITION BY NRCELL_NAME
          ORDER BY NRCELL_NAME
        ) AS _rn
      FROM
        filter_node_not_null
    ) t
  WHERE
    _rn = 1
)
SELECT
  *
FROM
  dedup_final;

/*
nodes:
  src_ericssonite_nrcellbu:
    x: 100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 2179a01c-7042-492a-ac50-9b58a19dc72c
    type: Source
    description:
      text: Source table for Ericsson NR cell configuration data.
      hash: c1010101
  src_nodesite_nrcell:
    x: 100
    y: 550
    dimensions:
      width: 180
      height: 95
    nodeId: affaaf51-06fc-4751-ad3f-8ff9d5e04f0d
    type: Source
    description:
      text: Source table for node site NR cell data.
      hash: c2020202
  src_rms_peas_cmas:
    x: 100
    y: 750
    dimensions:
      width: 180
      height: 95
    nodeId: 02fbc0a9-d4bb-4475-9c3e-ba8deda0b670
    type: Source
    description:
      text: Source table for PEA and CMA reference data.
      hash: c3030303
  select_27_cols:
    x: 350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 2947d403-923e-4df4-a7e2-746ba3b9337b
    description:
      text: Select 27 relevant columns from Ericsson NR cell source.
      hash: c4040404
  dedup_nrcell:
    x: 600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 5cba8003-b4b1-47a7-84a8-9570a51b1512
    description:
      text: Remove duplicate rows based on NRCELL_NAME.
      hash: c5050505
  cast_cma_int:
    x: 850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 5d11299b-7915-4a51-b868-4bf9f781cb6b
    description:
      text: Cast CMA to integer to normalize values.
      hash: c6060606
  cast_cma_str:
    x: 1100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 98a7781b-1f34-4eec-bd3c-e4bf41830a95
    description:
      text: Cast CMA back to string after normalization.
      hash: c7070707
  cast_fips_int:
    x: 1350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: ee45ff2c-f403-4071-b4d8-d13bddd4d441
    description:
      text: Cast FIPS to integer to normalize values.
      hash: c8080808
  cast_fips_str:
    x: 1600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 4e0f25ee-990e-4519-b1e0-939dd4a88be9
    description:
      text: Cast FIPS back to string after normalization.
      hash: c9090909
  epoch_to_date:
    x: 1850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 86958ea7-c48d-44d5-84ce-ac86f4c515e3
    description:
      text: Convert LOADDATE from epoch milliseconds to date.
      hash: ca0a0a0a
  date_to_str:
    x: 2100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: b50569d5-b56c-43f1-af8c-e14d2849922c
    description:
      text: Format LOADDATE date to yyyy-MM-dd string.
      hash: cb0b0b0b
  loaddate_str:
    x: 2350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: a3433cd4-fda8-46cb-884f-0c075cb611d7
    description:
      text: Cast LOADDATE to string type.
      hash: cc0c0c0c
  construct_geo_point:
    x: 2600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 2d230139-c3d4-4854-b82f-e20b2e79b47e
    description:
      text: Construct WKT geo point from latitude and longitude.
      hash: cd0d0d0d
  ontology_geo:
    x: 2850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 4e289d12-ce43-4271-8e1d-ceb983ac5ea9
    description:
      text: Ontology geo point pass-through.
      hash: ce0e0e0e
  agg_max_loaddate:
    x: 350
    y: 550
    dimensions:
      width: 180
      height: 95
    nodeId: 7e31f2be-ea13-4fe8-8c51-1417297232be
    description:
      text: Calculate maximum loaddate from nodesite table.
      hash: cf0f0f0f
  join5_nodesite_maxdate:
    x: 600
    y: 550
    dimensions:
      width: 180
      height: 95
    nodeId: fa9d4eb3-30af-4519-b745-eaea84c2e172
    description:
      text: Join nodesite with max loaddate for latest record filtering.
      hash: d0101010
  filter_latest_nodesite:
    x: 850
    y: 550
    dimensions:
      width: 180
      height: 95
    nodeId: 16b68d40-925b-4905-94f9-a443b8852734
    description:
      text: Filter to keep only latest nodesite records.
      hash: d1111111
  pea_fips_cast:
    x: 350
    y: 750
    dimensions:
      width: 180
      height: 95
    nodeId: 1934df3c-c9ce-4bf4-904e-f6c684e2340a
    description:
      text: Cast FIPS to string in PEA reference for join compatibility.
      hash: d2121212
  join6_nodesite:
    x: 3100
    y: 400
    dimensions:
      width: 180
      height: 95
    nodeId: e0650751-0b16-4bf9-9735-7ea34fddea31
    description:
      text: Join NR cells with latest nodesite data on NRCELL_NAME.
      hash: d3131313
  join7_pea:
    x: 3350
    y: 500
    dimensions:
      width: 180
      height: 95
    nodeId: 219eece9-01da-46d7-92c8-fc00573da6e8
    description:
      text: Join with PEA reference data on FIPS.
      hash: d4141414
  filter_node_not_null:
    x: 3600
    y: 500
    dimensions:
      width: 180
      height: 95
    nodeId: ac9fa3f8-842d-4ba7-a63e-35e43064da36
    description:
      text: Filter rows where node_ is not null and not empty.
      hash: d5151515
  dedup_final:
    x: 3850
    y: 500
    dimensions:
      width: 180
      height: 95
    nodeId: 1cfffe00-2862-47af-bb87-62dfad54be39
    description:
      text: Remove duplicate rows based on NRCELL_NAME.
      hash: d6161616
  ${catalog}.${schema}.NR_NOK_NetAudit:
    x: 4100
    y: 500
    dimensions:
      width: 180
      height: 95
    nodeId: d7693cae-7f4a-4630-a95b-79e605e70225
    type: Output
    description:
      text: NR Nokia Net Audit final output table.
      hash: d7171717
*/
