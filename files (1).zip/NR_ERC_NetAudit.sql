CREATE OR REPLACE MATERIALIZED VIEW ${catalog}.${schema}.NR_ERC_NetAudit
AS
WITH src_k_fbrc_scnr_cell AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.k_FBRC_SCNR_CELL
),
src_rms_peas_cmas AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.RMS_PEAs_CMAs
),
src_ericssonite_ssb AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.ERICSSONITE_SSB
),
src_levo_site_master_br AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.LEVO_SITE_MASTER_BR
),
-- ===== ERC NR source fips normalization =====
cast_src_fips_int AS (
  SELECT
    * EXCEPT(fips),
    CAST(fips AS INT) AS fips
  FROM
    src_k_fbrc_scnr_cell
),
cast_src_fips_str AS (
  SELECT
    * EXCEPT(fips),
    CAST(fips AS STRING) AS fips
  FROM
    cast_src_fips_int
),
-- ===== PEA reference =====
pea_fips_cast AS (
  SELECT
    CAST(FIPS AS STRING) AS FIPS,
    PEA_,
    PEA_Name
  FROM
    src_rms_peas_cmas
),
-- ===== PEA added join =====
pea_added AS (
  SELECT
    l.*,
    r.PEA_,
    r.PEA_Name
  FROM
    cast_src_fips_str l
    LEFT JOIN pea_fips_cast r ON l.fips = r.FIPS
),
-- ===== Select + Cast chain =====
select_31_cols AS (
  SELECT
    edmarket,
    market,
    bbu_usid,
    bbu_fa_code,
    county,
    fips,
    cma,
    remote_usid,
    face,
    latitude,
    longitude,
    nrcell_name,
    cell_type,
    on_air,
    band,
    bw_dl,
    arfcndl,
    arfcnul,
    call_sign,
    refresh_date,
    gnb_name,
    rru_name,
    lte_cells_on_same_rru,
    cpri_link_rate,
    sw_name,
    ems_name,
    dss_ltecell,
    cellbarred,
    configuredmaxtxpower,
    PEA_,
    PEA_Name
  FROM
    pea_added
),
cast_cma_int AS (
  SELECT
    * EXCEPT(cma),
    CAST(cma AS INT) AS cma
  FROM
    select_31_cols
),
cast_cma_str AS (
  SELECT
    * EXCEPT(cma),
    CAST(cma AS STRING) AS cma
  FROM
    cast_cma_int
),
cast_fips_int AS (
  SELECT
    * EXCEPT(fips),
    CAST(fips AS INT) AS fips
  FROM
    cast_cma_str
),
cast_fips_str AS (
  SELECT
    * EXCEPT(fips),
    CAST(fips AS STRING) AS fips
  FROM
    cast_fips_int
),
cast_refresh_str AS (
  SELECT
    * EXCEPT(refresh_date),
    CAST(refresh_date AS STRING) AS refresh_date
  FROM
    cast_fips_str
),
concat_prim AS (
  SELECT
    *,
    CONCAT(
      COALESCE(nrcell_name, ''),
      '-',
      COALESCE(refresh_date, '')
    ) AS concat_prim
  FROM
    cast_refresh_str
),
construct_geo_point AS (
  SELECT
    *,
    CONCAT('POINT(', longitude, ' ', latitude, ')') AS construct_geo_point
  FROM
    concat_prim
),
ontology_geo AS (
  SELECT
    *
  FROM
    construct_geo_point
),
-- ===== SSB branch: latest records only =====
agg_max_loaddate_ssb AS (
  SELECT
    MAX(LOADDATE_) AS LOADDATE_max
  FROM
    src_ericssonite_ssb
),
join3_ssb_maxdate AS (
  SELECT
    l.*,
    r.LOADDATE_max
  FROM
    src_ericssonite_ssb l
    LEFT JOIN agg_max_loaddate_ssb r ON l.LOADDATE_ = r.LOADDATE_max
),
filter_latest_ssb AS (
  SELECT
    *
  FROM
    join3_ssb_maxdate
  WHERE
    LOADDATE_ = LOADDATE_max
),
-- ===== LEVO branch: active sectors only =====
filter_levo_active AS (
  SELECT
    *
  FROM
    src_levo_site_master_br
  WHERE
    SOFT_SECTOR_ID > 0
),
-- ===== Final joins =====
addd_ssb AS (
  SELECT
    l.*,
    r.SSBFREQUENCY,
    r.SSBDURATION,
    r.SSBOFFSET
  FROM
    ontology_geo l
    LEFT JOIN filter_latest_ssb r ON l.nrcell_name = r.NRCELLDU_ID_
),
join4_levo AS (
  SELECT
    l.*,
    r.CLLI,
    r.SITE_ID_NAME_BBU
  FROM
    addd_ssb l
    LEFT JOIN filter_levo_active r ON l.nrcell_name = r.SOFT_SECTOR_NAME
),
add_uuid AS (
  SELECT
    UUID() AS uuid,
    *
  FROM
    join4_levo
)
SELECT
  *
FROM
  add_uuid;

/*
nodes:
  src_k_fbrc_scnr_cell:
    x: 100
    y: 150
    dimensions:
      width: 180
      height: 95
    nodeId: 120d4660-9884-4c2e-9324-0461300554fe
    type: Source
    description:
      text: Source table for Ericsson NR cell data (k_FBRC_SCNR_CELL).
      hash: e1010101
  src_rms_peas_cmas:
    x: 100
    y: 350
    dimensions:
      width: 180
      height: 95
    nodeId: 9a977890-af2a-419e-935f-72948b4a7d37
    type: Source
    description:
      text: Source table for PEA and CMA reference data.
      hash: e2020202
  src_ericssonite_ssb:
    x: 100
    y: 650
    dimensions:
      width: 180
      height: 95
    nodeId: c4851f84-2cbe-4256-bac5-631ae0cc2e0e
    type: Source
    description:
      text: Source table for Ericsson SSB parameters.
      hash: e3030303
  src_levo_site_master_br:
    x: 100
    y: 850
    dimensions:
      width: 180
      height: 95
    nodeId: cc857635-7db2-4e61-bf81-92dd5c3321a2
    type: Source
    description:
      text: Source table for LEVO site master data.
      hash: e4040404
  cast_src_fips_int:
    x: 350
    y: 150
    dimensions:
      width: 180
      height: 95
    nodeId: 416ac459-95c8-473b-abc1-04691c067ec7
    description:
      text: Cast fips to integer to normalize source values.
      hash: e5050505
  cast_src_fips_str:
    x: 600
    y: 150
    dimensions:
      width: 180
      height: 95
    nodeId: d87e5fac-b4bc-4e64-826f-5f133af70879
    description:
      text: Cast fips back to string after normalization.
      hash: e6060606
  pea_fips_cast:
    x: 350
    y: 350
    dimensions:
      width: 180
      height: 95
    nodeId: 2e172447-fb5e-4197-b77f-b162acc3f7fe
    description:
      text: Cast FIPS to string in PEA reference for join compatibility.
      hash: e7070707
  pea_added:
    x: 850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 136e3095-1253-4a13-91bc-97d764d5b62f
    description:
      text: Left join ERC NR source with PEA reference on fips.
      hash: e8080808
  select_31_cols:
    x: 1100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 9ef5a652-fa86-4f84-bc37-663b8261fd73
    description:
      text: Select 31 relevant columns from PEA-joined result.
      hash: e9090909
  cast_cma_int:
    x: 1350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: f76fe557-44be-4cb4-8193-1ef71519f9cd
    description:
      text: Cast cma to integer to normalize values.
      hash: ea0a0a0a
  cast_cma_str:
    x: 1600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 2866c58e-b762-400c-87d3-ce6794208328
    description:
      text: Cast cma back to string after normalization.
      hash: eb0b0b0b
  cast_fips_int:
    x: 1850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 0bbc743f-8715-41dc-ad54-37d895c11090
    description:
      text: Cast fips to integer to normalize values.
      hash: ec0c0c0c
  cast_fips_str:
    x: 2100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 39dab18b-7149-484e-bcd5-16dc5883bd3c
    description:
      text: Cast fips back to string after normalization.
      hash: ed0d0d0d
  cast_refresh_str:
    x: 2350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 8018a14b-412c-4e80-bc4c-4d1211e6231a
    description:
      text: Cast refresh_date to string type.
      hash: ee0e0e0e
  concat_prim:
    x: 2600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 54f4d42e-8300-4087-8dcf-f132ea64242e
    description:
      text: Concatenate nrcell_name and refresh_date with dash separator.
      hash: ef0f0f0f
  construct_geo_point:
    x: 2850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 295cd903-df9c-413e-9260-ca82d5c178fd
    description:
      text: Construct WKT geo point from latitude and longitude.
      hash: f0101010
  ontology_geo:
    x: 3100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: cf60ccea-55f2-40da-9d99-7c0772bc38b2
    description:
      text: Ontology geo point pass-through.
      hash: f1111111
  agg_max_loaddate_ssb:
    x: 350
    y: 650
    dimensions:
      width: 180
      height: 95
    nodeId: 8fae4d62-7738-401c-96b9-24e263ff9df2
    description:
      text: Calculate maximum LOADDATE_ from SSB table.
      hash: f2121212
  join3_ssb_maxdate:
    x: 600
    y: 650
    dimensions:
      width: 180
      height: 95
    nodeId: c27177ff-8fb0-47b0-8fe2-02168ff1bc81
    description:
      text: Join SSB with max loaddate for latest record filtering.
      hash: f3131313
  filter_latest_ssb:
    x: 850
    y: 650
    dimensions:
      width: 180
      height: 95
    nodeId: c2c7eddd-e052-4b4b-9ae3-4f5909c71f75
    description:
      text: Filter to keep only latest SSB records.
      hash: f4141414
  filter_levo_active:
    x: 350
    y: 850
    dimensions:
      width: 180
      height: 95
    nodeId: 5ea37b4f-2e72-47eb-b835-9022a22b666f
    description:
      text: Filter LEVO to active sectors where SOFT_SECTOR_ID greater than 0.
      hash: f5151515
  addd_ssb:
    x: 3350
    y: 450
    dimensions:
      width: 180
      height: 95
    nodeId: e5aa469a-7001-4278-8493-a81c8667b9a6
    description:
      text: Left join ERC NR with SSB parameters on nrcell_name.
      hash: f6161616
  join4_levo:
    x: 3600
    y: 550
    dimensions:
      width: 180
      height: 95
    nodeId: 0fad9769-b7d1-40af-a410-b6493d477f01
    description:
      text: Left join with LEVO site data on nrcell_name equals SOFT_SECTOR_NAME.
      hash: f7171717
  add_uuid:
    x: 3850
    y: 550
    dimensions:
      width: 180
      height: 95
    nodeId: 3bffeeda-82a4-44d0-98f3-2ba471955236
    description:
      text: Add UUID primary key column.
      hash: f8181818
  ${catalog}.${schema}.NR_ERC_NetAudit:
    x: 4100
    y: 550
    dimensions:
      width: 180
      height: 95
    nodeId: c133b147-928f-4e42-8472-f46bc8e70ced
    type: Output
    description:
      text: NR Ericsson Net Audit final output table with UUID primary key.
      hash: f9191919
*/
