CREATE OR REPLACE MATERIALIZED VIEW ${catalog}.${schema}.LTE_ERC_NetAudit
AS
WITH src_e_ndr_erk_lce8_nrb AS (
  SELECT
    *
  FROM
    ${src_catalog}.${src_schema}.e_ndr_erk_lce8_nrb
),
select_26_cols AS (
  SELECT
    EDMARKET,
    MARKET,
    BAND,
    BBU_FA_CODE,
    CALL_SIGN,
    CELL_TYPE,
    CMA,
    COUNTY,
    DSS_NRCELL,
    EARFCNDL,
    EARFCNUL,
    DUTYPE,
    EUTRAN_CELL_FDD_ID,
    FACE,
    FIPS,
    LATITUDE,
    LONGITUDE,
    ON_AIR,
    REMOTE_USID,
    RRU_LIST,
    TAC,
    USID,
    REFRESH_DATE,
    DL_CH_BW,
    CONFIGUREDMAXTXPOWER,
    MAXIMUMTRANSMISSIONPOWER
  FROM
    src_e_ndr_erk_lce8_nrb
),
dedup_eutran_cell AS (
  SELECT
    * EXCEPT(_rn)
  FROM
    (
      SELECT
        *,
        ROW_NUMBER() OVER (
          PARTITION BY EUTRAN_CELL_FDD_ID
          ORDER BY EUTRAN_CELL_FDD_ID
        ) AS _rn
      FROM
        select_26_cols
    ) t
  WHERE
    _rn = 1
),
cast_fips_int AS (
  SELECT
    * EXCEPT(FIPS),
    CAST(FIPS AS INT) AS FIPS
  FROM
    dedup_eutran_cell
),
cast_fips_str AS (
  SELECT
    * EXCEPT(FIPS),
    CAST(FIPS AS STRING) AS FIPS
  FROM
    cast_fips_int
),
cast_cma_int AS (
  SELECT
    * EXCEPT(CMA),
    CAST(CMA AS INT) AS CMA
  FROM
    cast_fips_str
),
cast_cma_str AS (
  SELECT
    * EXCEPT(CMA),
    CAST(CMA AS STRING) AS CMA
  FROM
    cast_cma_int
),
cast_dlchbw_str AS (
  SELECT
    * EXCEPT(DL_CH_BW),
    CAST(DL_CH_BW AS STRING) AS DL_CH_BW
  FROM
    cast_cma_str
),
construct_geo_point AS (
  SELECT
    *,
    CONCAT('POINT(', LONGITUDE, ' ', LATITUDE, ')') AS construct_geo_point
  FROM
    cast_dlchbw_str
)
SELECT
  *
FROM
  construct_geo_point;

/*
nodes:
  src_e_ndr_erk_lce8_nrb:
    x: 100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 250b6ffa-3a8a-489a-8f19-6a9c82f7cf8d
    type: Source
    description:
      text: Source table for Ericsson LTE cell configuration data.
      hash: a1b2c3d4
  select_26_cols:
    x: 350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 0a9aa4c4-0e62-4206-bdef-eac920b5daff
    description:
      text: Select 26 relevant columns from Ericsson LTE source.
      hash: b2c3d4e5
  dedup_eutran_cell:
    x: 600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 86994f18-40a4-4a71-a78c-9b784b25bc87
    description:
      text: Remove duplicate rows based on EUTRAN_CELL_FDD_ID.
      hash: c3d4e5f6
  cast_fips_int:
    x: 850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 25acb6e4-bdce-4724-94d8-e893f635f52b
    description:
      text: Cast FIPS to integer to normalize values.
      hash: d4e5f6a7
  cast_fips_str:
    x: 1100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 0df2eaf1-2e9f-490a-b1fa-ea5ab48c8eeb
    description:
      text: Cast FIPS back to string after normalization.
      hash: e5f6a7b8
  cast_cma_int:
    x: 1350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: bc31741d-8480-4af0-a2ec-0a47443167d6
    description:
      text: Cast CMA to integer to normalize values.
      hash: f6a7b8c9
  cast_cma_str:
    x: 1600
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 5e28b1a6-6360-447e-a312-bed50a2717d0
    description:
      text: Cast CMA back to string after normalization.
      hash: a7b8c9d0
  cast_dlchbw_str:
    x: 1850
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: c016cc8d-00f8-4831-858b-ce7dc91b73f1
    description:
      text: Cast DL_CH_BW to string type.
      hash: b8c9d0e1
  construct_geo_point:
    x: 2100
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: 435079fd-e577-47ae-8458-ee002c2886a8
    description:
      text: Construct WKT geo point from latitude and longitude.
      hash: c9d0e1f2
  ${catalog}.${schema}.LTE_ERC_NetAudit:
    x: 2350
    y: 250
    dimensions:
      width: 180
      height: 95
    nodeId: cf5e4c6d-99ad-4508-a6ca-1bcb03f342e6
    type: Output
    description:
      text: LTE Ericsson Net Audit final output table.
      hash: d0e1f2a3
*/
