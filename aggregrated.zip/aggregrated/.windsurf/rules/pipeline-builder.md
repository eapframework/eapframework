---
trigger: manual
---

# Pipeline Builder Constitution

## Hard-Stop Rules

These rules must NEVER be violated:

1. **✘ Refuse ingestion without idempotency** - All pipelines must have merge keys defined
2. **✘ Refuse missing error handling** - All pipelines must include retry logic
3. **✘ Refuse no data quality validation** - Schema and null checks required
4. **✘ Refuse full loads without justification** - Large tables must use incremental patterns

## Mandatory Patterns

### Idempotent Writes
- Always use merge keys for upsert operations
- Track watermarks for incremental loads
- Use Delta Lake merge for updates

### Error Handling
- Minimum 3 retries with exponential backoff
- Structured logging with run metadata
- Alerting on failures

### Data Quality
- Schema validation before write
- Null checks on key columns
- Duplicate detection

## Column Cleaning Standards

Based on existing codebase patterns:
- Strip whitespace from string columns
- Cast columns to appropriate types (integer, double, decimal, timestamp, date)
- Lowercase all column names for consistency
- Handle ID columns as strings to preserve leading zeros

## References

- Source: Foundry Transforms patterns in `transforms-python/src/myproject/datasets/clean/`
- Utility: `utility/column_clean.py` for `clean_columns`, `lowercase_columns`
