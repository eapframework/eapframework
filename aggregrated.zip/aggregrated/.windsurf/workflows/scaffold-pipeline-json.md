---
description: Scaffold pipeline.json into multiple DataStage-ready component files based on main tags
---

# Scaffold Pipeline JSON to DataStage Files

## Trigger

**Option 1: Local File**
```
/scaffold-pipeline-json ontology/pipeline.json
```

**Option 2: API Endpoint**
```
/scaffold-pipeline-json --api <pipeline_rid>
```

---

## Input Sources

### A. Local JSON File
Provide path to a local `pipeline.json` file exported from Palantir Foundry.

### B. Palantir Foundry API

**Base URL:**
```
https://<stack>.palantirfoundry.com/api/v2
```

**Pipeline Builder Export Endpoint:**
```http
GET /ontologies/{ontologyRid}/pipelines/{pipelineRid}/export
Authorization: Bearer {FOUNDRY_TOKEN}
Content-Type: application/json
```

**Required Environment Variables:**
```bash
export FOUNDRY_STACK="your-stack"           # e.g., "mycompany"
export FOUNDRY_TOKEN="your-bearer-token"    # OAuth2 token
export FOUNDRY_ONTOLOGY_RID="ri.ontology.main.ontology.xxx"
```

**API Request Example:**
```python
import os
import requests

stack = os.environ.get('FOUNDRY_STACK')
token = os.environ.get('FOUNDRY_TOKEN')
ontology_rid = os.environ.get('FOUNDRY_ONTOLOGY_RID')
pipeline_rid = "ri.stemma..pipeline.abc123"  # from command arg

url = f"https://{stack}.palantirfoundry.com/api/v2/ontologies/{ontology_rid}/pipelines/{pipeline_rid}/export"

headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

response = requests.get(url, headers=headers)
pipeline_json = response.json()
```

**Alternative: Pipeline Builder Direct Export:**
```http
GET /stemma/api/pipelines/{pipelineRid}/export?version=latest
Authorization: Bearer {FOUNDRY_TOKEN}
```

## Purpose

Parse the Palantir Pipeline Builder JSON (from local file **or API response**) and split it into multiple component files based on the **actual main tags** found in the JSON structure. These files will be fed to Watson DataStage flow for pipeline migration.

---

## Actual JSON Structure (from pipeline.json)

```json
{
  "snapshot": {
    "transforms": [...],      // 57 transforms
    "targets": [...],         // 4 output targets
    "groups": [...],
    "groupedExpressions": [...],
    "outputs": [...],
    "arguments": [...],
    "backendSettings": {...},
    "targetSettings": {...},
    "skippedTransforms": [...],
    "samplingStrategies": {...},
    "persistedTransforms": [...]
  },
  "display": {
    "transforms": {...},      // UI positions for transforms
    "targets": {...},         // UI positions for targets
    "groups": {...},
    "datasets": [...],        // 11 input datasets
    "mediaSets": {...},
    "charts": {...},
    "sources": {...},
    "clusters": {...},
    "colorDisplayNodes": {...},
    "displayFolders": {...}
  },
  "packaging": {
    "inputDatasets": [...]    // Dataset RIDs for inputs
  },
  "availableInstalledTransforms": [...],
  "availableInstalledModels": [...],
  "availableBackendSettings": {...},
  "settings": {...},
  "mainSandbox": "..."
}
```

## Transform Types Found

| Transform Type | Count | DataStage Stage |
|---------------|-------|-----------------|
| `applyExpression` | 35 | Transformer |
| `complexLeftJoin` | 8 | Join |
| `dropDuplicates` | 4 | Remove_Duplicates |
| `filter` | 4 | Filter |
| `select` | 4 | Transformer |
| `aggregate` | 2 | Aggregator |
| **Total** | **57** | |

---

## Output File Structure

Split into `{json_dir}/datastage_scaffold/`:

```
datastage_scaffold/
│
├── 01_snapshot/
│   ├── transforms/
│   │   ├── applyExpression.json    # 35 transforms
│   │   ├── complexLeftJoin.json    # 8 joins
│   │   ├── dropDuplicates.json     # 4 dedups
│   │   ├── filter.json             # 4 filters
│   │   ├── select.json             # 4 selects
│   │   └── aggregate.json          # 2 aggregations
│   ├── targets.json                # 4 output targets
│   ├── groups.json
│   ├── groupedExpressions.json
│   ├── backendSettings.json
│   ├── targetSettings.json
│   └── persistedTransforms.json
│
├── 02_display/
│   ├── datasets.json               # 11 input datasets
│   ├── transforms_positions.json   # UI layout
│   └── targets_positions.json
│
├── 03_packaging/
│   └── inputDatasets.json          # Dataset RIDs
│
├── 04_settings/
│   ├── availableTransforms.json
│   ├── availableModels.json
│   ├── backendSettings.json
│   └── pipelineSettings.json
│
├── 05_datastage/
│   ├── sources.json                # DataStage source stages
│   ├── transformers.json           # DataStage transformer stages
│   ├── joins.json                  # DataStage join stages
│   ├── aggregators.json            # DataStage aggregator stages
│   ├── filters.json                # DataStage filter stages
│   ├── dedups.json                 # DataStage remove_duplicates stages
│   ├── targets.json                # DataStage target stages
│   └── links.json                  # DataStage stage connections
│
└── manifest.yaml                   # Index of all files
```

---

## Processing Steps

### Step 1: Extract Snapshot Transforms

Split `snapshot.transforms` by `transformId`:

```python
# Group transforms by type
transform_groups = {}
for transform in snapshot['transforms']:
    tid = transform['transformId']
    if tid not in transform_groups:
        transform_groups[tid] = []
    transform_groups[tid].append(transform)

# Write each group to separate file
for tid, transforms in transform_groups.items():
    write_json(f"01_snapshot/transforms/{tid}.json", {
        "transformType": tid,
        "count": len(transforms),
        "transforms": transforms
    })
```

### Step 2: Extract Targets

```python
# Extract output targets
targets = snapshot.get('targets', [])
write_json("01_snapshot/targets.json", {
    "count": len(targets),
    "targets": targets
})
```

### Step 3: Extract Input Datasets

```python
# From display.datasets
datasets = display.get('datasets', [])
write_json("02_display/datasets.json", {
    "count": len(datasets),
    "datasets": datasets
})
```

### Step 4: Generate DataStage Stages

For each transform type, generate DataStage-compatible stage definitions:

**applyExpression → Transformer:**
```json
{
  "stageType": "PxTransformer",
  "stageName": "tx_{id}",
  "derivations": [
    {
      "output_column": "{alias}",
      "expression": "{datastage_expression}"
    }
  ]
}
```

**complexLeftJoin → Join:**
```json
{
  "stageType": "PxJoin",
  "stageName": "join_{id}",
  "joinType": "left_outer",
  "joinKeys": ["{left_key} = {right_key}"],
  "rightColumnsKeep": [...]
}
```

**dropDuplicates → Remove_Duplicates:**
```json
{
  "stageType": "PxRemDup",
  "stageName": "dedup_{id}",
  "keyColumns": [...],
  "duplicateHandling": "Keep First"
}
```

**filter → Filter:**
```json
{
  "stageType": "PxFilter",
  "stageName": "filter_{id}",
  "whereClause": "{condition}"
}
```

**aggregate → Aggregator:**
```json
{
  "stageType": "PxAggregator",
  "stageName": "agg_{id}",
  "groupBy": [...],
  "aggregations": [
    {"output": "{col}", "function": "{func}", "input": "{source}"}
  ]
}
```

### Step 5: Generate Manifest

```yaml
pipeline_source: ontology/pipeline.json
generated_at: {timestamp}

summary:
  total_transforms: 57
  total_datasets: 11
  total_targets: 4

transform_breakdown:
  applyExpression: 35
  complexLeftJoin: 8
  dropDuplicates: 4
  filter: 4
  select: 4
  aggregate: 2

files:
  - path: 01_snapshot/transforms/applyExpression.json
    type: transforms
    count: 35
    datastage_type: Transformer
    
  - path: 01_snapshot/transforms/complexLeftJoin.json
    type: transforms
    count: 8
    datastage_type: Join
    
  # ... etc

datastage_stages:
  sources: 11
  transformers: 39
  joins: 8
  aggregators: 2
  filters: 4
  dedups: 4
  targets: 4
```

---

## DataStage Consumption Order

Feed the scaffolded files to Watson DataStage in this order:

1. **`02_display/datasets.json`** → Create **11 source stages** (PxSequentialFile)
2. **`05_datastage/transformers.json`** → Create **39 transformer stages**
3. **`05_datastage/joins.json`** → Create **8 join stages**
4. **`05_datastage/aggregators.json`** → Create **2 aggregator stages**
5. **`05_datastage/filters.json`** → Create **4 filter stages**
6. **`05_datastage/dedups.json`** → Create **4 remove_duplicates stages**
7. **`01_snapshot/targets.json`** → Create **4 target stages** (PxSequentialFile)
8. **`05_datastage/links.json`** → Wire all stages with data links

---

## Expression Mapping Reference

| Palantir Expression | DataStage Derivation |
|--------------------|---------------------|
| `cast(col, string)` | `col = (VarChar(255))In.col` |
| `cast(col, integer)` | `col = (Int32)In.col` |
| `alias(expr, name)` | `name = {expr}` |
| `column(name)` | `In.name` |
| `literal(value)` | `"value"` or `123` |
| `add(a, b)` | `In.a + In.b` |
| `concat(a, b)` | `In.a : In.b` |
| `equals(a, b)` | `In.a = In.b` |
| `isNull(col)` | `IsNull(In.col)` |
| `max(col)` | `Max(In.col)` |
| `min(col)` | `Min(In.col)` |
| `sum(col)` | `Sum(In.col)` |
| `count(col)` | `Count(In.col)` |

---

## Type Mapping Reference

| Palantir Type | DataStage Type |
|---------------|----------------|
| `string` | `VarChar(255)` |
| `integer` | `Int32` |
| `long` | `Int64` |
| `double` | `Double` |
| `float` | `Float` |
| `boolean` | `Int8` |
| `timestamp` | `Timestamp` |
| `date` | `Date` |

---

## Example Usage

### Example 1: Local File Input

```
User: /scaffold-pipeline-json ontology/pipeline.json

AI Response:
1. Reading ontology/pipeline.json...
2. Found 8 main tags: snapshot, display, packaging, availableInstalledTransforms, 
   availableInstalledModels, availableBackendSettings, settings, mainSandbox
3. Extracting 57 transforms (6 types)...
4. Extracting 11 input datasets...
5. Extracting 4 output targets...
6. Generating DataStage stage definitions...
7. Writing 25 files to ontology/datastage_scaffold/
8. Generated manifest.yaml

Output: ontology/datastage_scaffold/
├── 01_snapshot/ (7 files)
├── 02_display/ (3 files)
├── 03_packaging/ (1 file)
├── 04_settings/ (4 files)
├── 05_datastage/ (8 files)
└── manifest.yaml

Ready for Watson DataStage import.
```

### Example 2: API Input

```
User: /scaffold-pipeline-json --api ri.stemma..pipeline.abc123

AI Response:
1. Fetching pipeline from Palantir Foundry API...
   Stack: mycompany.palantirfoundry.com
   Pipeline RID: ri.stemma..pipeline.abc123
2. API Response: 200 OK (245 KB)
3. Found 8 main tags: snapshot, display, packaging, availableInstalledTransforms, 
   availableInstalledModels, availableBackendSettings, settings, mainSandbox
4. Extracting 57 transforms (6 types)...
5. Extracting 11 input datasets...
6. Extracting 4 output targets...
7. Generating DataStage stage definitions...
8. Writing 25 files to datastage_scaffold/
9. Generated manifest.yaml

Output: datastage_scaffold/
├── 01_snapshot/ (7 files)
├── 02_display/ (3 files)
├── 03_packaging/ (1 file)
├── 04_settings/ (4 files)
├── 05_datastage/ (8 files)
└── manifest.yaml

Ready for Watson DataStage import.
```

---

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| `401 Unauthorized` | Invalid or expired token | Refresh `FOUNDRY_TOKEN` |
| `403 Forbidden` | No access to pipeline | Check pipeline permissions |
| `404 Not Found` | Invalid pipeline RID | Verify `pipeline_rid` format |
| `Connection Error` | Network/firewall issue | Check VPN or proxy settings |
| `JSON Decode Error` | Malformed response | Check API version compatibility |
