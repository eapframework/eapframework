---
description: Generic ingest archetype for any datasource to Raw zone (no transforms)
---

# Ingest to Raw (Generic)

## Goal
Create a reusable PySpark ingest archetype that reads data from a datasource
(connection-driven and fully configurable) and writes
**schema-preserving raw Parquet files** to the Raw zone.

This workflow is intentionally minimal and scalable:
- No assumptions about source systems
- No hard-coded connectors
- No transformations beyond optional incremental filtering

The same archetype must support **hundreds or thousands of connection variants**
without code changes.

---

## Output Contract
All ingests must write to:

raw/<dataset_name>/


- Format: **Parquet**
- Schema: source-defined (unchanged)
- Metadata columns are appended only

### Required Metadata Columns
- `_ingested_at` — ingestion timestamp
- `_source_system` — logical source system name

---

## Rules (Strict)
- NO joins
- NO column renames
- NO filters except watermark for incremental loads
- NO business logic
- Preserve source schema exactly (metadata columns appended only)

This workflow is **Raw ingestion only**.

---

## Connector Model (Open-Ended)

This archetype must not enumerate individual systems
(Snowflake, Oracle, Postgres, etc.).

Instead, it uses **adapter families** and configuration passthrough.

### Adapter Families

#### jdbc
Generic JDBC reader supporting:
- Snowflake
- Oracle
- Postgres
- SQL Server
- DB2
- MySQL
- Teradata
- Any JDBC-compliant system

#### spark_reader
Spark-native file readers:
- Parquet
- CSV
- JSON
- Avro
- Delta
- ADLS / S3 / GCS

#### custom
Reserved for sources requiring specialized logic:
- Kafka
- REST APIs
- SaaS connectors

New systems must be onboarded via configuration only — never code.

---

## Inputs (Configuration)

### Source
```yaml
source:
  adapter: jdbc | spark_reader | custom
  system: "<logical_source_system_name>"
  connection:
    name: "<connection_name>"          # or inline connection properties
    options: {}                        # arbitrary connector options
  read:
    mode: table | query | path
    table: "<db.schema.table>"         # when mode=table
    query: "<select_query>"            # when mode=query
    path: "<storage_path>"             # when mode=path
    options: {}                        # reader-specific options
    partitioning:                     # optional (mainly JDBC)
      enabled: false
      column: ""
      lower_bound: null
      upper_bound: null
      num_partitions: 8
Load
load:
  type: full | incremental
  watermark_column: ""                # required for incremental
  start_value: null                   # optional
Rules:

If type = incremental, apply watermark filtering

If watermark information is missing, behave as full load

Target
target:
  raw_base_path: "abfss://raw@<storage>.dfs.core.windows.net"
  dataset_name: "<dataset_name>"
  file_format: parquet
  write_mode: append | overwrite
  options: {}
Final output path:

<raw_base_path>/raw/<dataset_name>/
Incremental Load Semantics
If incremental loading is enabled, apply only the following filter:

watermark_column >= start_value
No other filtering or conditions are allowed.

Scalability Guarantee
This workflow must not contain any source-specific logic.

All system differences (URLs, drivers, credentials, options, partitioning)
must be supplied through configuration.

New source systems must be supported without modifying:

this workflow

ingest code

pipeline_builder logic

Generated Artifacts
This workflow generates files only under:

generated/ingest_raw/
Required files:

ingest_raw.py

config.py

README.md

Do NOT modify existing pipeline_builder files.

Ownership
This file defines the Raw ingestion contract.
All downstream pipelines must assume:

Raw data is untouched

Schema is source-defined

Metadata columns are always present


---
