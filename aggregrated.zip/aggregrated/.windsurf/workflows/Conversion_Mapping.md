---
description: Palantir pipeline.json parsing specification for extracting inputs, schemas, transforms, and outputs
---

# Palantir Pipeline.json Parsing Specification

This spec describes how to extract inputs, schemas, transforms, and outputs from a Palantir Pipeline Builder `pipeline.json` file.

---

## Pipeline Root Configuration

```yaml
json_file: pipeline.json
transforms_path: $.snapshot.transforms[*]
```

---

## 1. Input Sources

### Dataset References (by Foundry RID)

Datasets referenced directly by Foundry RID, and transform outputs that act as inputs to later steps.

| Path Type | JSONPath |
|-----------|----------|
| Dataset RID | `$.snapshot.transforms[*].arguments.dataset.primitive.dataset.rid` |
| Transform Output (dataset) | `$.snapshot.transforms[*].arguments.dataset.primitive.transformOutput.id` |
| Transform Output (left) | `$.snapshot.transforms[*].arguments.left.primitive.transformOutput.id` |
| Transform Output (right) | `$.snapshot.transforms[*].arguments.right.primitive.transformOutput.id` |

---

## 2. Column Expressions & Schema

Column aliases and types inferred from `columnExpression` / `cast` expressions.

### Primary Expression Mapping

**Array Path:** `$.snapshot.transforms[*].arguments.expression.primitive.expression.columnExpression`

| Field | JSONPath |
|-------|----------|
| `transform_id` | `^.id` |
| `expression_kind` | `$.expressionId` |
| `source_column` | `$.arguments.expression.primitive.expression.column.columnName` |
| `alias` | `$.arguments.alias.primitive.literal.string.value` |

### Nested Expression Mapping (Cast)

**Array Path:** `$.snapshot.transforms[*].arguments.expression.primitive.expression.columnExpression.arguments.expression.primitive.expression.columnExpression`

| Field | JSONPath |
|-------|----------|
| `transform_id` | `^.^.id` |
| `expression_kind` | `$.expressionId` |
| `source_column` | `$.arguments.expression.primitive.expression.column.columnName` |
| `target_type` | `$.arguments.type.primitive.typeParam.type.type` |

---

## 3. Transform Inventory

High-level list of all transforms, their type, and their primary inputs.

**Array Path:** `$.snapshot.transforms[*]`

| Field | JSONPath |
|-------|----------|
| `transform_id` | `$.id` |
| `transform_type` | `$.transformId` |
| `from_dataset_rid` | `$.arguments.dataset.primitive.dataset.rid` |
| `from_transform_output` | `$.arguments.dataset.primitive.transformOutput.id` |
| `version_major` | `$.transformVersion.major` |

---

## 4. Join Transforms

Join steps, including left/right inputs and join conditions.

**Array Path:** `$.snapshot.transforms[*]`
**Filter:** `$.transformId == "join"` or `$.transformId == "complexLeftJoin"`

### Join Fields

| Field | JSONPath |
|-------|----------|
| `join_transform_id` | `$.id` |
| `left_input_transform` | `$.arguments.left.primitive.transformOutput.id` |
| `right_input_dataset_rid` | `$.arguments.right.primitive.dataset.rid` |
| `join_condition_expression` | `$.arguments.joinCondition.primitive.expression` |

### Join Conditions Array

**Array Path:** `$.arguments.joinCondition.primitive.expression.columnExpression.arguments.conditions.composite.list.elements[*]`

| Field | JSONPath |
|-------|----------|
| `left_column` | `$.expression.columnExpression.arguments.left.primitive.expression.column.columnName` |
| `right_column` | `$.expression.columnExpression.arguments.right.primitive.expression.column.columnName` |

---

## 5. DropDuplicates Transforms

`dropDuplicates` transforms and the columns used for de-duplication.

**Array Path:** `$.snapshot.transforms[*]`
**Filter:** `$.transformId == "dropDuplicates"`

### Transform Fields

| Field | JSONPath |
|-------|----------|
| `transform_id` | `$.id` |
| `input_transform_output` | `$.arguments.dataset.primitive.transformOutput.id` |

### Dedup Columns Array

**Array Path:** `$.arguments.columns.composite.set.elements[*]`

| Field | JSONPath |
|-------|----------|
| `column_name` | `$.column.columnName` |

---

## 6. Pipeline Outputs

Pipeline outputs mapping to target datasets.

**Array Path:** `$.snapshot.outputs[*]`

| Field | JSONPath |
|-------|----------|
| `output_id` | `$.id` |
| `source_transform` | `$.sourceTransformId` |
| `output_dataset_rid` | `$.datasetRid` |

---

## Usage

This specification is meant as a starting point for building a parser:

1. Read each section's `array_path` definition
2. Apply the `json_path` mappings against `pipeline.json`
3. Write out structured tables (CSV, JSON, or database) for:
   - **Inputs** - Source datasets and transform dependencies
   - **Schema** - Column names, types, and aliases
   - **Transforms** - Transform inventory with types and versions
   - **Joins** - Join conditions and linked inputs
   - **Outputs** - Final output dataset mappings

### Example Parser Pseudocode

```python
import json
from jsonpath_ng import parse

def extract_transforms(pipeline_json):
    transforms_path = parse("$.snapshot.transforms[*]")
    return [match.value for match in transforms_path.find(pipeline_json)]

def extract_joins(transforms):
    return [t for t in transforms if t.get('transformId') in ('join', 'complexLeftJoin')]

def extract_outputs(pipeline_json):
    outputs_path = parse("$.snapshot.outputs[*]")
    return [match.value for match in outputs_path.find(pipeline_json)]
```
