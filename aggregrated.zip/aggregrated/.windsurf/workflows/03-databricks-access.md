---
description: Databricks access archetype (auth, connectivity, and workspace basics)
---

# Databricks Access

Establish and validate access to a Databricks workspace for local development,
notebook upload, and job execution. This archetype is focused on **authentication
and connectivity** only, not pipeline generation.

## Input

**Required**: Workspace host URL and a method of authentication.

Examples:
```
/databricks-access host: https://adb-1234567890123456.7.azuredatabricks.net, auth: token
```

```
/databricks-access host: https://adb-1234567890123456.7.azuredatabricks.net, auth: azure-cli
```

## Execution Steps

### 1. Parse Input
Extract from $ARGUMENTS:
- **host**: Databricks workspace URL
- **auth**: `token` | `azure-cli`
- **profile**: Databricks CLI profile name (optional)

If any required values are missing, request them.

### 2. Validate Environment
Confirm required tooling exists:
- `python` or `python3`
- Databricks CLI (`databricks`)

If CLI is missing, provide install command:
```
pip install databricks-cli
```

### 3. Configure Authentication

#### Option A: Token Auth (Recommended for CI)
Instructions:
```
databricks configure --token
```
Prompts for:
- Host
- Token

#### Option B: Azure CLI Auth (Interactive)
Instructions:
```
az login
databricks configure --aad-token
```
Prompts for:
- Host

### 4. Test Connectivity
Run a simple CLI check:
```
databricks workspace list /
```
Expected: a list of top-level workspace items.

### 5. Optional: Set Default Profile
If a profile name was provided:
```
databricks configure --profile <profile_name> --token
```
Then verify:
```
databricks workspace list / --profile <profile_name>
```

### 6. Optional: Validate DBFS Access
```
databricks fs ls dbfs:/
```
Expected: DBFS root listing.

### 7. Report Completion
Report:
- Host
- Auth method
- CLI profile (if set)
- Workspace connectivity status
- DBFS access status (if tested)

## Guardrails
- Never store tokens in repo files.
- Never commit `.databrickscfg` to source control.
- Prefer environment variables or CLI profile configuration.

## Examples

**Token Auth**:
```
/databricks-access host: https://adb-1234567890123456.7.azuredatabricks.net, auth: token
```

**Azure CLI Auth**:
```
/databricks-access host: https://adb-1234567890123456.7.azuredatabricks.net, auth: azure-cli
```

**With Profile**:
```
/databricks-access host: https://adb-1234567890123456.7.azuredatabricks.net, auth: token, profile: dev
```

## References
- Databricks CLI docs: https://docs.databricks.com/dev-tools/cli/
- Azure CLI login: https://learn.microsoft.com/cli/azure/authenticate-azure-cli
