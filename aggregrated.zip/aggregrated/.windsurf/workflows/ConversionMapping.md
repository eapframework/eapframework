# Pipeline to DataStage Transform Mapping Reference

## Transform Type Mappings

This document provides detailed mappings between pipeline transform types and DataStage stage types, including property conversions and configuration guidance.

---

## 1. applyExpression → PxTransformer (Transformer Stage)

### Purpose
Applies column expressions, type casts, and aliases to data.

### DataStage Configuration

**Stage Type**: PxTransformer (Transformer)

**Key Properties**:
- Input Link: Single input link from upstream stage
- Output Link: Single output link to downstream stage
- Derivations: Column expressions and transformations

### Conversion Details

#### Expression Types Handled:
1. **Cast Operations**
   - Pipeline: `cast(column, type)`
   - DataStage: Derivation with type conversion
   - Example: `StringToDecimal(column_name)`

2. **Alias Operations**
   - Pipeline: `alias(expression, "new_name")`
   - DataStage: Derivation with output column name
   - Example: Output column = "new_name", Derivation = expression

3. **Column References**
   - Pipeline: `column.columnName`
   - DataStage: Input column reference
   - Example: `InputLink.column_name`

### Manual Configuration Required:
- [ ] Define derivation expressions for each output column
- [ ] Set data types and lengths for derived columns
- [ ] Configure nullable properties
- [ ] Add descriptions for complex expressions
- [ ] Test expression logic with sample data

### Example Mapping:
```
Pipeline Transform:
{
  "transformId": "applyExpression",
  "arguments": {
    "expression": {
      "type": "cast",
      "column": "cma",
      "targetType": "string"
    }
  }
}

DataStage Stage:
Stage: Transformer_1
  Input: DSLink (from previous stage)
  Output: DSLink (to next stage)
  Derivations:
    - Column: cma
      Type: VarChar(255)
      Derivation: InputLink.cma
      Nullable: Yes
```

---

## 2. filter → PxTransformer (Transformer Stage with Constraints)

### Purpose
Filters rows based on specified conditions.

### DataStage Configuration

**Stage Type**: PxTransformer (Transformer)

**Key Properties**:
- Input Link: Single input link
- Output Link: Single output link
- Constraints: Filter conditions

### Conversion Details

#### Filter Condition Mapping:
- Pipeline filter conditions → DataStage constraint expressions
- Rows meeting constraint pass through
- Rows failing constraint are dropped

### Manual Configuration Required:
- [ ] Define constraint expression in DataStage syntax
- [ ] Set constraint name and description
- [ ] Configure output link for passed rows
- [ ] Optionally add reject link for failed rows
- [ ] Test filter logic with sample data

### Example Mapping:
```
Pipeline Transform:
{
  "transformId": "filter",
  "arguments": {
    "filterCondition": {
      "expression": "column > 100"
    }
  }
}

DataStage Stage:
Stage: Transformer_Filter_1
  Input: DSLink
  Output: DSLink (passed rows)
  Constraints:
    - Name: FilterCondition
      Expression: InputLink.column > 100
      Description: Filter rows where column > 100
```

---

## 3. select → PxTransformer (Transformer Stage with Column Mapping)

### Purpose
Selects specific columns from the input dataset.

### DataStage Configuration

**Stage Type**: PxTransformer (Transformer)

**Key Properties**:
- Input Link: Single input link
- Output Link: Single output link with selected columns only
- Column Mappings: Direct pass-through for selected columns

### Conversion Details

#### Column Selection:
- Only specified columns are mapped to output
- Column order can be rearranged
- Column names can be renamed

### Manual Configuration Required:
- [ ] Map each selected column from input to output
- [ ] Verify column data types
- [ ] Set column order as needed
- [ ] Add column descriptions
- [ ] Remove any unwanted columns

### Example Mapping:
```
Pipeline Transform:
{
  "transformId": "select",
  "arguments": {
    "columns": ["col1", "col2", "col3"]
  }
}

DataStage Stage:
Stage: Transformer_Select_1
  Input: DSLink
  Output: DSLink
  Column Mappings:
    - col1 → col1 (pass-through)
    - col2 → col2 (pass-through)
    - col3 → col3 (pass-through)
```

---

## 4. complexLeftJoin → PxJoin (Join Stage)

### Purpose
Performs left outer join between two datasets.

### DataStage Configuration

**Stage Type**: PxJoin (Join)

**Key Properties**:
- Left Input Link: Primary dataset
- Right Input Link: Lookup dataset
- Join Type: Left Outer
- Join Keys: Columns to join on
- Output Link: Combined result

### Conversion Details

#### Join Configuration:
1. **Join Type**: Left Outer (all rows from left, matching rows from right)
2. **Join Keys**: Columns used for matching
3. **Column Selection**: Which columns to keep from each side

### Manual Configuration Required:
- [ ] Define join key columns for left input
- [ ] Define join key columns for right input
- [ ] Select columns to keep from left input
- [ ] Select columns to keep from right input
- [ ] Configure null handling for non-matching rows
- [ ] Set partitioning and sorting for performance
- [ ] Test join logic with sample data

### Example Mapping:
```
Pipeline Transform:
{
  "transformId": "complexLeftJoin",
  "arguments": {
    "left": "dataset1",
    "right": "dataset2",
    "joinCondition": "left.key = right.key",
    "leftColumnsToKeep": ["col1", "col2"],
    "rightColumnsToKeep": ["col3", "col4"]
  }
}

DataStage Stage:
Stage: Join_1
  Left Input: DSLink_Left
  Right Input: DSLink_Right
  Join Type: Left Outer
  Join Keys:
    - Left: key
    - Right: key
  Output: DSLink
  Columns:
    From Left: col1, col2, key
    From Right: col3, col4
```

---

## 5. aggregate → PxAggregator (Aggregator Stage)

### Purpose
Groups data and performs aggregation calculations.

### DataStage Configuration

**Stage Type**: PxAggregator (Aggregator)

**Key Properties**:
- Input Link: Single input link
- Output Link: Aggregated results
- Grouping Keys: Columns to group by
- Aggregations: Calculations to perform

### Conversion Details

#### Aggregation Functions:
- COUNT → Count()
- SUM → Sum()
- AVG → Avg()
- MIN → Min()
- MAX → Max()
- FIRST → First()
- LAST → Last()

### Manual Configuration Required:
- [ ] Define grouping key columns
- [ ] Configure aggregation functions for each column
- [ ] Set output column names
- [ ] Configure data types for aggregated columns
- [ ] Set partitioning for performance
- [ ] Test aggregation logic with sample data

### Example Mapping:
```
Pipeline Transform:
{
  "transformId": "aggregate",
  "arguments": {
    "groupByColumns": ["region", "category"],
    "aggregations": [
      {"function": "sum", "column": "sales", "alias": "total_sales"},
      {"function": "count", "column": "*", "alias": "record_count"}
    ]
  }
}

DataStage Stage:
Stage: Aggregator_1
  Input: DSLink
  Output: DSLink
  Grouping Keys:
    - region
    - category
  Aggregations:
    - Column: sales
      Function: Sum
      Output: total_sales
      Type: Decimal(18,2)
    - Column: *
      Function: Count
      Output: record_count
      Type: Integer
```

---

## 6. dropDuplicates → PxRemoveDuplicates (Remove Duplicates Stage)

### Purpose
Removes duplicate records based on key columns.

### DataStage Configuration

**Stage Type**: PxRemoveDuplicates (Remove Duplicates)

**Key Properties**:
- Input Link: Single input link
- Output Link: Deduplicated records
- Key Columns: Columns that define uniqueness
- Keep: First or Last occurrence

### Conversion Details

#### Deduplication Logic:
- Records with same key column values are considered duplicates
- Can keep first or last occurrence
- Requires sorted input for best performance

### Manual Configuration Required:
- [ ] Define key columns for uniqueness
- [ ] Choose whether to keep first or last occurrence
- [ ] Configure sorting on key columns (for performance)
- [ ] Set partitioning strategy
- [ ] Test deduplication logic with sample data

### Example Mapping:
```
Pipeline Transform:
{
  "transformId": "dropDuplicates",
  "arguments": {
    "columns": ["id", "date"]
  }
}

DataStage Stage:
Stage: RemoveDuplicates_1
  Input: DSLink (sorted by id, date)
  Output: DSLink
  Key Columns:
    - id
    - date
  Keep: First
  Duplicate Handling: Drop
```

---

## Data Type Mappings

### Pipeline to DataStage Type Conversion

| Pipeline Type | DataStage Type | Notes |
|--------------|----------------|-------|
| string | VarChar | Default length: 255 |
| integer | Integer | 32-bit signed integer |
| long | BigInt | 64-bit signed integer |
| double | Double | 64-bit floating point |
| decimal | Decimal(p,s) | Precision and scale configurable |
| boolean | TinyInt | 0 = false, 1 = true |
| date | Date | Date only, no time |
| timestamp | Timestamp | Date and time |
| binary | Raw | Binary data |

### Type Conversion Functions

| Conversion | DataStage Function |
|-----------|-------------------|
| String to Integer | StringToInt32() |
| String to Decimal | StringToDecimal() |
| String to Date | StringToDate() |
| Integer to String | Int32ToString() |
| Date to String | DateToString() |
| Decimal to String | DecimalToString() |

---

## Performance Optimization Guidelines

### Partitioning Strategies
1. **Hash Partitioning**: For joins and aggregations on key columns
2. **Range Partitioning**: For sorted data operations
3. **Round Robin**: For even distribution without specific key
4. **Same**: Maintain partitioning from previous stage

### Sorting Considerations
1. Sort before joins on join keys
2. Sort before aggregations on grouping keys
3. Sort before remove duplicates on key columns
4. Use stable sort for maintaining order

### Best Practices
- Minimize data movement between stages
- Use appropriate partitioning for parallel processing
- Configure buffer sizes for large datasets
- Enable runtime column propagation where appropriate
- Use dataset stages for intermediate persistence

---

## Validation Checklist

After conversion, validate each stage:

### For All Stages:
- [ ] Stage name is descriptive
- [ ] Input/output links are connected
- [ ] Column metadata is complete
- [ ] Data types are appropriate
- [ ] Nullable flags are set correctly

### For Transformer Stages:
- [ ] All derivations are defined
- [ ] Expressions are syntactically correct
- [ ] Constraints are properly configured
- [ ] Column mappings are complete

### For Join Stages:
- [ ] Join type is correct (Left Outer)
- [ ] Join keys are defined for both inputs
- [ ] Column selection is appropriate
- [ ] Partitioning is configured

### For Aggregator Stages:
- [ ] Grouping keys are defined
- [ ] Aggregation functions are correct
- [ ] Output column names are set
- [ ] Data types for aggregations are appropriate

### For Remove Duplicates Stages:
- [ ] Key columns are defined
- [ ] Keep first/last is configured
- [ ] Input is sorted on key columns

---

## Common Issues and Solutions

### Issue: Expression Syntax Errors
**Solution**: Review DataStage expression syntax and convert pipeline expressions accordingly

### Issue: Join Performance Problems
**Solution**: Ensure proper partitioning and sorting on join keys

### Issue: Aggregation Incorrect Results
**Solution**: Verify grouping keys and aggregation functions

### Issue: Type Conversion Failures
**Solution**: Add explicit type conversion functions in derivations

### Issue: Null Handling
**Solution**: Use NullToValue() or IsNull() functions as needed

---

## Additional Resources

- IBM DataStage Parallel Job Developer's Guide
- DataStage Transformer Stage Reference
- DataStage Join Stage Reference
- DataStage Aggregator Stage Reference
- DataStage Functions and Operators Reference

---

*Document Version: 1.0*
*Last Updated: 2026-01-30*