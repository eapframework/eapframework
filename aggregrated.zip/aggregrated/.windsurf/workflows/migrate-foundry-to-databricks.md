---
description: End-to-end Foundry to Databricks migration - converts Python and Java pipelines
---

# Migrate Foundry to Databricks

Complete end-to-end workflow to convert all Foundry Transform code (Python and Java) to Databricks-ready PySpark pipelines.

## Input

**Required**: Source directories for Python and Java Foundry code
```
/migrate-foundry-to-databricks
```

## Output Folders

All converted code is saved to separate output folders:

| Source | Output Folder |
|--------|--------------|
| Python Transforms | `databricks/pipelines/python_converted/` |
| Java Transforms | `databricks/pipelines/java_converted/` |
| Shared Utilities | `databricks/pipelines/utils/` |

## Execution Steps

### Phase 1: Load Configuration

Read shared configuration files:
```
.cdo-aifc/templates/03-data-engineering/pipeline-builder/env-config.yaml
.cdo-aifc/data/rid_mapping.csv
.cdo-aifc/memory/archetypes/03-data-engineering/pipeline-builder-constitution.md
```

### Phase 2: Python Transforms Migration

**Source:** `Snowflake-DIY-NETAUDIT-Python/transforms-python/src/`

#### 2.1 Discover Python Files
```bash
# Find all Foundry Transform Python files
find Snowflake-DIY-NETAUDIT-Python/transforms-python/src -name "*.py" -type f
```

#### 2.2 Convert Each Python File
For each `.py` file found:
```
/scaffold-ingest <path_to_python_file>
```

**Conversion steps per file:**
1. Parse `@transform` decorator for Input/Output RIDs
2. Look up dataset names in `rid_mapping.csv`
3. Extract transformation logic and column configs
4. Generate PySpark pipeline with `main(spark)` entry point
5. Save to `databricks/pipelines/python_converted/{dataset_name}_pipeline.py`

#### 2.3 Generate Shared Utilities
Copy utility functions to shared location:
```
databricks/pipelines/utils/column_clean.py
databricks/pipelines/utils/__init__.py
```

### Phase 3: Java Transforms Migration

**Source:** `pipeline_builder/transforms-java/src/main/java/`

#### 3.1 Discover Java Pipeline Files
Look for the three-file pattern:
- `PipelineComputeTransform.java` - Inputs
- `PipelineOutputs.java` - Outputs
- `PipelineLogic.java` - Transformations

#### 3.2 Convert Java Pipeline
```
/transform-pipeline-java pipeline_builder/transforms-java/src/main/java
```

**Conversion steps:**
1. Parse `@Input` annotations from `PipelineComputeTransform.java`
2. Parse `Dataset<Row>` fields from `PipelineOutputs.java`
3. Convert Java Spark logic from `PipelineLogic.java` to PySpark
4. Generate Databricks notebook with 6 cells
5. Save to `databricks/pipelines/java_converted/`

### Phase 4: Generate Databricks Jobs

Create job configurations for all converted pipelines:

```
databricks/jobs/python_pipelines/
databricks/jobs/java_pipelines/
```

### Phase 5: Validation

Validate all converted pipelines against constitution rules:
- ✓ Idempotent write patterns
- ✓ Error handling included
- ✓ Type casting preserved
- ✓ Column cleaning applied
- ✓ Logging implemented

### Phase 6: Generate Summary Report

Output migration summary:
```
databricks/migration_report.md
```

Contents:
- Total files converted (Python + Java)
- Input/output path mappings
- Dependencies noted
- Validation results

## Detailed Workflow

### Step 1: Setup Output Directories
```python
# Create output directories
output_dirs = [
    "databricks/pipelines/python_converted",
    "databricks/pipelines/java_converted",
    "databricks/pipelines/utils",
    "databricks/jobs/python_pipelines",
    "databricks/jobs/java_pipelines"
]
```

### Step 2: Batch Convert Python Files
```python
python_source = "Snowflake-DIY-NETAUDIT-Python/transforms-python/src"
python_output = "databricks/pipelines/python_converted"

# For each .py file in source:
#   1. Run /scaffold-ingest workflow
#   2. Save output to python_output/{name}_pipeline.py
#   3. Generate job config
```

### Step 3: Convert Java Pipeline
```python
java_source = "pipeline_builder/transforms-java/src/main/java"
java_output = "databricks/pipelines/java_converted"

# Run /transform-pipeline-java workflow
# Save output to java_output/netaudit_pipeline.py
# Generate job config
```

### Step 4: Copy Shared Utilities
```python
# Copy column_clean.py to utils folder
# Generate __init__.py for imports
```

## Configuration

### ADLS Paths (from env-config.yaml)
```yaml
sources:
  adls:
    account: "abfss://otis-poc@datalakeeastus2prd.dfs.core.windows.net"

targets:
  adls:
    account: "abfss://otis-poc@datalakeeastus2prd.dfs.core.windows.net"
```

### TABLE_TO_FOLDER_MAPPING
```python
# Case-sensitive ADLS folder names - verify in ADLS
TABLE_TO_FOLDER_MAPPING = {
    "x_ndr_nokia_enb": "x_ndr_nokia_enb",
    "levo_site_master_brd": "LEVO/LEVO_SITE_MASTER_BRD",
    "fips_peas_cmas_table1": "FIPS_PEAs_CMAs_Table1",
    "x_eric_5gnr_cell_rrh": "x_eric_5gnr_cell_rrh",
    "x_nok_5gnr_cell_rrh": "x_nok_5gnr_cell_rrh",
    # ... add more as discovered
}
```

## Expected Output Structure

```
databricks/
├── pipelines/
│   ├── python_converted/
│   │   ├── x_site_general_info_pipeline.py
│   │   ├── x_eric_5gnr_cell_rrh_pipeline.py
│   │   ├── x_nok_5gnr_bbu_pipeline.py
│   │   └── ...
│   ├── java_converted/
│   │   └── netaudit_pipeline.py
│   └── utils/
│       ├── __init__.py
│       └── column_clean.py
├── jobs/
│   ├── python_pipelines/
│   │   ├── x_site_general_info_job.json
│   │   └── ...
│   └── java_pipelines/
│       └── netaudit_job.json
└── migration_report.md
```

## Usage Examples

**Run full migration:**
```
/migrate-foundry-to-databricks
```

**Run only Python migration:**
```
/scaffold-ingest Snowflake-DIY-NETAUDIT-Python/transforms-python/src --batch
```

**Run only Java migration:**
```
/transform-pipeline-java pipeline_builder/transforms-java/src/main/java
```

## Dependencies

| Workflow | Purpose |
|----------|---------|
| `/scaffold-ingest` | Converts Python Foundry transforms |
| `/transform-pipeline-java` | Converts Java Foundry transforms |

## Configuration Files

| File | Purpose |
|------|---------|
| `env-config.yaml` | ADLS connection config |
| `rid_mapping.csv` | RID to dataset name mapping |
| `pipeline-builder-constitution.md` | Hard-stop validation rules |

## Post-Migration Checklist

- [ ] Verify all Python files converted
- [ ] Verify Java pipeline converted
- [ ] Check ADLS paths are correct
- [ ] Validate TABLE_TO_FOLDER_MAPPING
- [ ] Test one pipeline in Databricks
- [ ] Upload utils to Databricks workspace
- [ ] Create Databricks jobs from JSON configs
