---
description: Palantir → Databricks automated migration - Fetch transform code and generate production notebooks
---

# Palantir to Databricks Migration

**Automated 4-step migration**: Read dataset list from manifest, fetch real transform code from Palantir, convert to Databricks PySpark notebooks, ready to upload and run.

## ⭐ Configuration

**NO HARDCODING.** All datasets defined in single manifest file:

```yaml
.windsurf/workflows/palantir-migration-manifest.yaml
```

See [HOW_TO_ADD_DATASETS.md](HOW_TO_ADD_DATASETS.md) to add/modify/enable/disable datasets.

---

## Invocation

### Simple mode (run all enabled datasets)
```
/palantir-to-databricks-migrate
```

### With custom manifest (future enhancement)
```
/palantir-to-databricks-migrate manifest: .windsurf/workflows/palantir-migration-manifest-prod.yaml
```

---

## Execution Steps

### Step 1: Load Configuration
- Read `palantir-migration-manifest.yaml` 
- Get list of enabled datasets (name, RIDs, merge keys, etc.)
- Validate manifest syntax

**Output**: Manifest loaded, N datasets to process

### Step 2: Load Credentials
- Read `.env` file for Palantir credentials (`PALANTIR_KEY`, `PALANTIR_HOST`)
- Read Databricks credentials (optional, `DATABRICKS_TOKEN`, `DATABRICKS_URL`)
- Validate connectivity to Palantir

**Output**: Connection established ✓

---

### Step 3: For Each Dataset in Manifest
**a) Fetch Transform Code from Palantir**
- Use dataset RID from manifest to locate transform
- Call Palantir API to download Python code
- Save original code for audit trail (if enabled)
- Skip if not enabled in manifest

**Output**: `{dataset_name}_palantir_original.py`

**b) Convert to Databricks Format**
- Parse Foundry Python syntax (decorators, Input/Output, etc.)
- Convert to Databricks PySpark equivalents
- Add ADLS Gen2 paths (from manifest)
- Add Databricks-specific functions (spark.read, spark.write, etc.)
- Generate complete, runnable notebook

**Conversion Mapping**:
```
Foundry @transform            → Databricks def transform
Input/Output decorators       → DataFrame parameters
write_dataframe()             → spark.write.format("delta")
Foundry utilities             → PySpark equivalents
```

**Output**: `{dataset_name}_databricks.py` (Databricks notebook)

---

### Step 4: Generate Summary
- List all generated notebooks
- Show file paths and sizes
- Display deployment instructions
- Optional: Generate Databricks CLI upload commands

**Output**: Summary report

---

## Output Contract

### Generated Files (in `scripts/output/demo/`)

For each dataset, you get TWO files:

**Original Palantir Code**:
```
{dataset_name}_palantir_original.py
```
- Exact code from Palantir (for audit/comparison)
- Preserves original logic

**Production Databricks Notebook**:
```
{dataset_name}_databricks.py
```
- Complete, runnable Databricks notebook
- Includes markdown documentation
- Configuration section with ADLS paths
- Transform logic (adapted from Palantir)
- Execution code (read → transform → write)
- Validation section

**Example structure** (databricks.py):
```python
# Databricks notebook source
# MAGIC %md
# MAGIC # Transform: x_site_general_info
# MAGIC **Migrated from Palantir Foundry**

# COMMAND ----------
# Configuration (ADLS paths, cluster settings)

# COMMAND ----------
# Original transform logic (adapted)

# COMMAND ----------
# Execution (read from ADLS, transform, write)

# COMMAND ----------
# Validation (count records, schema check)
```

---

## Steps to Deploy

### Manual Upload (Fastest)
```bash
# 1. Open Databricks workspace
# 2. Click Workspace → Import Notebook
# 3. Choose {dataset_name}_databricks.py
# 4. Select folder: /Shared/palantir-migration/
# 5. Click Import

# 6. Click notebook → Run → Run All
# 7. Wait for completion
```

### CLI Upload (Automated)
```bash
databricks workspace import \
  scripts/output/demo/{dataset_name}_databricks.py \
  /Shared/palantir-migration/{dataset_name}_databricks \
  --language PYTHON \
  --format SOURCE
```

### Create Job (Production)
```bash
databricks jobs create \
  --name "palantir-{dataset_name}-migration" \
  --new-cluster '{"spark_version":"13.3.x-scala2.12","node_type_id":"Standard_DS3_v2","num_workers":2}' \
  --notebook-task "{\"notebook_path\":\"/Shared/palantir-migration/{dataset_name}_databricks\"}" \
  --timeout-seconds 3600
```

---

## Execution

### Via Windsurf Chat
```
/palantir-to-databricks-migrate
```

Uses default datasets (x_site_general_info + X_ERIC_5GNR_CELL_RRH)

### Via CLI Script (Alternative)
```powershell
cd H:\DEEP\apm0047153-deep-otis
python scripts\otis_demo.py
```

---

## Validation

After generation, verify:

✅ **Files created**: Check `scripts/output/demo/` has 4 files (2 original + 2 databricks)

✅ **Syntax valid**: Open `_databricks.py` in VS Code → should have syntax highlighting

✅ **Notebooks ready**: Try uploading one to Databricks and running

✅ **Logic preserved**: Compare `_palantir_original.py` with `_databricks.py` - core logic should match

---

## Error Handling

### "Could not connect to Palantir"
- Check `.env` has `PALANTIR_KEY` set
- Verify internet connection to `paloma.palantirfoundry.com`
- Regenerate token if expired

### "Could not fetch transform code"
- Workflow continues with template code
- Notebooks still generated (less accurate but functional)
- Shows fallback template transform

### "Dataset RID not found"
- Verify RID format: `ri.foundry.main.dataset.{uuid}`
- Check RID exists in your Palantir workspace
- Use `.windsurf/data/rid_mapping.csv` to find correct RIDs

---

## Performance

| Operation | Time |
|-----------|------|
| Connect to Palantir | ~2s |
| Fetch 1 transform code | ~3s |
| Convert to Databricks | ~1s |
| Generate notebook | <1s |
| **Total (2 datasets)** | **~15 seconds** |

---

## Examples

### Example 1: Default (all enabled datasets in manifest)
```
/palantir-to-databricks-migrate
```

**Processes**: All datasets with `enabled: true` in manifest

**Output**: N notebooks in `scripts/output/demo/`

---

### Example 2: Add a new dataset to process

Edit `palantir-migration-manifest.yaml`:

```yaml
datasets:
  - name: "my_new_dataset"
    dataset_rid: "ri.foundry.main.dataset.YOUR-UUID"
    transform_rid: "ri.foundry.main.dataset.YOUR-TRANSFORM-UUID"
    enabled: true
    merge_key: "id"
```

Then run:
```
/palantir-to-databricks-migrate
```

---

### Example 3: Temporarily disable a dataset

Edit `palantir-migration-manifest.yaml`:

```yaml
  - name: "X_ERIC_5GNR_CELL_RRH"
    enabled: false  # ← Won't process this
```

Re-run. Only enabled datasets process.

---

## Related Workflows

- `/01-ingest-to-raw` - Ingest raw data from sources
- `/02-scaffold-ingest` - Generate ingest scaffolding
- `/03-databricks-access` - Setup Databricks connectivity
- **`/04-palantir-to-databricks-migrate`** ← You are here
- `/04-ingest-raw-scaffold-upload-run` - End-to-end ingest → scaffold → upload → run

---

## FAQ

**Q: Is this production-ready?**  
A: The generated notebooks are production-ready. Review before deploying to ensure logic matches your requirements.

**Q: Can I modify the generated notebooks?**  
A: Yes! The notebooks are yours to modify. Re-run this workflow to regenerate if Palantir code changes.

**Q: Does this handle all Palantir transforms?**  
A: Most common transforms (Python-based). Some advanced Foundry features may need manual adjustment.

**Q: Can I deploy multiple datasets at once?**  
A: Yes, specify multiple dataset RIDs. Workflow will generate notebooks for each.

**Q: How do I update if Palantir code changes?**  
A: Re-run this workflow with same RIDs - it will overwrite the generated notebooks.

---

## Success Criteria

You'll know it worked when:

✅ Console shows "✓ Connected" to Palantir  
✅ Shows "Retrieved X characters of code" for each dataset  
✅ Shows "Generated: {dataset_name}_databricks.py"  
✅ Files appear in `scripts/output/demo/`  
✅ Databricks notebooks are syntactically valid  
✅ Can upload to Databricks workspace  
✅ Can run on Databricks cluster  

---

## Support

If something goes wrong:
1. Check `.env` has credentials
2. Verify internet connection to Palantir
3. Check dataset RIDs are valid
4. Re-run workflow (may be transient API issue)
5. Review `scripts/output/demo/` for partial output
