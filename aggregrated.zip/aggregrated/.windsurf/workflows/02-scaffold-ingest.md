---
description: Convert Foundry Transform Python files to Databricks PySpark pipelines with ADLS I/O
---

# Scaffold Ingest

Convert existing Foundry Transform Python files to Databricks-ready PySpark pipelines that read/write from Azure Data Lake Storage (ADLS).

## Input

**Required**: Path to existing Foundry Transform Python file
```
/scaffold-ingest <path_to_foundry_transform.py>
```

## Execution Steps

### 1. Load Configuration
- Read `.cdo-aifc/templates/03-data-engineering/pipeline-builder/env-config.yaml` for ADLS config
- Read `.cdo-aifc/data/rid_mapping.csv` for dataset name to RID mappings
- Read `.cdo-aifc/memory/archetypes/03-data-engineering/pipeline-builder-constitution.md` for hard-stop rules

### 2. Parse Input File
From the existing Foundry Transform file, extract:
- **Input RID**: Parse `Input("ri.foundry.main.dataset.XXX")` from `@transform` decorator
- **Output RID**: Parse `Output("ri.foundry.main.dataset.YYY")` from `@transform` decorator
- **Input_dataset_name**: Look up Input RID in `rid_mapping.csv` to get `input_dataset_name`
- **Output_dataset_name**: Look up Output RID in `rid_mapping.csv` to get `output_dataset_name`
- **Transformation logic**: Extract the logic from the function body
- **Column configurations**: Extract all `cast_to_*` lists and format variables
- **ingestion_pattern**: If `@incremental` decorator present with semantic version parameter, use incremental; otherwise overwrite


### 3. Resolve ADLS Paths
Using `env-config.yaml` and `rid_mapping.csv`:
```python
# From env-config.yaml
Read `env_config.yaml` for input_container, input_folder_name, host_name,output_container, output_folder_name
Read `rid_mapping.csv` for input_dataset_name and output_dataset_name

# Construct paths
INPUT_PATH = f"abfss://{input_container}@{host_name}/{input_folder_name}"
OUTPUT_PATH = f"abfss://{output_container}@{host_name}/{output_folder_name}"
```

### 4. Generate PySpark Pipeline

**Conversion mapping (Foundry → Databricks):**

```python
# ============ BEFORE (Foundry Transform) ============
from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns

@transform(
    out=Output("ri.foundry.main.dataset.XXX"),
    df=Input("ri.foundry.main.dataset.YYY"),
)
def my_compute_function(out, df):
    df = clean_columns(df.dataframe(), ...)
    df = lowercase_columns(df)
    out.write_dataframe(df)

# ============ AFTER (Databricks PySpark) ============
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F

# ADLS Configuration (resolved from rid_mapping.csv)
INPUT_PATH = "abfss://otis-poc@datalakeeastus2prd.dfs.core.windows.net/x_eric_5gnr_cell_rrh"
OUTPUT_PATH = "abfss://otis-poc@datalakeeastus2prd.dfs.core.windows.net/x_eric_5gnr_cell_rrh_clean"

# Column configurations (preserved from original)
date_format = 'yyyyMMdd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
cast_to_timestamp_from_long_columns = ['LOADDATE']
# ... other cast lists ...

def transform(df: DataFrame) -> DataFrame:
    """Apply column cleaning transformations."""
    df = clean_columns(df, ...)  # preserved logic
    df = lowercase_columns(df)
    return df

def main(spark: SparkSession) -> None:
    """Databricks entry point."""
    # Read from ADLS
    df = spark.read.parquet(INPUT_PATH)
    
    # Apply transformations
    df = transform(df)
    
    # Write to ADLS
    df.write.mode("overwrite").parquet(OUTPUT_PATH)

if __name__ == "__main__":
    spark = SparkSession.builder.appName("x_eric_5gnr_cell_rrh_ingestion").getOrCreate()
    main(spark)
```

**Handling utility module dependency:**

Import from shared location (for Databricks workspace):
- Ensure `column_clean.py` is uploaded to Databricks workspace
- Use: `from utility.column_clean import clean_columns, lowercase_columns`

### 5. Generate Databricks Job Snippet

```json
{
  "name": "{dataset_name}_ingestion",
  "tasks": [{
    "task_key": "transform",
    "spark_python_task": {
      "python_file": "dbfs:/jobs/{dataset_name}.py"
    },
    "new_cluster": {
      "spark_version": "13.3.x-scala2.12",
      "num_workers": 2
    }
  }]
}
```

### 6. Validate Against Constitution
Check against hard-stop rules from `pipeline-builder-constitution.md`:
- ✓ Column cleaning patterns applied
- ✓ Lowercase column names for consistency
- ✓ Type casting for data quality

### 7. Report Completion
Output:
- Original file path
- Generated file path
- Input/output ADLS paths (resolved from RID)
- Column transformations preserved
- Databricks job snippet
- Dependencies noted

## Examples

**Convert single file:**
```
/scaffold-ingest Snowflake-DIY-NETAUDIT-Python/transforms-python/src/myproject/datasets/clean/x_site_general_info.py
```

**Convert with inline utilities:**
```
/scaffold-ingest x_eric_5gnr_cell_rrh.py --inline-utils
```

## Configuration Files

| File | Purpose |
|------|---------|
| `.cdo-aifc/templates/03-data-engineering/pipeline-builder/env-config.yaml` | ADLS connection config |
| `.cdo-aifc/data/rid_mapping.csv` | RID to dataset_name mapping |
| `.cdo-aifc/memory/archetypes/03-data-engineering/pipeline-builder-constitution.md` | Hard-stop rules |
| `pythonutilities/pythonutilities/src/utility/column_clean.py` | Shared utility functions |

## References

- Existing patterns: `Snowflake-DIY-NETAUDIT-Python/transforms-python/src/myproject/datasets/clean/`
- Utility module: `pythonutilities/pythonutilities/src/utility/column_clean.py`
- Spark version: 3.4.0+ (from env-config.yaml)
