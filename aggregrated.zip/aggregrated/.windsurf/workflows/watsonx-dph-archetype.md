---
description: IBM Data Product Hub service archetype - product registration, contracts, subscriptions, delivery
---

# IBM Data Product Hub Service Archetype

## Overview

Data Product Hub (DPH) enables organizations to package, publish, and share data products with governed access.

**Base URL:** `https://api.dataplatform.cloud.ibm.com`

---

## Core Endpoints

### Data Products

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v1/data_products` | List data products |
| POST | `/v1/data_products` | Create data product |
| GET | `/v1/data_products/{id}` | Get data product |
| PATCH | `/v1/data_products/{id}` | Update data product |
| DELETE | `/v1/data_products/{id}` | Delete data product |
| POST | `/v1/data_products/{id}/publish` | Publish data product |

### Data Product Versions

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v1/data_products/{id}/versions` | List versions |
| POST | `/v1/data_products/{id}/versions` | Create version |
| GET | `/v1/data_products/{id}/versions/{version}` | Get version |
| PATCH | `/v1/data_products/{id}/versions/{version}` | Update version |

### Contracts

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v1/data_product_contracts` | List contracts |
| POST | `/v1/data_product_contracts` | Create contract |
| GET | `/v1/data_product_contracts/{id}` | Get contract |
| POST | `/v1/data_product_contracts/{id}/approve` | Approve contract |
| POST | `/v1/data_product_contracts/{id}/reject` | Reject contract |

### Subscriptions

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v1/data_product_subscriptions` | List subscriptions |
| POST | `/v1/data_product_subscriptions` | Create subscription |
| GET | `/v1/data_product_subscriptions/{id}` | Get subscription |
| DELETE | `/v1/data_product_subscriptions/{id}` | Cancel subscription |

### Delivery

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v1/data_products/{id}/deliver` | Trigger delivery |
| GET | `/v1/data_products/{id}/deliveries` | List deliveries |
| GET | `/v1/data_products/{id}/deliveries/{delivery_id}` | Get delivery status |

---

## Python Client

```python
import requests
import os
from typing import List, Dict, Optional
from dataclasses import dataclass
from enum import Enum

class ProductState(Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    RETIRED = "retired"

class ContractState(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"

@dataclass
class DataProduct:
    id: str
    name: str
    description: str
    state: ProductState
    version: str
    owner: str
    tags: List[str]

class DataProductHubClient:
    """IBM Data Product Hub API Client."""
    
    BASE_URL = "https://api.dataplatform.cloud.ibm.com"
    
    def __init__(self, hub_id: str = None, auth = None):
        self.hub_id = hub_id or os.environ.get('DPH_HUB_ID')
        self.auth = auth or IBMIAMAuth()
    
    def _headers(self) -> dict:
        headers = self.auth.get_headers()
        headers['X-IBM-DPH-ID'] = self.hub_id
        return headers
    
    # --- Data Products ---
    
    def list_products(self, state: str = None) -> List[Dict]:
        """List all data products."""
        params = {}
        if state:
            params['state'] = state
        
        response = requests.get(
            f"{self.BASE_URL}/v1/data_products",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        return response.json().get('data_products', [])
    
    def get_product(self, product_id: str) -> Dict:
        """Get data product details."""
        response = requests.get(
            f"{self.BASE_URL}/v1/data_products/{product_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def create_product(self, name: str, description: str,
                      assets: List[str], tags: List[str] = None) -> Dict:
        """Create a new data product."""
        payload = {
            "name": name,
            "description": description,
            "assets": [{"asset_id": a} for a in assets],
            "tags": tags or []
        }
        response = requests.post(
            f"{self.BASE_URL}/v1/data_products",
            headers=self._headers(),
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def update_product(self, product_id: str, updates: dict) -> Dict:
        """Update a data product."""
        response = requests.patch(
            f"{self.BASE_URL}/v1/data_products/{product_id}",
            headers=self._headers(),
            json=updates
        )
        response.raise_for_status()
        return response.json()
    
    def publish_product(self, product_id: str, version: str = None) -> Dict:
        """Publish a data product."""
        payload = {}
        if version:
            payload['version'] = version
        
        response = requests.post(
            f"{self.BASE_URL}/v1/data_products/{product_id}/publish",
            headers=self._headers(),
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def retire_product(self, product_id: str) -> Dict:
        """Retire a data product."""
        response = requests.post(
            f"{self.BASE_URL}/v1/data_products/{product_id}/retire",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    # --- Versions ---
    
    def list_versions(self, product_id: str) -> List[Dict]:
        """List all versions of a data product."""
        response = requests.get(
            f"{self.BASE_URL}/v1/data_products/{product_id}/versions",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('versions', [])
    
    def create_version(self, product_id: str, version: str,
                      changes: str) -> Dict:
        """Create a new version."""
        response = requests.post(
            f"{self.BASE_URL}/v1/data_products/{product_id}/versions",
            headers=self._headers(),
            json={
                "version": version,
                "change_description": changes
            }
        )
        response.raise_for_status()
        return response.json()
    
    # --- Contracts ---
    
    def list_contracts(self, product_id: str = None,
                      state: str = None) -> List[Dict]:
        """List data product contracts."""
        params = {}
        if product_id:
            params['data_product_id'] = product_id
        if state:
            params['state'] = state
        
        response = requests.get(
            f"{self.BASE_URL}/v1/data_product_contracts",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        return response.json().get('contracts', [])
    
    def create_contract(self, product_id: str, consumer_id: str,
                       terms: dict) -> Dict:
        """Create a data product contract."""
        response = requests.post(
            f"{self.BASE_URL}/v1/data_product_contracts",
            headers=self._headers(),
            json={
                "data_product_id": product_id,
                "consumer_id": consumer_id,
                "terms": terms
            }
        )
        response.raise_for_status()
        return response.json()
    
    def approve_contract(self, contract_id: str) -> Dict:
        """Approve a contract."""
        response = requests.post(
            f"{self.BASE_URL}/v1/data_product_contracts/{contract_id}/approve",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def reject_contract(self, contract_id: str, reason: str) -> Dict:
        """Reject a contract."""
        response = requests.post(
            f"{self.BASE_URL}/v1/data_product_contracts/{contract_id}/reject",
            headers=self._headers(),
            json={"reason": reason}
        )
        response.raise_for_status()
        return response.json()
    
    # --- Subscriptions ---
    
    def list_subscriptions(self, consumer_id: str = None) -> List[Dict]:
        """List subscriptions."""
        params = {}
        if consumer_id:
            params['consumer_id'] = consumer_id
        
        response = requests.get(
            f"{self.BASE_URL}/v1/data_product_subscriptions",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        return response.json().get('subscriptions', [])
    
    def subscribe(self, contract_id: str) -> Dict:
        """Subscribe to a data product."""
        response = requests.post(
            f"{self.BASE_URL}/v1/data_product_subscriptions",
            headers=self._headers(),
            json={"contract_id": contract_id}
        )
        response.raise_for_status()
        return response.json()
    
    def unsubscribe(self, subscription_id: str) -> None:
        """Cancel a subscription."""
        response = requests.delete(
            f"{self.BASE_URL}/v1/data_product_subscriptions/{subscription_id}",
            headers=self._headers()
        )
        response.raise_for_status()
    
    # --- Delivery ---
    
    def deliver(self, product_id: str, destination: dict) -> Dict:
        """Trigger data product delivery."""
        response = requests.post(
            f"{self.BASE_URL}/v1/data_products/{product_id}/deliver",
            headers=self._headers(),
            json={"destination": destination}
        )
        response.raise_for_status()
        return response.json()
    
    def get_delivery_status(self, product_id: str, 
                           delivery_id: str) -> Dict:
        """Get delivery status."""
        response = requests.get(
            f"{self.BASE_URL}/v1/data_products/{product_id}/deliveries/{delivery_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
```

---

## Example: Create and Publish Data Product

```python
client = DataProductHubClient()

# Create data product
product = client.create_product(
    name="Customer 360",
    description="Unified customer view combining CRM, transactions, and support data",
    assets=[
        "asset_crm_customers",
        "asset_transactions",
        "asset_support_tickets"
    ],
    tags=["customer", "360", "marketing"]
)
print(f"Created product: {product['id']}")

# Add metadata
client.update_product(product['id'], {
    "owner": "data_platform_team",
    "sla": {
        "freshness": "daily",
        "availability": "99.9%"
    },
    "schema": {
        "fields": [
            {"name": "customer_id", "type": "string", "pii": False},
            {"name": "email", "type": "string", "pii": True},
            {"name": "lifetime_value", "type": "decimal", "pii": False}
        ]
    }
})

# Publish
published = client.publish_product(product['id'], version="1.0.0")
print(f"Published version: {published['version']}")
```

---

## Example: Contract Workflow

```python
# Consumer requests access
contract = client.create_contract(
    product_id="product_123",
    consumer_id="analytics_team",
    terms={
        "purpose": "Customer analytics dashboard",
        "retention_days": 90,
        "allowed_uses": ["analytics", "reporting"],
        "prohibited_uses": ["external_sharing", "ml_training"]
    }
)
print(f"Contract created: {contract['id']}, state: {contract['state']}")

# Owner approves
approved = client.approve_contract(contract['id'])
print(f"Contract approved: {approved['state']}")

# Consumer subscribes
subscription = client.subscribe(contract['id'])
print(f"Subscribed: {subscription['id']}")

# Deliver data
delivery = client.deliver(
    product_id="product_123",
    destination={
        "type": "s3",
        "bucket": "analytics-data",
        "prefix": "customer360/"
    }
)
print(f"Delivery started: {delivery['delivery_id']}")
```

---

## Contract Terms Schema

```yaml
terms:
  purpose: string           # Business purpose
  retention_days: int       # Data retention period
  allowed_uses:             # Permitted use cases
    - analytics
    - reporting
    - ml_training
  prohibited_uses:          # Forbidden use cases
    - external_sharing
    - resale
  data_classification: string  # PII, Confidential, Public
  geographic_restrictions:
    - US
    - EU
  expiration_date: date     # Contract end date
```

---

## Delivery Destinations

| Type | Properties |
|------|------------|
| `s3` | `bucket`, `prefix`, `region`, `role_arn` |
| `adls` | `account`, `container`, `path` |
| `gcs` | `bucket`, `prefix`, `project` |
| `snowflake` | `account`, `database`, `schema`, `table` |
| `databricks` | `catalog`, `schema`, `table` |
