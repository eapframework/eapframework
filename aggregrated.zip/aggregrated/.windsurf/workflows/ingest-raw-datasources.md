---
description: Ingest data from multiple datasources into raw layer with encrypted connection strings
---

# Multi-Datasource Raw Layer Ingestion

## Trigger

```
/ingest-raw --config datasources.yaml
/ingest-raw --source <source_name>
/ingest-raw --all
```

---

## Purpose

Ingest data from multiple heterogeneous datasources (databases, files, APIs, cloud storage) into a unified raw layer with **encrypted connection strings** and secure credential management.

---

## Supported Datasource Types

| Type | Connector | Encryption Method |
|------|-----------|-------------------|
| SQL Server | `pyodbc` / `sqlalchemy` | Azure Key Vault / AWS Secrets Manager |
| PostgreSQL | `psycopg2` | HashiCorp Vault |
| Oracle | `cx_Oracle` | Wallet / KMS |
| MySQL | `mysql-connector` | SSL/TLS + KMS |
| Snowflake | `snowflake-connector` | Key Pair Auth |
| Azure Blob | `azure-storage-blob` | Managed Identity / SAS |
| AWS S3 | `boto3` | IAM Role / KMS |
| REST API | `requests` | OAuth2 / API Key (encrypted) |
| SFTP | `paramiko` | SSH Key |
| Kafka | `confluent-kafka` | SASL/SSL |

---

## Connection String Encryption

### Option 1: Azure Key Vault

```python
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

credential = DefaultAzureCredential()
vault_url = "https://<vault-name>.vault.azure.net"
client = SecretClient(vault_url=vault_url, credential=credential)

# Retrieve encrypted connection string
conn_string = client.get_secret("sql-server-connection").value
```

### Option 2: AWS Secrets Manager

```python
import boto3
import json

client = boto3.client('secretsmanager', region_name='us-east-1')
response = client.get_secret_value(SecretId='prod/db/sqlserver')
credentials = json.loads(response['SecretString'])
```

### Option 3: HashiCorp Vault

```python
import hvac

client = hvac.Client(url='https://vault.company.com:8200')
client.token = os.environ['VAULT_TOKEN']

secret = client.secrets.kv.v2.read_secret_version(path='databases/sqlserver')
conn_string = secret['data']['data']['connection_string']
```

### Option 4: Local Encrypted Config (Fernet)

```python
from cryptography.fernet import Fernet

# Key stored securely (env var or key file)
key = os.environ['ENCRYPTION_KEY'].encode()
cipher = Fernet(key)

# Decrypt connection string
encrypted_conn = config['datasources']['sqlserver']['connection_encrypted']
conn_string = cipher.decrypt(encrypted_conn.encode()).decode()
```

---

## Configuration File: `datasources.yaml`

```yaml
encryption:
  provider: azure_keyvault  # azure_keyvault | aws_secrets | hashicorp_vault | local_fernet
  vault_url: https://mycompany-kv.vault.azure.net
  # For local_fernet: key_env_var: ENCRYPTION_KEY

raw_layer:
  target: azure_adls  # azure_adls | aws_s3 | local | databricks
  path: abfss://raw@datalake.dfs.core.windows.net/
  format: parquet  # parquet | delta | json | csv
  partition_by: [ingestion_date, source_system]

datasources:
  # SQL Server
  - name: erp_sqlserver
    type: sqlserver
    enabled: true
    secret_name: erp-sqlserver-connection  # Key Vault secret name
    tables:
      - schema: dbo
        table: customers
        incremental_column: modified_date
        watermark: "2024-01-01"
      - schema: dbo
        table: orders
        incremental_column: order_date
        watermark: "2024-01-01"
    schedule: "0 2 * * *"  # Daily at 2 AM

  # PostgreSQL
  - name: analytics_postgres
    type: postgresql
    enabled: true
    secret_name: analytics-postgres-connection
    tables:
      - schema: public
        table: events
        incremental_column: event_timestamp
      - schema: public
        table: sessions
        mode: full  # Full refresh
    schedule: "0 */4 * * *"  # Every 4 hours

  # Oracle
  - name: legacy_oracle
    type: oracle
    enabled: true
    secret_name: legacy-oracle-connection
    tables:
      - schema: PROD
        table: TRANSACTIONS
        incremental_column: TXN_DATE
    schedule: "0 6 * * *"

  # Snowflake
  - name: warehouse_snowflake
    type: snowflake
    enabled: true
    secret_name: snowflake-keypair  # Contains private key + account info
    warehouse: COMPUTE_WH
    database: ANALYTICS
    tables:
      - schema: PUBLIC
        table: FACT_SALES
        mode: full
    schedule: "0 0 * * 0"  # Weekly

  # Azure Blob Storage
  - name: vendor_files
    type: azure_blob
    enabled: true
    secret_name: vendor-storage-sas
    container: incoming
    path_pattern: "vendors/{vendor_id}/*.csv"
    file_format: csv
    options:
      header: true
      delimiter: ","
      encoding: utf-8
    schedule: "*/30 * * * *"  # Every 30 minutes

  # AWS S3
  - name: partner_s3
    type: aws_s3
    enabled: true
    secret_name: partner-aws-credentials
    bucket: partner-data-feed
    prefix: daily-exports/
    file_format: parquet
    schedule: "0 8 * * *"

  # REST API
  - name: crm_api
    type: rest_api
    enabled: true
    secret_name: crm-api-oauth  # Contains client_id, client_secret, token_url
    base_url: https://api.crm.company.com/v2
    auth_type: oauth2_client_credentials
    endpoints:
      - path: /contacts
        method: GET
        pagination:
          type: offset
          page_size: 1000
        incremental_param: modified_since
      - path: /opportunities
        method: GET
        pagination:
          type: cursor
          cursor_field: next_cursor
    schedule: "0 */2 * * *"

  # SFTP
  - name: bank_sftp
    type: sftp
    enabled: true
    secret_name: bank-sftp-credentials  # Contains host, user, private_key
    remote_path: /outgoing/statements/
    file_pattern: "statement_*.csv"
    archive_after_download: true
    schedule: "0 7 * * *"

  # Kafka
  - name: events_kafka
    type: kafka
    enabled: true
    secret_name: kafka-sasl-credentials
    bootstrap_servers: kafka.company.com:9093
    topics:
      - user_events
      - transaction_events
    consumer_group: raw-layer-ingestion
    security_protocol: SASL_SSL
    schedule: streaming  # Continuous
```

---

## Secret Format Examples

### SQL Server (Key Vault)
```json
{
  "driver": "ODBC Driver 18 for SQL Server",
  "server": "sqlserver.database.windows.net",
  "database": "erp_prod",
  "username": "etl_user",
  "password": "encrypted_password_here",
  "encrypt": true,
  "trust_server_certificate": false
}
```

### PostgreSQL
```json
{
  "host": "postgres.company.com",
  "port": 5432,
  "database": "analytics",
  "user": "etl_service",
  "password": "encrypted_password",
  "sslmode": "require"
}
```

### Snowflake (Key Pair)
```json
{
  "account": "xy12345.us-east-1",
  "user": "ETL_SERVICE",
  "private_key": "-----BEGIN ENCRYPTED PRIVATE KEY-----\n...",
  "private_key_passphrase": "passphrase_here"
}
```

### OAuth2 API
```json
{
  "client_id": "abc123",
  "client_secret": "encrypted_secret",
  "token_url": "https://auth.crm.com/oauth/token",
  "scope": "read:contacts read:opportunities"
}
```

---

## Processing Steps

### Step 1: Load Configuration
```python
import yaml
from pathlib import Path

config = yaml.safe_load(Path("datasources.yaml").read_text())
encryption_provider = config['encryption']['provider']
```

### Step 2: Initialize Secret Client
```python
def get_secret_client(provider, config):
    if provider == 'azure_keyvault':
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
        return SecretClient(
            vault_url=config['encryption']['vault_url'],
            credential=DefaultAzureCredential()
        )
    elif provider == 'aws_secrets':
        import boto3
        return boto3.client('secretsmanager')
    elif provider == 'hashicorp_vault':
        import hvac
        client = hvac.Client(url=config['encryption']['vault_url'])
        client.token = os.environ['VAULT_TOKEN']
        return client
    elif provider == 'local_fernet':
        from cryptography.fernet import Fernet
        key = os.environ[config['encryption']['key_env_var']].encode()
        return Fernet(key)
```

### Step 3: Decrypt Connection & Connect
```python
def get_connection(datasource, secret_client, provider):
    # Retrieve secret based on provider
    if provider == 'azure_keyvault':
        secret = secret_client.get_secret(datasource['secret_name']).value
        creds = json.loads(secret)
    elif provider == 'aws_secrets':
        response = secret_client.get_secret_value(SecretId=datasource['secret_name'])
        creds = json.loads(response['SecretString'])
    elif provider == 'hashicorp_vault':
        secret = secret_client.secrets.kv.v2.read_secret_version(
            path=datasource['secret_name']
        )
        creds = secret['data']['data']
    elif provider == 'local_fernet':
        encrypted = datasource['connection_encrypted']
        creds = json.loads(secret_client.decrypt(encrypted.encode()).decode())
    
    # Create connection based on datasource type
    if datasource['type'] == 'sqlserver':
        import pyodbc
        conn_str = (
            f"DRIVER={{{creds['driver']}}};"
            f"SERVER={creds['server']};"
            f"DATABASE={creds['database']};"
            f"UID={creds['username']};"
            f"PWD={creds['password']};"
            f"Encrypt={'yes' if creds.get('encrypt') else 'no'}"
        )
        return pyodbc.connect(conn_str)
    
    elif datasource['type'] == 'postgresql':
        import psycopg2
        return psycopg2.connect(
            host=creds['host'],
            port=creds['port'],
            database=creds['database'],
            user=creds['user'],
            password=creds['password'],
            sslmode=creds.get('sslmode', 'prefer')
        )
    
    elif datasource['type'] == 'oracle':
        import cx_Oracle
        dsn = cx_Oracle.makedsn(creds['host'], creds['port'], creds['service_name'])
        return cx_Oracle.connect(creds['user'], creds['password'], dsn)
    
    elif datasource['type'] == 'snowflake':
        import snowflake.connector
        return snowflake.connector.connect(
            account=creds['account'],
            user=creds['user'],
            private_key=creds['private_key'],
            private_key_passphrase=creds.get('private_key_passphrase')
        )
```

### Step 4: Extract Data
```python
def extract_table(conn, table_config, watermark=None):
    schema = table_config['schema']
    table = table_config['table']
    query = f"SELECT * FROM {schema}.{table}"
    
    # Incremental extraction
    if table_config.get('mode') != 'full' and table_config.get('incremental_column') and watermark:
        query += f" WHERE {table_config['incremental_column']} > '{watermark}'"
    
    return pd.read_sql(query, conn)
```

### Step 5: Write to Raw Layer
```python
def write_to_raw(df, datasource_name, table_name, config):
    from datetime import datetime
    
    ingestion_date = datetime.now().strftime('%Y-%m-%d')
    ingestion_ts = datetime.now().isoformat()
    
    # Add metadata columns
    df['_ingestion_date'] = ingestion_date
    df['_ingestion_timestamp'] = ingestion_ts
    df['_source_system'] = datasource_name
    
    base_path = config['raw_layer']['path']
    output_format = config['raw_layer']['format']
    
    path = f"{base_path}/{datasource_name}/{table_name}/ingestion_date={ingestion_date}"
    
    if output_format == 'parquet':
        df.to_parquet(path, index=False)
    elif output_format == 'delta':
        # Using delta-rs or Databricks
        from deltalake.writer import write_deltalake
        write_deltalake(path, df, mode='append')
    elif output_format == 'json':
        df.to_json(f"{path}/data.json", orient='records', lines=True)
    elif output_format == 'csv':
        df.to_csv(f"{path}/data.csv", index=False)
    
    return {"path": path, "rows": len(df)}
```

### Step 6: Update Watermarks
```python
def update_watermark(datasource_name, table_name, column, df, config):
    if column and len(df) > 0:
        new_watermark = df[column].max()
        
        watermark_path = f"{config['raw_layer']['path']}/_metadata/watermarks.json"
        
        # Load existing watermarks
        try:
            watermarks = json.load(open(watermark_path))
        except:
            watermarks = {}
        
        key = f"{datasource_name}.{table_name}"
        watermarks[key] = {
            "column": column,
            "value": str(new_watermark),
            "updated_at": datetime.now().isoformat()
        }
        
        # Save updated watermarks
        with open(watermark_path, 'w') as f:
            json.dump(watermarks, f, indent=2)
        
        return new_watermark
    return None
```

---

## Output Structure

```
raw/
├── erp_sqlserver/
│   ├── customers/
│   │   └── ingestion_date=2024-01-15/
│   │       └── part-00000.parquet
│   └── orders/
│       └── ingestion_date=2024-01-15/
│           └── part-00000.parquet
├── analytics_postgres/
│   ├── events/
│   └── sessions/
├── vendor_files/
│   └── raw_csv/
├── crm_api/
│   ├── contacts/
│   └── opportunities/
└── _metadata/
    ├── watermarks.json
    ├── ingestion_log.json
    └── schema_registry/
        ├── erp_sqlserver_customers.json
        └── erp_sqlserver_orders.json
```

---

## Security Best Practices

| Practice | Implementation |
|----------|----------------|
| **Never store plaintext credentials** | Use Key Vault / Secrets Manager |
| **Rotate secrets regularly** | Automate with secret rotation policies (90 days) |
| **Use managed identities** | Azure MSI / AWS IAM Roles (no keys in code) |
| **Encrypt data in transit** | TLS 1.2+ for all connections |
| **Encrypt data at rest** | Storage encryption (SSE-KMS / SSE-S3) |
| **Audit access** | Enable Key Vault / CloudTrail logging |
| **Least privilege** | Grant only SELECT on required tables |
| **Network isolation** | Private endpoints / VPC / VNet |
| **Secret versioning** | Track secret changes with versions |
| **Emergency rotation** | Have runbook for compromised credentials |

---

## Environment Variables

```bash
# Azure Key Vault (Managed Identity preferred)
export AZURE_TENANT_ID="your-tenant-id"
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"  # Or use MSI

# AWS Secrets Manager
export AWS_ACCESS_KEY_ID="your-access-key"
export AWS_SECRET_ACCESS_KEY="your-secret-key"
export AWS_DEFAULT_REGION="us-east-1"

# HashiCorp Vault
export VAULT_ADDR="https://vault.company.com:8200"
export VAULT_TOKEN="your-vault-token"

# Local Fernet encryption
export ENCRYPTION_KEY="your-fernet-key-base64"
```

---

## Example Usage

### Ingest All Enabled Sources
```
User: /ingest-raw --config datasources.yaml --all

AI Response:
1. Loading configuration from datasources.yaml...
2. Encryption provider: azure_keyvault
3. Connecting to Azure Key Vault: mycompany-kv.vault.azure.net ✓

Processing 8 enabled datasources...

[1/8] erp_sqlserver
  → Retrieving secret: erp-sqlserver-connection ✓
  → Connecting to SQL Server ✓
  → Extracting dbo.customers (incremental from 2024-01-14)
    → 15,432 rows extracted
  → Extracting dbo.orders (incremental from 2024-01-14)
    → 48,291 rows extracted
  → Writing to raw layer ✓

[2/8] analytics_postgres
  → Retrieving secret: analytics-postgres-connection ✓
  → Connecting to PostgreSQL ✓
  → Extracting public.events (incremental)
    → 234,567 rows extracted
  → Extracting public.sessions (full refresh)
    → 12,345 rows extracted
  → Writing to raw layer ✓

... (continuing for other sources)

Summary:
  Sources processed: 8
  Tables ingested: 14
  Total rows: 1,245,678
  Duration: 12m 34s
  Errors: 0
```

### Ingest Single Source
```
User: /ingest-raw --source erp_sqlserver

AI Response:
1. Loading configuration...
2. Processing source: erp_sqlserver
3. Retrieving secret from Azure Key Vault ✓
4. Connecting to SQL Server: sqlserver.database.windows.net ✓
5. Extracting 2 tables...
   → dbo.customers: 15,432 rows
   → dbo.orders: 48,291 rows
6. Writing to raw layer ✓
7. Updating watermarks ✓

Complete! 63,723 rows ingested in 2m 34s
```

---

## Error Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| `SecretNotFound` | Secret doesn't exist in vault | Create secret with correct name |
| `AuthenticationError` | Invalid credentials for vault | Check service principal / managed identity |
| `ConnectionTimeout` | Network/firewall blocking | Check NSG rules / private endpoints |
| `PermissionDenied` | Insufficient database privileges | Grant SELECT on required tables |
| `SchemaChanged` | Source schema modified | Update schema registry, alert data team |
| `QuotaExceeded` | API rate limit hit | Implement backoff, reduce batch size |
| `DiskFull` | Raw layer storage full | Increase storage / archive old data |
| `InvalidCredentials` | DB password expired | Rotate secret in Key Vault |

---

## Monitoring & Alerting

```yaml
alerts:
  - name: ingestion_failure
    condition: job_status == 'failed'
    channels: [slack, email]
    
  - name: high_latency
    condition: ingestion_duration > 30m
    channels: [slack]
    
  - name: low_row_count
    condition: row_count < expected_min * 0.5
    channels: [email]
    
  - name: schema_drift
    condition: schema_changed == true
    channels: [slack, email, pagerduty]
```
