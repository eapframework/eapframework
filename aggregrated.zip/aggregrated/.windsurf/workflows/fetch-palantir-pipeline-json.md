---
description: Fetch Palantir Pipeline Builder JSON via API for migration to PySpark
---

User input: $ARGUMENTS

## Configuration

**Config File**: `.windsurf/workflows/palantir-migration-config.yaml`

Load settings from config:
```yaml
api:
  base_url: "https://paloma.palantirfoundry.com"
  pipeline_path: "/eddie/api/pipelines-v2"
  timeout_seconds: 60
  retry_attempts: 3

pipelines:
  netaudit:
    rid: "ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043"
```

---

## Execution Steps

### 1. Parse Input
Extract from $ARGUMENTS:
- **pipeline_name**: Key from config `pipelines` section (e.g., `netaudit`)
- **pipeline_rid**: Or direct Pipeline resource ID (overrides config lookup)
- **environment**: `prod` or `dev` (default: from config `default_environment`)
- **sandbox_id**: Optional specific sandbox ID

Request clarification if neither pipeline_name nor pipeline_rid provided.

### 2. Load Configuration
```python
import yaml
with open(".windsurf/workflows/palantir-migration-config.yaml") as f:
    config = yaml.safe_load(f)

# Get pipeline RID from config or argument
pipeline_rid = args.pipeline_id or config["pipelines"][args.pipeline_name]["rid"]
```

### 3. Validate Prerequisites

| Requirement | Check | Config Key |
|-------------|-------|------------|
| Bearer Token | `PALANTIR_TOKEN` env var OR `--token` | `auth.token_env_var` |
| Network Access | Can reach API base URL | `api.base_url` |
| Pipeline RID | Valid format or exists in config | `pipelines.<name>.rid` |
| Output Directory | Writable path | `output.json_dir` |

### 4. Two-Step API Flow (with Retry)

**Step 1: Fetch Sandboxes**
```
GET {api.base_url}{api.pipeline_path}/{pipeline_rid}/sandboxes/get/all
```
- Retry up to `api.retry_attempts` times with `api.retry_delay_seconds` backoff
- Extract sandbox ID from response (robustly checks `id`, `sandboxId`, or `rid`)
- Uses first/latest sandbox if multiple exist

**Step 2: Fetch All Information**
```
GET {api.base_url}{api.pipeline_path}/{pipeline_rid}/all-information?sandboxId={sandbox_id}
```
- Returns complete pipeline definition with transforms, datasets, outputs
- Timeout: `api.timeout_seconds`

### 5. Execute Fetch Script

```bash
# Option 1: Using environment variable (recommended)
export PALANTIR_TOKEN="your_bearer_token"
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-id "ri.eddie.main.pipeline.19f85d48-afd4-44f7-xxxx-xxxxxxxxxxxx" \
    --pipeline-name "netaudit"

# Option 2: Token as argument (testing only)
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --token "your_token" \
    --pipeline-id "ri.eddie.main.pipeline.19f85d48-afd4-44f7-xxxx-xxxxxxxxxxxx"

# Option 3: List sandboxes first
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-id "ri.eddie.main.pipeline.19f85d48-afd4-44f7-xxxx-xxxxxxxxxxxx" \
    --list-sandboxes

# Option 4: Dry run (show URLs without fetching)
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-id "ri.eddie.main.pipeline.19f85d48-afd4-44f7-xxxx-xxxxxxxxxxxx" \
    --dry-run
```

### 6. Output Files

| File | Description |
|------|-------------|
| `{name}_{timestamp}.json` | Versioned pipeline JSON. This is the single source of truth for the migration. |

Output directory from config: `output.json_dir` (default: `pipeline_builder/DBX_Conversion/pipeline_json/`)

### 7. Validate Output

Check the fetched JSON contains required sections:
```json
{
  "pipeline": { "rid": "...", "name": "..." },
  "sandbox": { "id": "...", "name": "Main" },
  "snapshot": {
    "outputs": [...],
    "transforms": [...]
  }
}
```

### 8. Chain to Migration Workflow

After successful fetch, proceed to migration:
```
/migrate--palantir-json-to-pyspark Migrate {name}_YYYYMMDD_HHMMSS.json to PySpark, storage: datalakeeastus2prd, container: otis-poc
```

Or use config defaults:
```
/migrate--palantir-json-to-pyspark Migrate {name}_YYYYMMDD_HHMMSS.json using config environment: prod
```

## Error Handling

**SSL Certificate Errors** (corporate proxy):
- The script has been updated to **disable SSL verification** by default (`ssl.CERT_NONE`).
- This handles `[SSL: CERTIFICATE_VERIFY_FAILED]` errors common in corporate environments.
- To re-enable strict verification, comment out the SSL context lines in `fetch_palantir_pipeline.py`.

**401 Unauthorized**: Token expired or invalid. Generate new token from Palantir UI.

**404 Not Found**: Invalid pipeline RID. Verify RID in Palantir Pipeline Builder URL.

**No Sandbox ID Found**: API response format may differ. Check `--list-sandboxes` output.

**Network Timeout**: Increase timeout in script or check VPN connection.

## CLI Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--token` | No* | Bearer token (*required if `PALANTIR_TOKEN` not set) |
| `--pipeline-id` | Yes | Pipeline resource ID |
| `--pipeline-name` | No | Name for output files (default: netaudit) |
| `--sandbox-id` | No | Specific sandbox ID (auto-fetched if omitted) |
| `--output-dir` | No | Output directory path |
| `--dry-run` | No | Print URLs without fetching |
| `--list-sandboxes` | No | Only list sandboxes |

## Examples

### Basic Fetch
```
/fetch-palantir-pipeline-json Fetch NetAudit pipeline: ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043
```

### Fetch with Custom Name
```
/fetch-palantir-pipeline-json Fetch pipeline ri.eddie.main.pipeline.xxx as "site_master"
```

### List Available Sandboxes
```
/fetch-palantir-pipeline-json List sandboxes for pipeline: ri.eddie.main.pipeline.xxx
```

## Curl Commands (Manual Testing)

```bash
# Step 1: Get sandboxes
curl 'https://paloma.palantirfoundry.com/eddie/api/pipelines-v2/{PIPELINE_RID}/sandboxes/get/all' \
  -H 'authorization: Bearer {TOKEN}' \
  -H 'accept: application/json'

# Step 2: Get all information
curl 'https://paloma.palantirfoundry.com/eddie/api/pipelines-v2/{PIPELINE_RID}/all-information?sandboxId={SANDBOX_ID}' \
  -H 'authorization: Bearer {TOKEN}' \
  -H 'accept: application/json' \
  -o pipeline.json
```

## References

- **Config File**: `.windsurf/workflows/palantir-migration-config.yaml`
- **Script**: `pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py`
- **Output Dir**: `pipeline_builder/DBX_Conversion/pipeline_json/`
- **Next Workflow**: `/migrate--palantir-json-to-pyspark`

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.1.1 | 2026-02-09 | Updated documentation flow for sequential AI agent execution |
| 1.1.0 | 2026-02-09 | Simplified output to single timestamped JSON file (removed latest/metadata) |
| 1.0.0 | 2026-02-02 | Initial production release with config support |
