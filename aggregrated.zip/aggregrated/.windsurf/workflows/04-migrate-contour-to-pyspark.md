---
description: Convert Palantir Contour JSON to PySpark notebook for Databricks with auto RID resolution
---
 
User input: $ARGUMENTS
 
## Configuration
 
**Config File**: `.windsurf/workflows/palantir-migration-config.yaml`
 
Load settings from config:
```yaml
storage:
  prod:
    account: "datalakeeastus2prd"
    container: "otis-poc"
    base_path: "abfss://otis-poc@datalakeeastus2prd.dfs.core.windows.net"
 
output:
  json_dir: "pipeline_builder/DBX_Conversion/jsonexports"
  notebook_dir: "pipeline_builder/DBX_Conversion"
```
 
---
 
## Prerequisites
 
**Option A: Fetch JSON via API** (recommended)
Run `/fetch-contour-json` first to download the contour definition:
```
/fetch-contour-json Fetch Contour analysis
```
Output: `pipeline_builder/DBX_Conversion/jsonexports/contour_latest.json`
 
**Option B: Manual JSON Export**
Export JSON manually from Palantir Contour UI and place in `jsonexports/`.
 
---
 
## Execution Steps
 
### 1. Parse Input
Extract from $ARGUMENTS:
- **json_file**: Path to contour JSON (e.g., `contour_latest.json`)
- **environment**: `prod` or `dev` (loads storage config from YAML)
- **output_folder**: Override default output folder (optional)
- **output_name**: Name for generated notebook (default: `contour_transformation`)
 
Request clarification if json_file is missing.
 
### 2. Load Configuration
```python
import yaml
with open(".windsurf/workflows/palantir-migration-config.yaml") as f:
    config = yaml.safe_load(f)
 
env = config["storage"][environment]
storage_account = env["account"]
container = env["container"]
```
 
### 3. Parse Contour JSON Structure
 
Contour JSON contains sequential transformation snapshots:
 
| Board Type | Description | PySpark Equivalent |
|------------|-------------|-------------------|
| `starting` | Source dataset RID | `spark.read.parquet(INPUT_PATH)` |
| `expression` | Column transforms | `df.withColumn(col, expr)` |
| `custom` (sort-columns) | Sorting | `df.orderBy(cols)` |
| `table` | Final output | `df.write.format("delta")` |
 
### 4. Extract Transformations
 
```python
import json
 
with open(json_file) as f:
    data = json.load(f)
 
snapshots = data.get("snapshots", [])
 
# Extract source RID
source_rid = None
expressions = []
sort_columns = []
 
for snap in snapshots:
    board_type = snap.get("boardType")
    state = snap.get("boardState", {})
    
    if board_type == "starting":
        desc = state.get("startingSetDescription", {})
        source_rid = desc.get("identifier", "").split(":")[0]
        
    elif board_type == "expression":
        for expr in state.get("expressions", []):
            expressions.append({
                "column": expr["columnName"],
                "expression": expr["expression"],
                "action": state.get("action")
            })
            
    elif board_type == "custom":
        if state.get("customBoardId") == "sort-columns":
            child = state.get("childSetDescription", {})
            sort_dir = child.get("sortDirection", {})
            for col, direction in sort_dir.items():
                sort_columns.append({"column": col, "direction": direction})
```
 
### 5. Resolve RID to ADLS Folder
 
Use `rid_resolver.py` utility:
```python
from rid_resolver import resolve_rid_to_folder
 
result = resolve_rid_to_folder(spark, dbutils, source_rid, storage_account, container)
INPUT_FOLDER = result["adls_folder"] if result else "source_dataset"
```
 
### 6. Generate PySpark Notebook
 
Template structure:
```python
# Databricks notebook source
# Contour Transformation - Generated from {json_file}
# Source RID: {source_rid}
 
# COMMAND ----------
# Cell 1: Configuration
 
from pyspark.sql import functions as F
from rid_resolver import resolve_rid_to_folder
import logging
 
STORAGE_ACCOUNT = "{storage_account}"
CONTAINER = "{container}"
SOURCE_RID = "{source_rid}"
OUTPUT_FOLDER = "{output_folder}"
 
# COMMAND ----------
# Cell 2: Resolve INPUT_FOLDER from RID
 
result = resolve_rid_to_folder(spark, dbutils, SOURCE_RID, STORAGE_ACCOUNT, CONTAINER)
INPUT_FOLDER = result["adls_folder"] if result else "source_dataset"
INPUT_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{INPUT_FOLDER}"
OUTPUT_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{OUTPUT_FOLDER}"
 
# COMMAND ----------
# Cell 3: Load Data
 
df = spark.read.format("delta").load(INPUT_PATH)
 
# COMMAND ----------
# Cell 4: Apply Transformations
 
# Generated from expression boards:
{generated_transforms}
 
# COMMAND ----------
# Cell 5: Sort
 
df = df.orderBy({sort_columns})
 
# COMMAND ----------
# Cell 6: Write Output
 
df.write.format("delta").mode("overwrite").save(OUTPUT_PATH)
```
 
### 7. Expression Translation
 
| Contour Expression | PySpark Equivalent |
|-------------------|-------------------|
| `ROUND("col", 7)` | `F.round(F.col("col"), 7)` |
| `CAST("col" AS STRING)` | `F.col("col").cast("string")` |
| `CONCAT("a", "b")` | `F.concat(F.col("a"), F.col("b"))` |
| `COALESCE("a", "b")` | `F.coalesce(F.col("a"), F.col("b"))` |
| `UPPER("col")` | `F.upper(F.col("col"))` |
| `LOWER("col")` | `F.lower(F.col("col"))` |
| `TRIM("col")` | `F.trim(F.col("col"))` |
 
### 8. Output Files
 
| File | Description |
|------|-------------|
| `{name}.py` | Generated PySpark notebook |
| Logs | Transformation summary and RID resolution |
 
Output directory: `pipeline_builder/DBX_Conversion/`
 
### 9. Validation Checklist
 
- [ ] All expression boards translated
- [ ] RID resolution successful or fallback documented
- [ ] Sort columns present in DataFrame
- [ ] Output path configured correctly
- [ ] No Palantir-specific imports
 
## CLI Arguments
 
| Argument | Required | Description |
|----------|----------|-------------|
| `json_file` | Yes | Path to contour JSON |
| `--environment` | No | `prod` or `dev` (default: prod) |
| `--output-folder` | No | ADLS output folder name |
| `--output-name` | No | Generated notebook name |
 
## Examples
 
### Basic Migration
```
/migrate-contour-to-pyspark Migrate contour_latest.json to PySpark
```
 
### With Custom Output
```
/migrate-contour-to-pyspark Migrate contour_latest.json output_folder=site_data_transformed
```
 
### Full Example
```
/migrate-contour-to-pyspark Migrate jsonexports/contour_latest.json environment=prod output_name=site_transformation
```
 
## Guardrails
 
| Check | Action |
|-------|--------|
| Hardcoded credentials | FAIL - never include tokens |
| Missing RID resolution | WARN - use fallback folder |
| Unknown expression type | WARN - add comment for manual review |
| Palantir imports | FAIL - remove all Foundry references |
 
## References
 
- **RID Resolver**: `pipeline_builder/DBX_Conversion/rid_resolver.py`
- **Input JSON**: `pipeline_builder/DBX_Conversion/jsonexports/contour_latest.json`
- **Output**: `pipeline_builder/DBX_Conversion/contour_transformation.py`
- **Previous Workflow**: `/fetch-contour-json`
 
## Version History
 
| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02-04 | Initial release with RID resolution |
 