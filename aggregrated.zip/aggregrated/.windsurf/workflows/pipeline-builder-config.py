# Pipeline Builder Migration Config
# Customize these values for each migration

# Storage Configuration
STORAGE_ACCOUNT = "datalakeeastus2prd"
CONTAINER = "otis-poc"
OUTPUT_FOLDER = "x_site_general_info_parquet"

# Table to ADLS Folder Mapping (case-sensitive)
TABLE_TO_FOLDER_MAPPING = {
    "x_ndr_nokia_enb": "x_ndr_nokia_enb",
    "levo_site_master_brd": "LEVO_SITE_MASTER_BRD",
    "fips_peas_cmas_table1": "FIPS_PEAs_CMAs_Table1",
    "x_eric_5gnr_cell_rrh": "x_eric_5gnr_cell_rrh",
    "x_nok_5gnr_cell_rrh": "x_nok_5gnr_cell_rrh",
    "x_ndr_nokia_lcell_rrh": "x_ndr_nokia_lcell_rrh",
    "x_ndr_eric_lcell_rrh": "x_ndr_eric_lcell_rrh",
    "ericssonlte_nrcelldu": "ERICSSONLTE.NRCellDU",
    "nokialte_nrcell": "nokialte_NRCELL",
}
