---
description: Security configuration for IBM watsonx data services - API keys, vaults, IAM, and service credentials
---

# IBM watsonx Security Configuration

## Overview

Security architecture and credential management patterns for calling IBM watsonx data services from an IDE or automation pipeline.

---

## Supported Authentication Methods

| Method | Use Case | Security Level |
|--------|----------|----------------|
| **API Key** | Service-to-service, automation | Medium |
| **IAM Token** | User context, short-lived access | High |
| **Service ID** | Application identity | High |
| **Trusted Profile** | Cross-account, federated | Very High |
| **Private API Key** | Sensitive operations | Very High |

---

## IBM Cloud IAM Authentication

### Generate IAM Token from API Key

```bash
curl -X POST "https://iam.cloud.ibm.com/identity/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=urn:ibm:params:oauth:grant-type:apikey" \
  -d "apikey=${IBM_CLOUD_API_KEY}"
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "OKC4ZX1...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "expiration": 1706550000,
  "scope": "ibm openid"
}
```

### Python Implementation

```python
import os
import requests
from datetime import datetime, timedelta

class IBMIAMAuth:
    """IBM Cloud IAM authentication handler with token caching."""
    
    IAM_TOKEN_URL = "https://iam.cloud.ibm.com/identity/token"
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get('IBM_CLOUD_API_KEY')
        self._token = None
        self._token_expiry = None
    
    def get_token(self) -> str:
        """Get valid IAM token, refreshing if expired."""
        if self._token and self._token_expiry > datetime.now():
            return self._token
        
        response = requests.post(
            self.IAM_TOKEN_URL,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
                "apikey": self.api_key
            }
        )
        response.raise_for_status()
        
        data = response.json()
        self._token = data['access_token']
        self._token_expiry = datetime.now() + timedelta(seconds=data['expires_in'] - 60)
        
        return self._token
    
    def get_headers(self) -> dict:
        """Get authorization headers for API requests."""
        return {
            "Authorization": f"Bearer {self.get_token()}",
            "Content-Type": "application/json"
        }
```

---

## Secret Storage Options

### Option 1: IBM Key Protect

```python
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_keyprotect import KeyProtectV2

authenticator = IAMAuthenticator(os.environ['IBM_CLOUD_API_KEY'])
key_protect = KeyProtectV2(authenticator=authenticator)
key_protect.set_service_url(os.environ['KEY_PROTECT_URL'])

def get_secret(key_id: str) -> str:
    response = key_protect.get_key(id=key_id)
    return response.result['resources'][0]['payload']
```

### Option 2: IBM Secrets Manager

```python
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_secrets_manager_sdk import SecretsManagerV2

authenticator = IAMAuthenticator(os.environ['IBM_CLOUD_API_KEY'])
secrets_manager = SecretsManagerV2(authenticator=authenticator)
secrets_manager.set_service_url(os.environ['SECRETS_MANAGER_URL'])

def get_secret(secret_id: str) -> dict:
    response = secrets_manager.get_secret(id=secret_id)
    return response.result

def create_secret(name: str, value: str, secret_type: str = 'arbitrary'):
    response = secrets_manager.create_secret(
        secret_prototype={
            'secret_type': secret_type,
            'name': name,
            'payload': value,
            'description': f'Auto-created secret for {name}'
        }
    )
    return response.result['id']
```

**Secret Types:**
| Type | Use Case |
|------|----------|
| `arbitrary` | Any key-value data |
| `username_password` | Database credentials |
| `iam_credentials` | Service ID API keys |
| `kv` | Key-value pairs |
| `imported_cert` | TLS certificates |
| `public_cert` | Public certificates |
| `private_cert` | Private certificates |

### Option 3: HashiCorp Vault (Hybrid)

```python
import hvac
import os

class VaultIBMBridge:
    """Bridge between HashiCorp Vault and IBM services."""
    
    def __init__(self):
        self.vault = hvac.Client(
            url=os.environ['VAULT_ADDR'],
            token=os.environ['VAULT_TOKEN']
        )
    
    def get_ibm_api_key(self, path: str = 'ibm/api-key') -> str:
        secret = self.vault.secrets.kv.v2.read_secret_version(path=path)
        return secret['data']['data']['api_key']
    
    def get_db_credentials(self, service: str) -> dict:
        secret = self.vault.secrets.kv.v2.read_secret_version(
            path=f'ibm/databases/{service}'
        )
        return secret['data']['data']
```

### Option 4: Azure Key Vault (Cross-Cloud)

```python
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

def get_ibm_credentials_from_azure():
    credential = DefaultAzureCredential()
    vault_url = os.environ['AZURE_VAULT_URL']
    client = SecretClient(vault_url=vault_url, credential=credential)
    
    return {
        'api_key': client.get_secret('ibm-cloud-api-key').value,
        'region': client.get_secret('ibm-region').value,
        'project_id': client.get_secret('ibm-project-id').value
    }
```

---

## Service Credentials Configuration

### credentials.yaml Template

```yaml
# IBM watsonx Services Credentials
# Store sensitive values in vault, reference by secret_name

ibm_cloud:
  region: us-south
  resource_group: default
  api_key_secret: ibm-cloud-api-key  # Reference to vault secret

watsonx_data:
  instance_crn: "crn:v1:bluemix:public:lakehouse:us-south:a/xxx:xxx::"
  api_endpoint: https://us-south.lakehouse.cloud.ibm.com

datastage:
  project_id: "${DATASTAGE_PROJECT_ID}"
  api_endpoint: https://api.dataplatform.cloud.ibm.com
  credentials_secret: datastage-service-creds

knowledge_catalog:
  catalog_id: "${WKC_CATALOG_ID}"
  api_endpoint: https://api.dataplatform.cloud.ibm.com
  
manta:
  instance_url: https://manta.us-south.datalineage.cloud.ibm.com
  api_version: v1
  credentials_secret: manta-api-creds

data_product_hub:
  api_endpoint: https://api.dataplatform.cloud.ibm.com
  hub_id: "${DPH_HUB_ID}"

databand:
  tracker_url: https://databand.us-south.cloud.ibm.com
  api_key_secret: databand-api-key

vault:
  provider: ibm_secrets_manager
  url: https://us-south.secrets-manager.cloud.ibm.com
  instance_id: "${SECRETS_MANAGER_INSTANCE_ID}"
```

---

## Environment Variables Reference

```bash
# Core IBM Cloud
export IBM_CLOUD_API_KEY="your-api-key"
export IBM_CLOUD_REGION="us-south"
export IBM_CLOUD_RESOURCE_GROUP="default"

# watsonx.data
export WATSONX_DATA_CRN="crn:v1:bluemix:public:lakehouse:..."
export WATSONX_DATA_ENDPOINT="https://us-south.lakehouse.cloud.ibm.com"

# DataStage
export DATASTAGE_PROJECT_ID="your-project-id"
export DATASTAGE_ENDPOINT="https://api.dataplatform.cloud.ibm.com"

# Knowledge Catalog
export WKC_CATALOG_ID="your-catalog-id"

# Manta
export MANTA_INSTANCE_URL="https://manta.us-south.datalineage.cloud.ibm.com"

# Data Product Hub
export DPH_HUB_ID="your-hub-id"

# Databand
export DATABAND_TRACKER_URL="https://databand.us-south.cloud.ibm.com"
export DATABAND_API_KEY="your-databand-key"

# Secrets Manager
export SECRETS_MANAGER_URL="https://us-south.secrets-manager.cloud.ibm.com"
export SECRETS_MANAGER_INSTANCE_ID="your-instance-id"

# Key Protect
export KEY_PROTECT_URL="https://us-south.kms.cloud.ibm.com"
export KEY_PROTECT_INSTANCE_ID="your-instance-id"
```

---

## Service ID and Trusted Profiles

### Create Service ID

```bash
# Create service ID
ibmcloud iam service-id-create watsonx-etl-service \
  --description "Service ID for watsonx ETL automation"

# Create API key for service ID
ibmcloud iam service-api-key-create watsonx-etl-key watsonx-etl-service \
  --description "API key for ETL service"

# Assign policies
ibmcloud iam service-policy-create watsonx-etl-service \
  --roles Editor \
  --service-name lakehouse

ibmcloud iam service-policy-create watsonx-etl-service \
  --roles Editor \
  --service-name datastage
```

### Trusted Profile for Cross-Account

```bash
# Create trusted profile
ibmcloud iam trusted-profile-create watsonx-cross-account \
  --description "Cross-account access for watsonx services"

# Add trust relationship (Azure DevOps example)
ibmcloud iam trusted-profile-rule-create watsonx-cross-account \
  --name "Azure DevOps Trust" \
  --type "Profile-CR" \
  --conditions claim:iss,operator:equals,value:"https://login.microsoftonline.com/{tenant}/v2.0"
```

---

## Secure Client Factory

```python
import os
import yaml
from typing import Optional
from dataclasses import dataclass

@dataclass
class ServiceConfig:
    endpoint: str
    project_id: Optional[str] = None
    instance_id: Optional[str] = None

class WatsonxClientFactory:
    """Factory for creating authenticated watsonx service clients."""
    
    def __init__(self, config_path: str = "credentials.yaml"):
        self.config = self._load_config(config_path)
        self.auth = IBMIAMAuth()
        self.vault = self._init_vault()
    
    def _load_config(self, path: str) -> dict:
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    
    def _init_vault(self):
        provider = self.config['vault']['provider']
        if provider == 'ibm_secrets_manager':
            return IBMSecretsManagerVault(self.config['vault'])
        elif provider == 'ibm_key_protect':
            return IBMKeyProtectVault(self.config['vault'])
        elif provider == 'hashicorp':
            return HashiCorpVault(self.config['vault'])
        elif provider == 'azure':
            return AzureKeyVault(self.config['vault'])
    
    def get_datastage_client(self):
        return DataStageClient(
            endpoint=self.config['datastage']['api_endpoint'],
            project_id=os.environ.get('DATASTAGE_PROJECT_ID'),
            auth=self.auth
        )
    
    def get_knowledge_catalog_client(self):
        return KnowledgeCatalogClient(
            endpoint=self.config['knowledge_catalog']['api_endpoint'],
            catalog_id=os.environ.get('WKC_CATALOG_ID'),
            auth=self.auth
        )
    
    def get_manta_client(self):
        creds = self.vault.get_secret(self.config['manta']['credentials_secret'])
        return MantaClient(
            url=self.config['manta']['instance_url'],
            api_key=creds['api_key'],
            auth=self.auth
        )
    
    def get_dph_client(self):
        return DataProductHubClient(
            endpoint=self.config['data_product_hub']['api_endpoint'],
            hub_id=os.environ.get('DPH_HUB_ID'),
            auth=self.auth
        )
    
    def get_databand_client(self):
        api_key = self.vault.get_secret(self.config['databand']['api_key_secret'])
        return DatabandClient(
            tracker_url=self.config['databand']['tracker_url'],
            api_key=api_key
        )
```

---

## Private Endpoints

```yaml
private_endpoints:
  datastage: https://private.api.dataplatform.cloud.ibm.com
  knowledge_catalog: https://private.api.dataplatform.cloud.ibm.com
  watsonx_data: https://private.us-south.lakehouse.cloud.ibm.com
  manta: https://private.manta.us-south.datalineage.cloud.ibm.com
  secrets_manager: https://private.us-south.secrets-manager.cloud.ibm.com
```

---

## Security Best Practices

| Practice | Implementation |
|----------|----------------|
| **Rotate API keys** | 90-day rotation policy via IBM IAM |
| **Use Service IDs** | Never use personal API keys in automation |
| **Least privilege** | Grant minimum required IAM policies |
| **Token caching** | Cache IAM tokens, refresh before expiry |
| **Audit logging** | Enable Activity Tracker for all services |
| **Network isolation** | Use private endpoints where available |
| **Encrypt at rest** | Enable encryption for all data stores |
| **MFA for users** | Require MFA for IBM Cloud console access |

---

## Audit & Compliance

### Enable Activity Tracker

```bash
ibmcloud resource service-instance-create watsonx-audit-trail \
  logdnaat 7-day --region us-south
```

### Compliance Controls

| Standard | Controls |
|----------|----------|
| **SOC 2** | Access controls, audit logging, encryption |
| **GDPR** | Data residency, right to erasure, consent |
| **HIPAA** | PHI encryption, access logging, BAA |
| **PCI DSS** | Network segmentation, key management |
