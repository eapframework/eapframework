---
description: Migrate Java Foundry Spark pipeline to PySpark Databricks notebook
---

User input: $ARGUMENTS

## Execution Steps

### 1. Parse Input
Extract from $ARGUMENTS: Java source directory path, target output directory, ADLS storage account, container name. Request clarification if incomplete.

### 2. Load Configuration
- Read `pipeline-builder-config.py` for storage settings and table mappings
- Load Java source files for extraction

### 3. Extract from Java Sources

| Source File | Extract |
|-------------|---------|
| `PipelineComputeTransform.java` | `@Input` annotations → snake_case table names |
| `PipelineOutputs.java` | `Dataset<Row>` fields → output names (strip `ObjectTypeBackingDatasource`) |
| `PipelineLogic.java` | Transform logic: select, join, cast, dropDuplicates patterns |

### 4. Validate Constraints
Check against hard-stop rules:
- ✘ Refuse `dbutils.fs.ls()` for folder discovery (permission errors)
- ✘ Refuse hardcoded credentials or connection strings
- ✘ Refuse Delta format writes to existing Delta folders
- ✘ Refuse joins without duplicate column handling
If violated, explain clearly and suggest compliant alternative.

### 5. Generate PySpark Notebook

Create Databricks notebook with structure:
- **Cell 1**: Configuration (storage account, container, table mappings)
- **Cell 2**: Helper functions
- **Cell 3**: Input loading with retry logic
- **Cell 4**: Transformations (one block per output)
- **Cell 5**: Write outputs as Parquet
- **Cell 6**: Validation summary

Required helper functions:
```python
drop_duplicate_columns(df)  # Rename duplicates with _dup suffix
safe_select(df, columns)    # Select only existing columns
read_parquet_with_retry()   # Retry logic for reads
safe_cast_int_to_string()   # Type casting
construct_geo_point()       # Geo struct builder
```

Apply mandatory patterns:
- Direct parquet reads using `abfss://` paths
- `drop_duplicate_columns()` after every join
- Write Parquet with overwrite mode
- Delete existing output folder before write
- Retry ≥3 with exponential backoff

### 6. Conversion Patterns

| Java | PySpark |
|------|---------|
| `df.select("A", "B")` | `safe_select(df, ["A", "B"])` |
| `col("X").cast("string")` | `F.col("X").cast(StringType())` |
| `df.join(df2, col("A").equalTo(col("B")), "left")` | `df.join(df2, df["A"] == df2["B"], "left")` then `drop_duplicate_columns()` |
| `df.dropDuplicates("KEY")` | `df.dropDuplicates(["KEY"])` |
| `functions.when(...).otherwise(...)` | `F.when(...).otherwise(...)` |

### 7. Validate and Report

Report completion with:
- Generated notebook path
- Input/output table summary
- Applied guardrails
- Testing commands

## Error Handling

**Permission Errors**: Use direct `abfss://` paths, never `dbutils.fs.ls()`.

**Ambiguous Columns**: Apply `drop_duplicate_columns()` after joins to rename duplicates with `_dup` suffix.

**Delta Conflict**: Write to new folder (`_parquet` suffix) or delete existing folder before write.

**Missing Inputs**: Create empty DataFrame with correct schema, log warning, continue processing.

**Incomplete Input**: List missing information (Java source path, storage config), provide example invocation.

## Examples

**Basic Migration**: `/migrate--pipeline-builder-java-foundry-to-pyspark Migrate pipeline_builder Java code to PySpark, storage: datalakeeastus2prd, container: otis-poc`
Output: PySpark notebook with config, helpers, transforms, writes.

**Custom Output**: `/migrate--pipeline-builder-java-foundry-to-pyspark Migrate from transforms-java/src/main/java, output to x_site_general_info_parquet`
Output: PySpark notebook targeting specified output folder.

## References

- Config: `.windsurf/workflows/pipeline-builder-config.py`
- Production Template: `pipeline_builder/DBX_Conversion/pipeline_builder_transform_prod.py`
- Development Template: `pipeline_builder/DBX_Conversion/pipeline_builder_transform.py`
