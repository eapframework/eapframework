---
description: Generate integration tests for end-to-end migration pipeline execution
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /test-migration-orchestrator

Generate comprehensive integration tests for migration pipeline execution, configuration validation, and cross-archetype dependencies.

## When to Use

After:
- Generating migration plan (`/scaffold-migration-orchestrator`)
- Making configuration changes

Before:
- Executing actual migration
- Production deployment

## What to Provide

**Required:**
- Use case name (e.g., "NetAudit")
- Migration plan file path

**Optional:**
- Specific test scenarios to include
- Mock data for testing
- Validation rules to test

## Example Usage

```bash
/test-migration-orchestrator Validate migration config for NetAudit

Test migration plan: outputs/migration/netaudit/migration_plan.yaml
Generate tests for:
- Configuration validation (all YAML files)
- Dependency resolution (archetype execution order)
- End-to-end integration (full migration flow)
- Rollback procedures

Include mock data: true
Output: outputs/migration/netaudit/tests/
```

## Generated Test Structure

```
outputs/migration/{use_case}/tests/
├── test_config_validation.py       # YAML configuration validation
├── test_dependency_resolution.py   # Archetype dependency graph
├── test_integration_flow.py        # End-to-end migration flow
├── test_rollback_procedures.py     # Rollback logic
├── test_parallel_execution.py      # Parallel archetype execution
├── fixtures/
│   ├── mock_palantir_api.json      # Mock API responses
│   ├── mock_pipeline_json.json     # Sample Pipeline JSON
│   ├── mock_contour_json.json      # Sample Contour JSON
│   └── sample_config.yaml          # Test configuration
└── pytest.ini                      # Pytest configuration
```

## Test 1: Configuration Validation

**File**: `test_config_validation.py`

```python
"""
Test configuration validation for migration orchestrator.
Validates YAML schema, required fields, and cross-references.
"""

import pytest
import yaml
from pathlib import Path
from jsonschema import validate, ValidationError

class TestConfigValidation:
    
    @pytest.fixture
    def migration_plan(self):
        """Load migration plan YAML."""
        with open("outputs/migration/netaudit/migration_plan.yaml") as f:
            return yaml.safe_load(f)
    
    @pytest.fixture
    def config_schema(self):
        """Migration plan JSON schema."""
        return {
            "type": "object",
            "required": ["migration", "execution_plan", "options"],
            "properties": {
                "migration": {
                    "type": "object",
                    "required": ["use_case", "environment"],
                    "properties": {
                        "use_case": {"type": "string"},
                        "environment": {"type": "object"}
                    }
                }
            }
        }
    
    def test_migration_plan_schema(self, migration_plan, config_schema):
        """Test migration plan conforms to schema."""
        try:
            validate(instance=migration_plan, schema=config_schema)
        except ValidationError as e:
            pytest.fail(f"Migration plan validation failed: {e.message}")
    
    def test_use_case_name_valid(self, migration_plan):
        """Test use case name is alphanumeric."""
        use_case = migration_plan["migration"]["use_case"]
        assert use_case.replace("_", "").isalnum(), \
            f"Use case name must be alphanumeric: {use_case}"
    
    def test_environment_valid(self, migration_plan):
        """Test environment is prod or dev."""
        env_type = migration_plan["migration"]["environment"]["type"]
        assert env_type in ["prod", "dev"], \
            f"Environment must be 'prod' or 'dev', got: {env_type}"
    
    def test_storage_account_exists(self, migration_plan):
        """Test storage account name provided."""
        storage = migration_plan["migration"]["environment"]["storage_account"]
        assert storage, "Storage account must be specified"
        assert "datalake" in storage.lower(), \
            "Storage account should be Azure Data Lake"
    
    def test_container_exists(self, migration_plan):
        """Test container name provided."""
        container = migration_plan["migration"]["environment"]["container"]
        assert container, "Container must be specified"
    
    def test_all_archetypes_have_configs(self, migration_plan):
        """Test each archetype has a config file."""
        for stage in migration_plan["execution_plan"]:
            for archetype in stage["archetypes"]:
                config_file = archetype.get("config_file")
                assert config_file, \
                    f"Archetype {archetype['name']} missing config_file"
                
                # Check file exists
                config_path = Path(f"outputs/migration/netaudit/{config_file}")
                assert config_path.exists(), \
                    f"Config file not found: {config_file}"
    
    def test_validation_thresholds_valid(self, migration_plan):
        """Test validation thresholds are percentages."""
        for stage in migration_plan["execution_plan"]:
            for archetype in stage["archetypes"]:
                if archetype["name"] == "data-validator":
                    thresholds = archetype["inputs"]["thresholds"]
                    for layer, threshold in thresholds.items():
                        assert 0 <= threshold <= 100, \
                            f"Threshold for {layer} must be 0-100, got: {threshold}"
```

## Test 2: Dependency Resolution

**File**: `test_dependency_resolution.py`

```python
"""
Test archetype dependency resolution and execution order.
"""

import pytest
import yaml
from collections import defaultdict

class TestDependencyResolution:
    
    @pytest.fixture
    def execution_plan(self):
        """Load execution plan from migration plan."""
        with open("outputs/migration/netaudit/migration_plan.yaml") as f:
            plan = yaml.safe_load(f)
        return plan["execution_plan"]
    
    def test_no_circular_dependencies(self, execution_plan):
        """Test dependency graph has no cycles."""
        # Build dependency graph
        graph = defaultdict(list)
        for stage in execution_plan:
            stage_name = stage["name"]
            depends_on = stage.get("depends_on", [])
            for dep in depends_on:
                graph[stage_name].append(dep)
        
        # Detect cycles using DFS
        visited = set()
        rec_stack = set()
        
        def has_cycle(node):
            visited.add(node)
            rec_stack.add(node)
            
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    if has_cycle(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True
            
            rec_stack.remove(node)
            return False
        
        for node in graph:
            if node not in visited:
                assert not has_cycle(node), \
                    f"Circular dependency detected involving: {node}"
    
    def test_dependencies_exist(self, execution_plan):
        """Test all dependencies reference existing stages."""
        # Get all stage names
        stage_names = {stage["name"] for stage in execution_plan}
        
        # Check each dependency exists
        for stage in execution_plan:
            for dep in stage.get("depends_on", []):
                assert dep in stage_names, \
                    f"Stage '{stage['name']}' depends on non-existent stage: {dep}"
    
    def test_stage_order_respects_dependencies(self, execution_plan):
        """Test stages are ordered correctly based on dependencies."""
        completed = set()
        
        for idx, stage in enumerate(execution_plan):
            stage_name = stage["name"]
            depends_on = set(stage.get("depends_on", []))
            
            # All dependencies should be in completed set
            missing = depends_on - completed
            assert not missing, \
                f"Stage {idx} ('{stage_name}') has unmet dependencies: {missing}"
            
            completed.add(stage_name)
    
    def test_parallel_stages_are_independent(self, execution_plan):
        """Test parallel archetypes have no mutual dependencies."""
        for stage in execution_plan:
            if stage.get("parallel", False):
                archetypes = stage["archetypes"]
                archetype_names = {a["name"] for a in archetypes}
                
                # Check no internal dependencies
                for archetype in archetypes:
                    deps = archetype.get("depends_on", [])
                    internal_deps = set(deps) & archetype_names
                    assert not internal_deps, \
                        f"Parallel archetype '{archetype['name']}' has internal dependency: {internal_deps}"
```

## Test 3: End-to-End Integration

**File**: `test_integration_flow.py`

```python
"""
Test end-to-end migration flow execution.
"""

import pytest
import subprocess
from pathlib import Path

class TestIntegrationFlow:
    
    @pytest.fixture
    def migration_script(self):
        """Path to migration script."""
        return Path("outputs/migration/netaudit/run_migration.sh")
    
    def test_migration_script_exists(self, migration_script):
        """Test migration script was generated."""
        assert migration_script.exists(), \
            "Migration script not found"
    
    def test_migration_script_executable(self, migration_script):
        """Test migration script has execute permissions."""
        assert migration_script.stat().st_mode & 0o111, \
            "Migration script not executable"
    
    def test_dry_run_succeeds(self, migration_script):
        """Test dry run completes without errors."""
        result = subprocess.run(
            [str(migration_script), "--dry-run"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Dry run failed: {result.stderr}"
    
    def test_dry_run_output_format(self, migration_script):
        """Test dry run produces expected log output."""
        result = subprocess.run(
            [str(migration_script), "--dry-run"],
            capture_output=True,
            text=True
        )
        
        # Check for expected log messages
        assert "[INFO]" in result.stdout
        assert "[DRY RUN]" in result.stdout
        assert "Starting migration" in result.stdout
        assert "Completed" in result.stdout
    
    @pytest.mark.skip(reason="Requires actual Palantir/Azure access")
    def test_full_migration_flow(self, migration_script):
        """Test actual migration execution (integration test)."""
        result = subprocess.run(
            [str(migration_script)],
            capture_output=True,
            text=True,
            timeout=3600  # 1 hour timeout
        )
        assert result.returncode == 0, \
            f"Migration failed: {result.stderr}"
```

## Test 4: Rollback Procedures

**File**: `test_rollback_procedures.py`

```python
"""
Test rollback procedures for migration failure scenarios.
"""

import pytest
import yaml

class TestRollbackProcedures:
    
    @pytest.fixture
    def rollback_plan(self):
        """Load rollback plan YAML."""
        with open("outputs/migration/netaudit/rollback_plan.yaml") as f:
            return yaml.safe_load(f)
    
    def test_rollback_plan_exists(self, rollback_plan):
        """Test rollback plan was generated."""
        assert rollback_plan, "Rollback plan is empty"
        assert "rollback" in rollback_plan
    
    def test_all_stages_have_rollback(self, rollback_plan):
        """Test each stage has rollback procedures."""
        procedures = rollback_plan["rollback"]["procedures"]
        
        # Expected stages
        expected_stages = [
            "validation",
            "ingestion-generation",
            "code-generation",
            "metadata-extraction"
        ]
        
        actual_stages = {p["stage"] for p in procedures}
        
        for stage in expected_stages:
            assert stage in actual_stages, \
                f"Missing rollback procedure for stage: {stage}"
    
    def test_rollback_actions_defined(self, rollback_plan):
        """Test each rollback has defined actions."""
        procedures = rollback_plan["rollback"]["procedures"]
        
        for procedure in procedures:
            steps = procedure.get("rollback_steps", [])
            assert steps, \
                f"Stage '{procedure['stage']}' has no rollback steps"
            
            for step in steps:
                assert "action" in step, \
                    f"Rollback step missing 'action' field"
```

## Pytest Configuration

**File**: `pytest.ini`

```ini
[pytest]
testpaths = outputs/migration/netaudit/tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = 
    -v
    --strict-markers
    --tb=short
    --disable-warnings

markers =
    unit: Unit tests
    integration: Integration tests (require external systems)
    slow: Tests that take > 1 minute
```

## Running Tests

```bash
# Run all tests
pytest outputs/migration/netaudit/tests/

# Run specific test file
pytest outputs/migration/netaudit/tests/test_config_validation.py

# Run with verbose output
pytest -v outputs/migration/netaudit/tests/

# Run only fast tests (exclude integration)
pytest -m "not integration" outputs/migration/netaudit/tests/

# Generate coverage report
pytest --cov=migration --cov-report=html outputs/migration/netaudit/tests/
```

## Success Criteria

All tests pass:
- [x] Configuration validation (YAML schema, required fields)
- [x] Dependency resolution (no cycles, correct order)
- [x] Dry run execution (script runs without errors)
- [x] Rollback procedures (all stages covered)

## See Also

- [scaffold-migration-orchestrator.md](scaffold-migration-orchestrator.md) - Generate migration plan
- [debug-migration-orchestrator.md](debug-migration-orchestrator.md) - Troubleshoot test failures
