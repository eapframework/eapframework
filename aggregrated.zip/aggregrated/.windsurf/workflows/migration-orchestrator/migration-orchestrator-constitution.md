---
description: Orchestrate end-to-end Palantir to Azure migration pipeline across all archetypes
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# Migration Orchestrator Workflow

**Archetype**: Migration Orchestrator
**Purpose**: Chain all migration archetypes to execute full Palantir → Azure data pipeline migration
**Complexity**: High
**Expected Duration**: 2-4 hours per use case (full migration)

---

## When to Use This Workflow

Use `/migration-orchestrator` when you encounter:
- Need to migrate a complete Palantir use case to Azure
- Coordinating multiple archetypes (ingestion → transformation → validation)
- Managing dependencies between migration phases
- Executing production cutover
- Debugging cross-archetype integration issues
- Planning migration waves (multiple use cases)

---

## What This Workflow Does

**End-to-End Migration Flow**:
1. **Metadata Extraction** → Fetch Pipeline/Contour JSON from Palantir API
2. **Code Generation** → Convert JSON to PySpark notebooks (Silver/Gold layers)
3. **Transform Conversion** → Convert existing Foundry Python to Databricks PySpark
4. **Raw Ingestion** → Generate Bronze layer ingestion from source systems
5. **Data Validation** → Verify row count parity (Palantir vs Azure)
6. **Deployment** → Package and deploy to Databricks workspace

**Orchestration Features**:
- Sequential execution with dependency resolution
- Parallel execution where archetypes are independent
- Rollback procedures on failure
- Progress tracking and reporting
- Multi-environment support (dev, prod)
- Configuration validation before execution

**Migration Modes**:
- **Full Migration**: All 6 phases for new use case
- **Incremental Update**: Re-run specific archetypes only
- **Validation Only**: Run data-validator without regeneration
- **Dry Run**: Validate configs without executing

---

## Core Workflows

### `/scaffold-migration-orchestrator`
Generate end-to-end migration pipeline for a use case

**Triggers:**
- "generate full migration"
- "create migration pipeline"
- "scaffold migration for [use case]"

**Outputs:**
- `migration_plan.yaml` - Execution plan with dependencies
- `run_migration.sh` - Shell script to execute all archetypes
- `rollback_plan.yaml` - Rollback procedures
- `validation_report.json` - Pre-migration validation results

### `/test-migration-orchestrator`
Generate integration tests for full migration flow

**Triggers:**
- "test full migration"
- "create integration tests"
- "test cross-archetype dependencies"

**Outputs:**
- `test_migration_flow.py` - End-to-end integration tests
- `test_config_validation.py` - Configuration validation tests
- `test_dependency_resolution.py` - Dependency graph tests
- Mock fixtures for deterministic testing

### `/compare-migration-orchestrator`
Decide migration execution strategy before building

**Decision Points:**
- Sequential vs parallel archetype execution
- Pipeline vs Contour priority (which to migrate first)
- Full migration vs incremental approach
- Manual orchestration vs automated workflow
- Databricks Jobs API vs notebook execution

### `/debug-migration-orchestrator`
Troubleshoot cross-archetype integration failures

**Common Issues:**
- Dependency resolution failures (archetype X needs output from Y)
- Configuration conflicts (different YAML configs)
- Authentication failures across services
- Data flow errors (output of archetype X not compatible with archetype Y)
- Environment setup issues (missing credentials, paths)

### `/document-migration-orchestrator`
Generate migration playbook for operational use

**Output:**
- Pre-migration checklist (all prerequisites)
- Migration execution steps (detailed runbook)
- Post-migration validation procedures
- Rollback procedures (if migration fails)
- Production cutover guide (go-live steps)

### `/refactor-migration-orchestrator`
Improve orchestration configuration and code quality

**Goals:**
- YAML configuration validation and schema enforcement
- Extract reusable migration patterns
- Optimize parallel execution strategies
- Improve error handling and logging
- Secrets management best practices

---

## Dependencies

**Prerequisites:**
- All 5 archetypes available:
  - `ingestion-specialist` (Bronze layer)
  - `transform-converter` (Foundry Python conversion)
  - `metadata-extractor` (API JSON fetching)
  - `pipeline-generator` (PySpark notebook generation)
  - `data-validator` (Row count validation)
- External:
  - Palantir Foundry API access (Bearer token)
  - Databricks workspace access
  - Azure ADLS Gen2 storage account
  - Source system connectivity (Oracle, Snowflake, etc.)

**Consumers:**
- POC evidence pack (migration success metrics)
- Production deployment automation
- Migration wave planning (multi-use case rollout)

---

## Migration Execution Order

**Standard Sequential Flow**:
```
1. metadata-extractor (fetch Pipeline/Contour JSON)
   ↓
2. pipeline-generator (generate Silver/Gold notebooks)
   ↓
3. transform-converter (convert Foundry Python)
   ↓
4. ingestion-specialist (generate Bronze ingestion)
   ↓
5. data-validator (validate all layers)
```

**Parallel Execution Opportunities**:
- Steps 2 + 3 can run in parallel (independent)
- Pipeline and Contour extraction can run in parallel
- Multiple use cases can be migrated in parallel (separate pipelines)

**Critical Path**:
- Step 1 must complete before Step 2 (need JSON)
- Steps 2-4 must complete before Step 5 (need outputs to validate)

---

## Configuration Schema

**Migration Config** (`palantir-migration-config.yaml`):
```yaml
migration:
  use_case: "netaudit"  # or "site_master", etc.
  mode: "full"  # or "incremental", "validation-only", "dry-run"
  environment: "prod"  # or "dev"
  
  # Archetype execution plan
  archetypes:
    - name: metadata-extractor
      enabled: true
      config:
        pipeline_rid: "ri.eddie.main.pipeline.xxx"
        fetch_contour: true
    
    - name: pipeline-generator
      enabled: true
      depends_on: ["metadata-extractor"]
      config:
        json_file: "netaudit_latest.json"
        output_folder: "netaudit_outputs"
    
    - name: transform-converter
      enabled: true
      config:
        source_dir: "Snowflake-DIY-NETAUDIT-Python/transforms-python"
    
    - name: ingestion-specialist
      enabled: true
      config:
        tables: ["x_ndr_nokia_enb", "x_eric_5gnr_cell_rrh"]
    
    - name: data-validator
      enabled: true
      depends_on: ["pipeline-generator", "ingestion-specialist"]
      config:
        layers: ["bronze", "silver", "gold"]
        thresholds:
          bronze: 0.5
          silver: 0.5
          gold: 0.1
  
  # Execution options
  execution:
    parallel: false  # true for parallel execution where possible
    continue_on_error: false  # stop on first failure
    dry_run: false  # validate without executing
    
  # Rollback options
  rollback:
    enabled: true
    backup_outputs: true
    cleanup_on_failure: true
```

---

## Success Criteria

**Full Migration Success**:
- [ ] All archetypes executed without errors
- [ ] All dependencies resolved correctly
- [ ] Data validation passed (all layers within thresholds)
- [ ] Generated notebooks execute successfully in Databricks
- [ ] Configuration validated before execution
- [ ] Migration report generated with timestamps

**Incremental Migration Success**:
- [ ] Specified archetypes executed successfully
- [ ] No impact to previously migrated components
- [ ] Validation confirms no regression

---

## Tags

- migration
- orchestration
- end-to-end
- cross-archetype
- dependency-resolution
- production-deployment
- wave-planning
