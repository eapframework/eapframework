---
description: Compare migration execution strategies and make architectural decisions
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /compare-migration-orchestrator

Compare different migration execution strategies and make architectural decisions before building the migration pipeline.

## When to Use

Before:
- Generating migration plan (`/scaffold-migration-orchestrator`)
- First-time migration of a use case
- Changing execution strategy

After:
- Requirements gathering
- Understanding use case complexity

## Decision Framework

### Decision 1: Sequential vs Parallel Execution

**Option A: Sequential Execution**
```yaml
execution:
  mode: sequential
  stages:
    - metadata-extraction  (wait for completion)
    - code-generation      (wait for completion)
    - ingestion-generation (wait for completion)
    - validation          (wait for completion)
```

**Pros:**
- ✅ Simpler to debug (one thing at a time)
- ✅ Lower resource usage (one archetype running)
- ✅ Clearer progress tracking
- ✅ Easier rollback on failure
- ✅ Recommended for first migration

**Cons:**
- ❌ Longer total execution time
- ❌ Inefficient for independent archetypes
- ❌ Not scalable for multi-use-case waves

**When to use:**
- First migration of a use case
- POC or development environment
- Debugging migration issues
- Limited infrastructure resources

---

**Option B: Parallel Execution**
```yaml
execution:
  mode: parallel
  stages:
    - metadata-extraction                              (Stage 1)
    - code-generation (parallel: pipeline + transform) (Stage 2)
    - ingestion-generation                             (Stage 3)
    - validation                                      (Stage 4)
```

**Pros:**
- ✅ Faster total execution time (40-50% reduction)
- ✅ Better resource utilization
- ✅ Scalable for multi-use-case waves
- ✅ Production-ready approach

**Cons:**
- ❌ More complex to debug (multiple failures)
- ❌ Higher resource requirements
- ❌ Harder to track progress
- ❌ Rollback complexity increases

**When to use:**
- Production migrations
- Multi-use-case migration waves
- Mature migration process
- Abundant infrastructure resources

---

**Recommendation:**
- **POC/First Migration**: Sequential
- **Production**: Parallel (where archetypes are independent)
- **Hybrid**: Sequential for dependent stages, parallel within stages

---

### Decision 2: Pipeline vs Contour Priority

**Option A: Pipeline First**
```yaml
execution_plan:
  - stage: metadata-extraction
    archetypes:
      - metadata-extractor (Pipeline JSON only)
  - stage: code-generation
    archetypes:
      - pipeline-generator (Pipeline → PySpark)
```

**Pros:**
- ✅ Pipeline JSON has more complete metadata
- ✅ Simpler structure (datasets, transforms, outputs)
- ✅ Better for Silver/Gold layer generation
- ✅ Most use cases rely on Pipeline Builder

**Cons:**
- ❌ Misses Contour-specific transformations
- ❌ Incomplete for hybrid use cases

**When to use:**
- Use case primarily uses Pipeline Builder
- Contour is optional or supplementary
- Silver/Gold layers are priority

---

**Option B: Contour First**
```yaml
execution_plan:
  - stage: metadata-extraction
    archetypes:
      - metadata-extractor (Contour JSON only)
  - stage: code-generation
    archetypes:
      - pipeline-generator (Contour → PySpark)
```

**Pros:**
- ✅ Captures visual analysis transformations
- ✅ Better for data exploration use cases
- ✅ Simpler expression-based transforms

**Cons:**
- ❌ Less metadata than Pipeline JSON
- ❌ Missing complex join logic
- ❌ Not all use cases have Contour

**When to use:**
- Use case primarily uses Contour analysis
- Exploratory data analysis workflows
- Simple aggregation/filtering use cases

---

**Option C: Both (Parallel)**
```yaml
execution_plan:
  - stage: metadata-extraction
    parallel: true
    archetypes:
      - metadata-extractor (Pipeline JSON)
      - metadata-extractor (Contour JSON)
  - stage: code-generation
    archetypes:
      - pipeline-generator (both JSONs)
```

**Pros:**
- ✅ Complete metadata extraction
- ✅ No information loss
- ✅ Handles hybrid use cases
- ✅ Faster than sequential

**Cons:**
- ❌ Duplicate transformations may occur
- ❌ Requires merging logic in pipeline-generator
- ❌ Higher API call volume

**When to use:**
- Hybrid use cases (Pipeline + Contour)
- Complete migration (no missing transformations)
- Production migrations with API quota

---

**Recommendation:**
- **Pipeline Only**: Most common use cases
- **Both (Parallel)**: Hybrid use cases or complete migrations
- **Contour Only**: Rare (only for pure exploration use cases)

---

### Decision 3: Full Migration vs Incremental Approach

**Option A: Full Migration (All Archetypes)**
```yaml
archetypes:
  - metadata-extractor
  - pipeline-generator
  - transform-converter
  - ingestion-specialist
  - data-validator
```

**Pros:**
- ✅ Complete end-to-end migration
- ✅ All layers migrated (Bronze, Silver, Gold)
- ✅ Validation proves correctness
- ✅ Production-ready output

**Cons:**
- ❌ Longer execution time (1-4 hours)
- ❌ Higher failure risk (more moving parts)
- ❌ More resources required

**When to use:**
- New use case migration
- POC completion
- Production cutover
- Full validation required

---

**Option B: Incremental Approach (Subset of Archetypes)**

**Example: Validation Only**
```yaml
archetypes:
  - data-validator  # Re-validate after config changes
```

**Example: Code Update Only**
```yaml
archetypes:
  - pipeline-generator  # Regenerate notebooks after JSON update
  - data-validator      # Re-validate outputs
```

**Pros:**
- ✅ Faster execution (minutes vs hours)
- ✅ Lower failure risk (fewer dependencies)
- ✅ Iterative development approach
- ✅ Efficient for updates

**Cons:**
- ❌ Incomplete migration (missing layers)
- ❌ Manual dependency tracking
- ❌ May miss integration issues

**When to use:**
- Configuration changes (validation thresholds)
- Code updates (regenerate notebooks)
- Bug fixes (specific archetype)
- Iterative development

---

**Recommendation:**
- **First Migration**: Full migration
- **Updates/Bug Fixes**: Incremental (specific archetypes)
- **Config Changes**: Validation only
- **JSON Updates**: metadata-extractor + pipeline-generator

---

### Decision 4: Manual Orchestration vs Automated Workflow

**Option A: Manual Orchestration**
```bash
# Run each archetype manually
/metadata-extractor fetch pipeline: {rid}
/pipeline-generator migrate {json_file}
/transform-converter convert {python_files}
/ingestion-specialist generate for {tables}
/data-validator validate all layers
```

**Pros:**
- ✅ Full control over each step
- ✅ Easier to debug (pause between steps)
- ✅ No orchestration overhead
- ✅ Good for learning/POC

**Cons:**
- ❌ Error-prone (manual steps)
- ❌ Not repeatable (no automation)
- ❌ Slow (human intervention)
- ❌ Not scalable

**When to use:**
- Learning the migration process
- POC or experimentation
- One-off migrations
- Debugging specific archetypes

---

**Option B: Automated Workflow (Shell Script)**
```bash
# Generated script executes all archetypes
./outputs/migration/netaudit/run_migration.sh
```

**Pros:**
- ✅ Repeatable (same every time)
- ✅ Fast (no human intervention)
- ✅ Scalable (multi-use-case waves)
- ✅ Production-ready

**Cons:**
- ❌ Less control (automated execution)
- ❌ Harder to debug (logs instead of interactive)
- ❌ Requires upfront planning (migration plan)

**When to use:**
- Production migrations
- Multi-use-case waves
- Mature migration process
- CI/CD integration

---

**Option C: Databricks Jobs API**
```yaml
# Databricks workflow orchestration
jobs:
  - task: metadata-extraction
    notebook_path: /Workspace/migration/fetch_metadata.py
  - task: code-generation
    notebook_path: /Workspace/migration/generate_code.py
    depends_on: [metadata-extraction]
```

**Pros:**
- ✅ Native Databricks orchestration
- ✅ Built-in retry logic
- ✅ Job history and monitoring
- ✅ Cluster management

**Cons:**
- ❌ Databricks-specific (vendor lock-in)
- ❌ Requires notebook conversion (not shell scripts)
- ❌ More complex setup
- ❌ API rate limits

**When to use:**
- Databricks-centric architecture
- Production automation
- Need job monitoring/alerting
- Long-running migrations

---

**Recommendation:**
- **POC/Learning**: Manual orchestration
- **Production**: Automated workflow (shell script)
- **Enterprise Scale**: Databricks Jobs API (if using Databricks extensively)

---

### Decision 5: Single Environment vs Multi-Environment

**Option A: Single Environment (Prod Only)**
```yaml
environment:
  type: prod
  storage_account: datalakeeastus2prd
  container: otis-poc
```

**Pros:**
- ✅ Simpler configuration
- ✅ Fewer resources required
- ✅ Direct to production approach

**Cons:**
- ❌ No testing environment
- ❌ Higher risk (no dry run)
- ❌ Limited rollback options

**When to use:**
- POC only
- Small-scale migrations
- Throwaway environments

---

**Option B: Multi-Environment (Dev + Prod)**
```yaml
environments:
  dev:
    storage_account: datalakeeastus2dev
    container: otis-poc-dev
  prod:
    storage_account: datalakeeastus2prd
    container: otis-poc
```

**Pros:**
- ✅ Safe testing in dev first
- ✅ Lower production risk
- ✅ Rollback to dev if prod fails
- ✅ Production best practice

**Cons:**
- ❌ More resources (2 storage accounts)
- ❌ More complex configuration
- ❌ Longer migration time (dev then prod)

**When to use:**
- Production migrations
- Multi-team environments
- Risk-averse organizations
- Long-term migrations

---

**Recommendation:**
- **POC**: Single environment (prod)
- **Production**: Multi-environment (dev → prod promotion)

---

## Decision Matrix

| Use Case | Sequential/Parallel | Pipeline/Contour | Full/Incremental | Manual/Automated | Single/Multi Env |
|----------|---------------------|------------------|------------------|------------------|------------------|
| **POC First Migration** | Sequential | Pipeline First | Full | Manual | Single (Prod) |
| **Production Migration** | Parallel | Both (Parallel) | Full | Automated | Multi (Dev → Prod) |
| **Config Update** | Sequential | N/A | Incremental | Manual | Single |
| **Multi-Use-Case Wave** | Parallel | Both (Parallel) | Full | Automated (Jobs API) | Multi |
| **Bug Fix** | Sequential | N/A | Incremental | Manual | Dev Only |
| **JSON Update** | Sequential | Pipeline First | Incremental | Automated | Prod |

---

## Example Scenarios

### Scenario 1: NetAudit POC (First Migration)

**Decisions:**
- Sequential execution (easier to debug)
- Pipeline first (most metadata)
- Full migration (need all layers)
- Manual orchestration (learning)
- Single environment (POC only)

**Rationale**: First migration, learning process, need visibility into each step.

---

### Scenario 2: Production Cutover (NetAudit)

**Decisions:**
- Parallel execution (faster)
- Both Pipeline + Contour (complete migration)
- Full migration (production-ready)
- Automated workflow (repeatable)
- Multi-environment (dev → prod)

**Rationale**: Production-ready, need speed and repeatability, risk mitigation with dev environment.

---

### Scenario 3: Validation Threshold Update

**Decisions:**
- Sequential execution (simple change)
- N/A (no metadata needed)
- Incremental (data-validator only)
- Manual orchestration (one command)
- Single environment (prod only)

**Rationale**: Quick update, no dependencies, minimal risk.

---

## See Also

- [scaffold-migration-orchestrator.md](scaffold-migration-orchestrator.md) - Generate migration plan using selected strategy
- [document-migration-orchestrator.md](document-migration-orchestrator.md) - Migration playbook
- [test-migration-orchestrator.md](test-migration-orchestrator.md) - Validate strategy with tests
