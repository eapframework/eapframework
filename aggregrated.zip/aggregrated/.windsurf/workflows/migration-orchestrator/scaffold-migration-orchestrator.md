---
description: Generate end-to-end migration pipeline with dependency resolution and execution plan
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /scaffold-migration-orchestrator

Generate complete migration pipeline for a Palantir use case including execution plan, shell scripts, and rollback procedures.

## When to Use

After:
- Planning a new use case migration
- Defining requirements (source systems, target layers, validation criteria)
- Reviewing `compare-migration-orchestrator` for strategy selection

Before:
- Executing actual migration
- Running integration tests

## What to Provide

**Required:**
- Use case name (e.g., "NetAudit", "SiteMaster")
- Pipeline RID (from Palantir) OR Contour ref RID
- Source systems (Oracle, Snowflake, etc.)
- Target environment (prod, dev)

**Optional:**
- Custom execution order (override defaults)
- Parallel execution preferences
- Validation thresholds per layer
- Rollback strategy preferences

## Example Usage

```bash
/scaffold-migration-orchestrator Full migration for NetAudit

Context:
- Use case: OTIS Network Audit (Nokia/Ericsson cell data)
- Pipeline RID: ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043
- Source systems: Oracle (x_ndr_nokia_enb), Snowflake (site master)
- Target environment: prod (datalakeeastus2prd, container: otis-poc)
- Layers: Bronze, Silver, Gold
- Validation thresholds: Bronze ±0.5%, Silver ±0.5%, Gold ±0.1%

Migration plan:
1. Extract metadata (Pipeline + Contour JSON)
2. Generate PySpark notebooks (Silver/Gold from JSON)
3. Convert Foundry transforms (existing Python files)
4. Generate Bronze ingestion (from Oracle/Snowflake)
5. Validate all layers (row count parity)

Execution mode: Sequential (recommended for first migration)
Output directory: outputs/migration/netaudit/
```

## Generated File Structure

```
outputs/migration/{use_case_name}/
├── migration_plan.yaml          # Execution plan with dependencies
├── run_migration.sh             # Shell script to execute all archetypes
├── rollback_plan.yaml           # Rollback procedures per archetype
├── config/
│   ├── metadata_extractor.yaml  # Config for archetype 1
│   ├── pipeline_generator.yaml  # Config for archetype 2
│   ├── transform_converter.yaml # Config for archetype 3
│   ├── ingestion_specialist.yaml # Config for archetype 4
│   └── data_validator.yaml      # Config for archetype 5
├── validation/
│   ├── pre_migration_checks.json  # Prerequisites validation
│   └── config_validation.json      # YAML config validation
└── reports/
    └── migration_plan_summary.md   # Human-readable summary
```

## Migration Plan Template (YAML)

```yaml
# migration_plan.yaml
migration:
  use_case: "{use_case_name}"
  created_at: "2026-02-05T10:30:00Z"
  created_by: "migration-orchestrator"
  version: "1.0.0"
  
  environment:
    type: "prod"  # or "dev"
    storage_account: "datalakeeastus2prd"
    container: "otis-poc"
  
  # Archetype execution graph
  execution_plan:
    - stage: 1
      name: "metadata-extraction"
      archetypes:
        - name: metadata-extractor
          workflow: scaffold-metadata-extractor
          config_file: "config/metadata_extractor.yaml"
          inputs:
            pipeline_rid: "ri.eddie.main.pipeline.xxx"
            fetch_contour: true
          outputs:
            - "pipeline_json/netaudit_latest.json"
            - "jsonexports/contour_latest.json"
          estimated_duration: "5 minutes"
          
    - stage: 2
      name: "code-generation"
      depends_on: ["metadata-extraction"]
      parallel: true  # pipeline-generator and transform-converter can run in parallel
      archetypes:
        - name: pipeline-generator
          workflow: scaffold-pipeline-generator
          config_file: "config/pipeline_generator.yaml"
          inputs:
            - "pipeline_json/netaudit_latest.json"
            - "jsonexports/contour_latest.json"
          outputs:
            - "DBX_Conversion/netaudit_pipeline.py"
            - "DBX_Conversion/contour_transformation.py"
          estimated_duration: "10 minutes"
          
        - name: transform-converter
          workflow: scaffold-transform-converter
          config_file: "config/transform_converter.yaml"
          inputs:
            - "Snowflake-DIY-NETAUDIT-Python/transforms-python/src/**/*.py"
          outputs:
            - "generated/transforms/*.py"
          estimated_duration: "15 minutes"
          
    - stage: 3
      name: "ingestion-generation"
      depends_on: ["code-generation"]
      archetypes:
        - name: ingestion-specialist
          workflow: scaffold-ingestion-specialist
          config_file: "config/ingestion_specialist.yaml"
          inputs:
            tables:
              - "x_ndr_nokia_enb"
              - "x_eric_5gnr_cell_rrh"
              - "levo_site_master_brd"
          outputs:
            - "generated/ingest_raw/*.py"
            - "generated/ingest_raw/*.yaml"
          estimated_duration: "10 minutes"
          
    - stage: 4
      name: "validation"
      depends_on: ["code-generation", "ingestion-generation"]
      archetypes:
        - name: data-validator
          workflow: scaffold-data-validator
          config_file: "config/data_validator.yaml"
          inputs:
            layers: ["bronze", "silver", "gold"]
            thresholds:
              bronze: 0.5
              silver: 0.5
              gold: 0.1
          outputs:
            - "validation/notebooks/validate_all_layers.py"
            - "validation/reports/validation_results.json"
          estimated_duration: "20 minutes"
  
  # Total estimated time
  total_estimated_duration: "60 minutes"
  
  # Execution options
  options:
    parallel_execution: false  # Set to true for parallel stage execution
    continue_on_error: false   # Stop on first failure
    dry_run: false             # Validate without executing
    verbose_logging: true
    
  # Rollback configuration
  rollback:
    enabled: true
    backup_outputs: true
    cleanup_on_failure: true
    backup_location: "outputs/migration/{use_case_name}/backups/"
```

## Shell Script Template (run_migration.sh)

```bash
#!/bin/bash
# Generated migration script for {use_case_name}
# Created: {timestamp}
# DO NOT EDIT MANUALLY - regenerate using /scaffold-migration-orchestrator

set -euo pipefail  # Exit on error, undefined vars, pipe failures

# Configuration
USE_CASE="{use_case_name}"
CONFIG_DIR="$(dirname "$0")/config"
OUTPUT_DIR="$(dirname "$0")"
DRY_RUN=false
VERBOSE=false

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --dry-run)
      DRY_RUN=true
      shift
      ;;
    --verbose)
      VERBOSE=true
      shift
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

# Logging functions
log_info() {
  echo "[INFO] $(date +'%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
  echo "[ERROR] $(date +'%Y-%m-%d %H:%M:%S') - $1" >&2
}

log_success() {
  echo "[SUCCESS] $(date +'%Y-%m-%d %H:%M:%S') - $1"
}

# Stage execution function
execute_stage() {
  local stage_name=$1
  local stage_num=$2
  
  log_info "Starting Stage $stage_num: $stage_name"
  
  if [ "$DRY_RUN" = true ]; then
    log_info "[DRY RUN] Would execute: $stage_name"
    return 0
  fi
  
  # Actual execution logic here
  # Call appropriate archetype workflows
  
  log_success "Completed Stage $stage_num: $stage_name"
}

# Main execution
main() {
  log_info "Starting migration for use case: $USE_CASE"
  
  if [ "$DRY_RUN" = true ]; then
    log_info "DRY RUN MODE - No actual execution"
  fi
  
  # Stage 1: Metadata Extraction
  execute_stage "metadata-extraction" 1
  # /metadata-extractor fetch pipeline: {pipeline_rid}
  
  # Stage 2: Code Generation (parallel if configured)
  execute_stage "code-generation" 2
  # /pipeline-generator migrate {json_file}
  # /transform-converter convert {python_files}
  
  # Stage 3: Ingestion Generation
  execute_stage "ingestion-generation" 3
  # /ingestion-specialist generate for tables: {table_list}
  
  # Stage 4: Validation
  execute_stage "validation" 4
  # /data-validator validate all layers
  
  log_success "Migration pipeline completed successfully"
  log_info "Results saved to: $OUTPUT_DIR/reports/"
}

# Error handler
trap 'log_error "Migration failed at line $LINENO"' ERR

# Execute
main "$@"
```

## Rollback Plan Template (rollback_plan.yaml)

```yaml
# rollback_plan.yaml
rollback:
  use_case: "{use_case_name}"
  
  procedures:
    - stage: "validation"
      archetype: data-validator
      rollback_steps:
        - action: "delete_validation_notebooks"
          path: "outputs/validation/notebooks/"
        - action: "restore_previous_thresholds"
          config: "config/data_validator.yaml"
          
    - stage: "ingestion-generation"
      archetype: ingestion-specialist
      rollback_steps:
        - action: "delete_generated_notebooks"
          path: "generated/ingest_raw/"
        - action: "restore_previous_configs"
          path: "generated/ingest_raw/*.yaml"
          
    - stage: "code-generation"
      archetype: pipeline-generator
      rollback_steps:
        - action: "delete_generated_notebooks"
          path: "DBX_Conversion/*.py"
        - action: "remove_databricks_jobs"
          job_pattern: "{use_case}_*"
          
    - stage: "code-generation"
      archetype: transform-converter
      rollback_steps:
        - action: "delete_converted_transforms"
          path: "generated/transforms/"
          
    - stage: "metadata-extraction"
      archetype: metadata-extractor
      rollback_steps:
        - action: "delete_json_exports"
          path: "pipeline_json/{use_case}_*.json"
        - action: "delete_json_exports"
          path: "jsonexports/contour_*.json"
```

## Configuration Validation

Before generating files, validate:

**Prerequisites:**
- [ ] `palantir-migration-config.yaml` exists
- [ ] Pipeline RID or Contour ref RID provided
- [ ] Target storage account accessible
- [ ] Source system connection details available
- [ ] All 5 archetypes exist in `.windsurf/workflows/`

**Configuration Schema:**
- [ ] Use case name is valid (alphanumeric + underscore)
- [ ] Environment is "prod" or "dev"
- [ ] Pipeline RID format: `ri.eddie.main.pipeline.{uuid}`
- [ ] Storage account exists in Azure
- [ ] Container exists in storage account
- [ ] Validation thresholds are percentages (0-100)

**Dependency Graph:**
- [ ] No circular dependencies between archetypes
- [ ] All dependencies resolved (archetype exists)
- [ ] Parallel execution only for independent archetypes

## Generated Content Examples

### Example 1: NetAudit Full Migration

**Input:**
```
/scaffold-migration-orchestrator Full migration for NetAudit
Pipeline RID: ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043
Environment: prod
```

**Generated Files:**
- `outputs/migration/netaudit/migration_plan.yaml` (250 lines)
- `outputs/migration/netaudit/run_migration.sh` (180 lines)
- `outputs/migration/netaudit/rollback_plan.yaml` (120 lines)
- `outputs/migration/netaudit/config/*.yaml` (5 files, 50 lines each)

### Example 2: Incremental Update (Validation Only)

**Input:**
```
/scaffold-migration-orchestrator Validation only for NetAudit

Mode: incremental
Archetypes: [data-validator]
```

**Generated Files:**
- Simplified migration plan (only Stage 4)
- Shell script with single archetype execution
- Minimal rollback plan

## Report Completion

Output:
- Migration plan path: `outputs/migration/{use_case}/migration_plan.yaml`
- Execution script: `outputs/migration/{use_case}/run_migration.sh`
- Rollback plan: `outputs/migration/{use_case}/rollback_plan.yaml`
- Configuration files: `outputs/migration/{use_case}/config/`
- Estimated total duration: {calculated_time}
- Next step: Run `/test-migration-orchestrator` to validate configuration

## See Also

- [compare-migration-orchestrator.md](compare-migration-orchestrator.md) - Execution strategy decisions
- [test-migration-orchestrator.md](test-migration-orchestrator.md) - Configuration validation
- [debug-migration-orchestrator.md](debug-migration-orchestrator.md) - Troubleshooting integration issues
