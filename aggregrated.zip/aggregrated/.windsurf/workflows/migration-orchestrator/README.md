# Migration Orchestrator Archetype

## Overview

Orchestrates end-to-end Palantir to Azure data pipeline migration by coordinating all 5 migration archetypes in proper sequence with dependency resolution.

## Purpose

Execute complete use case migrations from Palantir Foundry to Azure (WatsonX.data + Databricks + Snowflake) by chaining metadata extraction, code generation, transformation, ingestion, and validation workflows.

## When to Use

- Migrating a complete Palantir use case to Azure
- Coordinating multiple migration phases with dependencies
- Executing production cutover
- Debugging cross-archetype integration issues
- Planning migration waves (multiple use cases)

## Quick Start

```bash
# 1. Configure migration
cp .windsurf/workflows/migration-orchestrator/templates/env-config.yaml config/netaudit-migration.yaml
# Edit config/netaudit-migration.yaml

# 2. Generate migration plan
/scaffold-migration-orchestrator Full migration for NetAudit use case

# 3. Validate configuration
/test-migration-orchestrator Validate migration config for NetAudit

# 4. Execute migration (dry run first)
./outputs/migration/run_migration.sh --dry-run

# 5. Execute actual migration
./outputs/migration/run_migration.sh

# 6. Review results
cat outputs/migration/migration_report.json
```

## Workflows

### `/scaffold-migration-orchestrator`
Generate end-to-end migration pipeline with dependency resolution

**Outputs:**
- `migration_plan.yaml` - Execution plan with archetype dependencies
- `run_migration.sh` - Shell script to execute all phases
- `rollback_plan.yaml` - Rollback procedures
- `validation_report.json` - Pre-migration validation

### `/test-migration-orchestrator`
Generate integration tests for full migration flow

**Outputs:**
- End-to-end integration tests
- Configuration validation tests
- Dependency resolution tests
- Mock fixtures

### `/compare-migration-orchestrator`
Decide migration execution strategy

**Decision Points:**
- Sequential vs parallel execution
- Pipeline vs Contour priority
- Full vs incremental migration
- Manual vs automated orchestration

### `/debug-migration-orchestrator`
Troubleshoot cross-archetype failures

**Common Issues:**
- Dependency resolution failures
- Configuration conflicts
- Authentication errors across services
- Data flow compatibility issues
- Environment setup problems

### `/document-migration-orchestrator`
Generate migration playbook

**Output:**
- Pre-migration checklist
- Execution runbook
- Post-migration validation guide
- Rollback procedures
- Production cutover guide

### `/refactor-migration-orchestrator`
Improve orchestration quality

**Goals:**
- YAML validation and schema
- Extract reusable patterns
- Optimize parallel execution
- Improve error handling
- Secrets management

## Archetype Structure

```
.windsurf/workflows/migration-orchestrator/
├── compare-migration-orchestrator.md
├── debug-migration-orchestrator.md
├── document-migration-orchestrator.md
├── refactor-migration-orchestrator.md
├── scaffold-migration-orchestrator.md
├── test-migration-orchestrator.md
├── migration-orchestrator-constitution.md
├── README.md (this file)
└── templates/
    ├── dev.yaml
    └── env-config.yaml
```

## Migration Flow

**Standard Sequential Flow**:
1. `metadata-extractor` → Fetch Pipeline/Contour JSON
2. `pipeline-generator` → Generate Silver/Gold notebooks
3. `transform-converter` → Convert Foundry Python
4. `ingestion-specialist` → Generate Bronze ingestion
5. `data-validator` → Validate all layers

**Parallel Opportunities**:
- Steps 2 + 3 can run in parallel
- Multiple use cases can migrate in parallel

## Dependencies

**Required Archetypes**:
- ingestion-specialist
- transform-converter
- metadata-extractor
- pipeline-generator
- data-validator

**External Systems**:
- Palantir Foundry API
- Databricks workspace
- Azure ADLS Gen2
- Source systems (Oracle, Snowflake, etc.)

## Configuration

**Main Config**: `palantir-migration-config.yaml`

Key sections:
- API configuration (Palantir endpoints)
- Pipeline registry (RID mappings)
- Storage configuration (Azure ADLS)
- Guardrails (hard stops, warnings)
- Execution options (parallel, continue-on-error)

See [templates/env-config.yaml](templates/env-config.yaml) for full schema.

## Success Criteria

**Full Migration**:
- All archetypes executed successfully
- Dependencies resolved correctly
- Data validation passed (all layers)
- Generated notebooks execute in Databricks
- Migration report generated

## Example Use Cases

**POC Migration** (NetAudit):
- Source: Palantir Foundry (Nokia/Ericsson cell data)
- Target: Azure ADLS + Databricks
- Timeline: 4 hours
- Archetypes: All 5 (full migration)

**Incremental Update**:
- Re-run specific archetypes only
- Example: Update validation thresholds → run data-validator only

**Multi-Use Case Wave**:
- Migrate 3 use cases in parallel
- Example: NetAudit + SiteMaster + GeoData simultaneously

## Troubleshooting

See [debug-migration-orchestrator.md](debug-migration-orchestrator.md) for:
- Cross-archetype dependency errors
- Configuration validation failures
- Authentication issues
- Data flow compatibility problems

## Related Documentation

- [Architecture: Migration Strategy](../../docs/architecture/migration-strategy.md)
- [Runbook: Production Cutover](../../docs/runbooks/production-cutover.md)
- [Config Reference: palantir-migration-config.yaml](palantir-migration-config.yaml)
