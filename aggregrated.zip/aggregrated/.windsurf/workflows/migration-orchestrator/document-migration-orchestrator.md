---
description: Generate migration playbook and operational runbooks for production use
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /document-migration-orchestrator

Generate comprehensive migration playbook and operational runbooks for team handoff and production execution.

## When to Use

After:
- Completing successful POC migration
- Finalizing migration strategy

Before:
- Production cutover
- Team handoff
- Documenting for audit/compliance

## What to Provide

**Required:**
- Use case name
- Migration plan file path
- Execution history (if available)

**Optional:**
- Team contacts
- Escalation procedures
- Custom operational notes

## Example Usage

```bash
/document-migration-orchestrator Generate runbook for NetAudit migration

Use case: NetAudit
Migration plan: outputs/migration/netaudit/migration_plan.yaml
Include: pre-migration checklist, execution steps, validation procedures, rollback guide
Audience: Operations team, data engineers
Output: outputs/migration/netaudit/docs/MIGRATION_PLAYBOOK.md
```

## Generated Documentation Structure

```
outputs/migration/{use_case}/docs/
├── MIGRATION_PLAYBOOK.md          # Complete operational guide
├── PRE_MIGRATION_CHECKLIST.md     # Prerequisites validation
├── EXECUTION_RUNBOOK.md            # Step-by-step execution guide
├── POST_MIGRATION_VALIDATION.md   # Validation procedures
├── ROLLBACK_PROCEDURES.md          # Emergency rollback guide
├── PRODUCTION_CUTOVER.md           # Go-live procedures
└── TROUBLESHOOTING_GUIDE.md        # Common issues + resolutions
```

---

## Migration Playbook Template

**File**: `MIGRATION_PLAYBOOK.md`

```markdown
# NetAudit Migration Playbook

**Version**: 1.0.0  
**Last Updated**: 2026-02-05  
**Owner**: Data Engineering Team  
**Status**: Production Ready

---

## Executive Summary

**Migration Scope**: Palantir Foundry → Azure (WatsonX.data + Databricks)  
**Use Case**: OTIS Network Audit (Nokia/Ericsson LTE/5G cell data)  
**Duration**: 2-4 hours  
**Complexity**: Medium  
**Risk Level**: Medium

**Objectives**:
- Migrate Bronze layer (raw data from Oracle/Snowflake)
- Migrate Silver layer (cleaned, enriched cell data)
- Migrate Gold layer (business-ready aggregations)
- Validate row count parity (±0.5% for Bronze/Silver, ±0.1% for Gold)
- Deploy to Databricks production workspace

---

## Migration Overview

### Source Systems
| System | Type | Tables | Data Volume |
|--------|------|--------|-------------|
| Oracle | Database | x_ndr_nokia_enb, x_eric_5gnr_cell_rrh | ~500M rows |
| Snowflake | Data Warehouse | levo_site_master_brd | ~2M rows |
| Palantir Foundry | Analytics Platform | Pipeline: NetAudit_project | ~300M rows (Silver/Gold) |

### Target Systems
| System | Purpose | Location |
|--------|---------|----------|
| Azure ADLS Gen2 | Storage | datalakeeastus2prd/otis-poc |
| Databricks | Compute | East US 2 Workspace |
| WatsonX.data | Orchestration | (Future) |

### Architecture Layers
- **Bronze**: Raw ingestion (Parquet, immutable, append-only)
- **Silver**: Cleaned and enriched (Delta/Iceberg tables)
- **Gold**: Business aggregations (Delta/Iceberg tables)

---

## Pre-Migration Checklist

Use [PRE_MIGRATION_CHECKLIST.md](PRE_MIGRATION_CHECKLIST.md) for detailed validation.

**Infrastructure**:
- [ ] Azure ADLS Gen2 storage account provisioned
- [ ] Container created: `otis-poc`
- [ ] Databricks workspace accessible
- [ ] Network connectivity verified (VPN/ExpressRoute)

**Access & Permissions**:
- [ ] Palantir API Bearer token generated (valid > 24 hours)
- [ ] Azure ADLS Gen2 write permissions
- [ ] Databricks workspace contributor access
- [ ] Source systems (Oracle, Snowflake) read access

**Configuration**:
- [ ] `palantir-migration-config.yaml` validated
- [ ] Pipeline RID confirmed: `ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043`
- [ ] Table mappings verified (rid_mapping.csv)
- [ ] Validation thresholds configured

**Archetypes**:
- [ ] All 5 archetypes available in `.windsurf/workflows/`
- [ ] Archetype versions compatible
- [ ] Dependencies resolved (no missing workflows)

**Tooling**:
- [ ] Python 3.9+ installed
- [ ] Required packages: pyyaml, pyspark, databricks-cli
- [ ] Databricks CLI configured
- [ ] Azure CLI configured

---

## Execution Steps

Use [EXECUTION_RUNBOOK.md](EXECUTION_RUNBOOK.md) for detailed step-by-step guide.

### High-Level Flow

1. **Metadata Extraction** (5 min)
   - Fetch Pipeline JSON from Palantir API
   - Fetch Contour JSON (if applicable)
   - Validate JSON structure

2. **Code Generation** (15 min)
   - Generate Silver/Gold PySpark notebooks from Pipeline JSON
   - Generate transformation notebooks from Contour JSON
   - Convert existing Foundry Python files to Databricks

3. **Ingestion Generation** (10 min)
   - Generate Bronze layer ingestion notebooks
   - Create configurations for Oracle/Snowflake connections

4. **Data Validation** (20 min)
   - Generate validation notebooks for all layers
   - Configure row count thresholds
   - Prepare validation reports

5. **Deployment** (10 min)
   - Upload notebooks to Databricks workspace
   - Create Databricks jobs
   - Schedule validation runs

### Execution Command

```bash
# Navigate to migration directory
cd outputs/migration/netaudit

# Dry run first (recommended)
./run_migration.sh --dry-run

# Execute actual migration
./run_migration.sh

# Monitor progress
tail -f logs/migration_execution.log
```

---

## Post-Migration Validation

Use [POST_MIGRATION_VALIDATION.md](POST_MIGRATION_VALIDATION.md) for detailed validation procedures.

**Validation Checklist**:
- [ ] All notebooks generated successfully
- [ ] Notebooks execute in Databricks without errors
- [ ] Bronze layer row counts match source systems (±0.5%)
- [ ] Silver layer row counts match Palantir (±0.5%)
- [ ] Gold layer row counts match Palantir (±0.1%)
- [ ] Data quality checks pass (no null primary keys)
- [ ] Performance benchmarks met (execution time < SLA)

**Validation Outputs**:
- Validation report: `outputs/validation/reports/all_layers_{timestamp}.json`
- Databricks execution logs: Databricks Workspace → Jobs
- Migration summary: `outputs/migration/netaudit/migration_report.json`

---

## Rollback Procedures

Use [ROLLBACK_PROCEDURES.md](ROLLBACK_PROCEDURES.md) for detailed rollback guide.

**Rollback Triggers**:
- Validation failures (row counts exceed thresholds)
- Data quality issues (schema mismatches, null PKs)
- Performance degradation (execution time > 2x baseline)
- Business stakeholder veto

**Rollback Steps**:
1. Stop all running Databricks jobs
2. Delete generated notebooks from Databricks workspace
3. Remove output folders from ADLS Gen2
4. Restore previous configuration (if updated)
5. Document rollback reason and date

**Rollback Command**:
```bash
./rollback_migration.sh --use-case netaudit
```

---

## Production Cutover

Use [PRODUCTION_CUTOVER.md](PRODUCTION_CUTOVER.md) for go-live procedures.

**Cutover Checklist**:
- [ ] POC validation successful
- [ ] Business stakeholder sign-off
- [ ] Production environment prepared
- [ ] Rollback plan tested
- [ ] Change management approval
- [ ] Communication plan executed

**Cutover Window**: TBD (typically 4-hour window during off-peak hours)

**Cutover Steps**:
1. Freeze source systems (read-only mode)
2. Execute migration in production
3. Run validation
4. Business user acceptance testing (UAT)
5. Go-live decision (go/no-go)
6. Unfreeze source systems OR rollback

---

## Troubleshooting

Use [TROUBLESHOOTING_GUIDE.md](TROUBLESHOOTING_GUIDE.md) for common issues.

**Quick Reference**:
- **API 401 Error**: Refresh Palantir Bearer token
- **ADLS Access Denied**: Verify Azure credentials (`az login`)
- **Validation Failure**: Check threshold configuration, review source data changes
- **Databricks Job Failure**: Review cluster logs, check notebook syntax
- **Missing Dependencies**: Re-run `/scaffold-migration-orchestrator`

---

## Team Contacts

| Role | Name | Contact | Escalation |
|------|------|---------|------------|
| Migration Lead | TBD | TBD | TBD |
| Data Engineer | TBD | TBD | TBD |
| Azure Admin | TBD | TBD | TBD |
| Databricks Admin | TBD | TBD | TBD |
| Business Owner | TBD | TBD | TBD |

---

## Appendix

### A. Configuration Files
- `palantir-migration-config.yaml`
- `rid_mapping.csv`
- `migration_plan.yaml`

### B. Reference Documentation
- Architecture: `docs/architecture/migration-strategy.md`
- Archetypes: `.windsurf/workflows/*/README.md`
- API Documentation: Palantir Developer Portal

### C. Audit Trail
- Migration execution logs: `outputs/migration/netaudit/logs/`
- Validation reports: `outputs/validation/reports/`
- Change history: Git commit log

---

**End of Migration Playbook**
```

---

## Other Documentation Files

### Pre-Migration Checklist

**File**: `PRE_MIGRATION_CHECKLIST.md`

Detailed checklist covering:
- Infrastructure prerequisites (storage, compute, network)
- Access and permissions validation
- Configuration file validation
- Dependency checks
- Tool installation verification

### Execution Runbook

**File**: `EXECUTION_RUNBOOK.md`

Step-by-step guide with:
- Detailed commands for each stage
- Expected outputs and logs
- Progress monitoring instructions
- Common error patterns and quick fixes
- Execution time estimates

### Post-Migration Validation

**File**: `POST_MIGRATION_VALIDATION.md`

Validation procedures including:
- Row count reconciliation steps
- Data quality checks (schemas, nulls, duplicates)
- Performance benchmarks
- UAT test cases
- Sign-off criteria

### Rollback Procedures

**File**: `ROLLBACK_PROCEDURES.md`

Emergency rollback guide with:
- Rollback triggers and decision criteria
- Step-by-step rollback commands
- Data cleanup procedures
- Configuration restoration
- Incident documentation template

### Production Cutover

**File**: `PRODUCTION_CUTOVER.md`

Go-live procedures including:
- Cutover window planning
- Freeze/unfreeze procedures
- Go/no-go decision criteria
- Communication templates
- Post-cutover monitoring

---

## Success Criteria

Documentation complete when:
- [ ] All 7 documentation files generated
- [ ] Migration playbook reviewed by team
- [ ] Checklists validated with actual migration
- [ ] Contact information populated
- [ ] Reviewed and approved by stakeholders

---

## See Also

- [scaffold-migration-orchestrator.md](scaffold-migration-orchestrator.md) - Generate migration plan
- [test-migration-orchestrator.md](test-migration-orchestrator.md) - Validate migration
- [debug-migration-orchestrator.md](debug-migration-orchestrator.md) - Troubleshoot issues
