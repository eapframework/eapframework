---
description: Troubleshoot cross-archetype integration failures and migration execution errors
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /debug-migration-orchestrator

Troubleshoot migration orchestration failures, cross-archetype integration issues, and configuration problems.

## When to Use

When encountering:
- Migration pipeline execution failures
- Cross-archetype dependency errors
- Configuration conflicts
- Authentication failures across services
- Data flow errors between archetypes
- Environment setup issues

## Common Issues

### Issue 1: Dependency Resolution Failure

**Symptom:**
```
[ERROR] Stage 2 (code-generation) failed: dependency 'metadata-extraction' not completed
[ERROR] Output file not found: pipeline_json/netaudit_latest.json
```

**Root Cause:**
- Stage 1 (metadata-extraction) failed silently
- Output file not generated in expected location
- Filename mismatch between archetypes

**Debug Steps:**
1. Check Stage 1 execution logs:
   ```bash
   cat outputs/migration/netaudit/logs/stage1_metadata-extraction.log
   ```

2. Verify output file exists:
   ```bash
   ls -l pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json
   ```

3. Check migration plan config:
   ```yaml
   # migration_plan.yaml
   - stage: 1
     archetypes:
       - name: metadata-extractor
         outputs:
           - "pipeline_json/netaudit_latest.json"  # Path must match
   ```

**Resolution:**
- Fix output path in migration plan
- OR update pipeline-generator to look in correct location
- OR add symbolic link as workaround:
  ```bash
  ln -s pipeline_builder/DBX_Conversion/pipeline_json outputs/migration/netaudit/pipeline_json
  ```

---

### Issue 2: Configuration Conflict

**Symptom:**
```
[ERROR] Config validation failed: storage_account mismatch
[ERROR] metadata-extractor config: datalakeeastus2dev
[ERROR] pipeline-generator config: datalakeeastus2prd
```

**Root Cause:**
- Different archetypes using different configs
- Copy-paste error in archetype configs
- Environment variable override

**Debug Steps:**
1. Compare archetype configs:
   ```bash
   grep storage_account outputs/migration/netaudit/config/*.yaml
   ```

2. Check environment variables:
   ```bash
   env | grep STORAGE
   ```

3. Validate against main config:
   ```bash
   yq '.storage.prod.account' .windsurf/workflows/palantir-migration-config.yaml
   ```

**Resolution:**
- Regenerate archetype configs from main config:
  ```bash
  /scaffold-migration-orchestrator Full migration for NetAudit  # Regenerate
  ```

- OR manually fix config files:
  ```yaml
  # All configs should match
  storage_account: datalakeeastus2prd
  container: otis-poc
  ```

---

### Issue 3: Authentication Failure Across Services

**Symptom:**
```
[ERROR] metadata-extractor: 401 Unauthorized - Palantir API
[ERROR] pipeline-generator: AnalysisException - Azure ADLS access denied
[ERROR] data-validator: AuthenticationException - Databricks SQL
```

**Root Cause:**
- Missing or expired tokens
- Different authentication methods per service
- Credentials not propagated across archetypes

**Debug Steps:**
1. Check Palantir token:
   ```bash
   echo $PALANTIR_TOKEN | cut -c1-20  # First 20 chars only
   ```

2. Check Azure credentials:
   ```bash
   az account show
   ```

3. Check Databricks token:
   ```bash
   databricks workspace list  # Test connection
   ```

**Resolution:**
- Refresh all tokens:
  ```bash
  # Palantir
  export PALANTIR_TOKEN=$(cat ~/palantir-token.txt)
  
  # Azure
  az login
  
  # Databricks
  databricks configure --token
  ```

- Store tokens in Azure Key Vault:
  ```yaml
  # migration_plan.yaml
  authentication:
    palantir:
      key_vault: true
      vault_url: "https://your-keyvault.vault.azure.net"
      secret_name: "palantir-api-token"
    databricks:
      key_vault: true
      secret_name: "databricks-token"
  ```

---

### Issue 4: Data Flow Compatibility Error

**Symptom:**
```
[ERROR] data-validator: Table not found - netaudit_outputs/LTE_NOK_NetAudit
[ERROR] Expected by pipeline-generator: LTE_NOK_NetAudit_as5706
[ERROR] Actual output: lte_nok_netaudit_as5706 (lowercase)
```

**Root Cause:**
- Naming convention mismatch between archetypes
- pipeline-generator uses PascalCase
- data-validator expects lowercase
- Case-sensitivity in Azure ADLS

**Debug Steps:**
1. List actual output tables:
   ```bash
   az storage fs directory list \
     --account-name datalakeeastus2prd \
     --file-system otis-poc \
     --path netaudit_outputs
   ```

2. Check pipeline-generator output:
   ```bash
   grep "output_name" pipeline_builder/DBX_Conversion/netaudit_pipeline.py
   ```

3. Check data-validator config:
   ```bash
   cat outputs/validation/config/table_catalog.json
   ```

**Resolution:**
- Standardize naming in migration plan:
  ```yaml
  # migration_plan.yaml
  naming_convention:
    case: lowercase  # or uppercase, preserve
    separator: underscore  # or hyphen
  ```

- Update pipeline-generator to follow convention
- OR update data-validator table catalog with actual names

---

### Issue 5: Environment Setup Issues

**Symptom:**
```
[ERROR] Archetype 'ingestion-specialist' not found
[ERROR] /ingestion-specialist: command not found
```

**Root Cause:**
- Archetypes not in expected location
- `ARCHETYPES_BASEDIR` not set correctly
- Missing archetype (not yet created)

**Debug Steps:**
1. Check ARCHETYPES_BASEDIR:
   ```bash
   echo $ARCHETYPES_BASEDIR
   ```

2. List available archetypes:
   ```bash
   ls -d .windsurf/workflows/*/
   ```

3. Check migration plan references:
   ```bash
   grep "name:" outputs/migration/netaudit/migration_plan.yaml
   ```

**Resolution:**
- Set ARCHETYPES_BASEDIR:
  ```bash
  export ARCHETYPES_BASEDIR=$(pwd)/.windsurf/workflows
  ```

- Verify all 5 archetypes exist:
  ```bash
  for arch in ingestion-specialist transform-converter metadata-extractor pipeline-generator data-validator; do
    if [ -d ".windsurf/workflows/$arch" ]; then
      echo "✓ $arch"
    else
      echo "✗ $arch (MISSING)"
    fi
  done
  ```

- Create missing archetypes or update migration plan to exclude them

---

### Issue 6: Parallel Execution Deadlock

**Symptom:**
```
[INFO] Starting Stage 2: code-generation (parallel)
[INFO] Launching archetype: pipeline-generator
[INFO] Launching archetype: transform-converter
[WARN] Both archetypes waiting on shared resource: ADLS write lock
[ERROR] Timeout after 30 minutes - deadlock detected
```

**Root Cause:**
- Both archetypes writing to same ADLS folder
- File lock contention
- Parallel execution not actually independent

**Debug Steps:**
1. Check output paths:
   ```bash
   grep output_path outputs/migration/netaudit/config/pipeline_generator.yaml
   grep output_path outputs/migration/netaudit/config/transform_converter.yaml
   ```

2. Check for overlapping files:
   ```bash
   diff \
     <(grep outputs outputs/migration/netaudit/config/pipeline_generator.yaml) \
     <(grep outputs outputs/migration/netaudit/config/transform_converter.yaml)
   ```

**Resolution:**
- Use separate output folders:
  ```yaml
  # pipeline_generator.yaml
  output_folder: "netaudit_outputs/pipeline_generated"
  
  # transform_converter.yaml
  output_folder: "netaudit_outputs/transform_converted"
  ```

- OR switch to sequential execution:
  ```yaml
  # migration_plan.yaml
  - stage: 2
    parallel: false  # Disable parallel execution
  ```

---

### Issue 7: Missing Archetype Output

**Symptom:**
```
[SUCCESS] Stage 2: code-generation completed
[ERROR] Stage 3: ingestion-generation failed - input dependency not met
[ERROR] Required table mappings not found from transform-converter
```

**Root Cause:**
- transform-converter completed but didn't generate expected output file
- Silent failure (exit code 0 but no output)
- Output file generated in wrong location

**Debug Steps:**
1. Check archetype execution log:
   ```bash
   cat outputs/migration/netaudit/logs/stage2_transform-converter.log
   ```

2. Search for expected output:
   ```bash
   find . -name "*table_mappings*" -type f
   ```

3. Check archetype exit code:
   ```bash
   echo $?  # Should be 0 for success
   ```

**Resolution:**
- Add output validation to migration script:
  ```bash
  # run_migration.sh
  if [ ! -f "outputs/migration/netaudit/table_mappings.json" ]; then
    log_error "transform-converter did not generate table_mappings.json"
    exit 1
  fi
  ```

- OR fix transform-converter to generate missing output

---

## Debugging Tools

### Tool 1: Migration Log Analyzer

```bash
# Analyze all stage logs for errors
grep -r "ERROR" outputs/migration/netaudit/logs/

# Show execution timeline
awk '{print $1, $2, $3}' outputs/migration/netaudit/logs/*.log | sort
```

### Tool 2: Config Diff

```bash
# Compare archetype configs for consistency
for config in outputs/migration/netaudit/config/*.yaml; do
  echo "=== $(basename $config) ==="
  yq '.storage_account' $config
  yq '.container' $config
done
```

### Tool 3: Dependency Graph Visualizer

```python
# visualize_dependencies.py
import yaml
import graphviz

with open("outputs/migration/netaudit/migration_plan.yaml") as f:
    plan = yaml.safe_load(f)

dot = graphviz.Digraph()
for stage in plan["execution_plan"]:
    stage_name = stage["name"]
    dot.node(stage_name)
    for dep in stage.get("depends_on", []):
        dot.edge(dep, stage_name)

dot.render("outputs/migration/netaudit/dependency_graph", format="png")
```

### Tool 4: Dry Run Validator

```bash
# Test migration without execution
./outputs/migration/netaudit/run_migration.sh --dry-run --verbose
```

---

## Resolution Strategies

### Strategy 1: Progressive Debugging

1. Run dry run first
2. Execute one stage at a time
3. Validate outputs before next stage
4. Check logs after each stage

### Strategy 2: Isolation Testing

1. Test each archetype independently
2. Use mock inputs where possible
3. Verify outputs match expected schema
4. Then run full migration

### Strategy 3: Rollback and Retry

1. Execute rollback plan
2. Fix root cause
3. Regenerate migration plan
4. Retry migration

---

## See Also

- [scaffold-migration-orchestrator.md](scaffold-migration-orchestrator.md) - Generate migration plan
- [test-migration-orchestrator.md](test-migration-orchestrator.md) - Validate before execution
- [compare-migration-orchestrator.md](compare-migration-orchestrator.md) - Choose better strategy
