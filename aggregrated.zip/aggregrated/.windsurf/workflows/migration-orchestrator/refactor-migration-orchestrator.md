---
description: Improve orchestration configuration quality and code patterns without changing behavior
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /refactor-migration-orchestrator

Improve migration orchestration configuration quality, extract reusable patterns, and optimize execution strategies without changing functional behavior.

## When to Use

When:
- Configuration files become complex or duplicated
- Need to extract reusable migration patterns
- Optimizing parallel execution strategies
- Improving error handling and logging
- Implementing secrets management best practices
- Migrating from legacy config formats

## Refactoring Goals

### Goal 1: YAML Configuration Validation

**Current State**: No schema validation
```yaml
# migration_plan.yaml - no validation
migration:
  use_case: netaudit
  environment:
    type: prod  # typo: "prd" would be accepted
```

**Target State**: JSON Schema validation
```yaml
# migration_plan_schema.json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "required": ["migration", "execution_plan", "options"],
  "properties": {
    "migration": {
      "type": "object",
      "required": ["use_case", "environment"],
      "properties": {
        "use_case": {
          "type": "string",
          "pattern": "^[a-zA-Z0-9_]+$"
        },
        "environment": {
          "type": "object",
          "required": ["type", "storage_account", "container"],
          "properties": {
            "type": {
              "enum": ["prod", "dev"]
            }
          }
        }
      }
    }
  }
}
```

**Validation Script**:
```python
# validate_migration_plan.py
import yaml
import jsonschema

with open("migration_plan.yaml") as f:
    plan = yaml.safe_load(f)

with open("migration_plan_schema.json") as f:
    schema = json.load(f)

try:
    jsonschema.validate(instance=plan, schema=schema)
    print("✓ Migration plan is valid")
except jsonschema.ValidationError as e:
    print(f"✗ Validation error: {e.message}")
    sys.exit(1)
```

**Benefits**:
- ✅ Catch config errors early
- ✅ IDE autocomplete support
- ✅ Self-documenting configuration
- ✅ Easier onboarding for new team members

---

### Goal 2: Extract Reusable Migration Patterns

**Current State**: Hardcoded migration logic
```bash
# run_migration.sh - hardcoded for NetAudit
execute_stage() {
  case $1 in
    metadata-extraction)
      /metadata-extractor fetch pipeline: ri.eddie.main.pipeline.19f85d48...
      ;;
    code-generation)
      /pipeline-generator migrate netaudit_latest.json
      ;;
  esac
}
```

**Target State**: Template-based generation
```python
# migration_template.py
from jinja2 import Template

template = Template("""
#!/bin/bash
# Generated migration script for {{ use_case }}

{% for stage in stages %}
execute_stage_{{ stage.number }}() {
  log_info "Starting Stage {{ stage.number }}: {{ stage.name }}"
  {% for archetype in stage.archetypes %}
  /{{ archetype.name }} {{ archetype.command }}
  {% endfor %}
}
{% endfor %}

main() {
  {% for stage in stages %}
  execute_stage_{{ stage.number }}
  {% endfor %}
}
""")

# Render with config
script = template.render(use_case="netaudit", stages=migration_plan["execution_plan"])
```

**Benefits**:
- ✅ Reusable across use cases
- ✅ Easier to maintain (single template)
- ✅ Consistent structure
- ✅ Rapid migration generation

---

### Goal 3: Optimize Parallel Execution

**Current State**: Sequential execution
```yaml
# migration_plan.yaml
execution_plan:
  - stage: 1
    name: metadata-extraction
  - stage: 2
    name: code-generation
    depends_on: [metadata-extraction]
```

**Target State**: Parallel DAG execution
```yaml
# migration_plan.yaml - with parallelization
execution_plan:
  - stage: 1
    name: metadata-extraction
    parallel_tasks:
      - task: pipeline-fetch
        archetype: metadata-extractor
        args: ["--type=pipeline"]
      - task: contour-fetch
        archetype: metadata-extractor
        args: ["--type=contour"]
  
  - stage: 2
    name: code-generation
    depends_on: [metadata-extraction]
    parallel_tasks:
      - task: pipeline-generation
        archetype: pipeline-generator
        depends_on: [pipeline-fetch]
      - task: transform-conversion
        archetype: transform-converter
        depends_on: []  # Independent
```

**Parallel Executor**:
```python
# parallel_executor.py
from concurrent.futures import ThreadPoolExecutor, wait
import yaml

def execute_task(task):
    """Execute a single task."""
    archetype = task["archetype"]
    args = task.get("args", [])
    subprocess.run([f"/{archetype}"] + args)

def execute_stage(stage):
    """Execute stage with parallel tasks."""
    tasks = stage["parallel_tasks"]
    
    # Build dependency graph
    graph = build_dependency_graph(tasks)
    
    # Execute in topological order with parallelization
    with ThreadPoolExecutor(max_workers=4) as executor:
        for task_group in get_independent_task_groups(graph):
            futures = [executor.submit(execute_task, task) for task in task_group]
            wait(futures)
```

**Benefits**:
- ✅ 40-50% faster execution
- ✅ Better resource utilization
- ✅ Scales to multi-use-case waves
- ✅ Maintains dependency resolution

---

### Goal 4: Improve Error Handling and Logging

**Current State**: Basic logging
```bash
# run_migration.sh
log_info() {
  echo "[INFO] $1"
}

execute_stage() {
  log_info "Starting stage"
  /archetype-workflow || log_error "Failed"
}
```

**Target State**: Structured logging with context
```python
# structured_logger.py
import logging
import json
from datetime import datetime

class StructuredLogger:
    def __init__(self, use_case, stage):
        self.use_case = use_case
        self.stage = stage
        self.logger = logging.getLogger(__name__)
    
    def log(self, level, message, **kwargs):
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level,
            "use_case": self.use_case,
            "stage": self.stage,
            "message": message,
            **kwargs
        }
        self.logger.log(getattr(logging, level), json.dumps(log_entry))

# Usage
logger = StructuredLogger("netaudit", "metadata-extraction")
logger.log("INFO", "Starting API fetch", pipeline_rid="ri.eddie.main.pipeline.xxx")
logger.log("ERROR", "API call failed", status_code=401, retry_attempt=3)
```

**Benefits**:
- ✅ Searchable logs (grep by use_case, stage)
- ✅ Structured for log aggregation tools
- ✅ Easier debugging with context
- ✅ Audit trail for compliance

---

### Goal 5: Secrets Management Best Practices

**Current State**: Environment variables
```bash
# .env
PALANTIR_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
DATABRICKS_TOKEN=dapi12345678901234567890
AZURE_CLIENT_SECRET=your-secret-here
```

**Target State**: Azure Key Vault integration
```python
# secrets_manager.py
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

class SecretsManager:
    def __init__(self, vault_url):
        credential = DefaultAzureCredential()
        self.client = SecretClient(vault_url=vault_url, credential=credential)
    
    def get_secret(self, name):
        """Fetch secret from Azure Key Vault."""
        return self.client.get_secret(name).value

# Usage
secrets = SecretsManager("https://your-keyvault.vault.azure.net")
palantir_token = secrets.get_secret("palantir-api-token")
databricks_token = secrets.get_secret("databricks-token")
```

**Configuration**:
```yaml
# palantir-migration-config.yaml
auth:
  key_vault:
    enabled: true
    vault_url: "https://your-keyvault.vault.azure.net"
    secrets:
      palantir_token: "palantir-api-token"
      databricks_token: "databricks-token"
      azure_client_secret: "azure-client-secret"
```

**Benefits**:
- ✅ No secrets in code or config files
- ✅ Centralized secret rotation
- ✅ Audit trail for secret access
- ✅ Compliance with security policies

---

### Goal 6: Migrate from Python Config to YAML

**Current State**: `pipeline-builder-config.py` (legacy)
```python
# pipeline-builder-config.py
STORAGE_ACCOUNT = "datalakeeastus2prd"
CONTAINER = "otis-poc"
OUTPUT_FOLDER = "x_site_general_info_parquet"

TABLE_TO_FOLDER_MAPPING = {
    "x_ndr_nokia_enb": "x_ndr_nokia_enb",
    "levo_site_master_brd": "LEVO_SITE_MASTER_BRD",
}
```

**Target State**: `palantir-migration-config.yaml` (current)
```yaml
# palantir-migration-config.yaml
storage:
  prod:
    account: "datalakeeastus2prd"
    container: "otis-poc"

output:
  parquet_suffix: "_parquet"

input_tables:
  x_ndr_nokia_enb: "x_ndr_nokia_enb"
  levo_site_master_brd: "LEVO_SITE_MASTER_BRD"
```

**Migration Script**:
```python
# migrate_config.py
import yaml

# Read legacy Python config
with open("pipeline-builder-config.py") as f:
    exec(f.read())  # Load variables

# Convert to YAML structure
config = {
    "storage": {
        "prod": {
            "account": STORAGE_ACCOUNT,
            "container": CONTAINER
        }
    },
    "input_tables": TABLE_TO_FOLDER_MAPPING
}

# Write YAML config
with open("palantir-migration-config.yaml", "w") as f:
    yaml.dump(config, f, default_flow_style=False)
```

**Benefits**:
- ✅ No code execution required (safer)
- ✅ Multi-environment support (dev, prod)
- ✅ Standard configuration format
- ✅ IDE support (syntax highlighting, validation)

---

## Refactoring Checklist

- [ ] YAML schema validation implemented
- [ ] Migration script template extracted
- [ ] Parallel execution optimized
- [ ] Structured logging added
- [ ] Secrets moved to Key Vault
- [ ] Legacy Python config deprecated
- [ ] Documentation updated
- [ ] Tests pass after refactoring

---

## Testing After Refactoring

```bash
# Validate YAML schema
python validate_migration_plan.py

# Test parallel execution
pytest tests/test_parallel_execution.py

# Test secret fetching
python -c "from secrets_manager import SecretsManager; print(SecretsManager('https://vault').get_secret('test'))"

# Full migration dry run
./outputs/migration/netaudit/run_migration.sh --dry-run
```

---

## Rollback Plan

If refactoring introduces bugs:

1. Revert to previous configuration format
2. Use git to restore old files:
   ```bash
   git checkout HEAD~1 palantir-migration-config.yaml
   ```
3. Document issues encountered
4. Plan incremental refactoring (not all at once)

---

## See Also

- [scaffold-migration-orchestrator.md](scaffold-migration-orchestrator.md) - Generate migration plan with improved patterns
- [test-migration-orchestrator.md](test-migration-orchestrator.md) - Validate refactored configuration
- [compare-migration-orchestrator.md](compare-migration-orchestrator.md) - Evaluate refactoring trade-offs
