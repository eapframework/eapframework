# Transform Converter Archetype

## Overview

The **Transform Converter** converts Palantir Foundry Transform Python files to Databricks PySpark pipelines, resolving RID-based Input/Output references to Azure ADLS Gen2 paths.

**Key Principle**: Preserve transformation logic exactly while adapting infrastructure (Foundry API → PySpark, RIDs → ADLS paths).

---

## Quick Start

### 1. Convert Foundry Transform to PySpark

```bash
/scaffold foundry_file=transforms-python/src/myproject/datasets/clean/x_eric_5gnr_cell_rrh.py
```

**What It Does**:
- Parses `@transform` decorator for Input/Output RIDs
- Resolves RIDs to ADLS paths using `rid_mapping.csv`
- Generates `generated/transforms/x_eric_5gnr_cell_rrh.py` (PySpark)
- Generates Databricks job JSON

### 2. Test Converted Script

```bash
/test script=generated/transforms/x_eric_5gnr_cell_rrh.py
```

**What It Does**:
- Validates RID resolution
- Tests ADLS path accessibility
- Verifies transformation logic preserved
- Compares output schema with Foundry original

### 3. Compare Conversion Strategies

```bash
/compare strategy=inline_utils vs shared_modules
```

**What It Does**:
- Compares inline utilities vs Databricks workspace modules
- Analyzes overwrite vs incremental mode trade-offs
- Recommends optimal conversion approach

### 4. Debug Conversion Failures

```bash
/debug error="RID not found in mapping"
```

**What It Does**:
- Diagnoses RID lookup errors
- Troubleshoots ADLS path resolution
- Resolves utility module import errors

### 5. Document Conversion Process

```bash
/document output=foundry-to-databricks-guide.md
```

**What It Does**:
- Generates conversion mapping guide
- Documents RID resolution process
- Includes example transformations

### 6. Refactor Converted Code

```bash
/refactor target=transforms consolidate_utils=True
```

**What It Does**:
- Consolidates shared transformation logic
- Optimizes utility module imports
- Improves code readability

---

## Conversion Example

### Before (Palantir Foundry)

**File**: `transforms-python/src/myproject/datasets/clean/x_eric_5gnr_cell_rrh.py`

```python
from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns

@transform(
    out=Output("ri.foundry.main.dataset.abc123"),
    df=Input("ri.foundry.main.dataset.xyz789"),
)
def my_compute_function(out, df):
    # Column configurations
    date_format = 'yyyyMMdd'
    datetime_format = 'yyyy-MM-dd HH:mm:ss'
    cast_to_timestamp_from_long_columns = ['LOADDATE']
    cast_to_date_from_string_columns = []
    
    # Transformations
    df_clean = clean_columns(
        df.dataframe(),
        date_format,
        datetime_format,
        cast_to_timestamp_from_long_columns,
        cast_to_date_from_string_columns
    )
    df_clean = lowercase_columns(df_clean)
    
    # Write output
    out.write_dataframe(df_clean)
```

### After (Databricks PySpark)

**File**: `generated/transforms/x_eric_5gnr_cell_rrh.py`

```python
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from utility.column_clean import clean_columns, lowercase_columns

# ADLS Configuration (resolved from rid_mapping.csv)
INPUT_PATH = "abfss://raw@datalakeeastus2prd.dfs.core.windows.net/x_ndr_eric_lcell_rrh"
OUTPUT_PATH = "abfss://silver@datalakeeastus2prd.dfs.core.windows.net/x_eric_5gnr_cell_rrh_clean"

# Column configurations (preserved from original)
date_format = 'yyyyMMdd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
cast_to_timestamp_from_long_columns = ['LOADDATE']
cast_to_date_from_string_columns = []


def transform(df: DataFrame) -> DataFrame:
    """Apply column cleaning transformations (preserved from Foundry)."""
    df_clean = clean_columns(
        df,
        date_format,
        datetime_format,
        cast_to_timestamp_from_long_columns,
        cast_to_date_from_string_columns
    )
    df_clean = lowercase_columns(df_clean)
    return df_clean


def main(spark: SparkSession) -> None:
    """Databricks entry point."""
    # Read from ADLS
    df = spark.read.parquet(INPUT_PATH)
    
    # Apply transformations
    df_transformed = transform(df)
    
    # Write to ADLS
    df_transformed.write.mode("overwrite").parquet(OUTPUT_PATH)
    
    print(f"✅ Transform complete: {OUTPUT_PATH}")
    print(f"   Rows processed: {df_transformed.count()}")


if __name__ == "__main__":
    spark = SparkSession.builder \
        .appName("x_eric_5gnr_cell_rrh_transform") \
        .getOrCreate()
    main(spark)
```

---

## RID Resolution

### RID Mapping CSV

**File**: `.cdo-aifc/data/rid_mapping.csv`

```csv
rid,dataset_name,container,folder_name
ri.foundry.main.dataset.xyz789,x_ndr_eric_lcell_rrh,raw,x_ndr_eric_lcell_rrh
ri.foundry.main.dataset.abc123,x_eric_5gnr_cell_rrh_clean,silver,x_eric_5gnr_cell_rrh_clean
```

### Path Resolution Logic

```python
import pandas as pd
import yaml

def resolve_rid_to_adls_path(rid: str, env_config: dict, rid_mapping: pd.DataFrame) -> str:
    """Resolve Foundry RID to ADLS path."""
    # Lookup RID in mapping
    mapping_row = rid_mapping[rid_mapping['rid'] == rid]
    
    if mapping_row.empty:
        raise KeyError(f"RID not found in mapping: {rid}")
    
    dataset_name = mapping_row.iloc[0]['dataset_name']
    container = mapping_row.iloc[0]['container']
    folder_name = mapping_row.iloc[0]['folder_name']
    
    # Construct ADLS path
    host_name = env_config['storage']['host_name']
    adls_path = f"abfss://{container}@{host_name}/{folder_name}"
    
    return adls_path
```

---

## Conversion Patterns

### Pattern 1: Input/Output Decorator

**Foundry**:
```python
@transform(
    out=Output("ri.foundry.main.dataset.abc123"),
    df=Input("ri.foundry.main.dataset.xyz789"),
)
def my_compute_function(out, df):
    # ...
```

**PySpark**:
```python
INPUT_PATH = "abfss://raw@storage.dfs.core.windows.net/dataset_input"
OUTPUT_PATH = "abfss://silver@storage.dfs.core.windows.net/dataset_output"

def main(spark: SparkSession):
    df = spark.read.parquet(INPUT_PATH)
    # ...
    df.write.mode("overwrite").parquet(OUTPUT_PATH)
```

---

### Pattern 2: Incremental Mode

**Foundry**:
```python
from transforms.api import transform, Input, Output, incremental

@incremental()
@transform(
    out=Output("ri.foundry.main.dataset.abc123"),
    df=Input("ri.foundry.main.dataset.xyz789"),
)
def my_compute_function(out, df):
    # ...
```

**PySpark**:
```python
def main(spark: SparkSession):
    df = spark.read.parquet(INPUT_PATH)
    
    # Apply watermark filter for incremental
    if LOAD_TYPE == "incremental":
        df = df.filter(f"updated_at >= '{WATERMARK_VALUE}'")
    
    # Append mode for incremental
    df.write.mode("append").parquet(OUTPUT_PATH)
```

---

### Pattern 3: Utility Module Imports

**Foundry**:
```python
from utility.column_clean import clean_columns, lowercase_columns
```

**PySpark (Databricks Workspace)**:
```python
# Upload column_clean.py to /Workspace/utility/column_clean.py
from utility.column_clean import clean_columns, lowercase_columns

# OR: Inline utilities (if consolidation preferred)
def clean_columns(df: DataFrame, ...) -> DataFrame:
    # Inline implementation
    pass
```

---

## Databricks Job Definition

**Generated Job JSON**:

```json
{
  "name": "x_eric_5gnr_cell_rrh_transform",
  "tasks": [
    {
      "task_key": "transform",
      "description": "Transform x_eric_5gnr_cell_rrh from Raw to Silver",
      "spark_python_task": {
        "python_file": "dbfs:/jobs/transforms/x_eric_5gnr_cell_rrh.py"
      },
      "new_cluster": {
        "spark_version": "13.3.x-scala2.12",
        "node_type_id": "Standard_D4s_v3",
        "num_workers": 2,
        "spark_conf": {
          "spark.databricks.delta.preview.enabled": "true"
        }
      },
      "libraries": [],
      "timeout_seconds": 3600
    }
  ],
  "schedule": {
    "quartz_cron_expression": "0 0 2 * * ?",
    "timezone_id": "UTC"
  },
  "email_notifications": {
    "on_failure": ["data-eng@company.com"]
  }
}
```

---

## Utility Module Management

### Option 1: Shared Databricks Workspace Module

**Advantages**:
- ✅ Single source of truth
- ✅ Easier updates (change once, affects all transforms)
- ✅ No code duplication

**Setup**:
```bash
# Upload to Databricks workspace
dbfs cp pythonutilities/pythonutilities/src/utility/column_clean.py \
  dbfs:/Workspace/utility/column_clean.py
```

**Import in PySpark**:
```python
from utility.column_clean import clean_columns, lowercase_columns
```

---

### Option 2: Inline Utilities

**Advantages**:
- ✅ Self-contained scripts (no external dependencies)
- ✅ Easier debugging (all code in one file)

**Disadvantages**:
- ❌ Code duplication
- ❌ Harder to maintain (update each transform individually)

**Implementation**:
```python
# Inline utility functions
def clean_columns(df: DataFrame, date_format: str, ...) -> DataFrame:
    """Column cleaning logic (copied from utility.column_clean)."""
    # ... implementation ...
    return df

def lowercase_columns(df: DataFrame) -> DataFrame:
    """Lowercase column names."""
    return df.toDF(*[c.lower() for c in df.columns])
```

---

## Troubleshooting

### RID Not Found in Mapping

**Symptom**:
```
KeyError: 'ri.foundry.main.dataset.abc123'
```

**Resolution**:
1. Extract RID from Foundry transform file
2. Query Palantir API for dataset metadata
3. Add RID to `rid_mapping.csv`:
   ```csv
   ri.foundry.main.dataset.abc123,x_eric_5gnr_cell_rrh_clean,silver,x_eric_5gnr_cell_rrh_clean
   ```
4. Re-run conversion

---

### ADLS Path Not Accessible

**Symptom**:
```
abfss.org.apache.hadoop.fs.azurebfs.contracts.exceptions.AbfsRestOperationException: 
Operation failed: "This request is not authorized", 403, Forbidden
```

**Resolution**:
1. Verify service principal has Storage Blob Data Contributor role
2. Check ABFS path format: `abfss://{container}@{storage}.dfs.core.windows.net/{folder}`
3. Confirm container exists in storage account

---

### Utility Module Import Error

**Symptom**:
```
ModuleNotFoundError: No module named 'utility.column_clean'
```

**Resolution**:
1. Upload `column_clean.py` to Databricks workspace:
   ```bash
   dbfs cp column_clean.py dbfs:/Workspace/utility/column_clean.py
   ```
2. Verify import path matches file location
3. Restart Databricks cluster if needed

---

### Schema Mismatch After Conversion

**Symptom**: Output schema different from Foundry transform

**Resolution**:
1. Compare Foundry transform logic with PySpark implementation
2. Verify all column cleaning patterns applied
3. Check `cast_to_*` lists preserved exactly
4. Run schema comparison test:
   ```python
   # Compare schemas
   foundry_schema = load_foundry_schema()
   pyspark_schema = df_transformed.schema
   assert foundry_schema == pyspark_schema
   ```

---

## Configuration Files

### env-config.yaml

```yaml
storage:
  host_name: "datalakeeastus2prd.dfs.core.windows.net"
  containers:
    raw: "raw"
    silver: "silver"
  folders:
    input: "x_ndr_eric_lcell_rrh"
    output: "x_eric_5gnr_cell_rrh_clean"

spark:
  version: "13.3.x-scala2.12"
  cluster:
    num_workers: 2
    node_type: "Standard_D4s_v3"
```

---

## Workflows

### scaffold-transform-converter
**Trigger**: `/scaffold`  
**Purpose**: Convert Foundry Transform Python to PySpark  
**Output**: PySpark script, Databricks job JSON

### test-transform-converter
**Trigger**: `/test`  
**Purpose**: Validate converted script  
**Output**: pytest results, schema comparison

### compare-transform-converter
**Trigger**: `/compare`  
**Purpose**: Compare conversion strategies  
**Output**: Decision table (inline vs shared utilities)

### debug-transform-converter
**Trigger**: `/debug`  
**Purpose**: Diagnose conversion failures  
**Output**: Root cause analysis, resolution steps

### document-transform-converter
**Trigger**: `/document`  
**Purpose**: Generate conversion documentation  
**Output**: Foundry→Databricks mapping guide

### refactor-transform-converter
**Trigger**: `/refactor`  
**Purpose**: Improve converted code quality  
**Output**: Refactored PySpark scripts

---

**End of README**
