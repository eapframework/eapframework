---
description: Generate PySpark scripts from Palantir Foundry Transform Python files with RID resolution
glyphEnabled: true
glyph: scaffold
---

User input: $ARGUMENTS

## Context

You are converting a **Palantir Foundry Transform Python file** to a **Databricks PySpark pipeline** by parsing RID-based Input/Output references, resolving ADLS paths, and preserving transformation logic exactly.

**Core Requirements**:
- Parse `@transform` decorator for Input/Output RIDs
- Resolve RIDs to ADLS paths using `rid_mapping.csv`
- Preserve transformation logic (column cleaning, business rules)
- Generate Databricks-ready PySpark script
- Create Databricks job JSON

---

## Expected User Input

The user will provide one of:
1. **Foundry file path**: `foundry_file=transforms-python/src/myproject/datasets/clean/x_eric_5gnr_cell_rrh.py`
2. **Multiple files**: `foundry_dir=transforms-python/src/myproject/datasets/clean/`
3. **Interactive mode**: `/scaffold` (prompt for file path)

---

## Step 1: Extract Requirements

### Parse User Input

Extract these parameters:

| Parameter | Required | Default | Example |
|-----------|----------|---------|---------|
| `foundry_file` | Yes* | - | `transforms-python/.../x_eric.py` |
| `foundry_dir` | Yes* | - | `transforms-python/src/myproject/datasets/clean/` |
| `output_path` | No | `generated/transforms` | Custom output directory |
| `inline_utils` | No | `false` | `true` (inline utilities vs import) |
| `config` | No | `env-config.yaml` | Path to environment config |

*Either `foundry_file` or `foundry_dir` required

---

## Step 2: Load Configuration Files

### Load RID Mapping

**File**: `.cdo-aifc/data/rid_mapping.csv`

```python
import pandas as pd

def load_rid_mapping(mapping_path: str) -> pd.DataFrame:
    """Load RID to dataset name mappings."""
    df = pd.read_csv(mapping_path)
    
    # Expected columns: rid, dataset_name, container, folder_name
    required_columns = ['rid', 'dataset_name', 'container', 'folder_name']
    missing = set(required_columns) - set(df.columns)
    
    if missing:
        raise ValueError(f"RID mapping missing columns: {missing}")
    
    return df
```

**Example Mapping**:
```csv
rid,dataset_name,container,folder_name
ri.foundry.main.dataset.xyz789,x_ndr_eric_lcell_rrh,raw,x_ndr_eric_lcell_rrh
ri.foundry.main.dataset.abc123,x_eric_5gnr_cell_rrh_clean,silver,x_eric_5gnr_cell_rrh_clean
```

---

### Load Environment Config

**File**: `.cdo-aifc/templates/03-data-engineering/pipeline-builder/env-config.yaml`

```python
import yaml

def load_env_config(config_path: str) -> dict:
    """Load ADLS environment configuration."""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Expected keys: storage.host_name, storage.containers
    if 'storage' not in config:
        raise ValueError("env-config.yaml missing 'storage' section")
    
    return config
```

**Example Config**:
```yaml
storage:
  host_name: "datalakeeastus2prd.dfs.core.windows.net"
  containers:
    raw: "raw"
    silver: "silver"
    gold: "gold"
```

---

## Step 3: Parse Foundry Transform File

### Extract RIDs from @transform Decorator

```python
import re
from typing import Tuple, Optional

def extract_rids_from_transform(file_content: str) -> Tuple[str, str, Optional[str]]:
    """Extract Input/Output RIDs and incremental mode from @transform decorator."""
    
    # Parse Input RID
    input_pattern = r'Input\("(ri\.foundry\.main\.dataset\.[^"]+)"\)'
    input_match = re.search(input_pattern, file_content)
    
    if not input_match:
        raise ValueError("No Input RID found in @transform decorator")
    
    input_rid = input_match.group(1)
    
    # Parse Output RID
    output_pattern = r'Output\("(ri\.foundry\.main\.dataset\.[^"]+)"\)'
    output_match = re.search(output_pattern, file_content)
    
    if not output_match:
        raise ValueError("No Output RID found in @transform decorator")
    
    output_rid = output_match.group(1)
    
    # Check for @incremental decorator
    incremental_pattern = r'@incremental\('
    is_incremental = re.search(incremental_pattern, file_content) is not None
    
    return input_rid, output_rid, "incremental" if is_incremental else "full"


# Example usage
file_content = """
from transforms.api import transform, Input, Output

@transform(
    out=Output("ri.foundry.main.dataset.abc123"),
    df=Input("ri.foundry.main.dataset.xyz789"),
)
def my_compute_function(out, df):
    # ...
"""

input_rid, output_rid, load_type = extract_rids_from_transform(file_content)
# Result: ('ri.foundry.main.dataset.xyz789', 'ri.foundry.main.dataset.abc123', 'full')
```

---

### Extract Transformation Logic

```python
def extract_transform_logic(file_content: str) -> dict:
    """Extract transformation function body and column configurations."""
    
    # Extract function body (everything inside @transform function)
    func_pattern = r'def\s+\w+\([^)]+\):\s*\n((?:    .+\n)*)'
    func_match = re.search(func_pattern, file_content, re.MULTILINE)
    
    if not func_match:
        raise ValueError("Could not extract transformation function")
    
    func_body = func_match.group(1)
    
    # Extract column configuration variables
    config_patterns = {
        'date_format': r"date_format\s*=\s*['\"]([^'\"]+)['\"]",
        'datetime_format': r"datetime_format\s*=\s*['\"]([^'\"]+)['\"]",
        'cast_to_timestamp_from_long_columns': r'cast_to_timestamp_from_long_columns\s*=\s*(\[.+?\])',
        'cast_to_date_from_string_columns': r'cast_to_date_from_string_columns\s*=\s*(\[.+?\])',
    }
    
    column_configs = {}
    for config_name, pattern in config_patterns.items():
        match = re.search(pattern, func_body)
        if match:
            column_configs[config_name] = match.group(1)
    
    return {
        'function_body': func_body,
        'column_configs': column_configs
    }
```

---

## Step 4: Resolve RIDs to ADLS Paths

```python
def resolve_rid_to_adls_path(
    rid: str,
    rid_mapping: pd.DataFrame,
    env_config: dict
) -> str:
    """Resolve Foundry RID to ADLS path."""
    
    # Lookup RID in mapping
    mapping_row = rid_mapping[rid_mapping['rid'] == rid]
    
    if mapping_row.empty:
        raise KeyError(f"RID not found in mapping: {rid}")
    
    dataset_name = mapping_row.iloc[0]['dataset_name']
    container = mapping_row.iloc[0]['container']
    folder_name = mapping_row.iloc[0]['folder_name']
    
    # Construct ADLS path
    host_name = env_config['storage']['host_name']
    adls_path = f"abfss://{container}@{host_name}/{folder_name}"
    
    return adls_path, dataset_name


# Example
input_path, input_dataset = resolve_rid_to_adls_path(
    "ri.foundry.main.dataset.xyz789",
    rid_mapping,
    env_config
)
# Result: ('abfss://raw@datalakeeastus2prd.dfs.core.windows.net/x_ndr_eric_lcell_rrh', 
#          'x_ndr_eric_lcell_rrh')
```

---

## Step 5: Generate PySpark Script

### PySpark Template

```python
PYSPARK_TEMPLATE = '''"""
Databricks PySpark Transform: {dataset_name}
Converted from Foundry Transform: {original_file}
Generated: {timestamp}
"""

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
{import_utilities}

# ADLS Configuration (resolved from rid_mapping.csv)
INPUT_PATH = "{input_path}"
OUTPUT_PATH = "{output_path}"

# Column configurations (preserved from original Foundry transform)
{column_configs}

{utility_functions}

def transform(df: DataFrame) -> DataFrame:
    """Apply transformations (preserved from Foundry transform logic)."""
{transform_logic}
    return df


def main(spark: SparkSession) -> None:
    """Databricks entry point."""
    # Read from ADLS
    print(f"📖 Reading from: {{INPUT_PATH}}")
    df = spark.read.parquet(INPUT_PATH)
    print(f"   Rows read: {{df.count():,}}")
    
    # Apply transformations
    print(f"🔄 Applying transformations...")
    df_transformed = transform(df)
    
    # Write to ADLS
    print(f"💾 Writing to: {{OUTPUT_PATH}}")
    df_transformed.write.mode("{write_mode}").parquet(OUTPUT_PATH)
    print(f"   Rows written: {{df_transformed.count():,}}")
    
    print(f"✅ Transform complete")


if __name__ == "__main__":
    spark = SparkSession.builder \\
        .appName("{dataset_name}_transform") \\
        .getOrCreate()
    main(spark)
'''

def generate_pyspark_script(
    input_path: str,
    output_path: str,
    dataset_name: str,
    transform_logic: dict,
    load_type: str,
    inline_utils: bool = False,
    original_file: str = ""
) -> str:
    """Generate complete PySpark script."""
    
    import datetime
    
    # Import utilities
    if inline_utils:
        import_utilities = "# Utilities inlined below"
        utility_functions = get_inline_utilities()
    else:
        import_utilities = "from utility.column_clean import clean_columns, lowercase_columns"
        utility_functions = ""
    
    # Column configurations
    column_configs_str = "\n".join([
        f"{key} = {value}"
        for key, value in transform_logic['column_configs'].items()
    ])
    
    # Transform logic (indent for function body)
    transform_logic_str = "\n".join([
        f"    {line}" if line.strip() else ""
        for line in transform_logic['function_body'].split('\n')
    ])
    
    # Write mode
    write_mode = "append" if load_type == "incremental" else "overwrite"
    
    # Fill template
    script = PYSPARK_TEMPLATE.format(
        dataset_name=dataset_name,
        original_file=original_file,
        timestamp=datetime.datetime.now().isoformat(),
        import_utilities=import_utilities,
        input_path=input_path,
        output_path=output_path,
        column_configs=column_configs_str,
        utility_functions=utility_functions,
        transform_logic=transform_logic_str,
        write_mode=write_mode
    )
    
    return script
```

---

## Step 6: Generate Databricks Job JSON

```python
DATABRICKS_JOB_TEMPLATE = '''{{
  "name": "{dataset_name}_transform",
  "tasks": [
    {{
      "task_key": "transform",
      "description": "Transform {dataset_name} from {input_container} to {output_container}",
      "spark_python_task": {{
        "python_file": "dbfs:/jobs/transforms/{dataset_name}.py"
      }},
      "new_cluster": {{
        "spark_version": "13.3.x-scala2.12",
        "node_type_id": "Standard_D4s_v3",
        "num_workers": 2,
        "spark_conf": {{
          "spark.databricks.delta.preview.enabled": "true"
        }}
      }},
      "libraries": [],
      "timeout_seconds": 3600
    }}
  ],
  "schedule": {{
    "quartz_cron_expression": "0 0 2 * * ?",
    "timezone_id": "UTC"
  }},
  "email_notifications": {{
    "on_failure": ["{notification_email}"]
  }}
}}'''

def generate_databricks_job_json(
    dataset_name: str,
    input_container: str,
    output_container: str,
    notification_email: str = "data-eng@company.com"
) -> str:
    """Generate Databricks job definition."""
    
    job_json = DATABRICKS_JOB_TEMPLATE.format(
        dataset_name=dataset_name,
        input_container=input_container,
        output_container=output_container,
        notification_email=notification_email
    )
    
    return job_json
```

---

## Step 7: Output Generated Files

### Save PySpark Script

```python
import os

def save_pyspark_script(script: str, dataset_name: str, output_dir: str = "generated/transforms"):
    """Save generated PySpark script."""
    os.makedirs(output_dir, exist_ok=True)
    
    output_path = os.path.join(output_dir, f"{dataset_name}.py")
    
    with open(output_path, 'w') as f:
        f.write(script)
    
    print(f"✅ Generated PySpark script: {output_path}")
    return output_path
```

### Save Databricks Job JSON

```python
def save_databricks_job_json(job_json: str, dataset_name: str, output_dir: str = "generated/jobs"):
    """Save Databricks job definition."""
    os.makedirs(output_dir, exist_ok=True)
    
    output_path = os.path.join(output_dir, f"{dataset_name}_job.json")
    
    with open(output_path, 'w') as f:
        f.write(job_json)
    
    print(f"✅ Generated Databricks job: {output_path}")
    return output_path
```

---

## Step 8: Generate Summary Report

**Output Template**:

```
================================================================================
🔄 Transform Conversion Complete
================================================================================

Original File: {original_file}
Generated PySpark Script: {pyspark_script_path}
Databricks Job JSON: {job_json_path}

RID Resolution:
---------------
Input RID: {input_rid}
  → {input_path}

Output RID: {output_rid}
  → {output_path}

Conversion Details:
-------------------
Dataset: {dataset_name}
Load Type: {load_type}
Write Mode: {write_mode}
Utilities: {utilities_mode}

Column Configurations Preserved:
--------------------------------
- date_format: {date_format}
- datetime_format: {datetime_format}
- cast_to_timestamp_from_long_columns: {cast_to_timestamp_cols}
- cast_to_date_from_string_columns: {cast_to_date_cols}

Transformation Logic:
---------------------
✅ Column cleaning applied
✅ Lowercase column names
✅ Business logic preserved

Next Steps:
-----------
1. Review generated PySpark script: {pyspark_script_path}
2. Test script: /test script={pyspark_script_path}
3. Upload utility modules to Databricks workspace (if using shared modules)
4. Deploy Databricks job: databricks jobs create --json-file {job_json_path}
5. Run initial test: databricks jobs run-now --job-id <job_id>

Dependencies:
-------------
{dependencies}

================================================================================
```

---

## Validation Checklist

Before completing, verify:

- [x] RIDs extracted from `@transform` decorator
- [x] All RIDs resolved to ADLS paths (no missing mappings)
- [x] Transformation logic preserved exactly
- [x] Column configurations preserved (cast lists, formats)
- [x] Write mode matches load type (incremental → append, full → overwrite)
- [x] PySpark script valid Python syntax
- [x] Databricks job JSON valid
- [x] Utility module imports correct (inline vs shared)

---

**End of Scaffold Workflow**
