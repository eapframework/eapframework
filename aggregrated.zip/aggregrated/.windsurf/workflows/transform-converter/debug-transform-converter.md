---
description: Debug transform conversion failures (RID lookup errors, ADLS resolution, import errors)
glyphEnabled: true
glyph: debug
---

User input: $ARGUMENTS

## Common Issues & Resolutions

### Issue 1: RID Not Found in Mapping

**Error Signature**:
```
KeyError: 'ri.foundry.main.dataset.abc123'
ValueError: RID not found in mapping: ri.foundry.main.dataset.abc123
```

**Root Causes**:
1. RID mapping CSV incomplete
2. Typo in RID string
3. RID not yet extracted from Palantir API

**Diagnostic Steps**:

1. **Extract RID from Foundry file**:
   ```python
   with open(foundry_file, 'r') as f:
       content = f.read()
   
   # Find all RIDs in file
   import re
   rids = re.findall(r'ri\.foundry\.main\.dataset\.[a-f0-9]+', content)
   print(f"RIDs found: {rids}")
   ```

2. **Check RID mapping CSV**:
   ```python
   import pandas as pd
   rid_mapping = pd.read_csv('rid_mapping.csv')
   
   for rid in rids:
       if rid not in rid_mapping['rid'].values:
           print(f"❌ Missing RID: {rid}")
   ```

3. **Query Palantir API for dataset**:
   ```python
   # Use metadata-extractor archetype
   /metadata-extractor fetch_rid={rid}
   # Add result to rid_mapping.csv
   ```

**Resolution**:
- Add missing RID to `rid_mapping.csv`:
  ```csv
  ri.foundry.main.dataset.abc123,x_eric_5gnr_cell_rrh_clean,silver,x_eric_5gnr_cell_rrh_clean
  ```
- Re-run conversion

---

### Issue 2: ADLS Path Resolution Failed

**Error Signature**:
```
ValueError: Cannot resolve ADLS path for dataset 'x_eric_5gnr_cell_rrh'
KeyError: 'host_name' not found in env-config.yaml
```

**Root Causes**:
1. Missing fields in `env-config.yaml`
2. Container name not in config
3. Folder name mismatch

**Diagnostic Steps**:

1. **Verify env-config.yaml structure**:
   ```yaml
   # Required structure
   storage:
     host_name: "datalakeeastus2prd.dfs.core.windows.net"  # REQUIRED
     containers:
       raw: "raw"  # REQUIRED
       silver: "silver"
       gold: "gold"
   ```

2. **Check RID mapping has container/folder**:
   ```python
   rid_row = rid_mapping[rid_mapping['rid'] == rid]
   required = ['container', 'folder_name']
   
   for col in required:
       if col not in rid_row.columns or pd.isna(rid_row.iloc[0][col]):
           print(f"❌ Missing column: {col}")
   ```

**Resolution**:
- Update `env-config.yaml` with missing fields
- Add container/folder_name to `rid_mapping.csv`
- Verify ADLS path format: `abfss://{container}@{host}/{folder}`

---

### Issue 3: Utility Module Import Error

**Error Signature**:
```
ModuleNotFoundError: No module named 'utility.column_clean'
ImportError: cannot import name 'clean_columns' from 'utility.column_clean'
```

**Root Causes**:
1. Utility module not uploaded to Databricks workspace
2. Import path incorrect
3. Module in wrong location

**Diagnostic Steps**:

1. **Check Databricks workspace for utility module**:
   ```python
   # List workspace files
   dbutils.fs.ls("/Workspace/utility/")
   # Expected: column_clean.py
   ```

2. **Verify import path**:
   ```python
   # Correct import (if using shared module)
   from utility.column_clean import clean_columns, lowercase_columns
   
   # Alternative: sys.path.append (if custom location)
   import sys
   sys.path.append("/Workspace/libs")
   from column_clean import clean_columns
   ```

**Resolution**:
- Upload utility module to Databricks:
  ```bash
  dbfs cp pythonutilities/pythonutilities/src/utility/column_clean.py \
    dbfs:/Workspace/utility/column_clean.py
  ```
- OR: Use inline utilities (set `inline_utils=true` in scaffold)
- Restart Databricks cluster after upload

---

### Issue 4: Schema Mismatch After Conversion

**Error Signature**:
```
AssertionError: Column not found: 'order_date'
TypeError: Column 'LOADDATE' has wrong type (expected timestamp, got long)
```

**Root Causes**:
1. Column cleaning logic not preserved
2. Cast configurations missing
3. Transformation logic altered

**Diagnostic Steps**:

1. **Compare original Foundry transform with PySpark**:
   ```python
   # Foundry: cast_to_timestamp_from_long_columns = ['LOADDATE']
   # PySpark: Verify this list is in generated script
   
   with open('generated/transforms/x_eric.py', 'r') as f:
       content = f.read()
       if 'cast_to_timestamp_from_long_columns' not in content:
           print("❌ Cast configuration missing")
   ```

2. **Check clean_columns function call**:
   ```python
   # Foundry transform
   df = clean_columns(df.dataframe(), date_format, datetime_format, ...)
   
   # PySpark transform
   df = clean_columns(df, date_format, datetime_format, ...)
   # Note: df.dataframe() → df (Spark DataFrame already)
   ```

**Resolution**:
- Re-run scaffold with `preserve_transformations=true`
- Manually verify cast configurations in generated script
- Compare schemas:
  ```python
  foundry_schema = get_foundry_schema()
  pyspark_schema = df_transformed.schema
  print(foundry_schema.compare(pyspark_schema))
  ```

---

### Issue 5: Incremental Mode Not Detected

**Error Signature**:
```
# Expected: mode("append")
# Actual: mode("overwrite")
```

**Root Causes**:
1. `@incremental` decorator not detected
2. Load type defaulted to "full"

**Diagnostic Steps**:

1. **Check Foundry file for @incremental decorator**:
   ```python
   with open(foundry_file, 'r') as f:
       content = f.read()
   
   if '@incremental' in content:
       print("✅ Incremental decorator found")
   else:
       print("❌ No @incremental decorator (defaulting to full load)")
   ```

2. **Verify PySpark script write mode**:
   ```python
   with open('generated/transforms/x_eric.py', 'r') as f:
       content = f.read()
       
       if 'mode("append")' in content:
           print("✅ Incremental mode (append)")
       elif 'mode("overwrite")' in content:
           print("⚠️  Full load mode (overwrite)")
   ```

**Resolution**:
- If `@incremental` exists in Foundry, manually update PySpark:
  ```python
  df_transformed.write.mode("append").parquet(OUTPUT_PATH)
  ```
- Add watermark filtering:
  ```python
  if LOAD_TYPE == "incremental":
      df = df.filter(f"updated_at >= '{WATERMARK_VALUE}'")
  ```

---

## Debugging Workflow

### Step 1: Reproduce Error

```bash
# Run conversion with verbose logging
/scaffold foundry_file={file} --verbose

# Capture full traceback
python scaffold_transform.py {file} 2>&1 | tee conversion.log
```

### Step 2: Isolate Component

Test each step independently:

1. **RID extraction**:
   ```python
   input_rid, output_rid, load_type = extract_rids_from_transform(content)
   print(f"Input RID: {input_rid}")
   print(f"Output RID: {output_rid}")
   ```

2. **RID resolution**:
   ```python
   input_path, _ = resolve_rid_to_adls_path(input_rid, rid_mapping, env_config)
   print(f"Input path: {input_path}")
   ```

3. **Transformation extraction**:
   ```python
   transform_logic = extract_transform_logic(content)
   print(f"Function body: {transform_logic['function_body'][:200]}...")
   ```

### Step 3: Generate Diagnostic Report

```
================================================================================
🔧 Transform Conversion Debug Report
================================================================================

Foundry File: {foundry_file}
Generated Script: {pyspark_script}

Error:
------
{error_message}

Diagnostics:
------------

1. RID Extraction:
   Input RID: {input_rid} (found: {input_rid_found})
   Output RID: {output_rid} (found: {output_rid_found})

2. RID Resolution:
   Input RID in mapping: {input_in_mapping}
   Output RID in mapping: {output_in_mapping}
   Input ADLS path: {input_path}
   Output ADLS path: {output_path}

3. Transformation Logic:
   Function body extracted: {func_body_extracted}
   Column configs found: {column_configs_found}
   Cast lists preserved: {cast_lists_preserved}

4. Utilities:
   Import mode: {utilities_mode}
   Module accessible: {module_accessible}

Root Cause:
-----------
{root_cause}

Resolution:
-----------
{resolution_steps}

Next Steps:
-----------
1. {step_1}
2. {step_2}
3. {step_3}

================================================================================
```

---

**End of Debug Workflow**
