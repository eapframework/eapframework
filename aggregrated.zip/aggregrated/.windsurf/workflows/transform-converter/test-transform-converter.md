---
description: Validate converted PySpark scripts before deployment
glyphEnabled: true
glyph: test
---

User input: $ARGUMENTS

## Context

You are validating a **converted PySpark script** to ensure RID resolution correctness, ADLS path accessibility, transformation logic preservation, and schema compatibility before deployment.

**Core Validations**:
- RID resolution correctness
- ADLS path accessibility
- Transformation logic matches Foundry original
- Output schema matches expected
- Databricks job JSON validity

---

## Step 1: Validate RID Resolution

```python
def test_rid_resolution(foundry_file: str, rid_mapping_path: str):
    """Test that all RIDs were resolved correctly."""
    # Extract RIDs from Foundry file
    with open(foundry_file, 'r') as f:
        content = f.read()
    
    input_rid, output_rid, _ = extract_rids_from_transform(content)
    
    # Load mapping
    rid_mapping = pd.read_csv(rid_mapping_path)
    
    # Verify Input RID exists
    input_row = rid_mapping[rid_mapping['rid'] == input_rid]
    assert not input_row.empty, f"Input RID not found: {input_rid}"
    
    # Verify Output RID exists
    output_row = rid_mapping[rid_mapping['rid'] == output_rid]
    assert not output_row.empty, f"Output RID not found: {output_rid}"
    
    print(f"✅ RID resolution valid")
    print(f"   Input: {input_rid} → {input_row.iloc[0]['dataset_name']}")
    print(f"   Output: {output_rid} → {output_row.iloc[0]['dataset_name']}")
```

---

## Step 2: Test ADLS Path Accessibility

```python
def test_adls_paths(input_path: str, output_path: str, spark: SparkSession):
    """Test ADLS paths are accessible."""
    # Test input path exists
    try:
        files = spark._jvm.org.apache.hadoop.fs.FileSystem.get(
            spark._jsc.hadoopConfiguration()
        ).listStatus(
            spark._jvm.org.apache.hadoop.fs.Path(input_path)
        )
        print(f"✅ Input path accessible: {input_path}")
        print(f"   Files found: {len(files)}")
    except Exception as e:
        print(f"❌ Input path not accessible: {input_path}")
        print(f"   Error: {e}")
        raise
    
    # Test output path writable
    output_container = output_path.split('@')[0].split('//')[1]
    try:
        test_path = f"{output_path}/_test_write"
        test_df = spark.createDataFrame([(1,)], ["id"])
        test_df.write.mode("overwrite").parquet(test_path)
        
        # Cleanup
        spark._jvm.org.apache.hadoop.fs.FileSystem.get(
            spark._jsc.hadoopConfiguration()
        ).delete(
            spark._jvm.org.apache.hadoop.fs.Path(test_path),
            True
        )
        
        print(f"✅ Output path writable: {output_path}")
    except Exception as e:
        print(f"❌ Output path not writable: {output_path}")
        print(f"   Error: {e}")
        raise
```

---

## Step 3: Compare Schemas

```python
def test_schema_preservation(
    pyspark_script_path: str,
    foundry_file: str,
    expected_schema: dict
):
    """Test output schema matches expected schema."""
    # Run PySpark script (dry run mode)
    exec(open(pyspark_script_path).read())
    
    # Compare schemas
    actual_schema = df_transformed.schema
    
    for field in expected_schema['fields']:
        field_name = field['name']
        field_type = field['type']
        
        actual_field = next((f for f in actual_schema.fields if f.name == field_name), None)
        
        if actual_field is None:
            print(f"❌ Missing column: {field_name}")
            raise AssertionError(f"Column not found: {field_name}")
        
        if actual_field.dataType.simpleString() != field_type:
            print(f"❌ Type mismatch: {field_name}")
            print(f"   Expected: {field_type}")
            print(f"   Actual: {actual_field.dataType.simpleString()}")
            raise AssertionError(f"Type mismatch: {field_name}")
    
    print(f"✅ Schema validation passed")
```

---

## Step 4: Validate Databricks Job JSON

```python
import json
from jsonschema import validate, ValidationError

DATABRICKS_JOB_SCHEMA = {
    "type": "object",
    "required": ["name", "tasks"],
    "properties": {
        "name": {"type": "string"},
        "tasks": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["task_key", "spark_python_task"],
                "properties": {
                    "task_key": {"type": "string"},
                    "spark_python_task": {
                        "type": "object",
                        "required": ["python_file"],
                        "properties": {
                            "python_file": {"type": "string", "pattern": "^dbfs:/"}
                        }
                    }
                }
            }
        }
    }
}

def test_databricks_job_json(job_json_path: str):
    """Validate Databricks job JSON structure."""
    with open(job_json_path, 'r') as f:
        job_config = json.load(f)
    
    try:
        validate(instance=job_config, schema=DATABRICKS_JOB_SCHEMA)
        print(f"✅ Databricks job JSON valid")
    except ValidationError as e:
        print(f"❌ Invalid job JSON: {e.message}")
        raise
```

---

## Step 5: Run pytest Test Suite

```python
# tests/test_transform_conversion.py

import pytest
from pyspark.sql import SparkSession

@pytest.fixture(scope="session")
def spark():
    return SparkSession.builder.appName("TestTransformConversion").getOrCreate()


def test_rid_extraction():
    """Test RID extraction from Foundry file."""
    content = '''
    @transform(
        out=Output("ri.foundry.main.dataset.abc123"),
        df=Input("ri.foundry.main.dataset.xyz789"),
    )
    '''
    input_rid, output_rid, _ = extract_rids_from_transform(content)
    
    assert input_rid == "ri.foundry.main.dataset.xyz789"
    assert output_rid == "ri.foundry.main.dataset.abc123"


def test_pyspark_script_syntax(tmp_path):
    """Test generated PySpark script has valid syntax."""
    script_path = tmp_path / "test_transform.py"
    
    # Generate script
    script = generate_pyspark_script(...)
    script_path.write_text(script)
    
    # Compile (check syntax)
    compile(script, str(script_path), 'exec')


def test_transformation_logic_preserved(spark):
    """Test transformation logic produces expected output."""
    # Create sample input
    input_df = spark.createDataFrame([
        ("2026-01-01", 1000),
        ("2026-01-02", 2000),
    ], ["date_str", "value"])
    
    # Apply transformation
    output_df = transform(input_df)
    
    # Verify expected output
    assert output_df.count() == 2
    assert "date_str" in output_df.columns
    assert "value" in output_df.columns


# Run tests
# pytest tests/test_transform_conversion.py -v --cov
```

---

## Validation Checklist

- [x] RID resolution tested
- [x] ADLS paths accessible
- [x] Schema matches expected
- [x] Databricks job JSON valid
- [x] PySpark script valid syntax
- [x] Transformation logic preserved
- [x] pytest suite passing

---

**End of Test Workflow**
