---
description: Convert Palantir Foundry Transform Python files to Databricks PySpark pipelines with ADLS I/O
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# Transform Converter Workflow

**Archetype**: Transform Converter
**Purpose**: Convert Palantir Foundry Python transforms to Databricks PySpark pipelines
**Complexity**: Medium
**Expected Duration**: 10-20 minutes per transform

---

## When to Use This Workflow

Use `/transform-converter` when you encounter:
- Palantir Foundry Transform Python files needing migration
- RID-based Input/Output references requiring ADLS path resolution
- Column cleaning logic that must be preserved
- Incremental vs overwrite mode decisions
- Utility module dependencies needing Databricks workspace integration
- Databricks job configuration generation

---

## What This Workflow Does

**Core Capabilities:**
- Parse Foundry `@transform` decorators (Input/Output RIDs)
- Resolve RIDs to ADLS paths using `rid_mapping.csv`
- Convert Foundry API to PySpark (preserve transformation logic)
- Handle utility module imports (`column_clean.py`)
- Generate Databricks-ready PySpark scripts
- Create Databricks job definitions

**Conversion Mapping:**
- `Input("ri.foundry.main.dataset.XXX")` → `spark.read.parquet(ADLS_PATH)`
- `Output("ri.foundry.main.dataset.YYY")` → `df.write.parquet(ADLS_PATH)`
- `@incremental` decorator → `mode("append")` + watermark filtering
- `out.write_dataframe(df)` → `df.write.mode("overwrite").parquet()`

---

## Output Contract

All converted PySpark scripts write to:
```
abfss://{output_container}@{host_name}/{output_folder_name}/
```

**Format**: Parquet  
**Mode**: Overwrite (default) or Append (if `@incremental` detected)  
**Schema**: Preserved from transformation logic

---

## Strict Rules

- ✅ Preserve all transformation logic exactly (no business logic changes)
- ✅ Maintain column cleaning patterns (`clean_columns`, `lowercase_columns`)
- ✅ Resolve RIDs using `rid_mapping.csv` (no hard-coded paths)
- ✅ Reference utility modules from Databricks workspace
- ❌ NO schema changes beyond original transform
- ❌ NO hard-coded ADLS paths (use configuration)
- ❌ NO inline utility code (reference shared modules)

---

## Available Workflows

### 1. scaffold-transform-converter
**When**: Converting Foundry Transform Python file to PySpark  
**What**: Parses RIDs, resolves ADLS paths, generates Databricks-ready script  
**Output**: `generated/transforms/<dataset_name>.py`, Databricks job JSON  
**Triggers**: `/scaffold`, user provides Foundry transform file path

### 2. test-transform-converter
**When**: Validating converted PySpark script before deployment  
**What**: Tests RID resolution, ADLS path accessibility, transformation logic  
**Output**: pytest results, schema comparison report  
**Triggers**: `/test`, user requests "test converted transform"

### 3. compare-transform-converter
**When**: Choosing between conversion strategies  
**What**: Compares inline utils vs shared modules, overwrite vs incremental mode  
**Output**: Decision table with trade-offs  
**Triggers**: `/compare`, user asks "inline or shared utilities?"

### 4. debug-transform-converter
**When**: Troubleshooting conversion failures  
**What**: Diagnoses RID lookup errors, ADLS path resolution, import errors  
**Output**: Root cause analysis, resolution steps  
**Triggers**: `/debug`, user reports "conversion failed"

### 5. document-transform-converter
**When**: Creating conversion documentation  
**What**: Generates Foundry→Databricks mapping guide, runbook, examples  
**Output**: Markdown documentation with conversion patterns  
**Triggers**: `/document`, user requests "document conversion process"

### 6. refactor-transform-converter
**When**: Improving converted code quality  
**What**: Consolidates shared logic, optimizes imports, improves readability  
**Output**: Refactored PySpark scripts with improvement report  
**Triggers**: `/refactor`, user requests "clean up converted transforms"

---

## Dependencies

**Required Before Execution**:
- `rid_mapping.csv`: RID to dataset name mappings
- `env-config.yaml`: ADLS connection configuration
- Utility modules uploaded to Databricks workspace (`column_clean.py`)
- Foundry Transform Python file (source)

**Integration Points**:
- **metadata-extractor**: Provides RID mappings from Palantir API
- **ingestion-specialist**: Provides Raw zone data consumed by transforms
- **data-validator**: Validates transformed data quality
- **migration-orchestrator**: Sequences transform conversions

---

## Success Criteria

**Conversion Valid**:
- ✅ All Input/Output RIDs resolved to ADLS paths
- ✅ Transformation logic preserved exactly
- ✅ Utility module imports reference Databricks workspace
- ✅ Write mode matches original (`@incremental` → append, else overwrite)
- ✅ Column configurations preserved (cast lists, format strings)

**Script Executable**:
- ✅ PySpark script runs without syntax errors
- ✅ ADLS paths accessible from Databricks
- ✅ Utility modules importable
- ✅ Output schema matches original Foundry transform
- ✅ Row count matches source (within tolerance)

**Databricks Job Created**:
- ✅ Job JSON valid
- ✅ Task references correct script path
- ✅ Cluster configuration appropriate (workers, Spark version)

---

## Common Failure Modes

### RID Not Found in Mapping
- **Symptom**: `KeyError: 'ri.foundry.main.dataset.XXX'`
- **Resolution**: Update `rid_mapping.csv` with missing RID, re-run conversion

### ADLS Path Resolution Error
- **Symptom**: `ValueError: Cannot resolve ADLS path for dataset`
- **Resolution**: Verify `env-config.yaml` has correct container, folder, host_name

### Utility Module Import Error
- **Symptom**: `ModuleNotFoundError: No module named 'utility.column_clean'`
- **Resolution**: Upload `column_clean.py` to Databricks workspace `/Workspace/utility/`

### Schema Mismatch After Conversion
- **Symptom**: Output schema different from Foundry transform
- **Resolution**: Verify transformation logic preserved, check column cleaning patterns

---

## Environment Variables

```yaml
ADLS_HOST_NAME: "<storage_account>.dfs.core.windows.net"
ADLS_INPUT_CONTAINER: "raw"
ADLS_OUTPUT_CONTAINER: "silver"
DATABRICKS_WORKSPACE_PATH: "/Workspace"
RID_MAPPING_PATH: ".cdo-aifc/data/rid_mapping.csv"
ENV_CONFIG_PATH: ".cdo-aifc/templates/03-data-engineering/pipeline-builder/env-config.yaml"
```

---

## Templates

**Available Templates**:
- `env-config.yaml`: ADLS connection configuration (host, containers, folders)
- `dev.yaml`: Development environment overrides (sample data, debug logging)

**Template Usage**:
```bash
# Convert Foundry transform with dev config
/scaffold foundry_file=x_eric_5gnr_cell_rrh.py config=dev.yaml
```

---

**End of Constitution**
