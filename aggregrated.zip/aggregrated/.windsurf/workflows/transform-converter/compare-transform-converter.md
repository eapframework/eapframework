---
description: Compare conversion strategies for utilities and load modes
glyphEnabled: true
glyph: compare
---

User input: $ARGUMENTS

## Comparison Framework

### Dimension 1: Utility Module Strategy

#### Inline Utilities vs Shared Databricks Workspace Modules

| Factor | Inline Utilities | Shared Modules |
|--------|------------------|----------------|
| **Code Duplication** | High (every transform has copy) | None (single source) |
| **Maintainability** | Low (update each transform) | High (update once) |
| **Deployment** | Easy (self-contained scripts) | Medium (upload to workspace) |
| **Debugging** | Easy (all code in one file) | Medium (multi-file debugging) |
| **Script Size** | Large (200-500 lines utilities) | Small (import only) |
| **Consistency** | Risk of divergence | Guaranteed consistency |

**Decision Tree**:
```
Is this a one-time migration?
├─ Yes → Use inline utilities (simpler deployment)
└─ No → Use shared modules (better long-term maintenance)

Will you have > 10 transforms?
├─ Yes → Use shared modules (avoid duplication)
└─ No → Inline acceptable
```

---

### Dimension 2: Write Mode Strategy

#### Overwrite vs Incremental (Append)

| Factor | Overwrite | Incremental (Append) |
|--------|-----------|----------------------|
| **When to Use** | Full refresh, small datasets | Large datasets, daily updates |
| **Data Volume** | All rows | Delta only |
| **Performance** | Slow (rewrites everything) | Fast (appends new rows) |
| **Complexity** | Low | Medium (requires watermark) |
| **Data Freshness** | Complete snapshot | Delta updates |
| **Storage** | Replaces previous | Accumulates (requires cleanup) |

**Recommendation**:
- **Overwrite**: Datasets < 10M rows, no watermark column available
- **Incremental**: Datasets > 10M rows, watermark column exists (`updated_at`, `load_date`)

---

### Dimension 3: ADLS Path Resolution

#### Hard-Coded vs Configuration-Driven

| Factor | Hard-Coded Paths | Configuration-Driven |
|--------|------------------|----------------------|
| **Flexibility** | None (requires code changes) | High (change config only) |
| **Environment Support** | Poor (dev/prod same paths) | Excellent (env-specific configs) |
| **Error Prone** | High (typos in paths) | Low (validated from RID mapping) |
| **Migration Effort** | Low (simple string replacement) | Medium (requires config files) |

**Recommendation**: Always use configuration-driven (RID mapping + env-config.yaml)

---

## Decision Matrix

### Scenario 1: Small Migration (< 10 Transforms)

**Input**:
- Transform count: 5 files
- Dataset sizes: 1-5M rows each
- Frequency: One-time migration

**Recommendation**:
```yaml
utilities: inline
write_mode: overwrite
path_resolution: configuration_driven
deployment: manual
```

**Rationale**:
- Inline utilities acceptable for small count
- Overwrite simpler for one-time migration
- Configuration still preferred (easier testing)

---

### Scenario 2: Large Migration (> 50 Transforms)

**Input**:
- Transform count: 100+ files
- Dataset sizes: 10M-1B rows
- Frequency: Recurring daily updates

**Recommendation**:
```yaml
utilities: shared_modules
write_mode: incremental
path_resolution: configuration_driven
deployment: automated_ci_cd
```

**Rationale**:
- Shared modules mandatory (avoid duplication)
- Incremental required for performance
- Configuration-driven for environment flexibility
- CI/CD for deployment at scale

---

## Comparison Output Template

```
================================================================================
🔍 Transform Conversion Strategy Comparison
================================================================================

Transform: {dataset_name}
Source: Foundry Transform ({foundry_file})

--------------------------------------------------------------------------------
Utility Module Strategy
--------------------------------------------------------------------------------

Option 1: Inline Utilities
  ✅ Pros:
     - Self-contained script (no external dependencies)
     - Easier debugging (all code visible)
     - Simpler deployment
  ❌ Cons:
     - Code duplication across transforms
     - Harder to maintain (update each file)
     - Larger script size (+300 lines)

Option 2: Shared Databricks Workspace Modules
  ✅ Pros:
     - No code duplication
     - Single source of truth
     - Easier maintenance (update once)
  ❌ Cons:
     - Requires workspace module upload
     - Multi-file debugging

Recommendation: {recommended_utility_strategy}
Reason: {reason}

--------------------------------------------------------------------------------
Write Mode Strategy
--------------------------------------------------------------------------------

Option 1: Overwrite (Full Refresh)
  Data Volume: All rows ({total_rows})
  Write Time: {overwrite_time} minutes
  Storage: Replaces previous data
  Best For: Datasets < 10M rows

Option 2: Incremental (Append)
  Data Volume: Delta only (~{delta_rows} rows/day)
  Write Time: {incremental_time} minutes
  Storage: Accumulates (requires periodic cleanup)
  Best For: Datasets > 10M rows, watermark column exists
  Requirement: Watermark column ({watermark_column})

Recommendation: {recommended_write_mode}
Savings: {time_savings}% faster, {storage_savings}% less storage churn

--------------------------------------------------------------------------------
Summary
--------------------------------------------------------------------------------

Recommended Configuration:

utilities: {recommended_utility_strategy}
write_mode: {recommended_write_mode}
path_resolution: configuration_driven

Expected Performance:
- Conversion time: {conversion_time} minutes
- Deployment time: {deployment_time} minutes
- Runtime: {runtime} minutes/execution

Next Steps:
1. Review recommendations
2. Update conversion config
3. Run scaffold: /scaffold foundry_file={foundry_file} inline_utils={inline_utils}
4. Test: /test script={output_script}

================================================================================
```

---

**End of Compare Workflow**
