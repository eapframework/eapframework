---
description: Generate Foundry→Databricks conversion documentation and runbooks
glyphEnabled: true
glyph: document
---

User input: $ARGUMENTS

## Documentation Templates

### Template 1: Foundry to Databricks Conversion Guide

**Filename**: `foundry-to-databricks-conversion-guide.md`

**Content**:

```markdown
# Foundry to Databricks Transform Conversion Guide

**Purpose**: Convert Palantir Foundry Transform Python files to Databricks PySpark pipelines  
**Target Audience**: Data Engineers migrating from Palantir to Azure  
**Last Updated**: {{current_date}}

---

## Overview

This guide documents the process of converting Palantir Foundry Transform files to Databricks-compatible PySpark scripts with ADLS I/O.

**Key Changes**:
- Foundry API → PySpark API
- RID-based references → ADLS paths
- `@transform` decorator → `main()` function
- `Input/Output` objects → `spark.read/write`

---

## Conversion Mapping

### 1. Import Statements

**Foundry**:
```python
from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns
```

**Databricks**:
```python
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from utility.column_clean import clean_columns, lowercase_columns  # From workspace
```

---

### 2. Transform Decorator

**Foundry**:
```python
@transform(
    out=Output("ri.foundry.main.dataset.abc123"),
    df=Input("ri.foundry.main.dataset.xyz789"),
)
def my_compute_function(out, df):
    # ...
```

**Databricks**:
```python
# RIDs resolved to ADLS paths
INPUT_PATH = "abfss://raw@storage.dfs.core.windows.net/dataset_input"
OUTPUT_PATH = "abfss://silver@storage.dfs.core.windows.net/dataset_output"

def transform(df: DataFrame) -> DataFrame:
    # ... (transformation logic moved here)
    return df

def main(spark: SparkSession) -> None:
    df = spark.read.parquet(INPUT_PATH)
    df_transformed = transform(df)
    df_transformed.write.mode("overwrite").parquet(OUTPUT_PATH)
```

---

### 3. DataFrame Access

**Foundry**:
```python
def my_compute_function(out, df):
    df_spark = df.dataframe()  # Access Spark DataFrame
    # ...
```

**Databricks**:
```python
def transform(df: DataFrame) -> DataFrame:
    # df is already a Spark DataFrame
    # ...
```

---

### 4. Writing Output

**Foundry**:
```python
def my_compute_function(out, df):
    # ...
    out.write_dataframe(df_clean)
```

**Databricks**:
```python
def main(spark: SparkSession) -> None:
    # ...
    df_transformed.write.mode("overwrite").parquet(OUTPUT_PATH)
```

---

### 5. Incremental Mode

**Foundry**:
```python
from transforms.api import incremental

@incremental()
@transform(...)
def my_compute_function(out, df):
    # ...
```

**Databricks**:
```python
def main(spark: SparkSession) -> None:
    df = spark.read.parquet(INPUT_PATH)
    
    # Apply watermark filter
    if LOAD_TYPE == "incremental":
        df = df.filter(f"updated_at >= '{WATERMARK_VALUE}'")
    
    # Append mode for incremental
    df_transformed.write.mode("append").parquet(OUTPUT_PATH)
```

---

## RID Resolution Process

### Step 1: Extract RIDs from Foundry File

```python
# Input RID: ri.foundry.main.dataset.xyz789
# Output RID: ri.foundry.main.dataset.abc123
```

### Step 2: Lookup RIDs in Mapping CSV

**File**: `rid_mapping.csv`

```csv
rid,dataset_name,container,folder_name
ri.foundry.main.dataset.xyz789,x_ndr_eric_lcell_rrh,raw,x_ndr_eric_lcell_rrh
ri.foundry.main.dataset.abc123,x_eric_5gnr_cell_rrh_clean,silver,x_eric_5gnr_cell_rrh_clean
```

### Step 3: Construct ADLS Paths

**From**: `env-config.yaml`

```yaml
storage:
  host_name: "datalakeeastus2prd.dfs.core.windows.net"
```

**Result**:
```
Input: abfss://raw@datalakeeastus2prd.dfs.core.windows.net/x_ndr_eric_lcell_rrh
Output: abfss://silver@datalakeeastus2prd.dfs.core.windows.net/x_eric_5gnr_cell_rrh_clean
```

---

## Utility Module Strategy

### Option 1: Shared Databricks Workspace Module (Recommended)

**Upload to Databricks**:
```bash
dbfs cp pythonutilities/pythonutilities/src/utility/column_clean.py \
  dbfs:/Workspace/utility/column_clean.py
```

**Import in PySpark**:
```python
from utility.column_clean import clean_columns, lowercase_columns
```

**Advantages**:
- ✅ No code duplication
- ✅ Single source of truth
- ✅ Easier maintenance

---

### Option 2: Inline Utilities

**Copy functions into each PySpark script**:
```python
def clean_columns(df: DataFrame, ...) -> DataFrame:
    # Inline implementation
    pass
```

**Advantages**:
- ✅ Self-contained scripts
- ✅ No external dependencies

**Disadvantages**:
- ❌ Code duplication
- ❌ Harder to update

---

## Conversion Workflow

### 1. Prepare Environment

```bash
# Ensure files exist
ls .cdo-aifc/data/rid_mapping.csv
ls .cdo-aifc/templates/03-data-engineering/pipeline-builder/env-config.yaml
```

### 2. Run Conversion

```bash
/scaffold foundry_file=transforms-python/src/myproject/datasets/clean/x_eric_5gnr_cell_rrh.py
```

### 3. Review Generated Files

```
generated/transforms/x_eric_5gnr_cell_rrh.py  # PySpark script
generated/jobs/x_eric_5gnr_cell_rrh_job.json  # Databricks job config
```

### 4. Test Conversion

```bash
/test script=generated/transforms/x_eric_5gnr_cell_rrh.py
```

### 5. Deploy to Databricks

```bash
# Upload script
dbfs cp generated/transforms/x_eric_5gnr_cell_rrh.py \
  dbfs:/jobs/transforms/x_eric_5gnr_cell_rrh.py

# Create job
databricks jobs create --json-file generated/jobs/x_eric_5gnr_cell_rrh_job.json
```

---

## Common Patterns

### Pattern 1: Column Cleaning

**Preserved from Foundry**:
```python
date_format = 'yyyyMMdd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
cast_to_timestamp_from_long_columns = ['LOADDATE']

df_clean = clean_columns(
    df,
    date_format,
    datetime_format,
    cast_to_timestamp_from_long_columns,
    []
)
```

---

### Pattern 2: Lowercase Column Names

**Preserved from Foundry**:
```python
df_clean = lowercase_columns(df_clean)
```

---

### Pattern 3: Business Logic Preservation

**Foundry**:
```python
df = df.filter(col("status") == "ACTIVE")
df = df.withColumn("total", col("price") * col("quantity"))
```

**Databricks** (unchanged):
```python
df = df.filter(col("status") == "ACTIVE")
df = df.withColumn("total", col("price") * col("quantity"))
```

---

## Troubleshooting

See [`debug-transform-converter.md`](debug-transform-converter.md) for detailed troubleshooting guide.

---

**End of Conversion Guide**
```

---

### Template 2: Transform Conversion Runbook

**Filename**: `transform-conversion-runbook.md`

```markdown
# Transform Conversion Runbook

**Dataset**: {{dataset_name}}  
**Foundry File**: {{foundry_file}}  
**Generated PySpark**: {{pyspark_script}}

---

## Pre-Conversion Checklist

- [ ] RID mapping CSV up-to-date
- [ ] env-config.yaml configured
- [ ] Utility modules uploaded to Databricks workspace
- [ ] Foundry transform file accessible

---

## Conversion Steps

### 1. Run Scaffold

```bash
/scaffold foundry_file={{foundry_file}}
```

**Expected Output**:
```
✅ Generated PySpark script: generated/transforms/{{dataset_name}}.py
✅ Generated Databricks job: generated/jobs/{{dataset_name}}_job.json
```

### 2. Review Generated Script

```python
# Verify RID resolution
INPUT_PATH = "{{input_path}}"
OUTPUT_PATH = "{{output_path}}"

# Verify transformation logic preserved
# ... (review column cleaning, business logic)
```

### 3. Test Locally (Optional)

```bash
/test script=generated/transforms/{{dataset_name}}.py
```

### 4. Upload to Databricks

```bash
dbfs cp generated/transforms/{{dataset_name}}.py \
  dbfs:/jobs/transforms/{{dataset_name}}.py
```

### 5. Create Databricks Job

```bash
databricks jobs create --json-file generated/jobs/{{dataset_name}}_job.json
```

### 6. Run Initial Test

```bash
databricks jobs run-now --job-id <job_id>
```

### 7. Validate Output

```python
# Check output path
df = spark.read.parquet("{{output_path}}")
print(f"Rows written: {df.count()}")

# Compare schema with Foundry original
foundry_schema = get_foundry_schema()
assert df.schema == foundry_schema
```

---

## Post-Conversion Checklist

- [ ] PySpark script tested successfully
- [ ] Schema matches Foundry original
- [ ] Row count matches source
- [ ] Databricks job created
- [ ] Documentation updated

---

**End of Runbook**
```

---

**End of Document Workflow**
