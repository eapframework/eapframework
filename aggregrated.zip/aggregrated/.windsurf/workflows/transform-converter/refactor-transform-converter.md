---
description: Improve converted PySpark code quality through consolidation and optimization
glyphEnabled: true
glyph: refactor
---

User input: $ARGUMENTS

## Refactoring Patterns

### Pattern 1: Consolidate Shared Transformation Logic

**Problem**: Multiple PySpark scripts have duplicate transformation logic

**Before** (5 separate scripts with 80% duplication):
```python
# x_eric_5gnr_cell_rrh.py
def transform(df: DataFrame) -> DataFrame:
    df = clean_columns(df, date_format, datetime_format, ...)
    df = lowercase_columns(df)
    df = df.filter(col("status") == "ACTIVE")  # Common logic
    return df

# x_nokia_5gnr_cell_rrh.py (80% duplicate)
def transform(df: DataFrame) -> DataFrame:
    df = clean_columns(df, date_format, datetime_format, ...)
    df = lowercase_columns(df)
    df = df.filter(col("status") == "ACTIVE")  # DUPLICATE
    return df
```

**After** (extracted common library):

**File**: `lib/common_transforms.py`
```python
"""Common transformation patterns for 5G NR cell datasets."""

from pyspark.sql import DataFrame
from pyspark.sql.functions import col
from utility.column_clean import clean_columns, lowercase_columns


def apply_standard_cleaning(
    df: DataFrame,
    date_format: str = 'yyyyMMdd',
    datetime_format: str = 'yyyy-MM-dd HH:mm:ss',
    cast_to_timestamp_cols: list = None
) -> DataFrame:
    """Apply standard column cleaning and lowercase."""
    df = clean_columns(
        df,
        date_format,
        datetime_format,
        cast_to_timestamp_cols or [],
        []
    )
    df = lowercase_columns(df)
    return df


def filter_active_records(df: DataFrame) -> DataFrame:
    """Filter for active status records."""
    return df.filter(col("status") == "ACTIVE")
```

**Refactored Scripts**:
```python
# x_eric_5gnr_cell_rrh.py (reduced from 150 → 50 lines)
from lib.common_transforms import apply_standard_cleaning, filter_active_records

def transform(df: DataFrame) -> DataFrame:
    df = apply_standard_cleaning(df, cast_to_timestamp_cols=['LOADDATE'])
    df = filter_active_records(df)
    return df
```

**Benefits**:
- ✅ Reduced duplication: 750 lines → 200 lines (73% reduction)
- ✅ Easier maintenance (update common logic once)
- ✅ Consistent behavior across transforms

---

### Pattern 2: Optimize Utility Module Imports

**Problem**: Every script imports same utilities individually

**Before** (each script):
```python
from utility.column_clean import clean_columns
from utility.column_clean import lowercase_columns
from utility.column_clean import remove_special_characters
from utility.column_clean import trim_whitespace
# ... 10 more imports
```

**After** (consolidated import):

**File**: `lib/__init__.py`
```python
"""Consolidated utilities for transform conversions."""

from utility.column_clean import (
    clean_columns,
    lowercase_columns,
    remove_special_characters,
    trim_whitespace,
    # ... all utilities
)

__all__ = [
    'clean_columns',
    'lowercase_columns',
    'remove_special_characters',
    'trim_whitespace',
]
```

**Refactored Scripts**:
```python
from lib import clean_columns, lowercase_columns
# Single import line
```

---

### Pattern 3: Extract Configuration to YAML

**Problem**: Hard-coded configurations in each PySpark script

**Before**:
```python
# x_eric_5gnr_cell_rrh.py (hard-coded)
date_format = 'yyyyMMdd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
cast_to_timestamp_from_long_columns = ['LOADDATE']
cast_to_date_from_string_columns = []

INPUT_PATH = "abfss://raw@storage.dfs.core.windows.net/x_ndr_eric_lcell_rrh"  # Hard-coded
OUTPUT_PATH = "abfss://silver@storage.dfs.core.windows.net/x_eric_5gnr_cell_rrh_clean"
```

**After**:

**File**: `configs/transforms/x_eric_5gnr_cell_rrh.yaml`
```yaml
# Transform configuration
dataset:
  name: "x_eric_5gnr_cell_rrh"
  description: "Eric 5G NR cell RRH cleaning transform"

paths:
  input: "abfss://raw@${STORAGE_ACCOUNT}.dfs.core.windows.net/x_ndr_eric_lcell_rrh"
  output: "abfss://silver@${STORAGE_ACCOUNT}.dfs.core.windows.net/x_eric_5gnr_cell_rrh_clean"

column_cleaning:
  date_format: "yyyyMMdd"
  datetime_format: "yyyy-MM-dd HH:mm:ss"
  cast_to_timestamp_from_long:
    - "LOADDATE"
  cast_to_date_from_string: []

write:
  mode: "overwrite"
  format: "parquet"
  options:
    compression: "snappy"
```

**Refactored Script**:
```python
import yaml
import os

def load_config(config_path: str) -> dict:
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Substitute environment variables
    storage_account = os.getenv('STORAGE_ACCOUNT', 'datalakeeastus2prd')
    config['paths']['input'] = config['paths']['input'].replace('${STORAGE_ACCOUNT}', storage_account)
    config['paths']['output'] = config['paths']['output'].replace('${STORAGE_ACCOUNT}', storage_account)
    
    return config

def main(spark: SparkSession, config_path: str = "configs/transforms/x_eric_5gnr_cell_rrh.yaml"):
    config = load_config(config_path)
    
    INPUT_PATH = config['paths']['input']
    OUTPUT_PATH = config['paths']['output']
    
    # ... rest of script
```

**Benefits**:
- ✅ Environment-specific configs (dev/prod)
- ✅ No hard-coded paths
- ✅ Easier configuration updates

---

### Pattern 4: Standardize Error Handling

**Problem**: Inconsistent or missing error handling

**Before**:
```python
def main(spark: SparkSession):
    df = spark.read.parquet(INPUT_PATH)  # No error handling
    df_transformed = transform(df)
    df_transformed.write.mode("overwrite").parquet(OUTPUT_PATH)
```

**After**:
```python
import logging

logger = logging.getLogger(__name__)

def main(spark: SparkSession):
    try:
        logger.info(f"Reading from: {INPUT_PATH}")
        df = spark.read.parquet(INPUT_PATH)
        logger.info(f"Rows read: {df.count():,}")
        
        logger.info("Applying transformations...")
        df_transformed = transform(df)
        
        logger.info(f"Writing to: {OUTPUT_PATH}")
        df_transformed.write.mode("overwrite").parquet(OUTPUT_PATH)
        logger.info(f"Rows written: {df_transformed.count():,}")
        
        logger.info("✅ Transform complete")
        
    except Exception as e:
        logger.error(f"❌ Transform failed: {str(e)}")
        logger.exception(e)
        raise
```

---

### Pattern 5: Add Data Quality Checks

**Problem**: No validation of transformed data

**Before**:
```python
def main(spark: SparkSession):
    df = spark.read.parquet(INPUT_PATH)
    df_transformed = transform(df)
    df_transformed.write.mode("overwrite").parquet(OUTPUT_PATH)
```

**After**:
```python
def validate_transformation(df_input: DataFrame, df_output: DataFrame):
    """Validate transformed data quality."""
    input_count = df_input.count()
    output_count = df_output.count()
    
    # Row count variance check (allow 1% tolerance)
    variance = abs(output_count - input_count) / input_count
    assert variance < 0.01, f"Row count variance too high: {variance:.2%}"
    
    # Null check on critical columns
    for col_name in ['id', 'status']:
        null_count = df_output.filter(col(col_name).isNull()).count()
        assert null_count == 0, f"Null values found in {col_name}: {null_count}"
    
    logger.info("✅ Data quality checks passed")


def main(spark: SparkSession):
    df = spark.read.parquet(INPUT_PATH)
    df_transformed = transform(df)
    
    # Validate before writing
    validate_transformation(df, df_transformed)
    
    df_transformed.write.mode("overwrite").parquet(OUTPUT_PATH)
```

---

## Refactoring Workflow

### Step 1: Analyze Converted Scripts

Scan for:
- Duplicate transformation logic
- Hard-coded configurations
- Missing error handling
- Inconsistent patterns

### Step 2: Extract Common Patterns

Identify shared logic:
- Column cleaning patterns
- Filter conditions
- Join operations
- Aggregations

### Step 3: Create Common Library

**File**: `lib/common_transforms.py`

Move shared logic into reusable functions.

### Step 4: Refactor Scripts

Update each script to use common library:
- Replace duplicate code with function calls
- Extract configs to YAML
- Add error handling
- Add data quality checks

### Step 5: Generate Refactoring Report

```
================================================================================
🔧 Transform Code Refactoring Report
================================================================================

Scope: {num_scripts} PySpark scripts
Date: {current_date}

Issues Identified:
------------------
1. ❌ Duplicate transformation logic (5 scripts, 80% duplication)
2. ❌ Hard-coded configurations (10 scripts)
3. ❌ No error handling (8 scripts)
4. ❌ No data quality checks (all scripts)

Refactoring Applied:
--------------------
1. ✅ Extracted common transforms: Created lib/common_transforms.py
2. ✅ Externalized configs: Migrated to configs/transforms/*.yaml
3. ✅ Added error handling: Logging + try/catch blocks
4. ✅ Added data quality checks: Row count validation, null checks

Code Quality Metrics:
---------------------
Before:
- Total lines: 3,500
- Code duplication: 65%
- Config files: 0
- Error handling: 20%

After:
- Total lines: 1,200 (66% reduction)
- Code duplication: 5%
- Config files: 10 (YAML)
- Error handling: 100%

Performance Impact:
-------------------
- No performance change (logic preserved)
- Easier debugging (centralized logging)
- Faster updates (change common library once)

Files Modified:
---------------
- lib/common_transforms.py (new)
- lib/__init__.py (new)
- configs/transforms/*.yaml (10 new files)
- All PySpark scripts (refactored imports, error handling)

Next Steps:
-----------
1. Review refactored code
2. Run regression tests
3. Deploy to dev environment
4. Update documentation

================================================================================
```

---

## Validation Checklist

- [x] Refactored code produces identical output
- [x] Code duplication reduced (< 10%)
- [x] Configurations externalized to YAML
- [x] Error handling added to all scripts
- [x] Data quality checks implemented
- [x] Common library unit tested
- [x] Regression tests pass

---

**End of Refactor Workflow**
