---
description: Generate test cases for validation logic across all layers
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /test-data-validator

Generate comprehensive test cases for validation notebooks.

## When to Use

After scaffolding validation notebooks to ensure correctness.

## Test Scenarios

### Happy Path Tests

**Test 1: Exact Match**
- Palantir count = 10,000
- Azure count = 10,000
- Expected: PASS

**Test 2: Within Threshold**
- Palantir count = 10,000
- Azure count = 9,950 (0.5% variance)
- Expected: PASS

### Edge Case Tests

**Test 3: Threshold Boundary**
- Palantir count = 10,000
- Azure count = 9,900 (1.0% variance)
- Expected: FAIL (exceeds 0.5% threshold)

**Test 4: Empty Tables**
- Palantir count = 0
- Azure count = 0
- Expected: PASS

**Test 5: Missing Azure Table**
- Palantir count = 10,000
- Azure table doesn't exist
- Expected: ERROR with clear message

**Test 6: API Timeout**
- Palantir API returns 500
- Expected: ERROR with retry logic

### Gate Logic Tests

**Test 7: Bronze Failure Stops Validation**
- Bronze: FAIL
- Expected: Silver/Gold not executed
- Report shows "stopped at Bronze"

**Test 8: Silver Failure Stops Validation**
- Bronze: PASS
- Silver: FAIL
- Expected: Gold not executed

## Example Usage

```bash
/test-data-validator validation notebooks

Behavior to validate:
- Happy path: 
  - Exact match → PASS
  - Small variance within threshold → PASS

- Edge cases:
  - Variance exceeds threshold → FAIL
  - Empty tables both sides → PASS
  - Missing table → ERROR
  - API timeout → ERROR with retry

- Gate logic:
  - Bronze fails → Silver/Gold skipped
  - Report shows clear failure reason

Output format:
- pytest-compatible test files
- Mock Palantir API responses
- Clear assertion messages
```

## Generated Test Structure

```
outputs/validation/tests/
├── test_bronze_validation.py
├── test_silver_validation.py
├── test_gold_validation.py
├── test_validation_utils.py
├── test_gate_logic.py
└── fixtures/
    ├── mock_palantir_responses.json
    ├── mock_table_catalog.json
    └── sample_thresholds.yaml
```

## Test File Templates

### test_bronze_validation.py
```python
import pytest
from unittest.mock import Mock, patch
from notebooks.validate_bronze import validate_layer

def test_bronze_validation_exact_match():
    """Bronze validation passes when counts match exactly."""
    # Mock Palantir API
    with patch('palantir_api_client.get_row_count') as mock_palantir:
        mock_palantir.return_value = 10000
        
        # Mock Azure query
        with patch('databricks_utils.get_table_count') as mock_azure:
            mock_azure.return_value = 10000
            
            # Run validator
            result = validate_layer("bronze", "test_table")
            
            # Assert
            assert result["status"] == "PASS"
            assert result["variance_pct"] == 0.0

def test_bronze_validation_within_threshold():
    """Bronze validation passes when variance within 0.5%."""
    with patch('palantir_api_client.get_row_count') as mock_palantir:
        mock_palantir.return_value = 10000
        
        with patch('databricks_utils.get_table_count') as mock_azure:
            mock_azure.return_value = 9950  # 0.5% variance
            
            result = validate_layer("bronze", "test_table")
            
            assert result["status"] == "PASS"
            assert result["variance_pct"] == 0.5

def test_bronze_validation_exceeds_threshold():
    """Bronze validation fails when variance exceeds 0.5%."""
    with patch('palantir_api_client.get_row_count') as mock_palantir:
        mock_palantir.return_value = 10000
        
        with patch('databricks_utils.get_table_count') as mock_azure:
            mock_azure.return_value = 9900  # 1.0% variance
            
            result = validate_layer("bronze", "test_table")
            
            assert result["status"] == "FAIL"
            assert result["variance_pct"] == 1.0

def test_bronze_validation_empty_tables():
    """Bronze validation passes when both tables are empty."""
    with patch('palantir_api_client.get_row_count') as mock_palantir:
        mock_palantir.return_value = 0
        
        with patch('databricks_utils.get_table_count') as mock_azure:
            mock_azure.return_value = 0
            
            result = validate_layer("bronze", "test_table")
            
            assert result["status"] == "PASS"
            assert result["variance_pct"] == 0.0

def test_bronze_validation_missing_azure_table():
    """Bronze validation errors when Azure table doesn't exist."""
    with patch('palantir_api_client.get_row_count') as mock_palantir:
        mock_palantir.return_value = 10000
        
        with patch('databricks_utils.get_table_count') as mock_azure:
            mock_azure.side_effect = Exception("Table not found")
            
            result = validate_layer("bronze", "test_table")
            
            assert result["status"] == "ERROR"
            assert "Table not found" in result["error_message"]
```

### test_gate_logic.py
```python
import pytest
from unittest.mock import Mock, patch
from notebooks.validate_all_layers import run_all_layer_validation

def test_gate_logic_stops_on_bronze_failure():
    """Silver/Gold validation skipped if Bronze fails."""
    with patch('notebooks.validate_bronze.validate_layer') as mock_bronze:
        mock_bronze.return_value = {
            "status": "FAIL",
            "summary": {"failed": 1}
        }
        
        with patch('notebooks.validate_silver.validate_layer') as mock_silver:
            with patch('notebooks.validate_gold.validate_layer') as mock_gold:
                
                result = run_all_layer_validation()
                
                # Assert bronze was called
                mock_bronze.assert_called_once()
                
                # Assert silver/gold were NOT called
                mock_silver.assert_not_called()
                mock_gold.assert_not_called()
                
                # Assert overall status is FAIL
                assert result["overall_status"] == "FAIL"
                
                # Assert only bronze in report
                assert len(result["layers"]) == 1
                assert result["layers"][0]["layer"] == "bronze"

def test_gate_logic_continues_on_bronze_success():
    """Silver validation runs if Bronze passes."""
    with patch('notebooks.validate_bronze.validate_layer') as mock_bronze:
        mock_bronze.return_value = {
            "status": "PASS",
            "summary": {"failed": 0}
        }
        
        with patch('notebooks.validate_silver.validate_layer') as mock_silver:
            mock_silver.return_value = {
                "status": "PASS",
                "summary": {"failed": 0}
            }
            
            with patch('notebooks.validate_gold.validate_layer') as mock_gold:
                mock_gold.return_value = {
                    "status": "PASS",
                    "summary": {"failed": 0}
                }
                
                result = run_all_layer_validation()
                
                # Assert all layers were called
                mock_bronze.assert_called_once()
                mock_silver.assert_called_once()
                mock_gold.assert_called_once()
                
                # Assert overall status is PASS
                assert result["overall_status"] == "PASS"
                
                # Assert all layers in report
                assert len(result["layers"]) == 3
```

## Mock Fixtures

### fixtures/mock_palantir_responses.json
```json
{
  "success_response": {
    "rowCount": 10000,
    "lastModified": "2026-01-22T14:00:00Z"
  },
  "timeout_response": {
    "error": "Request timeout after 30 seconds"
  },
  "auth_error": {
    "error": "Invalid authentication token"
  }
}
```

## Success Criteria

- All test files generated
- Tests cover happy path, edge cases, and gate logic
- Mock fixtures are realistic
- Tests are deterministic (no flaky tests)
- Clear assertion messages

## Running Tests

```bash
# Run all tests
pytest outputs/validation/tests/

# Run specific test file
pytest outputs/validation/tests/test_bronze_validation.py

# Run with coverage
pytest --cov=notebooks outputs/validation/tests/
```
