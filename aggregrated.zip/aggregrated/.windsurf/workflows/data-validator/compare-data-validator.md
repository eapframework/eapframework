---
description: Decide validation strategy before building
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /compare-data-validator

Decide validation approach before scaffolding.

## When to Use

Before building validation logic - make architectural decisions.

## Decision Points

### 1. Validation Depth

**Option A: Row Count Only (Phase 1 - Recommended for POC)**

Pros:
- Fast execution (< 5 minutes)
- Low compute cost
- Sufficient to prove pipeline correctness
- Easy to debug failures

Cons:
- Doesn't catch data corruption
- Doesn't detect schema drift
- May miss subtle data quality issues

Use for: POC, initial migration waves

**Option B: Row Count + Schema Validation**

Pros:
- Catches structural issues
- Validates column names/types
- Ensures data contracts maintained

Cons:
- More complex implementation
- Slower execution (10-15 minutes)
- Higher compute cost

Use for: Production readiness, critical datasets

**Option C: Row Count + Sample Hash Comparison**

Pros:
- Catches data corruption
- Validates actual data content
- Highest confidence in data parity

Cons:
- Expensive (compute + time)
- Complex to implement
- Requires deterministic hash function

Use for: Critical data, compliance requirements, post-POC

### 2. Threshold Strategy

**Option A: Uniform Thresholds (±0.5% all layers)**

Pros:
- Simple configuration
- Consistent expectations
- Easy to communicate

Cons:
- May be too loose for Gold layer
- Doesn't reflect data criticality

**Option B: Layer-Specific Thresholds (Recommended)**

Bronze: ±0.5% (raw ingestion variance acceptable)
Silver: ±0.5% (transformation should preserve data)
Gold: ±0.1% (business-ready must be accurate)

Pros:
- Matches data criticality
- Stricter where it matters most
- Allows for natural ingestion variance

Cons:
- More configuration
- Need to explain rationale to stakeholders

### 3. Validation Order

**Option A: Parallel (validate all layers simultaneously)**

Pros:
- Faster overall execution
- Get complete picture quickly

Cons:
- Wastes compute if Bronze is broken
- Harder to debug (multiple failures)
- Less clear root cause attribution

**Option B: Sequential with Gates (Bronze → Silver → Gold) - Recommended**

Pros:
- Stops on first failure (fail fast)
- Clearer debugging (know where to look)
- More efficient compute usage
- Better root cause attribution

Cons:
- Slightly slower (sequential not parallel)
- Won't see downstream issues if upstream fails

### 4. Reporting Format

**Option A: JSON Reports**

Pros:
- Machine-readable
- Easy to parse programmatically
- Good for automation/alerts

Cons:
- Not human-friendly
- Requires separate viewer

**Option B: JSON + HTML Dashboard**

Pros:
- Machine and human readable
- Visual pass/fail indicators
- Trend analysis over time

Cons:
- More complex to implement
- Requires web hosting

**Option C: JSON + Slack/Email Alerts**

Pros:
- Proactive notification
- No need to check manually
- Good for production

Cons:
- Alert fatigue risk
- Requires integration setup

## Example Usage

```bash
/compare-data-validator validation strategies

Context:
- Goal: Prove Palantir → Azure data parity for POC
- Timeline: 13-week POC
- Budget: Minimize compute costs
- Stakeholders: IBM team + AT&T data engineers

Decision criteria:
- Speed (must complete in < 5 minutes)
- Cost (cheap compute preferred)
- Sufficiency (enough to prove POC success)
- Simplicity (easy to debug and explain)

Expected output:
✅ Recommendation with rationale
⚠️ Tradeoffs and risks
📋 Decision record for documentation
```

## Recommended POC Configuration

**Validation Depth:** Row count only (Phase 1)
**Thresholds:** Layer-specific (Bronze/Silver ±0.5%, Gold ±0.1%)
**Order:** Sequential with gates (Bronze → Silver → Gold)
**Reporting:** JSON + timestamped files

**Rationale:**
- Fast enough for POC timeline
- Cheap compute cost (SQL queries only)
- Sufficient to prove pipeline correctness
- Can enhance in Phase 2 if needed
- Easy to debug and explain to stakeholders

**Phase 2 Enhancements (Post-POC):**
- Add schema validation for critical tables
- Add sample hash comparison for Gold layer
- Add automated Slack alerts
- Add trend analysis dashboard

## Decision Record Template

```markdown
# Data Validation Strategy Decision

**Date:** YYYY-MM-DD
**Decision:** Row count validation with layer-specific thresholds
**Status:** Approved
**Deciders:** Taylor, Palash, Sanjay

## Context

POC requires proving data parity between Palantir and Azure within 13 weeks.
Must minimize compute costs while providing sufficient confidence.

## Options Considered

1. Row count only (Phase 1)
2. Row count + schema validation
3. Row count + hash comparison

## Decision

Phase 1 (POC): Row count validation
- Bronze: ±0.5% variance acceptable
- Silver: ±0.5% variance acceptable
- Gold: ±0.1% variance acceptable (stricter)
- Sequential validation with gate logic

## Rationale

- **Speed:** Completes in < 5 minutes per use case
- **Cost:** SQL queries only, minimal compute
- **Sufficiency:** Proves pipeline moves data correctly
- **Simplicity:** Easy to debug and explain
- **Extensibility:** Can add schema/hash checks in Phase 2

## Consequences

**Accept:**
- Won't catch data corruption (mitigate: add Phase 2)
- Won't detect schema drift (mitigate: separate schema checks)
- Small variances may be false positives (mitigate: tune thresholds)

**Gain:**
- Fast iteration during POC
- Low compute costs
- Clear pass/fail criteria
- Easy stakeholder communication

## Review Date

End of POC (April 2026) - reassess for production migration

## Related Decisions

- Use Databricks Secret Manager for credentials (security)
- Generate timestamped JSON reports (audit trail)
- Stop validation on first layer failure (efficiency)
```

## Output

After comparison, provide:
1. **Recommended Approach:** Which options to use
2. **Rationale:** Why this approach fits your constraints
3. **Tradeoffs:** What you're accepting/gaining
4. **Decision Record:** Document for future reference
5. **Next Steps:** How to proceed with `/scaffold-data-validator`
