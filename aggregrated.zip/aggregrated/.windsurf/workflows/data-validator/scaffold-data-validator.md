---
description: Generate validation notebooks for Bronze, Silver, and Gold layers
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /scaffold-data-validator

Generate row count validation notebooks for medallion layers.

## When to Use

After running:
- Bronze ingestion (`ingestion-specialist`)
- Silver/Gold generation (`pipeline-generator`)

Before declaring a use case migration complete.

## What to Provide

**Required:**
- Layer to validate: `bronze`, `silver`, `gold`, or `all`
- Table catalog JSON (from Palantir API extraction)
- Variance thresholds per layer

**Optional:**
- Custom validation logic
- Specific tables to validate (subset)
- Output directory path

## Example Usage

```bash
/scaffold-data-validator all layers for OTIS

Context:
- Use case: OTIS network audit
- Tables: nokialte_nrcell, ericsson_5g_sites, regional_summary
- Thresholds: Bronze ±0.5%, Silver ±0.5%, Gold ±0.1%
- Include gate logic: stop on first layer failure

Requirements:
- PySpark notebooks for Databricks
- Palantir API integration for source counts
- Azure ADLS table queries for target counts
- JSON output with pass/fail status
- Timestamped validation reports

Output directory: outputs/validation/notebooks/
```

## Generated File Structure

```
outputs/validation/
├── notebooks/
│   ├── validate_bronze.py
│   ├── validate_silver.py
│   ├── validate_gold.py
│   ├── validate_all_layers.py
│   └── validation_utils.py
├── config/
│   ├── table_catalog.json
│   └── thresholds.yaml
└── tests/
    ├── test_bronze_validation.py
    ├── test_silver_validation.py
    ├── test_gold_validation.py
    └── fixtures/
        └── sample_table_catalog.json
```

## Notebook Templates

### validate_bronze.py
```python
# Databricks notebook for Bronze layer validation
# Compares Palantir bronze row counts with Azure bronze tables

from pyspark.sql import SparkSession
from datetime import datetime
import json

# Configuration
LAYER = "bronze"
THRESHOLD_PCT = 0.5

# Load table catalog
with open("config/table_catalog.json") as f:
    catalog = json.load(f)

# Validation logic
# [Generated based on table catalog]
```

### validate_all_layers.py
```python
# Sequential validation with gate logic
# Bronze → Silver → Gold

# Step 1: Validate Bronze
bronze_result = validate_layer("bronze")
if bronze_result["status"] == "FAIL":
    print("Bronze validation failed. Stopping.")
    exit(1)

# Step 2: Validate Silver
silver_result = validate_layer("silver")
if silver_result["status"] == "FAIL":
    print("Silver validation failed. Stopping.")
    exit(1)

# Step 3: Validate Gold
gold_result = validate_layer("gold")
```

## Configuration Files

### table_catalog.json
```json
{
  "bronze": [
    {
      "name": "nokialte_nrcell",
      "rid": "ri.foundry.main.dataset.abc123",
      "azure_path": "bronze.nokialte_nrcell"
    }
  ],
  "silver": [
    {
      "name": "nokia_lte_clean",
      "rid": "ri.foundry.main.dataset.def456",
      "azure_path": "silver.nokia_lte_clean"
    }
  ],
  "gold": [
    {
      "name": "regional_summary",
      "rid": "ri.foundry.main.dataset.ghi789",
      "azure_path": "gold.regional_summary"
    }
  ]
}
```

### thresholds.yaml
```yaml
bronze:
  variance_pct: 0.5
  rationale: "Raw ingestion may have minor timing differences"

silver:
  variance_pct: 0.5
  rationale: "Transformations should preserve data integrity"

gold:
  variance_pct: 0.1
  rationale: "Gold layer must be highly accurate for analytics"
```

## Validation Logic

**Bronze Layer:**
- Compare: Palantir bronze ↔ Azure bronze
- Threshold: ±0.5% variance acceptable
- Gate: Must pass before Silver validation

**Silver Layer:**
- Compare: Palantir silver ↔ Azure silver
- Threshold: ±0.5% variance acceptable
- Gate: Must pass before Gold validation

**Gold Layer:**
- Compare: Palantir gold ↔ Azure gold
- Threshold: ±0.1% variance acceptable (stricter)
- Gate: Final validation - POC success criteria

## Constraints

- Use Databricks Secret Manager for Palantir tokens
- Idempotent (safe to rerun)
- Generate timestamped reports
- Stop validation on first layer failure
- Clear error messages for debugging

## Success Criteria

- All notebooks generated successfully
- Configuration files validated
- Test files created
- Notebooks are syntactically valid Python
- Ready to run in Databricks environment

## Output

After scaffolding:
1. Review generated notebooks in `outputs/validation/notebooks/`
2. Configure `table_catalog.json` with your tables
3. Adjust `thresholds.yaml` if needed
4. Run `/test-data-validator` to generate test cases
5. Execute notebooks in Databricks
