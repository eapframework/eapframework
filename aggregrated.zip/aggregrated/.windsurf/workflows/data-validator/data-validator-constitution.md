---
description: Validate data parity between Palantir and Azure across Bronze, Silver, and Gold layers
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# Data Validator Workflow

**Archetype**: Data Validator
**Purpose**: Validate row count parity across medallion layers to prove migration correctness
**Complexity**: Medium
**Expected Duration**: 10-15 minutes per layer

---

## When to Use This Workflow

Use `/data-validator` when you encounter:
- Need to prove Palantir → Azure data parity
- Bronze ingestion completion (verify raw data)
- Silver transformation completion (verify cleaned data)
- Gold aggregation completion (verify business-ready data)
- Debugging data loss or duplication issues
- POC success criteria validation

---

## What This Workflow Does

**Phase 1 (Current):**
- Row count comparison (Palantir vs Azure)
- Layer-specific variance thresholds
- Sequential validation with gate logic
- Pass/fail reporting with timestamps

**Validation Layers:**
- Bronze: ±0.5% variance acceptable
- Silver: ±0.5% variance acceptable
- Gold: ±0.1% variance acceptable (stricter)

**Phase 2 (Future):**
- Schema validation (column types/names)
- Sample hash comparison (data integrity)
- Business rule validation
- Data quality metrics

---

## Core Workflows

### `/scaffold-data-validator`
Generate validation notebooks for specified layer(s)

**Triggers:**
- "generate validation notebook"
- "create data validator"
- "scaffold bronze validation"

**Outputs:**
- `validate_bronze.py`
- `validate_silver.py`
- `validate_gold.py`
- `validate_all_layers.py`
- `config/table_catalog.json`
- `config/thresholds.yaml`

### `/test-data-validator`
Generate test cases for validation logic

**Triggers:**
- "test validation logic"
- "create validator tests"
- "test gate logic"

**Outputs:**
- `test_bronze_validation.py`
- `test_silver_validation.py`
- `test_gold_validation.py`
- Mock fixtures for deterministic testing

### `/compare-data-validator`
Decide validation strategy before building

**Decision Points:**
- Row count only vs row count + schema
- Uniform thresholds vs layer-specific
- Parallel vs sequential validation
- Phase 1 vs Phase 2 scope

### `/debug-data-validator`
Troubleshoot validation failures

**Common Issues:**
- Row count mismatch (data loss)
- Azure table not found
- Palantir API timeout
- Variance exceeds threshold

### `/document-data-validator`
Generate runbook for operational use

**Output:**
- How to run validation
- How to interpret reports
- Troubleshooting guide
- Escalation procedures

### `/refactor-data-validator`
Improve code quality without changing behavior

**Goals:**
- Extract reusable validation functions
- Add comprehensive docstrings
- Reduce code duplication
- Ensure deterministic output

---

## Dependencies

**Prerequisites:**
- Archetype: `ingestion-specialist` (Bronze tables exist)
- Archetype: `pipeline-generator` (Silver/Gold notebooks exist)
- External: Palantir Catalog API access
- External: Databricks SQL access

**Consumers:**
- POC evidence pack
- Production monitoring
- Migration wave planning

---

## Success Criteria

- All layers pass within thresholds
- Reports generated in < 5 minutes
- Clear failure attribution (table, layer)
- Automated alerts on failures
- Idempotent (safe to rerun)

---

## Tags

- validation
- data-quality
- reconciliation
- medallion-architecture
- poc-critical
