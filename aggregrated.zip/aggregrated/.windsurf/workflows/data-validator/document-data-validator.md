---
description: Generate operational runbook for validation workflows
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /document-data-validator

Create operational documentation for validation workflows.

## When to Use

After validation notebooks are working - document for team use.

## What to Include

**Target Audience:** Data engineers running OTIS migration (IBM team + AT&T engineers)

**Scope:**
- Prerequisites (what must run first)
- Configuration steps (table catalog, thresholds)
- Execution instructions (commands, Databricks UI)
- Report interpretation (pass/fail/error meanings)
- Troubleshooting guide (common failures)
- Escalation procedures (when to ask for help)

**Exclude:**
- Code implementation details (documented in notebooks)
- Palantir API internals (reference external docs)
- Architectural decisions (link to decision records)

## Example Usage

```bash
/document-data-validator runbook for OTIS

Target audience: Data engineers on IBM Blueprint Pod
Include:
- Prerequisites checklist
- Configuration walkthrough
- Step-by-step execution guide
- Report interpretation guide
- Troubleshooting common issues
- When to escalate

Output format: Markdown runbook
Location: outputs/validation/RUNBOOK.md
```

## Runbook Template

### OTIS Data Validation Runbook

**Version:** 1.0.0
**Last Updated:** 2026-01-22
**Owner:** Blueprint Pod - Taylor
**Audience:** IBM Data Engineers + AT&T SMEs

---

#### Prerequisites

Before running validation:

✅ Bronze ingestion completed (`ingestion-specialist`)
✅ Silver/Gold notebooks generated (`pipeline-generator`)
✅ Databricks cluster running (DBR 13.3+, Standard cluster)
✅ Palantir API access configured (token in Secret Manager)
✅ Table catalog JSON prepared (from metadata extraction)

---

#### Configuration

**Step 1: Update Table Catalog**

Edit `config/table_catalog.json` with your tables:

```json
{
  "bronze": [
    {
      "name": "nokialte_nrcell",
      "rid": "ri.foundry.main.dataset.abc123",
      "azure_path": "bronze.nokialte_nrcell"
    }
  ],
  "silver": [...],
  "gold": [...]
}
```

**Step 2: Configure Thresholds (Optional)**

Edit `config/thresholds.yaml` if defaults don't work:

```yaml
bronze:
  variance_pct: 0.5  # Default: ±0.5%

silver:
  variance_pct: 0.5  # Default: ±0.5%

gold:
  variance_pct: 0.1  # Default: ±0.1% (stricter)
```

**Step 3: Configure Credentials**

Ensure Palantir token is in Databricks Secret Manager:

```bash
# Verify secret exists
databricks secrets list --scope palantir

# Should show: api-token
```

---

#### Running Validation

**Option 1: Validate All Layers (Recommended)**

```bash
# Import notebook to Databricks
databricks workspace import \
  notebooks/validate_all_layers.py \
  /Workspace/OTIS/validation/

# Run in Databricks UI
# 1. Open notebook
# 2. Select cluster
# 3. Click "Run All"
# 4. Wait 5-10 minutes
```

**Option 2: Validate Specific Layer**

```bash
# Bronze only
databricks workspace import notebooks/validate_bronze.py ...
# Run in Databricks UI

# Silver only
databricks workspace import notebooks/validate_silver.py ...
# Run in Databricks UI

# Gold only
databricks workspace import notebooks/validate_gold.py ...
# Run in Databricks UI
```

**Option 3: Command Line (Advanced)**

```bash
# Using Databricks CLI
databricks jobs create --json '
{
  "name": "OTIS Validation",
  "tasks": [{
    "task_key": "validate",
    "notebook_task": {
      "notebook_path": "/Workspace/OTIS/validation/validate_all_layers"
    },
    "existing_cluster_id": "your-cluster-id"
  }]
}'

databricks jobs run-now --job-id <job-id>
```

---

#### Interpreting Results

**Success Scenario:**

```json
{
  "overall_status": "PASS",
  "layers": [
    {
      "layer": "bronze",
      "summary": {"total": 5, "passed": 5, "failed": 0}
    },
    {
      "layer": "silver",
      "summary": {"total": 8, "passed": 8, "failed": 0}
    },
    {
      "layer": "gold",
      "summary": {"total": 3, "passed": 3, "failed": 0}
    }
  ]
}
```

**What this means:**
- ✅ All layers passed validation
- ✅ Data parity confirmed
- ✅ POC success criteria met
- ✅ Safe to proceed to next use case

---

**Failure Scenario:**

```json
{
  "overall_status": "FAIL",
  "layers": [
    {
      "layer": "bronze",
      "summary": {"total": 5, "passed": 4, "failed": 1},
      "results": [
        {
          "table": "ericsson_5g_sites",
          "status": "FAIL",
          "variance_pct": 0.67,
          "palantir_count": 450000,
          "azure_count": 447000
        }
      ]
    }
  ]
}
```

**What this means:**
- ❌ Bronze layer failed (1 table)
- ❌ Silver/Gold not validated (gate logic stopped)
- ⚠️ 3,000 rows missing in ericsson_5g_sites table
- 🔧 Need to debug and fix bronze issue first

---

**Error Scenario:**

```json
{
  "table": "nokia_lte_cells",
  "status": "ERROR",
  "error_message": "Table not found: bronze.nokia_lte_cells"
}
```

**What this means:**
- ⚠️ Technical issue (not data variance)
- 🔧 Table doesn't exist in Azure
- 🔧 Check if ingestion archetype ran
- 🔧 Verify table name in catalog

---

#### Troubleshooting Common Issues

**Issue 1: "Table not found"**

Cause: Upstream ingestion not completed

Fix:
```bash
# Verify table exists
spark.sql("SHOW TABLES IN bronze").show()

# If missing, run ingestion archetype
/scaffold-ingestion-specialist bronze for {table_name}
```

**Issue 2: "Palantir API timeout"**

Cause: Network or authentication issue

Fix:
```bash
# Check token
databricks secrets get --scope palantir --key api-token

# Test API manually
curl -H "Authorization: Bearer $TOKEN" \
  https://palantir.att.com/api/v1/datasets/{rid}/stats

# If expired, refresh token
```

**Issue 3: "Variance exceeds threshold"**

Cause: Data loss or timing issue

Fix:
```bash
# Check if data load is complete
SELECT MAX(ingestion_timestamp) FROM bronze.{table_name};

# If recent, wait 5 minutes and retry
# If old, investigate root cause (see /debug-data-validator)
```

**Issue 4: "Gate logic not stopping"**

Cause: Running layer validators independently

Fix:
```bash
# Don't run validate_bronze.py, validate_silver.py separately
# Use validate_all_layers.py for proper gate logic
```

---

#### When to Escalate

Escalate to Blueprint Pod (Taylor, Palash, Sanjay) if:

- ❌ Multiple tables failing consistently (> 3 tables)
- ❌ API access issues unresolved after 30 minutes
- ❌ Unknown root cause after following debug guide
- ❌ Validation logic needs architectural change
- ❌ Thresholds need adjustment (requires stakeholder approval)

**Escalation Channel:** Slack #att-deep-blueprint-pod

**Escalation Template:**

```markdown
🚨 Validation Escalation: OTIS Bronze Layer

**Issue:** Multiple bronze tables failing validation
**Tables Affected:** ericsson_5g_sites, nokia_lte_cells, samsung_5g_data
**Variance:** 0.6-0.8% (threshold: 0.5%)
**Root Cause:** Unknown after 30 minutes debugging
**Evidence:** Attached validation_report.json
**Impact:** Blocking POC demo preparation
**Urgency:** High (demo in 2 days)

**Tried:**
- ✅ Verified data load completed
- ✅ Checked Palantir timestamps
- ✅ Re-ran validation after 10-minute wait
- ❌ Variance still exceeding threshold

**Request:** Guidance on threshold adjustment or investigation
```

---

#### Appendix

**A. File Locations**

- Notebooks: `/Workspace/OTIS/validation/notebooks/`
- Config: `/Workspace/OTIS/validation/config/`
- Reports: `/dbfs/FileStore/OTIS/validation/reports/`
- Alerts: `/dbfs/FileStore/OTIS/validation/alerts/`

**B. Key Contacts**

- Blueprint Pod Lead: Taylor
- Solution Architect: Palash
- Lead Architect: Sanjay
- AT&T SME: Praveen

**C. Related Documentation**

- [Ingestion Archetype Runbook](../ingestion-specialist/RUNBOOK.md)
- [Pipeline Generator Guide](../pipeline-generator/RUNBOOK.md)
- [Validation Decision Record](../decisions/validation-strategy.md)

**D. Revision History**

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | 2026-01-22 | Taylor | Initial runbook |
