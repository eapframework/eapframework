---
description: Debug data validation failures with evidence-based troubleshooting
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /debug-data-validator

Troubleshoot validation failures with systematic evidence collection.

## When to Use

Use `/debug-data-validator` when you encounter:
- FAIL status in validation report
- ERROR status (technical issues)
- Unexpected variance patterns
- Palantir API failures
- Azure table not found errors
- Timeout or performance issues

## Required Evidence Pack

### 1. Validation Report

Provide the full JSON output from failed validation:

```json
{
  "table": "ericsson_5g_sites",
  "layer": "bronze",
  "palantir_count": 450000,
  "azure_count": 447000,
  "variance_pct": 0.6667,
  "threshold_pct": 0.5,
  "status": "FAIL"
}
```

### 2. Reproduction Steps

- Command used to run validation
- Table catalog configuration
- Threshold settings
- Databricks cluster configuration

### 3. Recent Changes

- New transforms deployed?
- Schema changes?
- Upstream pipeline failures?
- Infrastructure changes?

### 4. Error Logs

- Databricks job logs
- Palantir API errors
- Network/timeout issues
- Stack traces

## Example Usage

```bash
/debug-data-validator bronze failure for ericsson_5g_sites

Issue:
- Expected: PASS (variance within 0.5%)
- Actual: FAIL (variance 0.67%)

Evidence:
{
  "table": "ericsson_5g_sites",
  "layer": "bronze",
  "palantir_count": 450000,
  "azure_count": 447000,
  "variance_pct": 0.6667,
  "threshold_pct": 0.5,
  "status": "FAIL"
}

Reproduction:
python validate_bronze.py --table ericsson_5g_sites

Recent changes:
- Switched from full snapshot to incremental CDC
- Last successful validation: 2026-01-20

Goal: Identify where 3,000 rows are lost in the pipeline
```

## Common Failure Patterns

### Pattern 1: Row Count Mismatch

**Symptoms:** Azure count < Palantir count

**Likely Causes:**
- Incomplete data load (pipeline timeout)
- CDC missing changes
- Filter applied in Azure that doesn't exist in Palantir
- Timing issue (queried Azure before load completed)

**Debug Steps:**

```sql
-- Step 1: Check last update timestamp in Azure
SELECT MAX(ingestion_timestamp) FROM bronze.ericsson_5g_sites;

-- Step 2: Query Palantir for last modified time
-- Use Palantir API to get dataset modification time

-- Step 3: Compare time windows
-- If Azure timestamp is before Palantir, data load may be incomplete

-- Step 4: Check for filters
DESCRIBE EXTENDED bronze.ericsson_5g_sites;
-- Look for partition filters or table properties

-- Step 5: Check for duplicates (Azure count > Palantir)
SELECT COUNT(*) as total, COUNT(DISTINCT primary_key) as unique_count
FROM bronze.ericsson_5g_sites;
```

**Resolution:**
- If timing issue: Wait 5-10 minutes, rerun validation
- If CDC lag: Verify CDC pipeline is running
- If filter issue: Remove/adjust filter in Azure table
- If duplicates: Fix deduplication logic in ingestion

### Pattern 2: Azure Table Not Found

**Symptoms:** ERROR status with "table not found"

**Likely Causes:**
- Table not yet created by upstream archetype
- Typo in table name or database
- Wrong catalog/schema reference
- Permissions issue

**Debug Steps:**

```sql
-- Step 1: Verify table exists
SHOW TABLES IN bronze;

-- Step 2: Check table name in catalog
cat config/table_catalog.json | grep ericsson

-- Step 3: Verify exact path
SELECT * FROM bronze.ericsson_5g_sites LIMIT 1;

-- Step 4: Check permissions
SHOW GRANTS ON TABLE bronze.ericsson_5g_sites;
```

**Resolution:**
- If table doesn't exist: Run `ingestion-specialist` first
- If typo: Fix table_catalog.json
- If permissions: Grant SELECT to service account

### Pattern 3: Palantir API Timeout

**Symptoms:** ERROR status with API timeout

**Likely Causes:**
- Network connectivity issues
- Palantir instance overloaded
- Invalid authentication token
- API rate limiting

**Debug Steps:**

```bash
# Step 1: Test API manually
curl -H "Authorization: Bearer $TOKEN" \
  https://palantir.att.com/api/v1/datasets/{rid}/stats

# Step 2: Check token expiration
# Use jwt.io or similar to decode token

# Step 3: Check network connectivity
ping palantir.att.com

# Step 4: Verify API endpoint
echo $PALANTIR_API_URL
```

**Resolution:**
- If network issue: Check VPN/firewall
- If token expired: Refresh token
- If rate limited: Add exponential backoff
- If overloaded: Retry after 5 minutes

### Pattern 4: Variance at Threshold Boundary

**Symptoms:** FAIL with variance = 0.51% (threshold = 0.5%)

**Questions to Ask:**
- Is this a rounding issue?
- Is 0.51% materially different from 0.5%?
- Should threshold be adjusted?
- Is this consistent across multiple runs?

**Debug Steps:**

```python
# Recalculate variance manually
palantir_count = 450000
azure_count = 447000

variance = abs((azure_count - palantir_count) / palantir_count) * 100
print(f"Variance: {variance:.4f}%")  # More precision

# Check if rounding issue
if variance < 0.55:  # 0.5% + small buffer
    print("Consider adjusting threshold to 0.6%")
```

**Decision:**
- Bronze: ±0.5% → Consider adjusting to ±0.6% if consistent
- Silver: ±0.5% → Keep strict, investigate root cause
- Gold: ±0.1% → Keep very strict, must fix

### Pattern 5: Gate Logic Not Working

**Symptoms:** Silver validation ran even though Bronze failed

**Likely Causes:**
- Gate logic not implemented correctly
- Running layer validators independently
- Status field not checked properly

**Debug Steps:**

```python
# Check validate_all_layers.py logic
with open("notebooks/validate_all_layers.py") as f:
    content = f.read()
    
# Look for gate logic:
if "bronze_result['summary']['failed'] > 0" in content:
    print("Gate logic present")
else:
    print("Gate logic MISSING - FIX REQUIRED")
```

**Resolution:**
- Fix gate logic in validate_all_layers.py
- Ensure status checking before next layer
- Add tests for gate logic (test-data-validator)

## Debugging Workflow

### Step 1: Identify Failure Scope

```bash
# Which layer failed?
LAYER="bronze"

# Which tables failed?
FAILED_TABLES=("ericsson_5g_sites" "nokia_lte_cells")

# How many tables failed?
COUNT=2
```

### Step 2: Gather Evidence

```bash
# Collect validation report
cat outputs/validation_reports/bronze_*.json > debug_evidence.json

# Collect Databricks logs
databricks jobs list | grep validate_bronze

# Collect Palantir API logs
curl https://palantir.att.com/api/logs > palantir_logs.txt
```

### Step 3: Isolate Root Cause

**Hypothesis 1: Data Load Incomplete**

```sql
-- Check row count trend over time
SELECT 
  DATE(ingestion_timestamp) as date,
  COUNT(*) as row_count
FROM bronze.ericsson_5g_sites
GROUP BY DATE(ingestion_timestamp)
ORDER BY date DESC
LIMIT 7;

-- Look for sudden drop in row count
```

**Hypothesis 2: Filter Applied**

```sql
-- Check table properties
SHOW TBLPROPERTIES bronze.ericsson_5g_sites;

-- Look for partition filters or sampling
```

**Hypothesis 3: Timing Issue**

```python
# Compare timestamps
palantir_modified = "2026-01-22T14:00:00Z"
azure_ingestion = "2026-01-22T13:55:00Z"

# 5 minute lag might explain missing rows
if azure_ingestion < palantir_modified:
    print("Data load may not be complete - wait and retry")
```

### Step 4: Implement Fix

**Fix 1: Adjust Threshold (if variance acceptable)**

```yaml
# config/thresholds.yaml
bronze:
  variance_pct: 0.6  # Increased from 0.5
```

**Fix 2: Re-run Upstream (if data incomplete)**

```bash
# Re-run ingestion archetype
/scaffold-ingestion-specialist bronze for ericsson_5g_sites
```

**Fix 3: Add Buffer Time (if timing issue)**

```python
# In validate_all_layers.py
import time

print("Waiting 10 minutes for data load to complete...")
time.sleep(600)  # 10 minutes

# Then run validation
```

### Step 5: Verify Fix

```bash
# Re-run validation
python notebooks/validate_bronze.py --table ericsson_5g_sites

# Check new report
cat outputs/validation_reports/bronze_*.json | tail -20
```

## Escalation Criteria

Escalate to Blueprint Pod if:
- Multiple tables failing consistently (> 3 tables)
- Variance increasing over time
- API access issues unresolved after 30 minutes
- Unknown root cause after systematic debugging
- Validation logic needs architectural change

## Output

After debugging, provide:

1. **Root Cause:** What caused the failure
2. **Fix Applied:** What was changed
3. **Validation Result:** Did validation pass after fix?
4. **Prevention:** How to avoid this in future

**Example:**

```markdown
# Debug Report: ericsson_5g_sites Validation Failure

## Root Cause
CDC lag caused 5-minute delay between Palantir update and Azure ingestion.
Palantir modified: 2026-01-22T14:00:00Z
Azure ingested: 2026-01-22T13:55:00Z

## Fix Applied
Added 10-minute buffer before validation runs.
Modified validate_all_layers.py to wait after ingestion completes.

## Validation Result
PASS - variance reduced to 0.02% after buffer added.

## Prevention
Schedule validation to run 15 minutes after ingestion job completes.
Add dependency in workflow orchestration.
```
