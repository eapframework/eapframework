---
description: Improve validation code quality without changing behavior
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# /refactor-data-validator

Improve validation notebooks without changing behavior.

## When to Use

After validation works - cleanup for maintainability and team handoff.

## Refactor Goals

### 1. Extract Reusable Functions

Move duplicated code into `validation_utils.py`:

**Before (duplicated in validate_bronze.py, validate_silver.py, validate_gold.py):**

```python
# Duplicated 3 times
palantir_token = dbutils.secrets.get(scope="palantir", key="api-token")
response = requests.get(
    f"https://palantir.att.com/api/v1/datasets/{rid}/stats",
    headers={"Authorization": f"Bearer {palantir_token}"}
)
palantir_count = response.json()["rowCount"]

azure_count = spark.sql(f"SELECT COUNT(*) FROM {table_path}").collect()[0][0]

variance = abs((azure_count - palantir_count) / palantir_count) * 100
```

**After (in validation_utils.py):**

```python
def fetch_palantir_count(table_rid: str) -> int:
    """
    Fetch row count from Palantir dataset.
    
    Args:
        table_rid: Palantir dataset RID (e.g., ri.foundry.main.dataset.abc123)
    
    Returns:
        int: Row count from Palantir
    
    Raises:
        requests.HTTPError: If API call fails
        KeyError: If response doesn't contain rowCount
    """
    token = dbutils.secrets.get(scope="palantir", key="api-token")
    response = requests.get(
        f"https://palantir.att.com/api/v1/datasets/{table_rid}/stats",
        headers={"Authorization": f"Bearer {token}"},
        timeout=30
    )
    response.raise_for_status()
    return response.json()["rowCount"]

def fetch_azure_count(table_path: str) -> int:
    """
    Fetch row count from Azure table.
    
    Args:
        table_path: Full table path (e.g., bronze.nokialte_nrcell)
    
    Returns:
        int: Row count from Azure table
    
    Raises:
        AnalysisException: If table doesn't exist
    """
    result = spark.sql(f"SELECT COUNT(*) as cnt FROM {table_path}")
    return result.collect()[0]["cnt"]

def calculate_variance(source_count: int, target_count: int) -> float:
    """
    Calculate percentage variance between source and target counts.
    
    Args:
        source_count: Source system row count (Palantir)
        target_count: Target system row count (Azure)
    
    Returns:
        float: Variance percentage (0.0 to 100.0)
    
    Examples:
        >>> calculate_variance(10000, 9950)
        0.5
        >>> calculate_variance(0, 0)
        0.0
        >>> calculate_variance(10000, 0)
        100.0
    """
    if source_count == 0:
        return 0.0 if target_count == 0 else 100.0
    return abs((target_count - source_count) / source_count) * 100
```

### 2. Improve Readability

**Before:**

```python
for t in tbls:
    p = pc(t["rid"])
    a = ac(t["azure_path"])
    v = abs((a-p)/p)*100
    s = "PASS" if v <= th else "FAIL"
    res.append({"t": t["name"], "s": s, "v": v})
```

**After:**

```python
for table in tables:
    palantir_count = fetch_palantir_count(table["rid"])
    azure_count = fetch_azure_count(table["azure_path"])
    variance_pct = calculate_variance(palantir_count, azure_count)
    
    status = "PASS" if variance_pct <= threshold_pct else "FAIL"
    
    results.append({
        "table": table["name"],
        "status": status,
        "palantir_count": palantir_count,
        "azure_count": azure_count,
        "variance_pct": round(variance_pct, 4)
    })
```

### 3. Add Comprehensive Docstrings

**Before:**

```python
def validate_layer(layer, tables, threshold):
    # Validate tables
    results = []
    for table in tables:
        # Get counts
        p_count = get_palantir_count(table["rid"])
        a_count = get_azure_count(table["path"])
        # Check variance
        var = calc_var(p_count, a_count)
        status = "PASS" if var <= threshold else "FAIL"
        results.append({"table": table["name"], "status": status})
    return results
```

**After:**

```python
def validate_layer(layer_name: str, tables: List[Dict], threshold_pct: float) -> Dict:
    """
    Validate row counts for all tables in a medallion layer.
    
    This function iterates through all tables in the specified layer,
    fetches row counts from both Palantir and Azure, calculates variance,
    and determines pass/fail status based on the threshold.
    
    Args:
        layer_name: Name of the layer ("bronze", "silver", or "gold")
        tables: List of table configurations with keys:
            - name: Table name
            - rid: Palantir dataset RID
            - azure_path: Azure table path
        threshold_pct: Acceptable variance percentage (e.g., 0.5 for ±0.5%)
    
    Returns:
        Dict with keys:
            - layer: Layer name
            - threshold_pct: Threshold used
            - summary: Dict with total, passed, failed, errors counts
            - results: List of per-table validation results
            - timestamp: ISO timestamp of validation
    
    Examples:
        >>> tables = [{"name": "test", "rid": "ri.123", "azure_path": "bronze.test"}]
        >>> result = validate_layer("bronze", tables, 0.5)
        >>> result["summary"]["total"]
        1
    
    Raises:
        ValueError: If layer_name is not bronze/silver/gold
        requests.HTTPError: If Palantir API fails
        AnalysisException: If Azure table doesn't exist
    """
    if layer_name not in ["bronze", "silver", "gold"]:
        raise ValueError(f"Invalid layer: {layer_name}")
    
    results = []
    summary = {"total": 0, "passed": 0, "failed": 0, "errors": 0}
    
    for table in tables:
        try:
            palantir_count = fetch_palantir_count(table["rid"])
            azure_count = fetch_azure_count(table["azure_path"])
            variance_pct = calculate_variance(palantir_count, azure_count)
            
            status = "PASS" if variance_pct <= threshold_pct else "FAIL"
            
            result = {
                "table": table["name"],
                "layer": layer_name,
                "palantir_count": palantir_count,
                "azure_count": azure_count,
                "variance_pct": round(variance_pct, 4),
                "threshold_pct": threshold_pct,
                "status": status
            }
            
            results.append(result)
            summary["total"] += 1
            
            if status == "PASS":
                summary["passed"] += 1
            else:
                summary["failed"] += 1
                
        except Exception as e:
            results.append({
                "table": table["name"],
                "layer": layer_name,
                "status": "ERROR",
                "error_message": str(e)
            })
            summary["errors"] += 1
    
    return {
        "layer": layer_name,
        "threshold_pct": threshold_pct,
        "summary": summary,
        "results": results,
        "timestamp": datetime.utcnow().isoformat()
    }
```

### 4. Reduce Code Duplication

**Before (3 separate files with 90% duplicate code):**

- `validate_bronze.py` (200 lines)
- `validate_silver.py` (200 lines)
- `validate_gold.py` (200 lines)

**After (shared logic in validation_utils.py):**

- `validation_utils.py` (300 lines with all shared logic)
- `validate_bronze.py` (50 lines - just config and call to shared function)
- `validate_silver.py` (50 lines - just config and call to shared function)
- `validate_gold.py` (50 lines - just config and call to shared function)

### 5. Ensure Deterministic Output

**Before (fields in random order):**

```python
result = {
    "variance_pct": 0.5,
    "table": "nokialte_nrcell",
    "status": "PASS",
    "azure_count": 1234520,
    "palantir_count": 1234567
}
```

**After (fields in consistent order):**

```python
from collections import OrderedDict

result = OrderedDict([
    ("table", "nokialte_nrcell"),
    ("layer", "bronze"),
    ("palantir_count", 1234567),
    ("azure_count", 1234520),
    ("variance_pct", 0.5),
    ("threshold_pct", 0.5),
    ("status", "PASS")
])
```

## Example Usage

```bash
/refactor-data-validator validation notebooks

Goals:
- Extract validation logic into validation_utils.py
- Add comprehensive docstrings to all functions
- Remove code duplication across layer validators
- Improve variable names (no single-letter vars)
- Ensure deterministic JSON output
- Add type hints for all functions

What must not change:
- Validation behavior (pass/fail logic)
- Report schema (external tools depend on it)
- API contracts (Palantir/Databricks)

How to validate:
- All tests still pass (pytest)
- Reports match previous output format
- Run validation on sample data, compare results
- Code review by team member
```

## Refactoring Checklist

### Code Quality

- [ ] Extract reusable functions to validation_utils.py
- [ ] Add docstrings to all functions (Google style)
- [ ] Add type hints (mypy compatible)
- [ ] Remove single-letter variables
- [ ] Remove magic numbers (extract to constants)
- [ ] Remove commented-out code
- [ ] Consistent naming conventions (snake_case)

### Error Handling

- [ ] Add try-except blocks for API calls
- [ ] Add timeout to HTTP requests
- [ ] Add retry logic with exponential backoff
- [ ] Clear error messages (include context)
- [ ] Log errors before raising

### Performance

- [ ] Minimize API calls (cache when possible)
- [ ] Batch operations where supported
- [ ] Use efficient SQL queries
- [ ] Avoid unnecessary data conversions

### Maintainability

- [ ] Reduce code duplication (DRY principle)
- [ ] Extract configuration to YAML/JSON
- [ ] Separate concerns (API, DB, validation logic)
- [ ] Add inline comments for complex logic
- [ ] Consistent formatting (black, isort)

### Testing

- [ ] All tests pass after refactor
- [ ] Code coverage >= 80%
- [ ] No flaky tests
- [ ] Test determinism (same input → same output)

## Validation

After refactoring:

```bash
# Run tests
pytest outputs/validation/tests/ -v

# Check code quality
flake8 notebooks/
black --check notebooks/
mypy notebooks/

# Run validation on sample data
python notebooks/validate_all_layers.py --test-mode

# Compare outputs
diff outputs/before_refactor.json outputs/after_refactor.json

# Should show no differences in validation results
```

## Output

After refactoring, provide:

1. **Changes Summary:** What was refactored
2. **Test Results:** All tests passing
3. **Code Metrics:** Lines of code before/after, complexity
4. **Review:** Areas that still need improvement

**Example:**

```markdown
# Refactor Complete: Data Validation Notebooks

## Changes Summary

- Extracted 15 functions to validation_utils.py
- Added docstrings to 20 functions
- Reduced code duplication by 60% (600 lines → 450 lines)
- Added type hints to all functions
- Removed 50 lines of commented-out code

## Test Results

✅ All 32 tests passing
✅ Code coverage: 85%
✅ No flaky tests detected
✅ Validation results identical before/after refactor

## Code Metrics

- Lines of code: 600 → 450 (25% reduction)
- Cyclomatic complexity: 45 → 28 (38% reduction)
- Code duplication: 35% → 5%

## Review

Areas for future improvement:
- Add more unit tests for edge cases
- Consider async API calls for better performance
- Add caching for Palantir API responses
```
