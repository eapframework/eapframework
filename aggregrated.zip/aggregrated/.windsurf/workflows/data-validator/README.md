# Data Validator Archetype

## Overview

Validates data parity between Palantir and Azure across all medallion layers (Bronze, Silver, Gold) using row count reconciliation.

## Purpose

Prove that the migration pipeline correctly moves data from Palantir to Azure by comparing row counts at each layer. Phase 1 focuses on row count validation; Phase 2 will add schema validation and hash comparison.

## When to Use

- After bronze ingestion completes (validate raw data)
- After silver transformation completes (validate cleaned data)
- After gold aggregation completes (validate business-ready data)
- Before declaring a use case migration "complete"
- When debugging data loss or duplication issues

## Quick Start

```bash
# 1. Generate validation notebooks
/scaffold-data-validator all layers for OTIS

# 2. Configure table catalog
# Edit outputs/validation/config/table_catalog.json

# 3. Run validation
databricks workspace import outputs/validation/notebooks/validate_all_layers.py
# Run in Databricks UI

# 4. Review results
cat outputs/validation/reports/all_layers_*.json
```

## Workflows

### `/scaffold-data-validator`
Generate validation notebooks for Bronze, Silver, Gold layers

**Outputs:**
- `validate_bronze.py`, `validate_silver.py`, `validate_gold.py`
- `validate_all_layers.py` (with gate logic)
- `config/table_catalog.json`, `config/thresholds.yaml`

### `/test-data-validator`
Generate test cases for validation logic

**Outputs:**
- Unit tests for each layer
- Mock fixtures for deterministic testing
- Gate logic tests

### `/compare-data-validator`
Decide validation strategy before building

**Decision Points:**
- Row count only vs row count + schema
- Uniform vs layer-specific thresholds
- Parallel vs sequential validation

### `/debug-data-validator`
Troubleshoot validation failures

**Common Issues:**
- Row count mismatch
- Azure table not found
- Palantir API timeout
- Variance at threshold boundary

### `/document-data-validator`
Generate operational runbook

**Output:**
- Prerequisites checklist
- Configuration guide
- Execution instructions
- Troubleshooting guide

### `/refactor-data-validator`
Improve code quality

**Goals:**
- Extract reusable functions
- Add docstrings
- Reduce duplication
- Improve readability

## Archetype Structure

```
.windsurf/workflows/data-validator/
├── compare-data-validator.md
├── debug-data-validator.md
├── document-data-validator.md
├── refactor-data-validator.md
├── scaffold-data-validator.md
├── test-data-validator.md
├── data-validator-constitution.md
├── README.md (this file)
└── templates/
    ├── dev.yaml
    └── env-config.yaml
```

## Phase 1 Scope (Current)

- ✅ Row count validation
- ✅ Layer-specific thresholds (Bronze/Silver ±0.5%, Gold ±0.1%)
- ✅ Sequential validation with gate logic
- ✅ Pass/fail reporting with timestamps
- ✅ JSON output for automation

## Phase 2 Roadmap (Post-POC)

- ⏳ Schema validation (column names/types)
- ⏳ Sample hash comparison (data integrity)
- ⏳ Business rule validation
- ⏳ Data quality metrics
- ⏳ Automated Slack/email alerts
- ⏳ Trend analysis dashboard

## Dependencies

**Prerequisites:**
- `ingestion-specialist` archetype (Bronze tables exist)
- `pipeline-generator` archetype (Silver/Gold notebooks exist)
- Palantir Catalog API access
- Databricks SQL access

**External Tools:**
- Palantir REST API
- Databricks Secret Manager
- Azure ADLS Gen2

## Success Criteria

- All layers pass within thresholds
- Reports generated in < 5 minutes
- Clear failure attribution (table, layer)
- Automated alerts on failures
- Idempotent (safe to rerun)

## Key Files

**Configuration:**
- `table_catalog.json` - Tables to validate across all layers
- `thresholds.yaml` - Acceptable variance per layer

**Notebooks:**
- `validate_all_layers.py` - Main entry point (with gate logic)
- `validate_bronze.py` - Bronze layer validator
- `validate_silver.py` - Silver layer validator
- `validate_gold.py` - Gold layer validator
- `validation_utils.py` - Shared validation functions

**Reports:**
- `outputs/validation_reports/all_layers_*.json` - Comprehensive report
- `outputs/validation_reports/bronze_*.json` - Bronze-only report
- `outputs/validation_reports/silver_*.json` - Silver-only report
- `outputs/validation_reports/gold_*.json` - Gold-only report
- `outputs/alerts/failure_*.json` - Alert on failures

## Tags

- validation
- data-quality
- reconciliation
- medallion-architecture
- poc-critical

## Version History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | 2026-01-22 | Taylor | Initial archetype creation |
