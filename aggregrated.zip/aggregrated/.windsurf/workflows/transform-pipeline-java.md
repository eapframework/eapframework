---
description: Migrate Java Foundry Spark pipeline to PySpark Databricks notebook
---

# Java Foundry to PySpark Databricks Migration

Migrate a Java Foundry Spark pipeline to PySpark Databricks notebook by analyzing three source files and converting to executable Databricks code.

## Input

**Required**: Path to existing Java Foundry Transform file
```
/transform-pipeline-java <path_to_foundry_transform.java>
```

## Execution Steps

### 1. Load Configuration
- Read `.cdo-aifc/templates/03-data-engineering/pipeline-builder/env-config.yaml` for ADLS config
- Read `.cdo-aifc/memory/archetypes/03-data-engineering/pipeline-builder-constitution.md` for hard-stop rules

### 2. PipelineComputeTransform.java - INPUTS
Parse the @Input annotations to extract input dataset names:
- camelCase variable name → snake_case table name
- Example: `xNdrNokiaEnb` → `x_ndr_nokia_enb`

### 3. PipelineOutputs.java - OUTPUTS  
Parse the Dataset<Row> fields to extract output names:
- Remove "ObjectTypeBackingDatasource" suffix, convert to snake_case
- Example: `nrNokNetauditAs5706ObjectTypeBackingDatasource` → `nr_nok_netaudit_as5706`

### 4. PipelineLogic.java - TRANSFORMATION LOGIC
Parse the transform() method and convert Java Spark to PySpark:
- .select() → column selections
- .withColumn() → column transformations
- .join() → join operations
- .dropDuplicates() → deduplication
- .cast() → type conversions

## Configuration Parameters (CUSTOMIZE THESE)

    Storage Account: {{host_name}}
    Container: {{input_container_name}}
    Output Folder: {{OUTPUT_FOLDER_NAME}}

Table to ADLS Folder Mapping (case-sensitive, verify in ADLS):
```python
TABLE_TO_FOLDER_MAPPING = {
    "table_name": "ACTUAL_ADLS_FOLDER_NAME",
    # ...
}
```

## Requirements

1. Read input tables from ADLS Gen2 parquet using direct paths (no dbutils.fs.ls)
2. Map internal table names to exact ADLS folder names (case-sensitive)
3. Handle duplicate columns by renaming with _dup suffix
4. Write outputs as Parquet (not Delta) to avoid format conflicts
5. Delete existing output folder before write
6. Include retry logic for reading, logging, and validation cells
7. Use Databricks widgets for configurable parameters

## Key Helper Functions

- `drop_duplicate_columns(df)` - renames duplicate columns with _dup suffix
- `safe_select(df, columns)` - selects only columns that exist
- `safe_cast_int_to_string(df, col)` - safely casts int to string
- `construct_geo_point(df, lat, lon)` - creates geo point string
- `read_parquet_with_retry(path, max_retries)` - retry logic for reads

## Notebook Structure (6 Cells)

### Cell 1: Configuration
- Widgets for storage_account, container, output_folder
- ADLS base path construction
- Retry settings

### Cell 2: Helper Functions
- All utility functions listed above

### Cell 3: Load Inputs (from PipelineComputeTransform.java)
- TABLE_TO_FOLDER_MAPPING dictionary
- Read parquet from ADLS with retry
- Apply drop_duplicate_columns() to each input

### Cell 4: Transformations (from PipelineLogic.java)
- Port Java transform logic to PySpark
- Apply drop_duplicate_columns() after joins

### Cell 5: Write Outputs (from PipelineOutputs.java)
- Write parquet with folder cleanup
- Delete existing folder before write

### Cell 6: Validation
- Summary of inputs/outputs with row counts



## Key Conversion Patterns

| Java | PySpark |
|------|---------|
| `df.select("A", "B")` | `safe_select(df, ["A", "B"])` |
| `df.withColumn("X", col("Y").cast("string"))` | `df.withColumn("X", F.col("Y").cast(StringType()))` |
| `df.join(df2, col("A").equalTo(col("B")), "left")` | `df.join(df2, df["A"] == df2["B"], "left")` + `drop_duplicate_columns()` |
| `df.dropDuplicates("KEY")` | `df.dropDuplicates(["KEY"])` |
| `joinWithKeys(left, right, keys, "left", ...)` | Manual join + drop_duplicate_columns() |

## Common Issues & Solutions

1. **Permission errors on dbutils.fs.ls()** → Use direct path reading
2. **Duplicate columns after join** → Apply drop_duplicate_columns()
3. **Delta format conflict** → Delete folder before writing parquet
4. **Column name case mismatch** → Check actual ADLS data schema
5. **Ambiguous column reference** → Rename duplicates with _dup suffix

### Validate Against Constitution
Check against hard-stop rules:
- ✓ Idempotent write pattern
- ✓ Error handling included
- ✓ Type casting preserved
- ✓ Logging implemented

## Example Configuration

```python
# Storage Config
STORAGE_ACCOUNT = "datalakeeastus2prd"
CONTAINER = "otis-poc"
OUTPUT_FOLDER = "x_site_general_info_parquet"

# Table Mapping
TABLE_TO_FOLDER_MAPPING = {
    "x_ndr_nokia_enb": "x_ndr_nokia_enb",
    "levo_site_master_brd": "LEVO_SITE_MASTER_BRD",
    "fips_peas_cmas_table1": "FIPS_PEAs_CMAs_Table1",
    "x_eric_5gnr_cell_rrh": "x_eric_5gnr_cell_rrh",
    "x_nok_5gnr_cell_rrh": "x_nok_5gnr_cell_rrh",
    "x_ndr_nokia_lcell_rrh": "x_ndr_nokia_lcell_rrh",
    "x_ndr_eric_lcell_rrh": "x_ndr_eric_lcell_rrh",
    "ericssonlte_nrcelldu": "ERICSSONLTE.NRCellDU",
    "nokialte_nrcell": "nokialte_NRCELL",
}
```