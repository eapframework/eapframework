---
description: Transform mappings reference and code generation documentation
glyphEnabled: true
glyph: document
---

User input: $ARGUMENTS

## Pipeline Builder Transform Reference

Complete mapping of Palantir Pipeline Builder transform types to PySpark code.

---

## Transform Type: selectColumns

**Purpose**: Select subset of columns from DataFrame

**JSON Structure**:
```json
{
  "type": "selectColumns",
  "columns": ["CELLNAME", "LATITUDE", "LONGITUDE", "STATUS"]
}
```

**Generated PySpark**:
```python
df = safe_select(df, ["CELLNAME", "LATITUDE", "LONGITUDE", "STATUS"])
```

**Helper Function Required**:
```python
def safe_select(df, columns):
    """Select only existing columns, skip missing."""
    existing = set(df.columns)
    valid_cols = [c for c in columns if c in existing]
    if len(valid_cols) < len(columns):
        missing = set(columns) - existing
        print(f"⚠️  Columns not found: {missing}")
    return df.select(valid_cols)
```

---

## Transform Type: complexLeftJoin

**Purpose**: Left outer join between two DataFrames

**JSON Structure**:
```json
{
  "type": "complexLeftJoin",
  "leftDatasetRid": "ri.foundry.main.dataset.aaa",
  "rightDatasetRid": "ri.foundry.main.dataset.bbb",
  "onCondition": "SITEID"
}
```

**Generated PySpark**:
```python
# Join cell_data with site_master
df = df.join(site_master, df["SITEID"] == site_master["SITEID"], "left")
df = drop_duplicate_columns(df)  # Remove duplicate SITEID
```

**Helper Function Required**:
```python
def drop_duplicate_columns(df):
    """Rename duplicate columns with _dup suffix."""
    cols = df.columns
    seen = {}
    new_cols = []
    for col in cols:
        if col in seen:
            seen[col] += 1
            new_cols.append(f"{col}_dup{seen[col]}")
        else:
            seen[col] = 0
            new_cols.append(col)
    return df.toDF(*new_cols)
```

---

## Transform Type: dropDuplicates

**Purpose**: Remove duplicate rows based on key columns

**JSON Structure**:
```json
{
  "type": "dropDuplicates",
  "keys": ["CELLNAME", "DATE"]
}
```

**Generated PySpark**:
```python
df = df.dropDuplicates(["CELLNAME", "DATE"])
```

**No helper function needed** (native PySpark)

---

## Transform Type: applyExpression (cast)

**Purpose**: Cast column to different data type

**JSON Structure**:
```json
{
  "type": "applyExpression",
  "expressionType": "cast",
  "columnName": "CELLID",
  "fromType": "INTEGER",
  "toType": "STRING"
}
```

**Generated PySpark**:
```python
df = df.withColumn("CELLID", F.col("CELLID").cast("string"))
```

**Chained Casts**:
```python
# Cast INT → LONG → STRING
df = df.withColumn("CELLID", 
    F.col("CELLID").cast("long").cast("string")
)
```

---

## Transform Type: applyExpression (uuid)

**Purpose**: Generate UUID column

**JSON Structure**:
```json
{
  "type": "applyExpression",
  "expressionType": "uuid",
  "columnName": "row_id"
}
```

**Generated PySpark**:
```python
df = df.withColumn("row_id", F.expr("uuid()"))
```

---

## Transform Type: applyExpression (construct_geo_point)

**Purpose**: Create geographic point struct from latitude/longitude

**JSON Structure**:
```json
{
  "type": "applyExpression",
  "expressionType": "construct_geo_point",
  "latColumn": "LATITUDE",
  "lonColumn": "LONGITUDE",
  "outputColumn": "geo"
}
```

**Generated PySpark**:
```python
df = construct_geo_point(df, "LATITUDE", "LONGITUDE", "geo")
```

**Helper Function Required**:
```python
def construct_geo_point(df, lat_col, lon_col, output_col="geo"):
    """Construct geo point struct from lat/lon columns."""
    from pyspark.sql import functions as F
    return df.withColumn(output_col, 
        F.struct(F.col(lon_col), F.col(lat_col))
    )
```

---

## Transform Type: filter

**Purpose**: Filter rows based on condition

**JSON Structure**:
```json
{
  "type": "filter",
  "condition": "STATUS == 'ACTIVE'"
}
```

**Generated PySpark**:
```python
df = df.filter(F.col("STATUS") == "ACTIVE")
```

**Complex Conditions**:
```python
# Multiple conditions
df = df.filter(
    (F.col("STATUS") == "ACTIVE") & 
    (F.col("DATE") >= "2024-01-01")
)
```

---

## Transform Type: aggregate

**Purpose**: Aggregate DataFrame using functions (max, min, sum, etc.)

**JSON Structure**:
```json
{
  "type": "aggregate",
  "function": "max",
  "column": "LOADDATE"
}
```

**Generated PySpark**:
```python
max_loaddate = df.agg(F.max("LOADDATE")).collect()[0][0]
print(f"Max LOADDATE: {max_loaddate}")
```

**Multiple Aggregations**:
```python
agg_result = df.agg(
    F.max("LOADDATE").alias("max_date"),
    F.min("LOADDATE").alias("min_date"),
    F.count("*").alias("row_count")
).collect()[0]

print(f"Date range: {agg_result.min_date} to {agg_result.max_date}")
print(f"Row count: {agg_result.row_count:,}")
```

---

## Contour Expression Reference

Mapping of Contour board expressions to PySpark.

---

## Expression: ROUND

**Contour**:
```
ROUND("value", 2)
```

**PySpark**:
```python
df = df.withColumn("value", F.round(F.col("value"), 2))
```

---

## Expression: CAST

**Contour**:
```
CAST("id" AS STRING)
```

**PySpark**:
```python
df = df.withColumn("id", F.col("id").cast("string"))
```

---

## Expression: CONCAT

**Contour**:
```
CONCAT("first_name", " ", "last_name")
```

**PySpark**:
```python
df = df.withColumn("full_name", 
    F.concat(F.col("first_name"), F.lit(" "), F.col("last_name"))
)
```

---

## Expression: UPPER / LOWER

**Contour**:
```
UPPER("name")
LOWER("email")
```

**PySpark**:
```python
df = df.withColumn("name", F.upper(F.col("name")))
df = df.withColumn("email", F.lower(F.col("email")))
```

---

## Expression: TRIM

**Contour**:
```
TRIM("description")
```

**PySpark**:
```python
df = df.withColumn("description", F.trim(F.col("description")))
```

---

## Expression: COALESCE

**Contour**:
```
COALESCE("value1", "value2", 0)
```

**PySpark**:
```python
df = df.withColumn("result", 
    F.coalesce(F.col("value1"), F.col("value2"), F.lit(0))
)
```

---

## Board Type: sort-columns

**Contour**:
```json
{
  "boardType": "custom",
  "customBoardId": "sort-columns",
  "sortDirection": {
    "region": "ASC",
    "site_id": "DESC"
  }
}
```

**PySpark**:
```python
df = df.orderBy(
    F.col("region").asc(),
    F.col("site_id").desc()
)
```

---

## Generated Notebook Template

**Complete Structure**:

```python
# Databricks notebook source
# Generated from {json_file}
# Generated on: {timestamp}

# COMMAND ----------
# Cell 1: Configuration

from pyspark.sql import functions as F
from pyspark.sql.types import *

STORAGE_ACCOUNT = "{storage_account}"
CONTAINER = "{container}"

# COMMAND ----------
# Cell 2: Helper Functions

def safe_select(df, columns):
    """Select only existing columns."""
    existing = set(df.columns)
    valid_cols = [c for c in columns if c in existing]
    return df.select(valid_cols)

def drop_duplicate_columns(df):
    """Rename duplicate columns with _dup suffix."""
    cols = df.columns
    seen = {}
    new_cols = []
    for col in cols:
        if col in seen:
            seen[col] += 1
            new_cols.append(f"{col}_dup{seen[col]}")
        else:
            seen[col] = 0
            new_cols.append(col)
    return df.toDF(*new_cols)

def cast_to_string(df, col_name):
    """Cast column to string type."""
    return df.withColumn(col_name, F.col(col_name).cast("string"))

def construct_geo_point(df, lat_col, lon_col, output_col="geo"):
    """Construct geo point struct from lat/lon."""
    return df.withColumn(output_col, F.struct(F.col(lon_col), F.col(lat_col)))

# COMMAND ----------
# Cell 3: Load Input Tables

{table_1} = spark.read.parquet(f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{path_1}")
{table_2} = spark.read.parquet(f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{path_2}")

# COMMAND ----------
# Cell 4: Initialize Output DataFrames

{output_1} = None
{output_2} = None

# COMMAND ----------
# Cell 5+: Transformations (one per transform)

# Transform 1: Select Columns
df = safe_select({input_table}, ["COL1", "COL2", "COL3"])

# Transform 2: Join
df = df.join({other_table}, condition, "left")
df = drop_duplicate_columns(df)

# Transform 3: Filter
df = df.filter(F.col("STATUS") == "ACTIVE")

# Transform 4: Drop Duplicates
df = df.dropDuplicates(["PRIMARY_KEY"])

# Assign to output
{output_1} = df

# COMMAND ----------
# Cell N: Write Outputs

# Write {output_1}
OUTPUT_PATH_1 = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{output_folder_1}"
if {output_1} is not None:
    {output_1}.write.mode("overwrite").parquet(OUTPUT_PATH_1)
    print(f"✅ Wrote {{{output_1}.count():,}} rows to {output_folder_1}")

# COMMAND ----------
# Cell N+1: Validation

print("\n" + "=" * 80)
print("Pipeline Execution Summary")
print("=" * 80)
print(f"{output_1}: {{{output_1}.count():,}} rows")
print(f"Columns: {{{output_1}.columns}}")
print("=" * 80)
```

---

## Helper Functions Catalog

| Function | Purpose | Required For |
|----------|---------|--------------|
| `safe_select()` | Select only existing columns | selectColumns |
| `drop_duplicate_columns()` | Rename duplicates after join | complexLeftJoin |
| `cast_to_string()` | Cast column to string | applyExpression (cast) |
| `construct_geo_point()` | Build geo struct | applyExpression (geo) |

---

## Testing Commands

**Validate notebook syntax**:
```bash
python -m py_compile netaudit_pipeline.py
```

**Run in Databricks**:
```bash
databricks workspace import netaudit_pipeline.py /Workspace/pipelines/
databricks jobs run-now --job-id 123
```

**Local PySpark test**:
```bash
spark-submit netaudit_pipeline.py
```

---

**End of Document Workflow**
