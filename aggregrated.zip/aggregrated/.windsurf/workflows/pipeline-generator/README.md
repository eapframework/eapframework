# Pipeline Generator Archetype

Generate executable PySpark Databricks notebooks from Palantir Pipeline Builder and Contour JSON exports.

## Quick Start

### Generate from Pipeline Builder JSON

```bash
# Step 1: Extract Pipeline JSON (see metadata-extractor archetype)
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-name netaudit

# Step 2: Generate PySpark notebook
python tools/generate_pipeline.py \
    --input pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json \
    --environment prod \
    --output netaudit_pipeline.py
```

**Output**: `pipeline_builder/DBX_Conversion/netaudit_pipeline.py`

### Generate from Contour JSON

```bash
# Step 1: Extract Contour JSON
python pipeline_builder/DBX_Conversion/fetch_contour.py

# Step 2: Generate PySpark notebook
python tools/generate_contour.py \
    --input pipeline_builder/DBX_Conversion/jsonexports/contour_latest.json \
    --output site_analysis.py
```

**Output**: `pipeline_builder/DBX_Conversion/site_analysis.py`

## What Gets Generated

### Pipeline Builder → PySpark Notebook

**Input**: Pipeline JSON with transforms
```json
{
  "snapshot": {
    "transforms": [
      {
        "type": "selectColumns",
        "columns": ["CELLNAME", "LATITUDE", "LONGITUDE"]
      },
      {
        "type": "complexLeftJoin",
        "left": "cell_data",
        "right": "site_master",
        "on": "SITEID"
      }
    ],
    "outputs": [
      {
        "name": "cell_with_site_data",
        "primaryKey": ["CELLNAME"],
        "mode": "SNAPSHOT"
      }
    ]
  }
}
```

**Output**: PySpark Notebook
```python
# Databricks notebook source
# Generated from netaudit_latest.json

# COMMAND ----------
# Configuration
STORAGE_ACCOUNT = "datalakeeastus2prd"
CONTAINER = "otis-poc"

# COMMAND ----------
# Load input tables
cell_data = spark.read.parquet(f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/raw/cell_data")
site_master = spark.read.parquet(f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/raw/site_master")

# COMMAND ----------
# Transform 1: Select columns
df = cell_data.select(["CELLNAME", "LATITUDE", "LONGITUDE"])

# COMMAND ----------
# Transform 2: Left join with site_master
df = df.join(site_master, df["SITEID"] == site_master["SITEID"], "left")
df = drop_duplicate_columns(df)  # Remove duplicate SITEID

# COMMAND ----------
# Write output
OUTPUT_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/silver/cell_with_site_data"
df.write.mode("overwrite").parquet(OUTPUT_PATH)
```

## Transform Mappings

### Pipeline Builder Transforms

| JSON Transform | PySpark Code | Notes |
|---------------|--------------|-------|
| `selectColumns: ["A", "B"]` | `df.select(["A", "B"])` | Use safe_select() if columns may be missing |
| `complexLeftJoin` | `df.join(df2, condition, "left")` | Always call drop_duplicate_columns() after |
| `dropDuplicates: ["key"]` | `df.dropDuplicates(["key"])` | Preserves first occurrence |
| `applyExpression: cast(X, int)` | `df.withColumn("X", F.col("X").cast(IntegerType()))` | Chain multiple casts |
| `filter: col > 0` | `df.filter(F.col("col") > 0)` | Use F.col() for safety |
| `aggregate: max(date)` | `df.agg(F.max("date"))` | Returns DataFrame |

### Contour Expressions

| Contour Expression | PySpark Equivalent |
|-------------------|-------------------|
| `ROUND("value", 2)` | `F.round(F.col("value"), 2)` |
| `CAST("id" AS STRING)` | `F.col("id").cast("string")` |
| `CONCAT("a", "b")` | `F.concat(F.col("a"), F.col("b"))` |
| `UPPER("name")` | `F.upper(F.col("name"))` |
| `COALESCE("a", "b")` | `F.coalesce(F.col("a"), F.col("b"))` |

## Generated Notebook Structure

Every generated notebook follows this pattern:

```python
# COMMAND ----------
# Cell 1: Imports and Configuration
from pyspark.sql import functions as F
from pyspark.sql.types import *

STORAGE_ACCOUNT = "{storage_account}"
CONTAINER = "{container}"

# COMMAND ----------
# Cell 2: Helper Functions
def safe_select(df, columns):
    """Select only existing columns."""
    existing = set(df.columns)
    valid_cols = [c for c in columns if c in existing]
    return df.select(valid_cols)

def drop_duplicate_columns(df):
    """Rename duplicate columns with _dup suffix."""
    cols = df.columns
    seen = {}
    new_cols = []
    for col in cols:
        if col in seen:
            seen[col] += 1
            new_cols.append(f"{col}_dup{seen[col]}")
        else:
            seen[col] = 0
            new_cols.append(col)
    return df.toDF(*new_cols)

# COMMAND ----------
# Cell 3: Load Input Tables
{input_table_1} = spark.read.parquet(...)
{input_table_2} = spark.read.parquet(...)

# COMMAND ----------
# Cell 4-N: Transformations (one per output)
df_{output_1} = {input_table}.select(...)
# ... transforms ...

# COMMAND ----------
# Cell N+1: Write Outputs
df_{output_1}.write.mode("overwrite").parquet(OUTPUT_PATH_1)

# COMMAND ----------
# Cell N+2: Validation
print(f"Output rows: {df_{output_1}.count():,}")
```

## RID Resolution

Palantir dataset RIDs are resolved to ADLS paths using `rid_mapping.csv`:

**File**: `.cdo-aifc/data/rid_mapping.csv`
```csv
rid,adls_folder
ri.foundry.main.dataset.aaa,raw/levo_site_master
ri.foundry.main.dataset.bbb,silver/site_master_clean
```

**Resolution Logic**:
```python
import pandas as pd

rid_mapping = pd.read_csv(".cdo-aifc/data/rid_mapping.csv")
adls_folder = rid_mapping[rid_mapping['rid'] == dataset_rid]['adls_folder'].values[0]
# Result: "raw/levo_site_master"
```

## Guardrails

Generated code automatically enforces these guardrails:

| Guardrail | Enforcement | Why |
|-----------|-------------|-----|
| No `dbutils.fs.ls()` | Refuse generation | Causes permission errors |
| No hardcoded credentials | Refuse generation | Security risk |
| No Delta overwrites without delete | Add delete command | Prevents conflicts |
| drop_duplicate_columns() after joins | Auto-insert | Prevents ambiguous column errors |
| Column case matching | Validate against schema | Parquet is case-sensitive |

## Configuration

**File**: `.windsurf/workflows/palantir-migration-config.yaml`

```yaml
storage:
  prod:
    account: "datalakeeastus2prd"
    container: "otis-poc"
  dev:
    account: "datalakeeastus2dev"
    container: "otis-poc-dev"

input_tables:
  x_ndr_nokia_lcell_rrh: "x_ndr_nokia_lcell_rrh"
  x_ndr_nokia_enb: "x_ndr_nokia_enb"

guardrails:
  hard_stops:
    - "dbutils.fs.ls"
    - "hardcoded_credentials"
    - "delta_overwrite"
  auto_fix:
    duplicate_columns: true
    case_mismatch: true

output:
  notebook_dir: "pipeline_builder/DBX_Conversion"
```

## Common Issues

### Issue: RID Not Found in Mapping

**Error**: `KeyError: 'ri.foundry.main.dataset.xxx'`

**Fix**: Add missing RID to `rid_mapping.csv`:
```csv
ri.foundry.main.dataset.xxx,silver/new_dataset_name
```

### Issue: Ambiguous Columns After Join

**Error**: `AnalysisException: Reference 'SITEID' is ambiguous`

**Fix**: Generated code automatically calls `drop_duplicate_columns()` after joins

### Issue: Column Case Mismatch

**Error**: `AnalysisException: Column 'cellname' not found`

**Fix**: Check actual Parquet schema and update JSON column names to match case

## Testing Generated Notebooks

```bash
# Run integration tests
pytest tests/test_generated_pipelines.py -v

# Test specific notebook
databricks-cli workspace import netaudit_pipeline.py /Workspace/pipelines/
databricks-cli jobs run-now --job-id 123
```

## Workflows

- [scaffold-pipeline-generator.md](scaffold-pipeline-generator.md) - Generate PySpark from JSON
- [test-pipeline-generator.md](test-pipeline-generator.md) - Validate generated code
- [compare-pipeline-generator.md](compare-pipeline-generator.md) - Pipeline vs Contour strategies
- [debug-pipeline-generator.md](debug-pipeline-generator.md) - Troubleshoot generation issues
- [document-pipeline-generator.md](document-pipeline-generator.md) - Transform mappings reference
- [refactor-pipeline-generator.md](refactor-pipeline-generator.md) - Improve generated code

---

**Version**: 1.0.0  
**Maintainer**: DEEP Migration Team
