---
description: Improve generated PySpark code quality and maintainability
glyphEnabled: true
glyph: refactor
---

User input: $ARGUMENTS

## Refactoring Goals

1. **Consolidate duplicate transformations** across multiple outputs
2. **Extract common patterns** into reusable functions
3. **Optimize join strategies** to reduce shuffle operations
4. **Improve error handling** with try-catch blocks
5. **Add data quality checks** to validate transformations

---

## Refactor 1: Consolidate Duplicate Transformations

### Problem
Multiple outputs apply same transformations repeatedly

### Before (Duplicated)

**Generated**: 5 outputs, each with identical cleaning logic

```python
# Output 1: LTE_NOK_NetAudit
df1 = cell_data.select(["CELLNAME", "LATITUDE", "LONGITUDE"])
df1 = df1.filter(F.col("STATUS") == "ACTIVE")
df1 = df1.dropDuplicates(["CELLNAME"])

# Output 2: LTE_ERIC_NetAudit (80% duplicate)
df2 = cell_data.select(["CELLNAME", "LATITUDE", "LONGITUDE"])
df2 = df2.filter(F.col("STATUS") == "ACTIVE")  # DUPLICATE
df2 = df2.dropDuplicates(["CELLNAME"])  # DUPLICATE
```

### After (Consolidated)

```python
# Shared transformation function
def clean_cell_data(df):
    """Standard cell data cleaning."""
    df = df.select(["CELLNAME", "LATITUDE", "LONGITUDE", "STATUS"])
    df = df.filter(F.col("STATUS") == "ACTIVE")
    df = df.dropDuplicates(["CELLNAME"])
    return df

# Apply once
cell_data_clean = clean_cell_data(cell_data)

# Output 1: LTE_NOK_NetAudit (vendor-specific filter)
df1 = cell_data_clean.filter(F.col("VENDOR") == "Nokia")

# Output 2: LTE_ERIC_NetAudit
df2 = cell_data_clean.filter(F.col("VENDOR") == "Ericsson")
```

**Benefits**:
- ✅ Reduced code: 50 lines → 20 lines (60% reduction)
- ✅ Single source of truth for cleaning logic
- ✅ Easier to update transformation logic

---

## Refactor 2: Extract RID Resolution to Shared Module

### Problem
Every generated notebook has identical RID resolution code

### Before (Inline)

**Each notebook**: 30 lines of RID resolution code

```python
# In every generated notebook
import pandas as pd

rid_mapping = pd.read_csv(".cdo-aifc/data/rid_mapping.csv")

def resolve_rid(rid):
    matches = rid_mapping[rid_mapping['rid'] == rid]
    if len(matches) > 0:
        return matches.iloc[0]['adls_folder']
    else:
        return "unknown"

# Resolve all RIDs
dataset_paths = {}
for rid in dataset_rids:
    dataset_paths[rid] = resolve_rid(rid)
```

### After (Shared Module)

**File**: `lib/rid_resolver.py`
```python
"""Shared RID resolution module."""

import pandas as pd
from pathlib import Path
from typing import Dict, Optional

class RIDResolver:
    """Resolve Foundry RIDs to ADLS paths."""
    
    def __init__(self, mapping_file: str = ".cdo-aifc/data/rid_mapping.csv"):
        self.mapping = pd.read_csv(mapping_file)
        self._cache = {}
    
    def resolve(self, rid: str, fallback: str = "unknown") -> str:
        """Resolve RID to ADLS folder path."""
        
        # Check cache
        if rid in self._cache:
            return self._cache[rid]
        
        # Look up in mapping
        matches = self.mapping[self.mapping['rid'] == rid]
        
        if len(matches) > 0:
            path = matches.iloc[0]['adls_folder']
            self._cache[rid] = path
            return path
        else:
            print(f"⚠️  RID not found: {rid}. Using fallback: {fallback}")
            return fallback
    
    def resolve_all(self, rids: list) -> Dict[str, str]:
        """Resolve multiple RIDs."""
        return {rid: self.resolve(rid) for rid in rids}
```

**Refactored Notebooks**:
```python
from lib.rid_resolver import RIDResolver

resolver = RIDResolver()
dataset_paths = resolver.resolve_all(dataset_rids)
```

**Benefits**:
- ✅ 30 lines → 3 lines per notebook (90% reduction)
- ✅ Caching for repeated lookups
- ✅ Single place to update resolution logic

---

## Refactor 3: Optimize Join Strategies

### Problem
Generated code uses broadcast joins inefficiently

### Before (Suboptimal)

```python
# Small lookup table (1K rows) joined to large fact table (100M rows)
df = fact_table.join(lookup_table, "key", "left")  # No broadcast hint
```

### After (Optimized)

```python
from pyspark.sql.functions import broadcast

# Broadcast small lookup table
df = fact_table.join(broadcast(lookup_table), "key", "left")

print(f"✅ Broadcasting lookup_table ({lookup_table.count():,} rows)")
```

**Auto-detect broadcast candidates**:

```python
def smart_join(left_df, right_df, condition, how="left", broadcast_threshold=10000):
    """Auto-broadcast small tables."""
    
    # Count rows (cached)
    right_count = right_df.cache().count()
    
    if right_count < broadcast_threshold:
        print(f"✅ Broadcasting right table ({right_count:,} rows)")
        return left_df.join(broadcast(right_df), condition, how)
    else:
        print(f"⚠️  Large join ({right_count:,} rows). Consider partitioning.")
        return left_df.join(right_df, condition, how)

# Use in generated code
df = smart_join(fact_table, lookup_table, "key", "left")
```

**Benefits**:
- ✅ 10x faster joins for small lookup tables
- ✅ Reduced shuffle operations
- ✅ Automatic optimization

---

## Refactor 4: Add Comprehensive Error Handling

### Problem
Generated notebooks fail without clear error messages

### Before (No Error Handling)

```python
df = spark.read.parquet(INPUT_PATH)  # Fails silently if path doesn't exist
df_transformed = transform(df)
df_transformed.write.parquet(OUTPUT_PATH)
```

### After (With Error Handling)

```python
import logging

logger = logging.getLogger(__name__)

def safe_read_parquet(spark, path: str, table_name: str):
    """Read parquet with error handling."""
    try:
        logger.info(f"Reading {table_name} from {path}")
        df = spark.read.parquet(path)
        row_count = df.count()
        logger.info(f"✅ Loaded {row_count:,} rows from {table_name}")
        return df
    except Exception as e:
        logger.error(f"❌ Failed to read {table_name} from {path}")
        logger.exception(e)
        raise

def safe_write_parquet(df, path: str, output_name: str, mode: str = "overwrite"):
    """Write parquet with error handling and validation."""
    try:
        row_count = df.count()
        logger.info(f"Writing {output_name} ({row_count:,} rows) to {path}")
        
        # Delete existing if overwrite mode
        if mode == "overwrite":
            dbutils.fs.rm(path, recurse=True)
        
        df.write.mode(mode).parquet(path)
        logger.info(f"✅ Successfully wrote {output_name}")
        
        # Validate write
        df_verify = spark.read.parquet(path)
        verify_count = df_verify.count()
        assert verify_count == row_count, f"Row count mismatch: {verify_count} != {row_count}"
        logger.info(f"✅ Validation passed: {verify_count:,} rows")
        
    except Exception as e:
        logger.error(f"❌ Failed to write {output_name} to {path}")
        logger.exception(e)
        raise

# Use in generated code
df = safe_read_parquet(spark, INPUT_PATH, "cell_data")
df_transformed = transform(df)
safe_write_parquet(df_transformed, OUTPUT_PATH, "cell_enriched")
```

**Benefits**:
- ✅ Clear error messages with context
- ✅ Automatic validation after write
- ✅ Comprehensive logging

---

## Refactor 5: Add Data Quality Checks

### Problem
No validation of transformation results

### After (With Data Quality)

```python
def validate_transformation(df_input, df_output, validation_rules: dict):
    """Validate transformation quality."""
    
    input_count = df_input.count()
    output_count = df_output.count()
    
    # Rule 1: Row count variance check
    variance = abs(output_count - input_count) / input_count
    max_variance = validation_rules.get('max_row_variance', 0.01)  # 1% tolerance
    
    if variance > max_variance:
        logger.warning(f"⚠️  Row count variance: {variance:.2%} (threshold: {max_variance:.2%})")
        logger.warning(f"   Input: {input_count:,}, Output: {output_count:,}")
    else:
        logger.info(f"✅ Row count variance OK: {variance:.2%}")
    
    # Rule 2: Null check on critical columns
    critical_cols = validation_rules.get('non_null_columns', [])
    for col_name in critical_cols:
        null_count = df_output.filter(F.col(col_name).isNull()).count()
        if null_count > 0:
            logger.error(f"❌ Null values in {col_name}: {null_count:,}")
            raise ValueError(f"Data quality check failed: nulls in {col_name}")
        else:
            logger.info(f"✅ No nulls in {col_name}")
    
    # Rule 3: Duplicate check on primary key
    primary_key = validation_rules.get('primary_key', [])
    if primary_key:
        duplicate_count = df_output.count() - df_output.dropDuplicates(primary_key).count()
        if duplicate_count > 0:
            logger.error(f"❌ Duplicate primary keys: {duplicate_count:,}")
            raise ValueError(f"Data quality check failed: duplicates on {primary_key}")
        else:
            logger.info(f"✅ No duplicates on primary key: {primary_key}")
    
    logger.info("✅ All data quality checks passed")

# Use in generated code
validation_rules = {
    'max_row_variance': 0.01,
    'non_null_columns': ['CELLNAME', 'STATUS'],
    'primary_key': ['CELLNAME', 'DATE']
}

validate_transformation(df_input, df_output, validation_rules)
```

**Benefits**:
- ✅ Early detection of data issues
- ✅ Automated quality gates
- ✅ Clear quality metrics

---

## Refactor 6: Generate Configuration from JSON

### Problem
Configuration hardcoded in notebook

### After (External Config)

**File**: `configs/pipelines/netaudit.yaml`
```yaml
# Generated from Pipeline JSON
pipeline:
  name: "NetAudit"
  source_json: "netaudit_latest.json"

inputs:
  cell_data:
    path: "raw/x_ndr_nokia_lcell_rrh"
    format: "parquet"
  
  site_master:
    path: "raw/levo_site_master"
    format: "parquet"

outputs:
  cell_enriched:
    path: "silver/cell_enriched"
    format: "parquet"
    mode: "overwrite"
    primary_key: ["CELLNAME", "DATE"]

validation:
  max_row_variance: 0.01
  non_null_columns: ["CELLNAME", "STATUS"]

logging:
  level: "INFO"
```

**Refactored Notebook**:
```python
import yaml

# Load pipeline config
with open("configs/pipelines/netaudit.yaml") as f:
    config = yaml.safe_load(f)

# Use config values
INPUT_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{config['inputs']['cell_data']['path']}"
OUTPUT_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{config['outputs']['cell_enriched']['path']}"
VALIDATION_RULES = config['validation']
```

**Benefits**:
- ✅ Environment-specific configs (dev/prod)
- ✅ No code changes for path updates
- ✅ Version control for configurations

---

## Refactoring Workflow

### Step 1: Analyze Generated Notebooks

Scan for:
- Duplicate transformation patterns
- Hardcoded configurations
- Missing error handling
- Suboptimal join strategies

### Step 2: Extract Common Patterns

Move to shared modules:
- `lib/rid_resolver.py` - RID resolution
- `lib/data_quality.py` - Validation functions
- `lib/io_utils.py` - Safe read/write functions

### Step 3: Update Code Generator

Modify generation templates to use shared modules:
```python
# In code generator
IMPORTS = '''
from lib.rid_resolver import RIDResolver
from lib.data_quality import validate_transformation
from lib.io_utils import safe_read_parquet, safe_write_parquet
'''
```

### Step 4: Regenerate and Test

```bash
# Regenerate all notebooks
python tools/generate_pipeline.py --input netaudit_latest.json --refactored

# Run tests
pytest tests/test_generated_pipelines.py -v
```

---

## Code Quality Metrics

### Before Refactoring
- Total lines: 450 per notebook
- Code duplication: 60%
- Error handling: 10%
- Data quality checks: 0%

### After Refactoring
- Total lines: 180 per notebook (60% reduction)
- Code duplication: 5%
- Error handling: 100%
- Data quality checks: 100%

**Improvement**: 60% less code, 100% more robust

---

**End of Refactor Workflow**
