---
description: Compare Pipeline Builder vs Contour generation strategies
glyphEnabled: true
glyph: compare
---

User input: $ARGUMENTS

## Overview

Two primary JSON sources for code generation:
1. **Pipeline Builder JSON**: Full transform code, complex joins, incremental logic
2. **Contour JSON**: Expression-based transformations, filters, aggregations

Choose the right strategy based on pipeline complexity and target platform.

---

## Generation Strategy Comparison

| Aspect | Pipeline Builder | Contour |
|--------|------------------|---------|
| **Input Complexity** | High (full transform DAG) | Low (sequential expressions) |
| **Code Preservation** | Exact Python logic | Expression translation only |
| **Schema Information** | ✅ Complete (inputs, outputs, types) | ⚠️ Inferred from expressions |
| **Primary Keys** | ✅ Defined | ❌ Not available |
| **Incremental Logic** | ✅ Preserved (mode=INCREMENTAL) | ❌ Not supported |
| **Join Complexity** | ✅ Multi-table joins with conditions | ⚠️ Limited join support |
| **Helper Functions** | Required (safe_select, drop_duplicate_columns) | Minimal |
| **Generated Lines** | 300-500 lines | 100-200 lines |
| **Target Platform** | Databricks (PySpark notebooks) | Databricks or Snowflake (SQL views) |

---

## When to Use Pipeline Builder Generation

### Scenario 1: Complex ETL Pipelines

**Use if**:
- Pipeline has 5+ transforms
- Complex joins (left, inner, cross)
- Incremental load logic (append mode)
- Multiple outputs with different primary keys
- Custom Python transform logic

**Example**:
```json
{
  "transforms": [
    {"type": "selectColumns", "columns": ["A", "B", "C"]},
    {"type": "complexLeftJoin", "left": "cell", "right": "site", "on": "siteid"},
    {"type": "dropDuplicates", "keys": ["cellname"]},
    {"type": "applyExpression", "expression": "construct_geo_point(lat, lon)"},
    {"type": "filter", "condition": "status == 'ACTIVE'"}
  ],
  "outputs": [
    {"name": "cell_enriched", "primaryKey": ["cellname"], "mode": "SNAPSHOT"}
  ]
}
```

**Generated Code Quality**: High fidelity to original

---

## When to Use Contour Generation

### Scenario 2: Simple Analytics Transformations

**Use if**:
- Analysis has 1-3 expression boards
- Simple column transformations (ROUND, CAST, CONCAT)
- Sorting/filtering only
- Single output
- No incremental logic needed

**Example**:
```json
{
  "snapshots": [
    {"boardType": "starting", "identifier": "ri.foundry.main.dataset.xxx"},
    {"boardType": "expression", "expression": "ROUND(value, 2)"},
    {"boardType": "custom", "customBoardId": "sort-columns", "sortDirection": {"region": "ASC"}}
  ]
}
```

**Generated Code Quality**: Simpler, less robust

---

## Code Generation Comparison

### Pipeline Builder → PySpark

**Input**: 5 transforms, 2 inputs, 1 output

**Generated Structure**:
```python
# Databricks notebook source

# COMMAND ----------
# Cell 1: Configuration
STORAGE_ACCOUNT = "datalakeeastus2prd"
CONTAINER = "otis-poc"

# COMMAND ----------
# Cell 2: Helper Functions (20 lines)
def safe_select(df, columns): ...
def drop_duplicate_columns(df): ...
def construct_geo_point(df, lat, lon): ...

# COMMAND ----------
# Cell 3: Load Input Tables (2 tables)
cell_data = spark.read.parquet("abfss://raw@.../cell_data")
site_master = spark.read.parquet("abfss://raw@.../site_master")

# COMMAND ----------
# Cell 4: Transform 1 - Select Columns
df = safe_select(cell_data, ["CELLNAME", "SITEID", "LATITUDE", "LONGITUDE"])

# COMMAND ----------
# Cell 5: Transform 2 - Join with Site Master
df = df.join(site_master, df["SITEID"] == site_master["SITEID"], "left")
df = drop_duplicate_columns(df)

# COMMAND ----------
# Cell 6: Transform 3 - Drop Duplicates
df = df.dropDuplicates(["CELLNAME"])

# COMMAND ----------
# Cell 7: Transform 4 - Construct Geo Point
df = construct_geo_point(df, "LATITUDE", "LONGITUDE", "geo")

# COMMAND ----------
# Cell 8: Transform 5 - Filter Active Only
df = df.filter(F.col("STATUS") == "ACTIVE")

# COMMAND ----------
# Cell 9: Write Output
OUTPUT_PATH = "abfss://silver@.../cell_enriched"
df.write.mode("overwrite").parquet(OUTPUT_PATH)
print(f"✅ Wrote {df.count():,} rows")
```

**Total**: ~150 lines, 9 cells

---

### Contour → PySpark

**Input**: 2 expression boards, 1 sort board

**Generated Structure**:
```python
# Databricks notebook source

# COMMAND ----------
# Cell 1: Configuration
STORAGE_ACCOUNT = "datalakeeastus2prd"
CONTAINER = "otis-poc"
SOURCE_RID = "ri.foundry.main.dataset.xxx"

# COMMAND ----------
# Cell 2: Resolve RID
from rid_resolver import resolve_rid_to_folder
result = resolve_rid_to_folder(spark, dbutils, SOURCE_RID, STORAGE_ACCOUNT, CONTAINER)
INPUT_PATH = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net/{result['adls_folder']}"

# COMMAND ----------
# Cell 3: Load Data
df = spark.read.format("delta").load(INPUT_PATH)

# COMMAND ----------
# Cell 4: Apply Expression - ROUND
df = df.withColumn("value", F.round(F.col("value"), 2))

# COMMAND ----------
# Cell 5: Sort
df = df.orderBy(F.col("region").asc())

# COMMAND ----------
# Cell 6: Write Output
OUTPUT_PATH = "abfss://silver@.../site_analysis"
df.write.format("delta").mode("overwrite").save(OUTPUT_PATH)
```

**Total**: ~50 lines, 6 cells

---

## Feature Support Matrix

| Feature | Pipeline Builder | Contour |
|---------|------------------|---------|
| Select columns | ✅ Full support | ⚠️ Not applicable |
| Joins | ✅ All types (left, inner, cross) | ❌ Limited |
| Drop duplicates | ✅ With key columns | ❌ Not supported |
| Column expressions | ✅ Complex (cast, uuid, geo) | ✅ Basic (ROUND, CAST, CONCAT) |
| Filters | ✅ Complex conditions | ✅ Simple conditions |
| Aggregations | ✅ All functions | ⚠️ Limited |
| Sort | ✅ Multi-column | ✅ Multi-column |
| Incremental mode | ✅ append/overwrite | ❌ overwrite only |
| Primary keys | ✅ Defined | ❌ Not available |
| Helper functions | ✅ Generated | ⚠️ Minimal |

---

## Decision Matrix

### Question 1: How many transforms?

| Count | Recommended |
|-------|-------------|
| 1-2 | **Contour** (simpler) |
| 3-5 | **Pipeline Builder** (more robust) |
| 6+ | **Pipeline Builder** (required) |

### Question 2: Does it have joins?

| Joins | Recommended |
|-------|-------------|
| No joins | **Contour** (simpler) |
| 1-2 joins | **Pipeline Builder** (handles duplicates) |
| 3+ joins | **Pipeline Builder** (required) |

### Question 3: Incremental load needed?

| Incremental | Recommended |
|-------------|-------------|
| No (full refresh) | **Either** |
| Yes (append mode) | **Pipeline Builder** (only option) |

### Question 4: Target platform?

| Platform | Recommended |
|----------|-------------|
| Databricks only | **Either** |
| Databricks + Snowflake | **Pipeline Builder** → PySpark, **Contour** → SQL |

---

## Hybrid Strategy

For complex migrations, use **both**:

1. **Pipeline Builder** → Databricks notebooks (ETL layer, Silver zone)
2. **Contour** → Snowflake views (Analytics layer, Gold zone)

**Workflow**:
```
Source Data
    ↓
Pipeline Builder JSON → PySpark Notebooks → Databricks (Silver zone)
    ↓
Contour JSON → SQL Views → Snowflake (Gold zone)
```

**Benefits**:
- ✅ ETL logic preserved in Databricks
- ✅ Analytics logic in Snowflake (lower cost)
- ✅ Clear separation of concerns

---

## Effort Comparison

| Task | Pipeline Builder | Contour |
|------|------------------|---------|
| JSON parsing | 30 min | 10 min |
| RID resolution | 20 min | 20 min |
| Code generation | 2 hours | 30 min |
| Testing | 1 hour | 30 min |
| Debugging | 1 hour | 30 min |
| **Total** | **4.5 hours** | **2 hours** |

**Recommendation**: Use Contour for simple cases, Pipeline Builder for production pipelines

---

## Validation Checklist

After choosing generation strategy:

- [ ] Input JSON contains all required transforms
- [ ] RIDs can be resolved to ADLS paths
- [ ] Target platform supports generated code (PySpark/SQL)
- [ ] Primary keys available (Pipeline Builder) or not needed (Contour)
- [ ] Incremental logic required → Must use Pipeline Builder
- [ ] Joins present → Prefer Pipeline Builder (better duplicate handling)

---

**End of Compare Workflow**
