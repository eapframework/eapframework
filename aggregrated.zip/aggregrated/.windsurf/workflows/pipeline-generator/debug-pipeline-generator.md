---
description: Troubleshoot code generation and execution issues
glyphEnabled: true
glyph: debug
---

User input: $ARGUMENTS

## Common Issues

## Issue 1: RID Not Found in Mapping

### Symptoms
```
KeyError: 'ri.foundry.main.dataset.19f85d48-afd4-44f7-81d9-c3e95c3e1043'
```

### Root Cause
Dataset RID from Pipeline JSON not present in rid_mapping.csv

### Diagnostic Steps

1. **Check RID mapping file**:
```bash
cat .cdo-aifc/data/rid_mapping.csv | grep "19f85d48"
# Empty result = RID not mapped
```

2. **Find dataset name in Pipeline JSON**:
```python
import json
with open("pipeline_json/netaudit_latest.json") as f:
    data = json.load(f)

for ds in data['snapshot']['datasets']:
    if '19f85d48' in ds['rid']:
        print(f"Dataset: {ds['name']}")
        print(f"RID: {ds['rid']}")
```

### Resolution

**Add RID to mapping file**:

**File**: `.cdo-aifc/data/rid_mapping.csv`
```csv
rid,adls_folder
ri.foundry.main.dataset.19f85d48-afd4-44f7-81d9-c3e95c3e1043,raw/levo_site_master
```

**Regenerate notebook**:
```bash
python tools/generate_pipeline.py --input netaudit_latest.json
```

---

## Issue 2: Ambiguous Column After Join

### Symptoms
```
AnalysisException: Reference 'SITEID' is ambiguous, could be: SITEID, SITEID
```

### Root Cause
Join creates duplicate columns, code doesn't call drop_duplicate_columns()

### Diagnostic Steps

1. **Check generated join code**:
```python
# Look for this pattern:
df = df.join(site_master, df["SITEID"] == site_master["SITEID"], "left")
# Missing: df = drop_duplicate_columns(df)
```

2. **Verify helper function defined**:
```bash
grep -n "def drop_duplicate_columns" netaudit_pipeline.py
# Should find function definition
```

### Resolution

**Option 1: Regenerate with fix**

Update code generator to auto-insert drop_duplicate_columns():

```python
# In generate_transform_code()
if transform_type == 'complexLeftJoin':
    code = f'df = df.join({right_table}, condition, "left")\n'
    code += f'df = drop_duplicate_columns(df)  # Remove duplicate columns'
    return code
```

**Option 2: Manual fix**

Edit generated notebook:
```python
# After every join, add:
df = drop_duplicate_columns(df)
```

---

## Issue 3: Column Case Mismatch

### Symptoms
```
AnalysisException: Column 'cellname' does not exist. Did you mean 'CELLNAME'?
```

### Root Cause
JSON uses lowercase column names, Parquet has uppercase

### Diagnostic Steps

1. **Check actual Parquet schema**:
```python
df = spark.read.parquet("abfss://raw@.../cell_data")
print(df.columns)
# Output: ['CELLNAME', 'SITEID', 'STATUS']  (uppercase)
```

2. **Check JSON column references**:
```bash
grep -o '"cellname"' netaudit_latest.json
# JSON references lowercase
```

### Resolution

**Option 1: Normalize Parquet to lowercase**

```python
# In notebook, after loading:
cell_data = spark.read.parquet("...")
cell_data = cell_data.toDF(*[c.lower() for c in cell_data.columns])
```

**Option 2: Update JSON column names**

Edit Pipeline JSON to match Parquet case:
```json
{
  "columns": ["CELLNAME", "SITEID", "STATUS"]
}
```

**Option 3: Case-insensitive matching**

```python
def safe_select_case_insensitive(df, columns):
    """Select columns with case-insensitive matching."""
    df_cols_lower = {c.lower(): c for c in df.columns}
    matched_cols = [df_cols_lower.get(c.lower(), c) for c in columns]
    return df.select(matched_cols)
```

---

## Issue 4: Missing Helper Function

### Symptoms
```
NameError: name 'safe_select' is not defined
```

### Root Cause
Generated code references helper function not defined in notebook

### Resolution

**Ensure helper functions cell exists**:

```python
# Cell 2: Helper Functions
def safe_select(df, columns):
    """Select only existing columns."""
    existing = set(df.columns)
    valid_cols = [c for c in columns if c in existing]
    return df.select(valid_cols)

def drop_duplicate_columns(df):
    """Rename duplicate columns with _dup suffix."""
    cols = df.columns
    seen = {}
    new_cols = []
    for col in cols:
        if col in seen:
            seen[col] += 1
            new_cols.append(f"{col}_dup{seen[col]}")
        else:
            seen[col] = 0
            new_cols.append(col)
    return df.toDF(*new_cols)

def cast_to_string(df, col_name):
    """Cast column to string type."""
    from pyspark.sql import functions as F
    return df.withColumn(col_name, F.col(col_name).cast("string"))
```

---

## Issue 5: Delta Table Overwrite Conflict

### Symptoms
```
AnalysisException: Cannot overwrite table that is also being read from
```

### Root Cause
Attempting to overwrite Delta table in place without delete

### Resolution

**Option 1: Delete before write**

```python
# Before write operation:
dbutils.fs.rm(OUTPUT_PATH, recurse=True)

df.write.format("delta").mode("overwrite").save(OUTPUT_PATH)
```

**Option 2: Write to temp, then rename**

```python
TEMP_PATH = f"{OUTPUT_PATH}_temp"
df.write.format("delta").mode("overwrite").save(TEMP_PATH)

dbutils.fs.rm(OUTPUT_PATH, recurse=True)
dbutils.fs.mv(TEMP_PATH, OUTPUT_PATH)
```

**Option 3: Use INSERT OVERWRITE**

```python
df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(OUTPUT_PATH)
```

---

## Issue 6: Hardcoded Storage Account

### Symptoms
```
⚠️  Guardrail violation: Hardcoded storage account name
```

### Root Cause
Generated code contains hardcoded "datalakeeastus2prd" instead of variable

### Resolution

**Update code generator**:

```python
# Instead of:
path = f"abfss://raw@datalakeeastus2prd.dfs.core.windows.net/..."

# Generate:
path = f"abfss://raw@{STORAGE_ACCOUNT}.dfs.core.windows.net/..."
```

**Manual fix**:

```python
# Cell 1: Add variable
STORAGE_ACCOUNT = "datalakeeastus2prd"

# Cell 3: Use variable
INPUT_PATH = f"abfss://raw@{STORAGE_ACCOUNT}.dfs.core.windows.net/cell_data"
```

---

## Issue 7: Unresolved Contour Expression

### Symptoms
```
# TODO: Validate expression
df = df.withColumn("col", F.expr("CUSTOM_FUNCTION(x)"))
```

### Root Cause
Contour expression uses custom function not in PySpark

### Resolution

**Option 1: Manual translation**

Identify Contour custom function and translate:

```python
# CUSTOM_FUNCTION(x) → Manual PySpark equivalent
df = df.withColumn("col", F.when(F.col("x") > 0, F.col("x")).otherwise(0))
```

**Option 2: Extend expression converter**

```python
def convert_contour_expression(expression: str) -> str:
    if 'CUSTOM_FUNCTION(' in expression:
        # Add custom logic
        return 'F.when(...)'
    # ... existing conversions
```

---

## Issue 8: Schema Mismatch Between Source and Generated

### Symptoms
```
AssertionError: Output schema mismatch
Expected: ['CELLNAME', 'LATITUDE', 'LONGITUDE', 'STATUS']
Actual: ['CELLNAME', 'LATITUDE', 'LONGITUDE']
```

### Root Cause
Pipeline JSON missing column in transform

### Diagnostic Steps

1. **Compare Pipeline JSON outputs**:
```python
import json
with open("netaudit_latest.json") as f:
    data = json.load(f)

for output in data['snapshot']['outputs']:
    print(f"Output: {output['name']}")
    print(f"Columns: {[p['name'] for p in output['properties']]}")
```

2. **Check generated select statement**:
```bash
grep "safe_select" netaudit_pipeline.py
```

### Resolution

**Add missing column to Pipeline JSON**:

```json
{
  "properties": [
    {"name": "CELLNAME", "type": "STRING"},
    {"name": "LATITUDE", "type": "DOUBLE"},
    {"name": "LONGITUDE", "type": "DOUBLE"},
    {"name": "STATUS", "type": "STRING"}  // Add missing column
  ]
}
```

**Regenerate notebook**.

---

## Issue 9: Incremental Logic Not Preserved

### Symptoms
Generated notebook uses `mode("overwrite")` instead of `mode("append")`

### Root Cause
Pipeline JSON has `mode: "INCREMENTAL"` but code generator defaulted to overwrite

### Resolution

**Update code generator to check mode**:

```python
for output in outputs:
    mode = output.get('mode', 'SNAPSHOT')
    write_mode = 'append' if mode == 'INCREMENTAL' else 'overwrite'
    
    code = f'df.write.mode("{write_mode}").parquet(OUTPUT_PATH)'
```

**Add incremental filter**:

```python
# For incremental loads, add max date filter
if mode == 'INCREMENTAL':
    max_date = spark.read.parquet(OUTPUT_PATH).agg(F.max("date")).collect()[0][0]
    df = df.filter(F.col("date") > max_date)
```

---

## Debugging Checklist

When notebook execution fails:

- [ ] Check RID mapping for missing entries
- [ ] Verify column case matches Parquet schema
- [ ] Ensure helper functions are defined
- [ ] Look for ambiguous column errors after joins
- [ ] Check for hardcoded paths/credentials
- [ ] Validate Delta table operations
- [ ] Review Contour expression translations
- [ ] Compare output schema with Pipeline JSON
- [ ] Verify incremental mode settings

---

## Logging Best Practices

Add comprehensive logging to generated notebooks:

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)

logger = logging.getLogger(__name__)

# In transformation cells:
logger.info(f"Loading {table_name} from {INPUT_PATH}")
logger.info(f"Rows after transform: {df.count():,}")
logger.info(f"Writing output to {OUTPUT_PATH}")
```

---

**End of Debug Workflow**
