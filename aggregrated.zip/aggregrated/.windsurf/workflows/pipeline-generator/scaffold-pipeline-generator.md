---
description: Generate PySpark Databricks notebook from Palantir JSON exports
glyphEnabled: true
glyph: scaffold
---

User input: $ARGUMENTS

## Parse Input

Extract from $ARGUMENTS:
- **json_file**: Path to Pipeline or Contour JSON file
- **json_type**: "pipeline" or "contour" (auto-detect if not specified)
- **environment**: "prod" or "dev" (default: prod)
- **output_name**: Name for generated notebook (default: derived from json_file)
- **output_folder**: Override default ADLS output folder

**Examples**:
```
Generate PySpark from netaudit_latest.json environment prod
Generate Contour notebook from contour_latest.json output site_analysis
Generate Pipeline notebook from pipeline.json, output_folder=silver/transformed
```

---

## Prerequisites Validation

### 1. Check Input JSON Exists

```python
from pathlib import Path
import json

json_path = Path(json_file)
if not json_path.exists():
    raise FileNotFoundError(f"JSON file not found: {json_path}")

# Load and validate JSON
with open(json_path) as f:
    data = json.load(f)

# Auto-detect type
if 'snapshot' in data:
    json_type = 'pipeline'
elif 'snapshots' in data:
    json_type = 'contour'
else:
    raise ValueError("Unknown JSON format (missing 'snapshot' or 'snapshots')")

print(f"✅ Detected {json_type} JSON")
```

### 2. Load Configuration

```python
import yaml

config_path = Path(".windsurf/workflows/palantir-migration-config.yaml")
with open(config_path) as f:
    config = yaml.safe_load(f)

# Get environment settings
env_config = config['storage'][environment]
storage_account = env_config['account']
container = env_config['container']

print(f"✅ Environment: {environment}")
print(f"   Storage: {storage_account}")
print(f"   Container: {container}")
```

### 3. Load RID Mapping

```python
import pandas as pd

rid_mapping_path = Path(".cdo-aifc/data/rid_mapping.csv")
if rid_mapping_path.exists():
    rid_mapping = pd.read_csv(rid_mapping_path)
    print(f"✅ RID mapping loaded: {len(rid_mapping)} entries")
else:
    print("⚠️  RID mapping not found - will use fallback paths")
    rid_mapping = pd.DataFrame(columns=['rid', 'adls_folder'])
```

---

## Pipeline Builder JSON Generation

### Step 1: Parse Pipeline JSON Structure

```python
def parse_pipeline_json(data: dict) -> dict:
    """Extract transforms, datasets, and outputs from Pipeline JSON."""
    
    snapshot = data.get('snapshot', {})
    
    # Extract datasets
    datasets = {}
    for ds in snapshot.get('datasets', []):
        rid = ds.get('rid')
        name = ds.get('name', '').strip('/')
        datasets[rid] = {
            'name': name,
            'rid': rid,
            'schema': ds.get('schema', {})
        }
    
    # Extract outputs
    outputs = []
    for out in snapshot.get('outputs', []):
        outputs.append({
            'dataset_rid': out.get('datasetRid'),
            'name': out.get('pluralDisplayName', 'output'),
            'primary_key': out.get('primaryKey', []),
            'mode': out.get('mode', 'SNAPSHOT'),
            'properties': out.get('properties', [])
        })
    
    # Extract transforms
    transforms = snapshot.get('transforms', [])
    
    return {
        'datasets': datasets,
        'outputs': outputs,
        'transforms': transforms
    }

parsed = parse_pipeline_json(data)
print(f"✅ Parsed: {len(parsed['datasets'])} datasets, {len(parsed['transforms'])} transforms, {len(parsed['outputs'])} outputs")
```

### Step 2: Resolve RIDs to ADLS Paths

```python
def resolve_rid(rid: str, rid_mapping: pd.DataFrame, fallback_name: str = "unknown") -> str:
    """Resolve Foundry RID to ADLS folder path."""
    
    matches = rid_mapping[rid_mapping['rid'] == rid]
    
    if len(matches) > 0:
        adls_folder = matches.iloc[0]['adls_folder']
        print(f"✅ Resolved {rid} → {adls_folder}")
        return adls_folder
    else:
        print(f"⚠️  RID not found: {rid}. Using fallback: {fallback_name}")
        return fallback_name

# Resolve all dataset RIDs
dataset_paths = {}
for rid, ds_info in parsed['datasets'].items():
    adls_folder = resolve_rid(rid, rid_mapping, ds_info['name'])
    dataset_paths[rid] = adls_folder
```

### Step 3: Generate Helper Functions

```python
HELPER_FUNCTIONS = '''
def safe_select(df, columns):
    """Select only existing columns, skip missing ones."""
    existing = set(df.columns)
    valid_cols = [c for c in columns if c in existing]
    if len(valid_cols) < len(columns):
        missing = set(columns) - existing
        print(f"⚠️  Columns not found: {missing}")
    return df.select(valid_cols)

def drop_duplicate_columns(df):
    """Rename duplicate columns with _dup suffix."""
    cols = df.columns
    seen = {}
    new_cols = []
    for col in cols:
        if col in seen:
            seen[col] += 1
            new_cols.append(f"{col}_dup{seen[col]}")
        else:
            seen[col] = 0
            new_cols.append(col)
    return df.toDF(*new_cols)

def cast_to_string(df, col_name):
    """Cast column to string type."""
    return df.withColumn(col_name, F.col(col_name).cast("string"))

def construct_geo_point(df, lat_col, lon_col, output_col="geo"):
    """Construct geo point struct from lat/lon columns."""
    return df.withColumn(output_col, F.struct(F.col(lon_col), F.col(lat_col)))
'''
```

### Step 4: Generate Transform Code

```python
def generate_transform_code(transform: dict, datasets: dict) -> str:
    """Convert Pipeline transform to PySpark code."""
    
    transform_type = transform.get('type')
    
    # Select columns
    if transform_type == 'selectColumns':
        columns = transform.get('columns', [])
        return f'df = safe_select(df, {columns})'
    
    # Left join
    elif transform_type == 'complexLeftJoin':
        left_rid = transform.get('leftDatasetRid')
        right_rid = transform.get('rightDatasetRid')
        on_condition = transform.get('onCondition', 'key')
        
        left_name = datasets.get(left_rid, {}).get('name', 'left_df')
        right_name = datasets.get(right_rid, {}).get('name', 'right_df')
        
        code = f'# Join {left_name} with {right_name}\n'
        code += f'df = df.join({right_name}, df["{on_condition}"] == {right_name}["{on_condition}"], "left")\n'
        code += f'df = drop_duplicate_columns(df)  # Remove duplicate columns'
        return code
    
    # Drop duplicates
    elif transform_type == 'dropDuplicates':
        keys = transform.get('keys', [])
        return f'df = df.dropDuplicates({keys})'
    
    # Apply expression (cast, uuid, etc.)
    elif transform_type == 'applyExpression':
        expression_type = transform.get('expressionType')
        
        if expression_type == 'cast':
            col_name = transform.get('columnName')
            from_type = transform.get('fromType')
            to_type = transform.get('toType')
            return f'df = df.withColumn("{col_name}", F.col("{col_name}").cast("{to_type}"))'
        
        elif expression_type == 'uuid':
            col_name = transform.get('columnName', 'uuid')
            return f'df = df.withColumn("{col_name}", F.expr("uuid()"))'
        
        elif expression_type == 'construct_geo_point':
            lat_col = transform.get('latColumn', 'latitude')
            lon_col = transform.get('lonColumn', 'longitude')
            output_col = transform.get('outputColumn', 'geo')
            return f'df = construct_geo_point(df, "{lat_col}", "{lon_col}", "{output_col}")'
    
    # Filter
    elif transform_type == 'filter':
        condition = transform.get('condition', 'True')
        return f'df = df.filter({condition})'
    
    # Aggregate
    elif transform_type == 'aggregate':
        agg_func = transform.get('function', 'max')
        col_name = transform.get('column')
        return f'max_value = df.agg(F.{agg_func}("{col_name}")).collect()[0][0]'
    
    # Unknown transform
    else:
        return f'# TODO: Implement {transform_type} transform'

# Generate all transform code
transform_code = []
for transform in parsed['transforms']:
    code = generate_transform_code(transform, parsed['datasets'])
    transform_code.append(code)
```

### Step 5: Generate Complete Notebook

```python
def generate_notebook(
    output_name: str,
    storage_account: str,
    container: str,
    dataset_paths: dict,
    transform_code: list,
    outputs: list,
    output_folder: str = None
) -> str:
    """Generate complete PySpark Databricks notebook."""
    
    notebook = []
    
    # Cell 1: Header and Configuration
    notebook.append("# Databricks notebook source")
    notebook.append(f"# Generated from {json_file}")
    notebook.append(f"# Generated on: {datetime.now().isoformat()}")
    notebook.append("")
    notebook.append("# COMMAND ----------")
    notebook.append("# Cell 1: Configuration")
    notebook.append("")
    notebook.append("from pyspark.sql import functions as F")
    notebook.append("from pyspark.sql.types import *")
    notebook.append("")
    notebook.append(f'STORAGE_ACCOUNT = "{storage_account}"')
    notebook.append(f'CONTAINER = "{container}"')
    notebook.append("")
    
    # Cell 2: Helper Functions
    notebook.append("# COMMAND ----------")
    notebook.append("# Cell 2: Helper Functions")
    notebook.append("")
    notebook.append(HELPER_FUNCTIONS)
    notebook.append("")
    
    # Cell 3: Load Input Tables
    notebook.append("# COMMAND ----------")
    notebook.append("# Cell 3: Load Input Tables")
    notebook.append("")
    
    for rid, adls_folder in dataset_paths.items():
        table_name = adls_folder.split('/')[-1]
        path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/{adls_folder}"
        notebook.append(f'{table_name} = spark.read.parquet("{path}")')
    notebook.append("")
    
    # Cell 4: Initialize output DataFrames
    notebook.append("# COMMAND ----------")
    notebook.append("# Cell 4: Initialize Output DataFrames")
    notebook.append("")
    for output in outputs:
        output_var = output['name'].lower().replace(' ', '_')
        notebook.append(f'{output_var} = None  # Will be populated by transforms')
    notebook.append("")
    
    # Cell 5+: Transformations
    for i, code in enumerate(transform_code, start=5):
        notebook.append("# COMMAND ----------")
        notebook.append(f"# Cell {i}: Transform {i-4}")
        notebook.append("")
        notebook.append(code)
        notebook.append("")
    
    # Final Cell: Write Outputs
    cell_num = len(transform_code) + 5
    notebook.append("# COMMAND ----------")
    notebook.append(f"# Cell {cell_num}: Write Outputs")
    notebook.append("")
    
    for output in outputs:
        output_var = output['name'].lower().replace(' ', '_')
        output_path_name = output_folder or output['name'].lower().replace(' ', '_')
        output_path = f"abfss://{container}@{storage_account}.dfs.core.windows.net/{output_path_name}"
        
        notebook.append(f'# Write {output["name"]}')
        notebook.append(f'if {output_var} is not None:')
        notebook.append(f'    {output_var}.write.mode("overwrite").parquet("{output_path}")')
        notebook.append(f'    print(f"✅ Wrote {{output_var}.count():,}} rows to {output_path}")')
        notebook.append("")
    
    return '\n'.join(notebook)

# Generate notebook
notebook_content = generate_notebook(
    output_name=output_name or 'generated_pipeline',
    storage_account=storage_account,
    container=container,
    dataset_paths=dataset_paths,
    transform_code=transform_code,
    outputs=parsed['outputs'],
    output_folder=output_folder
)
```

### Step 6: Save Generated Notebook

```python
from datetime import datetime

output_dir = Path(config['output']['notebook_dir'])
output_dir.mkdir(parents=True, exist_ok=True)

# Generate filename
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_filename = f"{output_name}_{timestamp}.py"
output_path = output_dir / output_filename

# Save notebook
with open(output_path, 'w') as f:
    f.write(notebook_content)

print(f"✅ Generated notebook: {output_path}")
print(f"   Lines: {len(notebook_content.splitlines())}")
print(f"   Cells: {notebook_content.count('# COMMAND ----------')}")
```

---

## Contour JSON Generation

### Step 1: Parse Contour JSON

```python
def parse_contour_json(data: dict) -> dict:
    """Extract snapshots from Contour JSON."""
    
    snapshots = data.get('snapshots', [])
    
    source_rid = None
    expressions = []
    sort_columns = []
    
    for snap in snapshots:
        board_type = snap.get('boardType')
        state = snap.get('boardState', {})
        
        # Extract source dataset
        if board_type == 'starting':
            desc = state.get('startingSetDescription', {})
            identifier = desc.get('identifier', '')
            source_rid = identifier.split(':')[0] if ':' in identifier else identifier
        
        # Extract expressions
        elif board_type == 'expression':
            for expr in state.get('expressions', []):
                expressions.append({
                    'column': expr.get('columnName'),
                    'expression': expr.get('expression'),
                    'action': state.get('action')
                })
        
        # Extract sort columns
        elif board_type == 'custom':
            if state.get('customBoardId') == 'sort-columns':
                child = state.get('childSetDescription', {})
                sort_dir = child.get('sortDirection', {})
                for col, direction in sort_dir.items():
                    sort_columns.append({
                        'column': col,
                        'direction': direction
                    })
    
    return {
        'source_rid': source_rid,
        'expressions': expressions,
        'sort_columns': sort_columns
    }

parsed_contour = parse_contour_json(data)
```

### Step 2: Convert Contour Expressions to PySpark

```python
def convert_contour_expression(expression: str) -> str:
    """Convert Contour expression to PySpark."""
    
    # ROUND("col", 2) → F.round(F.col("col"), 2)
    if expression.startswith('ROUND('):
        import re
        match = re.match(r'ROUND\("(\w+)",\s*(\d+)\)', expression)
        if match:
            col_name, decimals = match.groups()
            return f'F.round(F.col("{col_name}"), {decimals})'
    
    # CAST("col" AS STRING) → F.col("col").cast("string")
    elif 'CAST(' in expression:
        match = re.match(r'CAST\("(\w+)"\s+AS\s+(\w+)\)', expression)
        if match:
            col_name, data_type = match.groups()
            return f'F.col("{col_name}").cast("{data_type.lower()}")'
    
    # CONCAT("a", "b") → F.concat(F.col("a"), F.col("b"))
    elif expression.startswith('CONCAT('):
        cols = re.findall(r'"(\w+)"', expression)
        col_refs = ', '.join(f'F.col("{c}")' for c in cols)
        return f'F.concat({col_refs})'
    
    # UPPER/LOWER/TRIM
    elif expression.startswith('UPPER('):
        col_name = re.search(r'"(\w+)"', expression).group(1)
        return f'F.upper(F.col("{col_name}"))'
    
    # Default: return as-is with warning
    return f'F.expr("{expression}")  # TODO: Validate expression'

# Convert all expressions
contour_code = []
for expr in parsed_contour['expressions']:
    col_name = expr['column']
    pyspark_expr = convert_contour_expression(expr['expression'])
    contour_code.append(f'df = df.withColumn("{col_name}", {pyspark_expr})')
```

### Step 3: Generate Contour Notebook

(Similar structure to Pipeline notebook, but simpler)

---

## Guardrails Enforcement

```python
def check_guardrails(notebook_content: str, guardrails: dict) -> list:
    """Check generated notebook against guardrails."""
    
    violations = []
    
    # Check hard stops
    for hard_stop in guardrails.get('hard_stops', []):
        if hard_stop in notebook_content:
            violations.append(f"❌ Hard stop violated: {hard_stop}")
    
    # Check for hardcoded credentials
    if 'AccountKey=' in notebook_content or 'SharedAccessSignature=' in notebook_content:
        violations.append("❌ Hardcoded credentials detected")
    
    # Check for Delta overwrites without delete
    if '.format("delta")' in notebook_content and '.mode("overwrite")' in notebook_content:
        if 'dbutils.fs.rm' not in notebook_content:
            violations.append("⚠️  Delta overwrite without delete (may cause issues)")
    
    return violations

# Check guardrails
violations = check_guardrails(notebook_content, config['guardrails'])

if violations:
    print("⚠️  Guardrail violations detected:")
    for v in violations:
        print(f"   {v}")
else:
    print("✅ All guardrails passed")
```

---

## Validation Report

```python
print("\n" + "=" * 80)
print("Pipeline Generation Report")
print("=" * 80)
print(f"Input JSON: {json_file}")
print(f"Type: {json_type}")
print(f"Environment: {environment}")
print(f"Output: {output_path}")
print(f"\nStatistics:")
print(f"  Datasets: {len(dataset_paths)}")
print(f"  Transforms: {len(transform_code)}")
print(f"  Outputs: {len(parsed['outputs'])}")
print(f"  Notebook cells: {notebook_content.count('# COMMAND ----------')}")
print(f"  Lines of code: {len(notebook_content.splitlines())}")
print(f"\nNext steps:")
print(f"  1. Review generated notebook: {output_path}")
print(f"  2. Test with sample data in Databricks")
print(f"  3. Deploy to production workspace")
print("=" * 80)
```

---

**End of Scaffold Workflow**
