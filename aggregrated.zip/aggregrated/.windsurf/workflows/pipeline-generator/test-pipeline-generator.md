---
description: Validate generated PySpark notebooks for syntax, schema, and execution
glyphEnabled: true
glyph: test
---

User input: $ARGUMENTS

## Test Suite Overview

Validates generated PySpark notebooks for:
- ✅ Python syntax correctness
- ✅ PySpark API usage
- ✅ Schema compatibility
- ✅ Guardrails compliance
- ✅ Execution with sample data

---

## Test 1: Python Syntax Validation

```python
import ast
from pathlib import Path

def test_python_syntax(notebook_path: Path):
    """Validate Python syntax of generated notebook."""
    
    with open(notebook_path) as f:
        code = f.read()
    
    try:
        ast.parse(code)
        print(f"✅ Python syntax valid: {notebook_path}")
        return True
    except SyntaxError as e:
        print(f"❌ Syntax error in {notebook_path}")
        print(f"   Line {e.lineno}: {e.msg}")
        print(f"   {e.text}")
        return False

# Test all generated notebooks
notebook_dir = Path("pipeline_builder/DBX_Conversion")
for notebook in notebook_dir.glob("*_pipeline_*.py"):
    test_python_syntax(notebook)
```

---

## Test 2: PySpark API Validation

```python
def test_pyspark_imports(notebook_path: Path):
    """Check for valid PySpark imports."""
    
    with open(notebook_path) as f:
        code = f.read()
    
    # Required imports
    required_imports = [
        'from pyspark.sql import functions as F',
        'from pyspark.sql.types import'
    ]
    
    missing = []
    for imp in required_imports:
        if imp not in code:
            missing.append(imp)
    
    if missing:
        print(f"⚠️  Missing imports in {notebook_path}:")
        for imp in missing:
            print(f"   {imp}")
        return False
    
    print(f"✅ PySpark imports valid: {notebook_path}")
    return True

def test_pyspark_functions(notebook_path: Path):
    """Check for valid PySpark function usage."""
    
    with open(notebook_path) as f:
        code = f.read()
    
    # Check for common mistakes
    issues = []
    
    # Using col() without F prefix
    if 'col(' in code and 'F.col(' not in code:
        issues.append("Use F.col() instead of col()")
    
    # Using select() without list
    if '.select("' in code:
        issues.append("Use .select([...]) with list instead of .select('col')")
    
    # Ambiguous column references after join
    if '.join(' in code:
        if 'drop_duplicate_columns' not in code:
            issues.append("Missing drop_duplicate_columns() after join")
    
    if issues:
        print(f"⚠️  PySpark usage issues in {notebook_path}:")
        for issue in issues:
            print(f"   - {issue}")
        return False
    
    print(f"✅ PySpark functions valid: {notebook_path}")
    return True
```

---

## Test 3: Schema Validation

```python
def test_schema_compatibility(notebook_path: Path, expected_outputs: list):
    """Validate output schemas match expectations."""
    
    # Parse notebook for output schemas
    with open(notebook_path) as f:
        code = f.read()
    
    # Extract write operations
    import re
    write_patterns = re.findall(r'(\w+)\.write\..*\.parquet\("(.+?)"\)', code)
    
    found_outputs = [pattern[0] for pattern in write_patterns]
    expected_names = [out['name'].lower().replace(' ', '_') for out in expected_outputs]
    
    missing = set(expected_names) - set(found_outputs)
    extra = set(found_outputs) - set(expected_names)
    
    if missing:
        print(f"❌ Missing outputs in {notebook_path}: {missing}")
        return False
    
    if extra:
        print(f"⚠️  Extra outputs in {notebook_path}: {extra}")
    
    print(f"✅ Schema compatibility: {notebook_path}")
    print(f"   Expected: {len(expected_outputs)}, Found: {len(found_outputs)}")
    return True
```

---

## Test 4: Guardrails Compliance

```python
def test_guardrails(notebook_path: Path, guardrails: dict):
    """Check notebook against security and best practice guardrails."""
    
    with open(notebook_path) as f:
        code = f.read()
    
    violations = []
    
    # Hard stops
    for hard_stop in guardrails.get('hard_stops', []):
        if hard_stop in code:
            violations.append(f"❌ Prohibited pattern: {hard_stop}")
    
    # Specific checks
    if 'dbutils.fs.ls' in code:
        violations.append("❌ dbutils.fs.ls() causes permission errors")
    
    if 'AccountKey=' in code or 'SharedAccessSignature=' in code:
        violations.append("❌ Hardcoded credentials detected")
    
    if '@' in code and 'dfs.core.windows.net' in code:
        # Check if storage account is hardcoded
        if 'STORAGE_ACCOUNT' not in code:
            violations.append("⚠️  Hardcoded storage account (use variable)")
    
    # Delta table checks
    if '.format("delta")' in code and '.mode("overwrite")' in code:
        if 'dbutils.fs.rm' not in code and 'spark.sql("DROP TABLE' not in code:
            violations.append("⚠️  Delta overwrite without cleanup (may cause errors)")
    
    if violations:
        print(f"❌ Guardrail violations in {notebook_path}:")
        for v in violations:
            print(f"   {v}")
        return False
    
    print(f"✅ Guardrails passed: {notebook_path}")
    return True
```

---

## Test 5: Integration Test with Sample Data

```python
def test_execution_with_sample_data(notebook_path: Path, spark_session):
    """Execute notebook with sample data."""
    
    # Create sample input data
    from pyspark.sql.types import StructType, StructField, StringType, DoubleType
    
    schema = StructType([
        StructField("CELLNAME", StringType(), True),
        StructField("LATITUDE", DoubleType(), True),
        StructField("LONGITUDE", DoubleType(), True),
        StructField("STATUS", StringType(), True)
    ])
    
    sample_data = [
        ("CELL001", 40.7128, -74.0060, "ACTIVE"),
        ("CELL002", 34.0522, -118.2437, "ACTIVE"),
        ("CELL003", 41.8781, -87.6298, "INACTIVE")
    ]
    
    df_sample = spark_session.createDataFrame(sample_data, schema)
    
    # Write sample data to temp location
    temp_path = "/tmp/test_input"
    df_sample.write.mode("overwrite").parquet(temp_path)
    
    # Execute notebook (modify paths to use temp)
    with open(notebook_path) as f:
        code = f.read()
    
    # Replace paths with temp paths
    code = code.replace('abfss://raw@', f'file://{temp_path}/')
    code = code.replace('abfss://silver@', f'file:///tmp/test_output/')
    
    try:
        exec(code, {'spark': spark_session})
        print(f"✅ Execution successful: {notebook_path}")
        return True
    except Exception as e:
        print(f"❌ Execution failed: {notebook_path}")
        print(f"   Error: {str(e)}")
        return False
```

---

## Test 6: RID Resolution Validation

```python
def test_rid_resolution(notebook_path: Path, rid_mapping_path: Path):
    """Validate all RIDs are resolved to valid ADLS paths."""
    
    import pandas as pd
    
    # Load RID mapping
    rid_mapping = pd.read_csv(rid_mapping_path)
    known_rids = set(rid_mapping['rid'].values)
    
    # Extract RIDs from notebook
    with open(notebook_path) as f:
        code = f.read()
    
    # Find parquet read operations
    import re
    parquet_reads = re.findall(r'spark\.read\.parquet\("(.+?)"\)', code)
    
    # Check if all paths are resolved (no RIDs in paths)
    unresolved = []
    for path in parquet_reads:
        if 'ri.foundry.main.dataset' in path or 'ri.eddie.main' in path:
            unresolved.append(path)
    
    if unresolved:
        print(f"❌ Unresolved RIDs in {notebook_path}:")
        for rid in unresolved:
            print(f"   {rid}")
        return False
    
    print(f"✅ RID resolution complete: {notebook_path}")
    return True
```

---

## Test 7: Column Case Consistency

```python
def test_column_case_consistency(notebook_path: Path):
    """Check for consistent column name casing."""
    
    with open(notebook_path) as f:
        code = f.read()
    
    # Extract column references
    import re
    col_refs = re.findall(r'F\.col\("(\w+)"\)', code)
    
    # Check for mixed case (CELLNAME vs cellname)
    lowercase_cols = {c.lower(): c for c in col_refs}
    
    inconsistent = []
    for lower, original in lowercase_cols.items():
        variations = [c for c in col_refs if c.lower() == lower and c != original]
        if variations:
            inconsistent.append((original, variations))
    
    if inconsistent:
        print(f"⚠️  Column case inconsistencies in {notebook_path}:")
        for original, variations in inconsistent:
            print(f"   {original} vs {variations}")
        return False
    
    print(f"✅ Column case consistent: {notebook_path}")
    return True
```

---

## Pytest Test Suite

**File**: `tests/test_generated_pipelines.py`

```python
"""Pytest suite for generated PySpark notebooks."""

import pytest
from pathlib import Path
import yaml

@pytest.fixture
def notebook_dir():
    return Path("pipeline_builder/DBX_Conversion")

@pytest.fixture
def config():
    with open(".windsurf/workflows/palantir-migration-config.yaml") as f:
        return yaml.safe_load(f)

@pytest.fixture
def rid_mapping():
    import pandas as pd
    return pd.read_csv(".cdo-aifc/data/rid_mapping.csv")

def test_all_notebooks_syntax(notebook_dir):
    """Test all generated notebooks have valid Python syntax."""
    notebooks = list(notebook_dir.glob("*_pipeline_*.py"))
    assert len(notebooks) > 0, "No notebooks found"
    
    for notebook in notebooks:
        assert test_python_syntax(notebook), f"Syntax error in {notebook}"

def test_all_notebooks_guardrails(notebook_dir, config):
    """Test all notebooks comply with guardrails."""
    notebooks = list(notebook_dir.glob("*_pipeline_*.py"))
    guardrails = config['guardrails']
    
    for notebook in notebooks:
        assert test_guardrails(notebook, guardrails), f"Guardrail violation in {notebook}"

def test_all_notebooks_rid_resolution(notebook_dir, rid_mapping):
    """Test all RIDs are resolved."""
    notebooks = list(notebook_dir.glob("*_pipeline_*.py"))
    rid_mapping_path = Path(".cdo-aifc/data/rid_mapping.csv")
    
    for notebook in notebooks:
        assert test_rid_resolution(notebook, rid_mapping_path), f"Unresolved RIDs in {notebook}"

def test_notebook_structure():
    """Test notebook has required sections."""
    notebook = Path("pipeline_builder/DBX_Conversion/netaudit_pipeline_latest.py")
    
    with open(notebook) as f:
        code = f.read()
    
    # Check for required sections
    assert "# COMMAND ----------" in code, "Missing cell separators"
    assert "STORAGE_ACCOUNT" in code, "Missing storage account config"
    assert "def safe_select" in code, "Missing helper functions"
    assert ".read.parquet" in code, "Missing data loading"
    assert ".write" in code, "Missing data writing"
```

**Run tests**:
```bash
pytest tests/test_generated_pipelines.py -v --tb=short
```

---

## Validation Checklist

After generating notebooks, verify:

- [ ] Python syntax is valid (ast.parse succeeds)
- [ ] PySpark imports are present
- [ ] All RIDs resolved to ADLS paths
- [ ] Guardrails pass (no dbutils.fs.ls, no hardcoded credentials)
- [ ] drop_duplicate_columns() called after joins
- [ ] Column names use consistent case
- [ ] Output paths configured correctly
- [ ] Helper functions defined
- [ ] Sample data execution succeeds

---

## Test Execution Report

```python
def generate_test_report(notebook_path: Path):
    """Generate comprehensive test report."""
    
    print("=" * 80)
    print(f"Test Report: {notebook_path.name}")
    print("=" * 80)
    
    results = {
        'Python Syntax': test_python_syntax(notebook_path),
        'PySpark Imports': test_pyspark_imports(notebook_path),
        'PySpark Functions': test_pyspark_functions(notebook_path),
        'Guardrails': test_guardrails(notebook_path, config['guardrails']),
        'RID Resolution': test_rid_resolution(notebook_path, rid_mapping_path),
        'Column Case': test_column_case_consistency(notebook_path)
    }
    
    passed = sum(results.values())
    total = len(results)
    
    print(f"\nResults: {passed}/{total} tests passed")
    print("\nDetails:")
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status} {test_name}")
    
    print("=" * 80)
    
    return passed == total
```

---

**End of Test Workflow**
