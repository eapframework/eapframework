---
description: Archetype for generating PySpark code from Palantir Pipeline and Contour JSON
glyphEnabled: true
glyph: constitution
---

# Pipeline Generator Archetype Constitution

## Purpose

The **pipeline-generator** archetype converts Palantir Foundry metadata (Pipeline Builder JSON, Contour JSON) into executable PySpark Databricks notebooks. This enables migration of ETL pipelines and analytics logic from Palantir to Azure Databricks.

## Core Responsibilities

1. **JSON Parsing**: Parse Pipeline Builder and Contour JSON structures
2. **RID Resolution**: Resolve Foundry dataset RIDs to Azure ADLS paths using rid_mapping.csv
3. **Code Generation**: Generate PySpark notebooks with proper Spark SQL transformations
4. **Transform Mapping**: Convert Palantir transform types to PySpark equivalents
5. **Guardrails Enforcement**: Prevent common migration issues (hardcoded credentials, Delta conflicts, ambiguous columns)
6. **Schema Preservation**: Maintain column types, primary keys, and partitioning strategies

## Workflows

### Primary Workflows

1. **scaffold**: Generate PySpark notebook from Pipeline/Contour JSON
   - Parse JSON structure (transforms, datasets, outputs)
   - Resolve RIDs to ADLS paths
   - Generate notebook cells with transformations
   - Apply guardrails and best practices

2. **test**: Validate generated PySpark code
   - Syntax validation (Python, PySpark)
   - Schema validation (columns match source)
   - Guardrails compliance checks
   - Integration tests on sample data

### Supporting Workflows

3. **compare**: Choose between Pipeline vs Contour generation strategies
   - Pipeline Builder: Full transform code preservation
   - Contour: Expression-based transformations
   - Hybrid: Combined approach

4. **debug**: Troubleshoot code generation issues
   - RID resolution failures
   - Column ambiguity after joins
   - Schema mismatches
   - Missing helper functions

5. **document**: Create migration runbooks and API reference
   - Transform type mappings
   - Helper function catalog
   - Generated notebook structure
   - Testing procedures

6. **refactor**: Improve generated code quality
   - Consolidate duplicate transformations
   - Optimize join strategies
   - Extract common helper functions
   - Improve error handling

## Dependencies

### Upstream Archetypes
- **metadata-extractor**: Provides Pipeline/Contour JSON files

### External Dependencies
- **RID Mapping CSV**: `.cdo-aifc/data/rid_mapping.csv` (maps Foundry RIDs to ADLS paths)
- **Utility Modules**: `utility/column_clean.py` (optional shared helpers)
- **Configuration**: `.windsurf/workflows/palantir-migration-config.yaml`

### Downstream Consumers
- **Databricks Notebooks**: Generated `.py` files imported into Databricks workspace
- **Databricks Jobs**: JSON job definitions for orchestration

## Success Criteria

✅ **Syntactically Valid**: Generated Python code has no syntax errors
✅ **Schema Accurate**: Output schemas match Palantir pipeline outputs
✅ **Guardrails Pass**: No hardcoded credentials, Delta conflicts, or permission errors
✅ **RID Resolution**: All dataset RIDs resolved to valid ADLS paths
✅ **Executable**: Notebook runs successfully in Databricks with sample data
✅ **Testable**: Integration tests validate row counts and schema

## Common Failure Modes

❌ **Unresolved RID**: Dataset RID not found in rid_mapping.csv (manual mapping needed)
❌ **Ambiguous Columns**: Duplicate columns after join (need drop_duplicate_columns())
❌ **Case Mismatch**: Column names in JSON don't match Parquet file case
❌ **Missing Helper Function**: Generated code references undefined function
❌ **Delta Overwrite Conflict**: Attempt to overwrite existing Delta table without delete
❌ **Hardcoded Path**: Embedded storage account name instead of using variables

## Integration Points

- **Input**: Pipeline/Contour JSON from metadata-extractor archetype
- **Output**: PySpark notebooks (.py) in `pipeline_builder/DBX_Conversion/`
- **Configuration**: Storage account, container, output folders from config YAML
- **Validation**: Test suite runs generated notebooks on sample data

## Transform Type Support

### Pipeline Builder Transforms
- `selectColumns` → `df.select()`
- `complexLeftJoin` → `df.join(..., "left")`
- `dropDuplicates` → `df.dropDuplicates()`
- `applyExpression` → `df.withColumn()`
- `filter` → `df.filter()`
- `aggregate` → `df.agg()`

### Contour Transforms
- `expression` (ROUND, CAST, CONCAT) → `F.round()`, `.cast()`, `F.concat()`
- `sort-columns` → `df.orderBy()`
- `filter` → `df.filter()`
- `aggregate` → `df.groupBy().agg()`

---

**Version**: 1.0.0  
**Last Updated**: 2026-02-05  
**Maintainer**: DEEP Migration Team
