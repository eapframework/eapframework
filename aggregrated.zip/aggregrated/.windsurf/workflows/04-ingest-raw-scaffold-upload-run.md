---
description: Orchestrate ingest-to-raw, scaffold-ingest, upload to Databricks, and run
---

# Ingest -> Scaffold -> Upload -> Run

Chain the generic ingest-to-raw archetype with scaffold-ingest, then upload the
resulting Python notebooks to a Databricks workspace and run them to validate
migration feasibility.

## Inputs

**Required**:
- **ingest_config**: Path to ingest-to-raw YAML config
- **foundry_transform**: Path to Foundry Transform Python file
- **databricks_host**: Workspace base URL (https://adb-...azuredatabricks.net)
- **workspace_folder**: Databricks workspace path to upload (e.g. /Workspace/Users/you@company.com/migrations)

**Optional**:
- **profile**: Databricks CLI profile name
- **auth**: token | azure-cli (default: token)

Example:
```
/ingest-raw-scaffold-upload-run ingest_config: generated/ingest_raw/config.yaml, foundry_transform: Snowflake-DIY-NETAUDIT-Python/transforms-python/src/myproject/datasets/clean/x_site_general_info.py, databricks_host: https://adb-1234567890123456.7.azuredatabricks.net, workspace_folder: /Workspace/Users/you@company.com/migrations
```

## Execution Steps

### 1. Run Ingest-to-Raw
Invoke the ingest archetype using the config provided.

Command:
```
/01-ingest-to-raw <ingest_config>
```

Expected outputs (generated/ingest_raw/):
- ingest_raw.py
- config.py
- README.md

### 2. Run Scaffold-Ingest
Convert a Foundry Transform file into a Databricks-ready PySpark pipeline.

Command:
```
/02-scaffold-ingest <foundry_transform>
```

Expected output:
- A generated PySpark file under the output location reported by the workflow

### 3. Upload to Databricks Workspace
Upload both generated Python files as Databricks notebooks.

Example (token auth):
```
databricks configure --token
```

Upload (use --profile <profile> if provided):
```
databricks workspace import generated/ingest_raw/ingest_raw.py <workspace_folder>/ingest_raw --format SOURCE --language PYTHON --overwrite

databricks workspace import <scaffold_output_py> <workspace_folder>/scaffold_ingest --format SOURCE --language PYTHON --overwrite
```

### 4. Run Notebooks (Validation)
Use a one-off submit to validate execution.

Example:
```
databricks runs submit --json '{"run_name":"ingest_raw_validation","new_cluster":{"spark_version":"13.3.x-scala2.12","num_workers":1},"spark_python_task":{"python_file":"dbfs:/Workspace/<workspace_folder>/ingest_raw"}}'
```

```
databricks runs submit --json '{"run_name":"scaffold_ingest_validation","new_cluster":{"spark_version":"13.3.x-scala2.12","num_workers":1},"spark_python_task":{"python_file":"dbfs:/Workspace/<workspace_folder>/scaffold_ingest"}}'
```

### 5. Report Results
Summarize:
- ingest-to-raw output paths
- scaffold-ingest output path
- Databricks workspace upload locations
- Run IDs (if submitted)

## Guardrails
- Do not modify existing pipeline_builder files.
- Do not store tokens in repo files.
- Use workspace path (not numeric folder id).

## Notes
- Databricks imports Python files with Databricks notebook cell markers when present; plain PySpark scripts still import and run as notebooks.
- If you use an AAD auth flow, use `databricks configure --aad-token`.

## References
- [01-ingest-to-raw.md](01-ingest-to-raw.md)
- [02-scaffold-ingest.md](02-scaffold-ingest.md)
- [03-databricks-access.md](03-databricks-access.md)
