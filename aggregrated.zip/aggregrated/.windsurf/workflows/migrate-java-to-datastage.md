---
description: Convert Java Foundry Spark pipeline to IBM Watson DataStage jobs
---

# Java Foundry to Watson DataStage Migration

Convert Java Foundry Spark pipelines to IBM Watson DataStage parallel jobs by parsing source files and generating DataStage-compatible artifacts.

## Input

**Option A**: Path to Java Foundry transform directory containing:
- `PipelineComputeTransform.java`
- `PipelineLogic.java`
- `PipelineOutputs.java`

```
/migrate-java-to-datastage <path_to_transforms_java_directory>
```

**Option B (Preferred)**: Palantir Pipeline Builder JSON export
```
/migrate-java-to-datastage --json <path_to_pipeline.json>
```

Example: `/migrate-java-to-datastage --json ontology/pipeline.json`

## Execution Steps

### 0. Parse Palantir Pipeline JSON (Option B - Preferred)

When using `--json` flag with a Palantir Pipeline Builder export (`pipeline.json`):

#### JSON Structure Overview
```json
{
  "pipeline": {
    "rid": "ri.eddie.main.pipeline.XXX",
    "name": "Pipeline_Name"
  },
  "sandbox": { "id": "...", "name": "Main" },
  "version": { "backend": "Spark" },
  "snapshot": {
    "transforms": [
      {
        "id": "uuid",
        "transformId": "applyExpression|join|project|aggregate|filter|...",
        "arguments": { ... }
      }
    ],
    "inputs": [ { "datasetRid": "ri.foundry.main.dataset.XXX", "alias": "..." } ],
    "outputs": [ { "datasetRid": "ri.foundry.main.dataset.YYY", "alias": "..." } ]
  }
}
```

#### Transform ID → DataStage Stage Mapping

| Palantir transformId | DataStage Stage |
|---------------------|-----------------|
| `applyExpression` | **Transformer** (column derivation) |
| `project` | **Transformer** (column selection) |
| `join` | **Join** stage |
| `leftJoin` / `rightJoin` | **Join** stage (Left/Right Outer) |
| `aggregate` | **Aggregator** stage |
| `filter` | **Filter** stage |
| `dropDuplicates` | **Remove Duplicates** stage |
| `union` | **Funnel** stage |
| `sort` | **Sort** stage |

#### Expression ID → DataStage Derivation Mapping

| Palantir expressionId | DataStage Expression |
|----------------------|----------------------|
| `alias` | Column rename: `Out.newname = In.oldname` |
| `cast` | Type conversion: `(TargetType)In.col` |
| `literal` | Constant: `"value"` or `123` |
| `column` | Column reference: `In.columnName` |
| `add` / `subtract` / `multiply` / `divide` | Arithmetic: `In.a + In.b` |
| `concat` | String concat: `In.a : In.b` |
| `when` / `otherwise` | Conditional: `If In.cond Then val1 Else val2` |
| `isNull` / `isNotNull` | Null check: `IsNull(In.col)` |
| `max` / `min` / `sum` / `avg` / `count` | Aggregation functions |

#### Parsing Steps for JSON Input
1. Extract `snapshot.inputs` → Create Source stages
2. Extract `snapshot.outputs` → Create Target stages  
3. Iterate `snapshot.transforms` in order:
   - Map each `transformId` to DataStage stage type
   - Convert nested `arguments.expression` to DataStage derivations
   - Preserve column lineage through transform chain

---

### 1. Parse PipelineComputeTransform.java - INPUTS/OUTPUTS (Option A)
Extract I/O definitions from annotations:
- **@Input("ri.foundry.main.dataset.XXX")** → Source stage (Dataset/File stage)
- **@Output("/path/to/output/...")** → Target stage (Dataset/File stage)
- camelCase variable → snake_case table name (e.g., `xNdrNokiaEnb` → `x_ndr_nokia_enb`)

### 2. Parse PipelineOutputs.java - OUTPUT SCHEMA
Extract output dataset fields:
- `Dataset<Row>` field names → Target table names
- Remove "ObjectTypeBackingDatasource" suffix, convert to snake_case

### 3. Parse PipelineLogic.java - TRANSFORMATION LOGIC
Convert Spark operations to DataStage stages:

| Java Spark | DataStage Stage |
|------------|-----------------|
| `.select(col("A"), col("B"))` | **Transformer** - Column derivation |
| `.withColumn("X", expr)` | **Transformer** - Derive new column |
| `.join(df2, keys, "left")` | **Join** stage (Left Outer) |
| `.dropDuplicates("KEY")` | **Remove Duplicates** stage |
| `.cast(DataTypes.StringType)` | **Transformer** - Type conversion |
| `.groupBy().agg()` | **Aggregator** stage |
| `.filter(condition)` | **Filter** stage |
| `.union()` | **Funnel** stage |

### 4. Generate DataStage Job Components

#### 4.1 Source Stages (per @Input)
```
Stage: ds_{input_name}
Type: Sequential File / Dataset / DB2 Connector
Properties:
  - File/Table: {resolved_path_or_table}
  - Schema: {inferred_from_usage}
```

#### 4.2 Transformer Stages (per transformation block)
```
Stage: tx_{transform_name}
Type: Transformer
Derivations:
  - {column}: {expression}
```

#### 4.3 Join Stages
```
Stage: join_{left}_{right}
Type: Join
Join Type: {left|inner|full}
Keys: {key_columns}
```

#### 4.4 Target Stages (per @Output)
```
Stage: tgt_{output_name}
Type: Sequential File / Dataset / DB2 Connector
Properties:
  - File/Table: {resolved_path_or_table}
  - Write Mode: Overwrite
```

### 5. Key Conversion Patterns

#### Column Selection → Transformer Derivation
```java
// Java Spark
df.select(functions.col("MARKET").alias("MARKET"),
          functions.col("NRCELL_NAME").alias("NRCELL_NAME"));
```
```
// DataStage Transformer
Derivation: MARKET = In.MARKET
Derivation: NRCELL_NAME = In.NRCELL_NAME
```

#### Type Casting → Transformer with Conversion
```java
// Java Spark
df.withColumn("CMA", new Column(new Cast(col("CMA").expr(), DataTypes.IntegerType)));
```
```
// DataStage Transformer
Derivation: CMA = (Int32)In.CMA
```

#### Join with Keys → Join Stage
```java
// Java Spark
joinWithKeys(left, right, keys, "left", ...)
```
```
// DataStage Join Stage
Join Type: Left Outer
Left Input: {left_link}
Right Input: {right_link}  
Key: {key_columns} (= condition)
```

#### Aggregation → Aggregator Stage
```java
// Java Spark
df.groupBy().agg(functions.max(col("loaddate_")).alias("loaddate_max"));
```
```
// DataStage Aggregator
Group By: (none or columns)
Aggregation: loaddate_max = Max(loaddate_)
```

### 6. Type Mapping (Java Spark → DataStage)

| Java Spark Type | DataStage Type |
|-----------------|----------------|
| `DataTypes.StringType` | `VarChar` / `String` |
| `DataTypes.IntegerType` | `Int32` |
| `DataTypes.LongType` | `Int64` |
| `DataTypes.DoubleType` | `Double` |
| `DataTypes.FloatType` | `Float` |
| `DataTypes.BooleanType` | `Int8` (0/1) |
| `DataTypes.TimestampType` | `Timestamp` |
| `DataTypes.DateType` | `Date` |
| `DataTypes.DecimalType` | `Decimal` |

### 7. Generate Output Artifacts

| Artifact | Description |
|----------|-------------|
| `{job_name}.dsx` | DataStage job export file |
| `{job_name}_schema.json` | Column schemas per stage |
| `{job_name}_mapping.md` | Source→Target column mapping |

### 8. DataStage Job Metadata Template
```yaml
Job Name: {derived_from_pipeline}
Job Type: Parallel
Stages:
  - Sources: {count}
  - Transformers: {count}
  - Joins: {count}
  - Targets: {count}
```

## Configuration Files

| File | Purpose |
|------|---------|
| `ontology/pipeline.json` | Palantir Pipeline Builder JSON export (preferred input) |
| `.cdo-aifc/templates/03-data-engineering/datastage/connection-config.yaml` | DB/File connection settings |
| `.cdo-aifc/data/rid_mapping.csv` | RID to dataset_name mapping |

## DataStage-Specific Considerations

1. **Schema Propagation**: DataStage requires explicit schemas; infer from Java types and column usage
2. **Null Handling**: Use `IsNull()` / `SetNull()` functions in Transformer
3. **Date/Timestamp Conversion**:
   - Epoch millis → `TimestampFromSecondsSince(In.col/1000, 1970-01-01)`
   - Date formatting → `DateToString(In.col, "%Y%m%d")`
4. **Geo Point**: Store as separate LAT/LON columns or as String `In.LONGITUDE:":":In.LATITUDE`
5. **Partitioning**: Configure hash partitioning on join keys for performance
6. **Duplicate Columns**: Rename with `_dup` suffix before join stages

## Common Unsupported Operations

| Java Spark Operation | DataStage Workaround |
|---------------------|----------------------|
| `unsupportedExpression("epochMillisToDate")` | `TimestampFromSecondsSince()` |
| `unsupportedExpression("dateToString")` | `DateToString()` |
| `unsupportedExpression("createOntologyGeopoint")` | Concatenate LAT/LON as string |

## Example Usage

**From Java source files:**
```
/migrate-java-to-datastage pipeline_builder/transforms-java/src/main/java
```

**From Palantir Pipeline JSON (preferred):**
```
/migrate-java-to-datastage --json ontology/pipeline.json
```

Outputs:
- `datastage_jobs/netaudit_project_pipeline.dsx`
- `datastage_jobs/netaudit_project_pipeline_schema.json`
- `datastage_jobs/netaudit_project_pipeline_mapping.md`

## Validation Checklist

- [ ] All @Input datasets mapped to Source stages
- [ ] All @Output datasets mapped to Target stages
- [ ] Type casts converted to DataStage type conversions
- [ ] Joins have correct key mappings and join types
- [ ] Aggregations use correct DataStage aggregation functions
- [ ] Null handling applied where needed
- [ ] Schema defined for each link between stages
