---
description: Fetch Palantir Contour analysis JSON via API for migration to PySpark
---
 
User input: $ARGUMENTS
 
## Configuration
 
**Config File**: `.windsurf/workflows/palantir-migration-config.yaml`
 
Load settings from config:
```yaml
api:
  base_url: "https://paloma.palantirfoundry.com"
  contour_path: "/contour/api/refs"
  timeout_seconds: 60
  retry_attempts: 3
 
contour:
  default_ref_rid: "ri.contour.main.ref.d000b16c-50b3-4790-a7d5-2ea2c2e56dee"
  default_node_id: "62f1f204-fbd2-32d0-8beb-77058c0a0be5"
```
 
---
## Execution Steps
 
### 1. Parse Input
Extract from $ARGUMENTS:
- **ref_rid**: Contour reference RID (e.g., `ri.contour.main.ref.xxx`)
- **node_id**: Board node ID (from Contour URL or JSON)
- **output_name**: Name for output file (default: `contour`)
 
Request clarification if ref_rid or node_id not provided.
 
### 2. Validate Prerequisites
 
| Requirement | Check | Config Key |
|-------------|-------|------------|
| Bearer Token | `PALANTIR_TOKEN` env var OR `--token` | `auth.token_env_var` |
| Network Access | Can reach API base URL | `api.base_url` |
| Ref RID | Valid format `ri.contour.main.ref.xxx` | `contour.default_ref_rid` |
| Node ID | Valid UUID format | `contour.default_node_id` |
| Output Directory | Writable path | `output.json_dir` |
 
### 3. API Endpoint
 
**Fetch Contour Board**
```
GET {api.base_url}/contour/api/refs/{ref_rid}/nodes/{node_id}/board
```
 
Headers:
```
Accept: application/json
Authorization: Bearer {token}
```
 
### 4. Execute Fetch Script
 
```bash
# Option 1: Using environment variable (recommended)
export PALANTIR_TOKEN="your_bearer_token"
python pipeline_builder/DBX_Conversion/fetch_contour.py
 
# Option 2: With custom ref/node
python pipeline_builder/DBX_Conversion/fetch_contour.py \
    --ref-rid "ri.contour.main.ref.xxx" \
    --node-id "xxx-xxx-xxx"
 
# Option 3: Token as argument (testing only)
python pipeline_builder/DBX_Conversion/fetch_contour.py \
    --token "your_token" \
    --ref-rid "ri.contour.main.ref.xxx" \
    --node-id "xxx"
```
 
### 5. Output Files
 
| File | Description |
|------|-------------|
| `contour_{timestamp}.json` | Versioned contour JSON (audit trail) |
| `contour_latest.json` | Latest contour JSON (used by migrate workflow) |
 
Output directory: `pipeline_builder/DBX_Conversion/jsonexports/`
 
### 6. Validate Output
 
Check the fetched JSON contains required sections:
```json
{
  "snapshots": [
    {
      "id": "...",
      "boardType": "starting|expression|custom|table",
      "boardState": {
        "@type": "...",
        "startingSetDescription": { "identifier": "ri.foundry.main.dataset.xxx" }
      }
    }
  ]
}
```
 
### 7. Chain to Migration Workflow
 
After successful fetch, proceed to migration:
```
/migrate-contour-to-pyspark Migrate contour_latest.json to PySpark
```
 
## CLI Arguments
 
| Argument | Required | Description |
|----------|----------|-------------|
| `--token` | No* | Bearer token (*required if `PALANTIR_TOKEN` not set) |
| `--ref-rid` | No | Contour reference RID (default from config) |
| `--node-id` | No | Board node ID (default from config) |
| `--output` | No | Output filename |
 
## Curl Command (Manual Testing)
 
```bash
curl -sS -L -X GET \
  "https://paloma.palantirfoundry.com/contour/api/refs/{REF_RID}/nodes/{NODE_ID}/board" \
  -H "Accept: application/json" \
  -H "Authorization: Bearer {TOKEN}" \
  -o contour.json
```
 
## Error Handling
 
**SSL Certificate Errors** (corporate proxy):
```python
# Edit fetch_contour.py - SSL bypass is enabled by default
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE
```
 
**401 Unauthorized**: Token expired or invalid. Generate new token from Palantir UI.
 
**404 Not Found**: Invalid ref_rid or node_id. Check Contour URL for correct IDs.
 
## Examples
 
### Basic Fetch (using defaults)
```
/fetch-contour-json Fetch Contour analysis
```
 
### Fetch with Custom IDs
```
/fetch-contour-json Fetch Contour ref: ri.contour.main.ref.xxx node: yyy-zzz
```
 
## How to Find Ref RID and Node ID
 
1. Open Contour analysis in Palantir
2. Look at browser URL: `https://paloma.palantirfoundry.com/contour/view/{ref_rid}?...`
3. Or export JSON manually and check `refRid` and `id` fields in snapshots
 
## References
 
- **Script**: `pipeline_builder/DBX_Conversion/fetch_contour.py`
- **Output Dir**: `pipeline_builder/DBX_Conversion/jsonexports/`
- **Next Workflow**: `/migrate-contour-to-pyspark`
 
## Version History
 
| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02-04 | Initial release |
 
 