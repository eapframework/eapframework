# Metadata Extractor Archetype

Extract pipeline and analysis metadata from Palantir Foundry APIs for migration to Azure.

## Quick Start

### Extract Pipeline Builder Metadata

```bash
# Set authentication token
export PALANTIR_TOKEN="your_bearer_token"

# Fetch pipeline metadata
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-id "ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043" \
    --pipeline-name "netaudit"

# Output: pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json
```

### Extract Contour Analysis Metadata

```bash
# Fetch contour metadata
python pipeline_builder/DBX_Conversion/fetch_contour.py \
    --ref-rid "ri.contour.main.ref.d000b16c-50b3-4790-a7d5-2ea2c2e56dee" \
    --node-id "62f1f204-fbd2-32d0-8beb-77058c0a0be5"

# Output: pipeline_builder/DBX_Conversion/jsonexports/contour_latest.json
```

## What Gets Extracted

### Pipeline Builder JSON

```json
{
  "pipeline": {
    "rid": "ri.eddie.main.pipeline.xxx",
    "name": "NetAudit Pipeline"
  },
  "sandbox": {
    "id": "yyy",
    "name": "Main",
    "isPublished": true
  },
  "snapshot": {
    "transforms": [
      {
        "id": "transform_1",
        "name": "CleanSiteData",
        "pythonCode": "def transform(...):",
        "inputs": ["ri.foundry.main.dataset.aaa"],
        "outputs": ["ri.foundry.main.dataset.bbb"]
      }
    ],
    "datasets": [
      {
        "rid": "ri.foundry.main.dataset.aaa",
        "name": "/raw/site_master",
        "schema": {...}
      }
    ],
    "outputs": [
      {
        "datasetRid": "ri.foundry.main.dataset.bbb",
        "outputType": "DATASET",
        "primaryKey": ["site_id", "date"]
      }
    ]
  }
}
```

### Contour Analysis JSON

```json
{
  "snapshots": [
    {
      "id": "snapshot_1",
      "boardType": "starting",
      "boardState": {
        "startingSetDescription": {
          "identifier": "ri.foundry.main.dataset.xxx",
          "type": "dataset"
        }
      }
    },
    {
      "id": "snapshot_2",
      "boardType": "expression",
      "expression": {
        "type": "filter",
        "column": "status",
        "operator": "equals",
        "value": "ACTIVE"
      }
    }
  ]
}
```

## Configuration

**File**: `.windsurf/workflows/palantir-migration-config.yaml`

```yaml
api:
  base_url: "https://paloma.palantirfoundry.com"
  pipeline_path: "/eddie/api/pipelines-v2"
  contour_path: "/contour/api/refs"
  timeout_seconds: 60
  retry_attempts: 3
  retry_delay_seconds: 5

auth:
  token_env_var: "PALANTIR_TOKEN"

pipelines:
  netaudit:
    rid: "ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043"
  site_master:
    rid: "ri.eddie.main.pipeline.xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"

contour:
  default_ref_rid: "ri.contour.main.ref.d000b16c-50b3-4790-a7d5-2ea2c2e56dee"
  default_node_id: "62f1f204-fbd2-32d0-8beb-77058c0a0be5"

output:
  json_dir: "pipeline_builder/DBX_Conversion/pipeline_json/"
  versioning: true  # Save timestamped copies
```

## How to Find RIDs

### Pipeline RID
1. Open Pipeline Builder in Palantir
2. Look at browser URL: `https://paloma.palantirfoundry.com/pipeline-builder/{PIPELINE_RID}`
3. Or use API: `GET /eddie/api/pipelines-v2` to list all pipelines

### Contour Ref/Node IDs
1. Open Contour analysis in Palantir
2. Browser URL: `https://paloma.palantirfoundry.com/contour/view/{REF_RID}?...`
3. Export JSON manually and find `refRid` and `id` fields

### Dataset RIDs
- Found in Pipeline JSON `snapshot.datasets[].rid`
- Or in Contour JSON `startingSetDescription.identifier`

## Authentication

### Generate Bearer Token

1. Log into Palantir Foundry
2. Open Developer Console (F12)
3. Go to Application → Cookies
4. Copy value of `multipass` cookie
5. Set environment variable:

```bash
export PALANTIR_TOKEN="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9..."
```

**Token TTL**: 24 hours (regenerate daily)

## API Endpoints

### Pipeline Builder

```bash
# Step 1: Get sandboxes
GET /eddie/api/pipelines-v2/{pipeline_rid}/sandboxes/get/all

# Step 2: Get all information
GET /eddie/api/pipelines-v2/{pipeline_rid}/all-information?sandboxId={sandbox_id}
```

### Contour

```bash
# Get board configuration
GET /contour/api/refs/{ref_rid}/nodes/{node_id}/board
```

## Output Files

| File | Description |
|------|-------------|
| `{name}_{timestamp}.json` | Versioned copy (e.g., `netaudit_20260204_143022.json`) |
| `{name}_latest.json` | Symlink/copy to latest version |
| `{name}_metadata.json` | Extracted metadata summary (RIDs, primary keys) |

## Common Issues

### 401 Unauthorized
**Cause**: Token expired or invalid  
**Fix**: Regenerate bearer token from Palantir UI

### 404 Not Found
**Cause**: Invalid Pipeline/Contour RID  
**Fix**: Verify RID in Palantir URL or config file

### SSL Certificate Error
**Cause**: Corporate proxy blocks SSL verification  
**Fix**: Edit script to bypass SSL (dev/testing only):

```python
import ssl
ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE
```

### No Sandbox ID Found
**Cause**: Pipeline has no published sandbox  
**Fix**: Publish sandbox in Pipeline Builder, or specify `--sandbox-id` manually

## Next Steps

After extracting metadata:

1. **Validate**: Run `test-metadata-extractor` workflow
2. **Generate Code**: Chain to `pipeline-generator` archetype
3. **Convert Transforms**: Chain to `transform-converter` archetype
4. **Validate Data**: Chain to `data-validator` archetype

## Workflows

- [scaffold-metadata-extractor.md](scaffold-metadata-extractor.md) - Extract metadata via APIs
- [test-metadata-extractor.md](test-metadata-extractor.md) - Validate extracted JSON
- [compare-metadata-extractor.md](compare-metadata-extractor.md) - Pipeline vs Contour comparison
- [debug-metadata-extractor.md](debug-metadata-extractor.md) - Troubleshoot API failures
- [document-metadata-extractor.md](document-metadata-extractor.md) - API reference documentation
- [refactor-metadata-extractor.md](refactor-metadata-extractor.md) - Improve extraction scripts

## References

- **Scripts**:
  - `pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py`
  - `pipeline_builder/DBX_Conversion/fetch_contour.py`
- **Config**: `.windsurf/workflows/palantir-migration-config.yaml`
- **Palantir API Docs**: https://paloma.palantirfoundry.com/workspace/documentation

---

**Version**: 1.0.0  
**Maintainer**: DEEP Migration Team
