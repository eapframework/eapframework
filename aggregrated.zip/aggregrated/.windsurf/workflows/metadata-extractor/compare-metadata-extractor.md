---
description: Compare Pipeline Builder vs Contour for metadata extraction
glyphEnabled: true
glyph: compare
---

User input: $ARGUMENTS

## Overview

Two primary sources of metadata in Palantir Foundry:
1. **Pipeline Builder**: Transform code, lineage, dependencies
2. **Contour**: Analysis logic, filters, aggregations, visualizations

Choose the right extraction source based on migration goals.

---

## Comparison Table

| Aspect | Pipeline Builder | Contour |
|--------|------------------|---------|
| **API Endpoint** | `/eddie/api/pipelines-v2` | `/contour/api/refs` |
| **Primary Use** | ETL pipelines | Analytics/BI dashboards |
| **Contains** | Python transform code, dataset RIDs, lineage | SQL-like operations, filters, aggregations |
| **Best For** | Migrating data pipelines | Migrating analysis logic |
| **Output Format** | PySpark notebooks | SQL queries / Snowflake views |
| **Complexity** | High (full Python code) | Medium (declarative operations) |
| **Lineage Info** | ✅ Full DAG | ⚠️  Limited (board sequence) |
| **Schema** | ✅ Included | ⚠️  Inferred from operations |
| **Primary Keys** | ✅ Defined in outputs | ❌ Not defined |
| **Incremental Logic** | ✅ Explicit in code | ❌ Not supported |

---

## When to Use Pipeline Builder

### Scenario 1: Migrating ETL Pipelines

**Use Pipeline Builder if**:
- Need to convert Python transform code to PySpark
- Pipeline has complex transformations (joins, window functions)
- Need to preserve incremental load logic
- Require exact lineage (dataset → transform → output)

**Example**:
```
Pipeline: NetAudit Data Cleaning
- Input: raw/levo_site_master
- Transforms:
  1. CleanSiteData: Remove nulls, lowercase columns
  2. JoinReferenceData: Enrich with cell_rrh data
  3. CalculateMetrics: Aggregate by site_id, date
- Output: silver/site_master_clean (PK: site_id, date)
```

**Migration Path**:
```
Extract Pipeline JSON → transform-converter → PySpark notebooks → Databricks
```

---

## When to Use Contour

### Scenario 2: Migrating Analytics Logic

**Use Contour if**:
- Dashboard has filter/aggregation logic to preserve
- Need to convert Contour operations to SQL
- Analysis is read-only (no data writes)
- Migrating to Snowflake views instead of Databricks

**Example**:
```
Contour Analysis: Site Health Dashboard
- Starting Set: silver/site_master_clean
- Operations:
  1. Filter: status = 'ACTIVE'
  2. Filter: date >= '2024-01-01'
  3. Aggregate: COUNT(*) by site_id, region
  4. Sort: region ASC
```

**Migration Path**:
```
Extract Contour JSON → pipeline-generator → SQL views → Snowflake
```

---

## Decision Matrix

### Question 1: What type of workload?

| Workload Type | Recommended Source |
|--------------|-------------------|
| ETL pipeline (write data) | **Pipeline Builder** |
| Analytics dashboard (read-only) | **Contour** |
| Both (pipeline + dashboard) | **Extract both** |

### Question 2: What's the migration target?

| Target Platform | Preferred Source |
|----------------|------------------|
| Databricks (PySpark) | **Pipeline Builder** |
| Snowflake (SQL) | **Contour** |
| Both | **Extract both** |

### Question 3: What metadata do you need?

| Required Metadata | Source |
|-------------------|--------|
| Transform Python code | **Pipeline Builder** |
| Dataset lineage (full DAG) | **Pipeline Builder** |
| Primary keys | **Pipeline Builder** |
| Filter logic | **Contour** |
| Aggregation logic | **Contour** |
| Column mappings | **Both** |

---

## Extraction Strategy Comparison

### Strategy 1: Pipeline Builder Only

**Pros**:
- ✅ Complete transform code
- ✅ Full lineage
- ✅ Primary keys defined
- ✅ Incremental logic preserved

**Cons**:
- ❌ Analysis logic not captured
- ❌ Dashboard filters not preserved
- ❌ Visualization configs lost

**When to use**: Migrating data pipelines to Databricks

---

### Strategy 2: Contour Only

**Pros**:
- ✅ Analysis logic preserved
- ✅ Filter/aggregation operations clear
- ✅ Easier to convert to SQL

**Cons**:
- ❌ No transform code
- ❌ Limited lineage
- ❌ No primary keys
- ❌ No incremental logic

**When to use**: Migrating analytics dashboards to Snowflake views

---

### Strategy 3: Both (Recommended)

**Pros**:
- ✅ Complete metadata coverage
- ✅ Can migrate pipelines + dashboards
- ✅ Cross-validate lineage
- ✅ Preserve all business logic

**Cons**:
- ⚠️  More API calls
- ⚠️  More JSON files to manage
- ⚠️  Need to reconcile differences

**When to use**: Production migrations requiring full fidelity

**Workflow**:
```
1. Extract Pipeline JSON → transform-converter → PySpark (Databricks)
2. Extract Contour JSON → pipeline-generator → SQL views (Snowflake)
3. Validate data consistency between Databricks and Snowflake
```

---

## API Response Comparison

### Pipeline Builder Response

```json
{
  "pipeline": {
    "rid": "ri.eddie.main.pipeline.xxx",
    "name": "NetAudit Pipeline"
  },
  "snapshot": {
    "transforms": [
      {
        "id": "t1",
        "name": "CleanSiteData",
        "pythonCode": "def transform(df):\n    return df.filter(...)",
        "inputs": ["ri.foundry.main.dataset.aaa"],
        "outputs": ["ri.foundry.main.dataset.bbb"]
      }
    ],
    "datasets": [
      {"rid": "ri.foundry.main.dataset.aaa", "name": "raw/site_master"}
    ],
    "outputs": [
      {
        "datasetRid": "ri.foundry.main.dataset.bbb",
        "primaryKey": ["site_id", "date"]
      }
    ]
  }
}
```

**What you get**:
- ✅ Full Python transform code
- ✅ Input/output RIDs
- ✅ Primary keys
- ✅ Dataset names

---

### Contour Response

```json
{
  "snapshots": [
    {
      "id": "s1",
      "boardType": "starting",
      "boardState": {
        "startingSetDescription": {
          "identifier": "ri.foundry.main.dataset.aaa"
        }
      }
    },
    {
      "id": "s2",
      "boardType": "expression",
      "expression": {
        "type": "filter",
        "column": "status",
        "operator": "equals",
        "value": "ACTIVE"
      }
    },
    {
      "id": "s3",
      "boardType": "custom",
      "aggregation": {
        "type": "count",
        "groupBy": ["site_id", "region"]
      }
    }
  ]
}
```

**What you get**:
- ✅ Starting dataset RID
- ✅ Filter operations
- ✅ Aggregation logic
- ❌ No transform code
- ❌ No primary keys

---

## Migration Code Comparison

### From Pipeline Builder JSON

**Input**: `CleanSiteData` transform code
```python
# Palantir Transform
@transform(
    df=Input("ri.foundry.main.dataset.aaa"),
    output=Output("ri.foundry.main.dataset.bbb")
)
def compute(df):
    return df.filter(col("status") == "ACTIVE")
```

**Migrated PySpark**:
```python
# Databricks Notebook
df = spark.read.parquet("abfss://raw@storage.dfs.core.windows.net/site_master")
df_clean = df.filter(col("status") == "ACTIVE")
df_clean.write.mode("overwrite").parquet("abfss://silver@storage.dfs.core.windows.net/site_master_clean")
```

---

### From Contour JSON

**Input**: Filter + Aggregation operations
```json
[
  {"type": "filter", "column": "status", "operator": "equals", "value": "ACTIVE"},
  {"type": "aggregate", "function": "count", "groupBy": ["site_id", "region"]}
]
```

**Migrated SQL**:
```sql
-- Snowflake View
CREATE OR REPLACE VIEW site_health AS
SELECT 
    site_id,
    region,
    COUNT(*) AS record_count
FROM silver.site_master_clean
WHERE status = 'ACTIVE'
GROUP BY site_id, region
ORDER BY region;
```

---

## Recommendations

### For ETL Migration (Data Pipelines)
✅ **Use Pipeline Builder**
- Extract complete transform code
- Preserve incremental logic
- Maintain lineage
- Migrate to Databricks PySpark

### For Analytics Migration (Dashboards)
✅ **Use Contour**
- Extract filter/aggregation logic
- Convert to SQL views
- Migrate to Snowflake

### For Production Migration
✅ **Use Both**
- Pipeline Builder → Databricks (ETL layer)
- Contour → Snowflake (Analytics layer)
- Cross-validate results

---

## Validation Checklist

After choosing extraction source:

- [ ] Extracted metadata includes all required transforms/operations
- [ ] RID resolution complete (all datasets mapped to ADLS paths)
- [ ] Primary keys captured (Pipeline Builder only)
- [ ] Incremental logic preserved (Pipeline Builder only)
- [ ] Filter/aggregation logic preserved (Contour only)
- [ ] Migration target platform aligns with source (PySpark ← Pipeline, SQL ← Contour)

---

**End of Compare Workflow**
