---
description: API reference and metadata extraction documentation
glyphEnabled: true
glyph: document
---

User input: $ARGUMENTS

## Palantir Foundry API Reference

Complete guide to Palantir Foundry APIs used for metadata extraction.

---

## Pipeline Builder API

### Base URL
```
https://paloma.palantirfoundry.com/eddie/api/pipelines-v2
```

### Authentication
All endpoints require Bearer token in Authorization header:
```
Authorization: Bearer {multipass_cookie_value}
```

---

### Endpoint 1: Get All Sandboxes

**Purpose**: Retrieve all sandboxes for a pipeline

**Method**: `GET`

**Path**: `/{pipeline_rid}/sandboxes/get/all`

**Example**:
```bash
curl -X GET \
  "https://paloma.palantirfoundry.com/eddie/api/pipelines-v2/ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043/sandboxes/get/all" \
  -H "Authorization: Bearer $PALANTIR_TOKEN" \
  -H "Accept: application/json"
```

**Response**:
```json
{
  "sandboxes": [
    {
      "id": "62f1f204-fbd2-32d0-8beb-77058c0a0be5",
      "name": "Main",
      "isPublished": true,
      "createdAt": "2024-01-15T10:30:00Z"
    },
    {
      "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "name": "Dev",
      "isPublished": false,
      "createdAt": "2024-02-01T14:20:00Z"
    }
  ]
}
```

**Response Fields**:
- `id`: Sandbox identifier (required for next API call)
- `name`: Human-readable sandbox name
- `isPublished`: Whether sandbox is published (prefer `true`)
- `createdAt`: Sandbox creation timestamp

---

### Endpoint 2: Get All Information

**Purpose**: Retrieve complete pipeline definition (transforms, datasets, outputs)

**Method**: `GET`

**Path**: `/{pipeline_rid}/all-information?sandboxId={sandbox_id}`

**Example**:
```bash
curl -X GET \
  "https://paloma.palantirfoundry.com/eddie/api/pipelines-v2/ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043/all-information?sandboxId=62f1f204-fbd2-32d0-8beb-77058c0a0be5" \
  -H "Authorization: Bearer $PALANTIR_TOKEN" \
  -H "Accept: application/json" \
  -o pipeline.json
```

**Response**:
```json
{
  "pipeline": {
    "rid": "ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043",
    "name": "NetAudit Pipeline",
    "description": "Process NetAudit site master data"
  },
  "sandbox": {
    "id": "62f1f204-fbd2-32d0-8beb-77058c0a0be5",
    "name": "Main",
    "isPublished": true
  },
  "snapshot": {
    "transforms": [
      {
        "id": "transform_1",
        "name": "CleanSiteData",
        "pythonCode": "@transform(...)\ndef compute(df):\n    return df.filter(col('status') == 'ACTIVE')",
        "inputs": ["ri.foundry.main.dataset.aaa"],
        "outputs": ["ri.foundry.main.dataset.bbb"]
      }
    ],
    "datasets": [
      {
        "rid": "ri.foundry.main.dataset.aaa",
        "name": "/raw/levo_site_master",
        "path": "raw/levo_site_master",
        "schema": {
          "fields": [
            {"name": "site_id", "type": "string"},
            {"name": "status", "type": "string"},
            {"name": "date", "type": "date"}
          ]
        }
      },
      {
        "rid": "ri.foundry.main.dataset.bbb",
        "name": "/silver/site_master_clean",
        "path": "silver/site_master_clean"
      }
    ],
    "outputs": [
      {
        "datasetRid": "ri.foundry.main.dataset.bbb",
        "outputType": "DATASET",
        "primaryKey": ["site_id", "date"],
        "mode": "SNAPSHOT"
      }
    ]
  }
}
```

**Key Sections**:
- `snapshot.transforms[]`: All transform code
  - `pythonCode`: Full Python function with `@transform` decorator
  - `inputs`: Array of input dataset RIDs
  - `outputs`: Array of output dataset RIDs
- `snapshot.datasets[]`: All datasets referenced
  - `rid`: Foundry dataset identifier
  - `path`: Foundry dataset path (map to ADLS path)
  - `schema`: Column definitions (may be `null`)
- `snapshot.outputs[]`: Pipeline outputs
  - `datasetRid`: Output dataset RID
  - `primaryKey`: Primary key columns (critical for incremental loads)
  - `mode`: SNAPSHOT (overwrite) or INCREMENTAL (append)

---

## Contour API

### Base URL
```
https://paloma.palantirfoundry.com/contour/api/refs
```

### Authentication
Same Bearer token as Pipeline Builder

---

### Endpoint: Get Board Configuration

**Purpose**: Retrieve Contour analysis board configuration

**Method**: `GET`

**Path**: `/{ref_rid}/nodes/{node_id}/board`

**Example**:
```bash
curl -X GET \
  "https://paloma.palantirfoundry.com/contour/api/refs/ri.contour.main.ref.d000b16c-50b3-4790-a7d5-2ea2c2e56dee/nodes/62f1f204-fbd2-32d0-8beb-77058c0a0be5/board" \
  -H "Authorization: Bearer $PALANTIR_TOKEN" \
  -H "Accept: application/json" \
  -o contour.json
```

**Response**:
```json
{
  "snapshots": [
    {
      "id": "snapshot_1",
      "boardType": "starting",
      "boardState": {
        "@type": "com.palantir.contour.api.StartingSet",
        "startingSetDescription": {
          "identifier": "ri.foundry.main.dataset.aaa",
          "type": "dataset"
        }
      }
    },
    {
      "id": "snapshot_2",
      "boardType": "expression",
      "expression": {
        "type": "filter",
        "column": "status",
        "operator": "equals",
        "value": "ACTIVE"
      }
    },
    {
      "id": "snapshot_3",
      "boardType": "custom",
      "aggregation": {
        "type": "count",
        "groupBy": ["site_id", "region"],
        "orderBy": [{"column": "region", "direction": "ASC"}]
      }
    }
  ]
}
```

**Board Types**:
- `starting`: Initial dataset (source)
- `expression`: Filter/calculation operation
- `custom`: Aggregation/grouping
- `table`: Table visualization (metadata only)

**Expression Types**:
- `filter`: WHERE clause equivalent
- `calculate`: New column creation
- `aggregate`: GROUP BY equivalent
- `join`: JOIN operation

---

## How to Find RIDs

### Method 1: Browser URL

**Pipeline RID**:
1. Open Pipeline Builder in Palantir
2. Browser URL format: `https://paloma.palantirfoundry.com/pipeline-builder/{PIPELINE_RID}`
3. Copy entire RID: `ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043`

**Contour Ref RID**:
1. Open Contour analysis in Palantir
2. Browser URL format: `https://paloma.palantirfoundry.com/contour/view/{REF_RID}?...`
3. Copy RID: `ri.contour.main.ref.d000b16c-50b3-4790-a7d5-2ea2c2e56dee`

**Node ID** (for Contour):
1. Export Contour board as JSON (UI option)
2. Find `id` field in first snapshot
3. Or check browser Network tab for API call parameters

---

### Method 2: Configuration File

Store frequently used RIDs in config:

**File**: `.windsurf/workflows/palantir-migration-config.yaml`

```yaml
pipelines:
  netaudit:
    rid: "ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043"
    description: "NetAudit site master data pipeline"
  
  site_master:
    rid: "ri.eddie.main.pipeline.xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    description: "Site master ETL pipeline"

contour:
  default_ref_rid: "ri.contour.main.ref.d000b16c-50b3-4790-a7d5-2ea2c2e56dee"
  default_node_id: "62f1f204-fbd2-32d0-8beb-77058c0a0be5"

datasets:
  raw_site_master: "ri.foundry.main.dataset.aaa"
  silver_site_master_clean: "ri.foundry.main.dataset.bbb"
```

---

## Bearer Token Management

### How to Generate Token

1. **Log into Palantir Foundry** in Chrome/Edge
2. **Open Developer Console** (F12 or Ctrl+Shift+I)
3. Navigate to: **Application** tab → **Cookies** → `https://paloma.palantirfoundry.com`
4. Find cookie named **`multipass`**
5. Copy entire **Value** field (starts with `eyJhbGciOi...`)
6. Set environment variable:
   ```bash
   export PALANTIR_TOKEN="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9..."
   ```

### Token Properties

- **Format**: JWT (JSON Web Token)
- **Encoding**: Base64-encoded JSON
- **TTL**: 24 hours (regenerate daily)
- **Scope**: User's Palantir permissions

### Token Storage (Secure)

**Option 1: Environment Variable** (development):
```bash
# ~/.bashrc or ~/.zshrc
export PALANTIR_TOKEN="your_token_here"
```

**Option 2: Secrets Manager** (production):
```python
import boto3

# AWS Secrets Manager
client = boto3.client('secretsmanager')
response = client.get_secret_value(SecretId='palantir/token')
token = response['SecretString']
```

**Option 3: Azure Key Vault** (production):
```python
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

credential = DefaultAzureCredential()
client = SecretClient(vault_url="https://myvault.vault.azure.net/", credential=credential)
token = client.get_secret("palantir-token").value
```

---

## Error Codes

| HTTP Code | Error Code | Meaning | Resolution |
|-----------|------------|---------|------------|
| 400 | BAD_REQUEST | Invalid request format | Check API parameters |
| 401 | PERMISSION_DENIED | Invalid/expired token | Regenerate bearer token |
| 403 | FORBIDDEN | No access to resource | Request Palantir permissions |
| 404 | NOT_FOUND | Invalid RID | Verify RID in config/UI |
| 429 | RATE_LIMIT_EXCEEDED | Too many requests | Add exponential backoff |
| 500 | INTERNAL_ERROR | Palantir API error | Retry or contact support |
| 503 | SERVICE_UNAVAILABLE | API down | Wait and retry |

---

## Rate Limits

Palantir API rate limits (unofficial estimates):
- **Requests per minute**: ~60
- **Requests per hour**: ~1,000
- **Concurrent connections**: ~10

**Best Practices**:
- Add 1-2 second delay between requests
- Implement exponential backoff on 429 errors
- Cache API responses locally
- Use batch operations where available

---

## Metadata Extraction Runbook Template

```markdown
# Metadata Extraction Runbook: {Pipeline Name}

## Prerequisites
- [ ] Palantir bearer token generated (valid 24h)
- [ ] VPN connected to corporate network
- [ ] Python 3.8+ installed
- [ ] Config file updated with correct RIDs

## Extraction Steps

### Step 1: Set Authentication
```bash
export PALANTIR_TOKEN="your_token_here"
```

### Step 2: Extract Pipeline Metadata
```bash
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-name {pipeline_name} \
    --output-name {output_name}
```

**Expected output**:
- `pipeline_builder/DBX_Conversion/pipeline_json/{output_name}_latest.json`
- `pipeline_builder/DBX_Conversion/pipeline_json/{output_name}_{timestamp}.json`

### Step 3: Validate Extraction
```bash
python -m json.tool pipeline_builder/DBX_Conversion/pipeline_json/{output_name}_latest.json > /dev/null
echo "✅ JSON valid"

pytest tests/test_metadata_extraction.py -v
```

### Step 4: Review Metadata
- [ ] Transforms extracted: {expected_count}
- [ ] Datasets extracted: {expected_count}
- [ ] Primary keys defined: {expected_count}
- [ ] Schema information present: Yes/No

### Step 5: Chain to Migration
```bash
# Generate PySpark code
python tools/generate_pipeline.py --input {output_name}_latest.json
```

## Troubleshooting
- If 401 error → Regenerate token (Step 1)
- If 404 error → Verify RID in config
- If timeout → Check VPN connection
- If SSL error → Enable SSL bypass (dev only)

## Rollback
Delete extracted files:
```bash
rm pipeline_builder/DBX_Conversion/pipeline_json/{output_name}_*.json
```

## Success Criteria
- [x] JSON extracted successfully
- [x] All transforms present
- [x] All datasets resolved
- [x] Primary keys captured
- [x] Validation tests pass
```

---

## API Response Size Guidelines

| Pipeline Size | Response Size | Extraction Time |
|---------------|---------------|-----------------|
| Small (1-5 transforms) | ~50 KB | < 5 seconds |
| Medium (6-20 transforms) | ~200 KB | 5-15 seconds |
| Large (21-50 transforms) | ~1 MB | 15-30 seconds |
| Very Large (50+ transforms) | > 5 MB | > 30 seconds |

**Optimization**:
- Enable compression: `Accept-Encoding: gzip`
- Filter to specific transforms if API supports it
- Extract incrementally (one pipeline at a time)

---

## References

- **Palantir Foundry Docs**: https://www.palantir.com/docs/foundry/
- **Pipeline Builder Guide**: https://www.palantir.com/docs/foundry/pipeline-builder/
- **Contour Guide**: https://www.palantir.com/docs/foundry/contour/
- **RID Format Spec**: `ri.{service}.{environment}.{type}.{uuid}`

---

**End of Document Workflow**
