---
description: Archetype for extracting metadata from Palantir Foundry APIs (Pipeline Builder, Contour)
glyphEnabled: true
glyph: constitution
---

# Metadata Extractor Archetype Constitution

## Purpose

The **metadata-extractor** archetype retrieves pipeline definitions, dataset metadata, and analysis configurations from Palantir Foundry APIs. This metadata is essential for accurate migration to Azure Databricks and Snowflake.

## Core Responsibilities

1. **API Authentication**: Manage Palantir bearer tokens via environment variables or CLI arguments
2. **Pipeline Metadata Extraction**: Fetch Pipeline Builder JSON (transforms, datasets, outputs)
3. **Contour Metadata Extraction**: Fetch Contour analysis JSON (board snapshots, filters, aggregations)
4. **RID Resolution**: Extract Resource IDentifiers (RIDs) for datasets, transforms, and outputs
5. **Version Control**: Save timestamped and latest versions of extracted metadata
6. **Error Recovery**: Handle SSL errors, token expiration, network timeouts, and API rate limits

## Workflows

### Primary Workflows

1. **scaffold**: Extract Pipeline/Contour metadata via API calls
   - Two-step fetch: sandboxes → all-information
   - Retry logic for transient failures
   - SSL bypass for corporate proxy environments

2. **test**: Validate extracted metadata completeness
   - Check required JSON sections exist
   - Validate RID formats
   - Verify dataset/output references

### Supporting Workflows

3. **compare**: Choose between Pipeline Builder vs Contour extraction
   - Pipeline Builder: Full transform code, lineage
   - Contour: Analysis logic, aggregations, filters

4. **debug**: Diagnose API failures
   - 401 Unauthorized (token issues)
   - 404 Not Found (invalid RIDs)
   - SSL certificate errors

5. **document**: Create metadata extraction runbooks
   - How to find Pipeline RIDs
   - How to generate bearer tokens
   - API endpoint reference

6. **refactor**: Improve extraction scripts
   - Consolidate retry logic
   - Add rate limiting
   - Implement caching

## Dependencies

### External APIs
- **Palantir Foundry API**: `https://paloma.palantirfoundry.com`
  - `/eddie/api/pipelines-v2` (Pipeline Builder)
  - `/contour/api/refs` (Contour)

### Configuration
- **Config File**: `.windsurf/workflows/palantir-migration-config.yaml`
- **Environment Variables**: `PALANTIR_TOKEN`

### Downstream Consumers
- **pipeline-generator**: Consumes Pipeline JSON to generate PySpark code
- **transform-converter**: Uses RIDs to resolve ADLS paths
- **data-validator**: Validates against source schema extracted from metadata

## Success Criteria

✅ **Complete Metadata**: All transforms, datasets, outputs, and primary keys extracted
✅ **Valid JSON**: No parsing errors, schema validation passes
✅ **RID Mapping**: All RIDs can be resolved to Azure ADLS paths
✅ **Audit Trail**: Timestamped versions saved for rollback
✅ **Error Handling**: Graceful retries, clear error messages

## Common Failure Modes

❌ **Token Expired**: Bearer token has 24-hour TTL (regenerate daily)
❌ **Invalid RID**: Typo in Pipeline/Contour reference ID
❌ **No Sandbox Found**: Pipeline has no published sandbox
❌ **SSL Certificate Error**: Corporate proxy requires SSL bypass
❌ **Rate Limited**: Too many API calls (implement exponential backoff)

## Integration Points

- **Input**: User provides Pipeline RID or Contour ref/node IDs
- **Output**: JSON files in `pipeline_builder/DBX_Conversion/pipeline_json/`
- **Next Step**: Chain to **pipeline-generator** or **transform-converter** archetypes

---

**Version**: 1.0.0  
**Last Updated**: 2026-02-04  
**Maintainer**: DEEP Migration Team
