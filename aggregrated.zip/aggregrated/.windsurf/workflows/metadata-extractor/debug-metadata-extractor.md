---
description: Troubleshoot metadata extraction failures
glyphEnabled: true
glyph: debug
---

User input: $ARGUMENTS

## Common Issues

## Issue 1: 401 Unauthorized

### Symptoms
```
ERROR: HTTP 401 Unauthorized
{"errorCode": "PERMISSION_DENIED", "message": "Invalid bearer token"}
```

### Root Cause
Bearer token expired or not set

### Diagnostic Steps

1. **Check environment variable**:
```bash
echo $PALANTIR_TOKEN
# Should output long JWT token starting with "eyJhbGciOi..."
```

2. **Verify token expiration**:
```bash
# Decode JWT token (first part)
echo $PALANTIR_TOKEN | cut -d'.' -f2 | base64 -d 2>/dev/null | jq

# Look for "exp" field (Unix timestamp)
# Token typically expires after 24 hours
```

3. **Test token with curl**:
```bash
curl -H "Authorization: Bearer $PALANTIR_TOKEN" \
     https://paloma.palantirfoundry.com/eddie/api/pipelines-v2 \
     -o /dev/null -w "%{http_code}\n"

# Should return 200 if token valid
```

### Resolution

**Generate new bearer token**:

1. Log into Palantir Foundry UI
2. Open Developer Console (F12)
3. Navigate to: **Application** → **Cookies** → `https://paloma.palantirfoundry.com`
4. Find cookie named `multipass`
5. Copy value (long JWT token)
6. Set environment variable:
```bash
export PALANTIR_TOKEN="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9..."
```

**Verify**:
```bash
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-id "ri.eddie.main.pipeline.xxx" \
    --dry-run
```

---

## Issue 2: 404 Not Found

### Symptoms
```
ERROR: HTTP 404 Not Found
{"errorCode": "NOT_FOUND", "message": "Pipeline not found: ri.eddie.main.pipeline.xxx"}
```

### Root Cause
Invalid or typo in Pipeline/Contour RID

### Diagnostic Steps

1. **Verify RID format**:
```python
import re

# Pipeline RID format
pipeline_rid = "ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043"
assert re.match(r'^ri\.eddie\.main\.pipeline\.[a-f0-9\-]{36}$', pipeline_rid)

# Contour Ref RID format
contour_rid = "ri.contour.main.ref.d000b16c-50b3-4790-a7d5-2ea2c2e56dee"
assert re.match(r'^ri\.contour\.main\.ref\.[a-f0-9\-]{36}$', contour_rid)
```

2. **Check config file**:
```bash
# Verify RID in config matches UI
cat .windsurf/workflows/palantir-migration-config.yaml | grep -A 2 "netaudit:"
```

3. **Find correct RID in UI**:
- Open Pipeline Builder in browser
- URL will show: `https://paloma.palantirfoundry.com/pipeline-builder/{CORRECT_RID}`
- Copy RID from URL

### Resolution

**Update config file**:
```yaml
pipelines:
  netaudit:
    rid: "ri.eddie.main.pipeline.CORRECT-RID-HERE"
```

**Verify**:
```bash
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-name netaudit \
    --list-sandboxes
```

---

## Issue 3: SSL Certificate Error

### Symptoms
```
ERROR: SSL: CERTIFICATE_VERIFY_FAILED
urllib.error.URLError: <urlopen error [SSL: CERTIFICATE_VERIFY_FAILED]>
```

### Root Cause
Corporate proxy intercepts SSL connections

### Resolution

**Edit fetch script to bypass SSL verification** (development only):

**File**: `pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py`

```python
import ssl

# Around line 75-77, add:
ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

# In urlopen call:
with urllib.request.urlopen(req, context=ssl_context, timeout=60) as response:
    ...
```

**⚠️ Security Warning**: Only use this in development. Do NOT deploy to production with SSL bypass.

---

## Issue 4: No Sandbox ID Found

### Symptoms
```
ERROR: No sandboxes found for pipeline
```

### Root Cause
Pipeline has no published sandbox, or API response format changed

### Diagnostic Steps

1. **List all sandboxes**:
```bash
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-id "ri.eddie.main.pipeline.xxx" \
    --list-sandboxes
```

**Expected output**:
```json
{
  "sandboxes": [
    {"id": "yyy", "name": "Main", "isPublished": true},
    {"id": "zzz", "name": "Dev", "isPublished": false}
  ]
}
```

2. **Check if sandbox exists in UI**:
- Open Pipeline Builder
- Look for "Sandbox" dropdown
- If no sandboxes, create and publish one

### Resolution

**Option 1: Publish sandbox in UI**:
1. Open Pipeline Builder
2. Click "Sandboxes" → "Main"
3. Click "Publish"

**Option 2: Manually specify sandbox ID**:
```bash
python pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py \
    --pipeline-id "ri.eddie.main.pipeline.xxx" \
    --sandbox-id "yyy"
```

**Option 3: Modify script to use first sandbox** (if `isPublished` field missing):

```python
# fetch_palantir_pipeline.py
sandbox_id = sandboxes_response['sandboxes'][0]['id']  # Use first sandbox
```

---

## Issue 5: Network Timeout

### Symptoms
```
ERROR: <urlopen error timed out>
TimeoutError: [Errno 110] Connection timed out
```

### Root Cause
- VPN disconnected
- Firewall blocking API access
- API endpoint slow/down

### Diagnostic Steps

1. **Check VPN connection**:
```bash
ping paloma.palantirfoundry.com
# Should resolve and respond
```

2. **Test network connectivity**:
```bash
curl -I https://paloma.palantirfoundry.com
# Should return HTTP 200
```

3. **Increase timeout**:

**File**: `pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py`

```python
# Change timeout from 60 to 300 seconds
with urllib.request.urlopen(req, context=ssl_context, timeout=300) as response:
    ...
```

### Resolution

- Connect to VPN
- Check firewall rules (allow `paloma.palantirfoundry.com`)
- Increase timeout in script
- Contact network admin if persistent

---

## Issue 6: Invalid JSON Response

### Symptoms
```
ERROR: json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)
```

### Root Cause
- API returned HTML error page instead of JSON
- Empty response

### Diagnostic Steps

1. **Capture raw response**:
```bash
curl -H "Authorization: Bearer $PALANTIR_TOKEN" \
     "https://paloma.palantirfoundry.com/eddie/api/pipelines-v2/{RID}/all-information?sandboxId={ID}" \
     -o debug_response.txt

# Check content type
file debug_response.txt
```

2. **Check for HTML error page**:
```bash
head -20 debug_response.txt
# If starts with "<!DOCTYPE html>", it's an error page
```

### Resolution

- Review HTML error page for specific error message
- Usually indicates 401/403/404 error (see Issues 1-2)
- Fix underlying authentication/permission issue

---

## Issue 7: Rate Limiting

### Symptoms
```
ERROR: HTTP 429 Too Many Requests
{"errorCode": "RATE_LIMIT_EXCEEDED", "message": "Too many requests"}
```

### Root Cause
Exceeded Palantir API rate limits

### Resolution

**Add exponential backoff** to fetch script:

```python
import time

def fetch_with_retry(url, headers, retries=5):
    """Fetch with exponential backoff."""
    for attempt in range(retries):
        try:
            response = urllib.request.urlopen(req, context=ssl_context, timeout=60)
            return json.loads(response.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 429:  # Rate limited
                wait_time = (2 ** attempt) * 5  # 5s, 10s, 20s, 40s, 80s
                print(f"⚠️  Rate limited. Waiting {wait_time}s...")
                time.sleep(wait_time)
            else:
                raise
    raise Exception("Max retries exceeded")
```

**Update config**:
```yaml
api:
  retry_attempts: 5
  retry_delay_seconds: 5
  exponential_backoff: true
```

---

## Issue 8: Missing Dataset Schema

### Symptoms
- JSON extracted successfully
- But `datasets[].schema` is `null` or missing

### Root Cause
Schema not included in API response (depends on Palantir version)

### Workaround

**Option 1: Extract schema from transform code**:
```python
# Parse transform pythonCode for column references
import re

code = transform['pythonCode']
columns = re.findall(r'col\("(\w+)"\)', code)  # Extract column names
```

**Option 2: Fetch schema from separate API**:
```bash
# Dataset schema endpoint (if available)
GET /foundry-data-proxy/api/datasets/{dataset_rid}/schema
```

**Option 3: Infer schema from ADLS files**:
```python
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
df = spark.read.parquet("abfss://raw@storage.dfs.core.windows.net/site_master")
schema = df.schema
print(schema.json())
```

---

## Debugging Checklist

- [ ] Token is valid and not expired (check with curl)
- [ ] RID format correct (Pipeline: `ri.eddie.main.pipeline.xxx`)
- [ ] VPN connected (can ping `paloma.palantirfoundry.com`)
- [ ] SSL bypass enabled if corporate proxy present
- [ ] Sandbox exists and published (or manually specified)
- [ ] Timeout sufficient (increase if slow network)
- [ ] Rate limiting handled (exponential backoff)
- [ ] Output directory writable

---

## Logging Best Practices

Add comprehensive logging to extraction scripts:

```python
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.FileHandler('metadata_extraction.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# In script:
logger.debug(f"Fetching from URL: {url}")
logger.info(f"Sandbox ID: {sandbox_id}")
logger.warning(f"No schema found for dataset: {rid}")
logger.error(f"Failed to fetch pipeline: {e}")
```

---

**End of Debug Workflow**
