---
description: Validate extracted metadata completeness and correctness
glyphEnabled: true
glyph: test
---

User input: $ARGUMENTS

## Test Suite Overview

Validates extracted Pipeline and Contour JSON files for:
- ✅ JSON syntax correctness
- ✅ Required sections present
- ✅ RID format validation
- ✅ Schema completeness
- ✅ Cross-reference integrity

---

## Test 1: JSON Syntax Validation

**Purpose**: Ensure extracted files are valid JSON

```python
import json
from pathlib import Path

def test_json_syntax(json_file: Path):
    """Validate JSON syntax."""
    try:
        with open(json_file) as f:
            data = json.load(f)
        print(f"✅ Valid JSON: {json_file}")
        return data
    except json.JSONDecodeError as e:
        print(f"❌ JSON Syntax Error in {json_file}")
        print(f"   Line {e.lineno}, Column {e.colno}: {e.msg}")
        raise

# Test all extracted files
json_dir = Path("pipeline_builder/DBX_Conversion/pipeline_json/")
for json_file in json_dir.glob("*_latest.json"):
    test_json_syntax(json_file)
```

---

## Test 2: Pipeline JSON Schema Validation

**Purpose**: Verify all required sections exist in Pipeline JSON

```python
def test_pipeline_schema(pipeline_json: dict):
    """Validate Pipeline Builder JSON structure."""
    
    # Required top-level keys
    required_keys = ['snapshot']
    for key in required_keys:
        assert key in pipeline_json, f"Missing required key: {key}"
    
    snapshot = pipeline_json['snapshot']
    
    # Required snapshot sections
    assert 'transforms' in snapshot, "Missing 'transforms' section"
    assert 'datasets' in snapshot, "Missing 'datasets' section"
    assert 'outputs' in snapshot, "Missing 'outputs' section"
    
    # Validate transforms
    for i, transform in enumerate(snapshot['transforms']):
        assert 'id' in transform, f"Transform {i}: missing 'id'"
        assert 'name' in transform, f"Transform {i}: missing 'name'"
        assert 'pythonCode' in transform or 'code' in transform, f"Transform {i}: missing code"
        assert 'inputs' in transform, f"Transform {i}: missing 'inputs'"
        assert 'outputs' in transform, f"Transform {i}: missing 'outputs'"
    
    # Validate datasets
    for i, dataset in enumerate(snapshot['datasets']):
        assert 'rid' in dataset, f"Dataset {i}: missing 'rid'"
        assert 'name' in dataset or 'path' in dataset, f"Dataset {i}: missing name/path"
    
    # Validate outputs
    for i, output in enumerate(snapshot['outputs']):
        assert 'datasetRid' in output, f"Output {i}: missing 'datasetRid'"
        # Primary key is optional but should be list if present
        if 'primaryKey' in output:
            assert isinstance(output['primaryKey'], list), f"Output {i}: primaryKey must be list"
    
    print(f"✅ Pipeline schema valid")
    print(f"   - {len(snapshot['transforms'])} transforms")
    print(f"   - {len(snapshot['datasets'])} datasets")
    print(f"   - {len(snapshot['outputs'])} outputs")

# Test
with open("pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json") as f:
    pipeline_data = json.load(f)
test_pipeline_schema(pipeline_data)
```

---

## Test 3: Contour JSON Schema Validation

**Purpose**: Verify all required sections exist in Contour JSON

```python
def test_contour_schema(contour_json: dict):
    """Validate Contour JSON structure."""
    
    # Required top-level keys
    assert 'snapshots' in contour_json, "Missing 'snapshots' section"
    
    snapshots = contour_json['snapshots']
    assert len(snapshots) > 0, "No snapshots found"
    
    # Validate each snapshot
    for i, snapshot in enumerate(snapshots):
        assert 'id' in snapshot, f"Snapshot {i}: missing 'id'"
        assert 'boardType' in snapshot, f"Snapshot {i}: missing 'boardType'"
        
        # Validate board type
        valid_types = ['starting', 'expression', 'custom', 'table']
        assert snapshot['boardType'] in valid_types, \
            f"Snapshot {i}: invalid boardType '{snapshot['boardType']}'"
        
        # Starting board must have startingSetDescription
        if snapshot['boardType'] == 'starting':
            assert 'boardState' in snapshot, f"Snapshot {i}: missing 'boardState'"
            assert 'startingSetDescription' in snapshot['boardState'], \
                f"Snapshot {i}: missing 'startingSetDescription'"
            
            starting_set = snapshot['boardState']['startingSetDescription']
            assert 'identifier' in starting_set, \
                f"Snapshot {i}: missing dataset identifier"
    
    print(f"✅ Contour schema valid")
    print(f"   - {len(snapshots)} snapshots")

# Test
with open("pipeline_builder/DBX_Conversion/jsonexports/contour_latest.json") as f:
    contour_data = json.load(f)
test_contour_schema(contour_data)
```

---

## Test 4: RID Format Validation

**Purpose**: Validate all RIDs follow Palantir format

```python
import re

def test_rid_format(rid: str, rid_type: str = 'dataset') -> bool:
    """Validate RID format."""
    
    patterns = {
        'dataset': r'^ri\.foundry\.main\.dataset\.[a-f0-9\-]+$',
        'pipeline': r'^ri\.eddie\.main\.pipeline\.[a-f0-9\-]+$',
        'contour_ref': r'^ri\.contour\.main\.ref\.[a-f0-9\-]+$',
        'transform': r'^[a-zA-Z0-9_\-]+$'  # Looser for transform IDs
    }
    
    pattern = patterns.get(rid_type)
    if not pattern:
        raise ValueError(f"Unknown RID type: {rid_type}")
    
    if not re.match(pattern, rid):
        print(f"❌ Invalid {rid_type} RID: {rid}")
        return False
    
    return True

def test_all_rids(pipeline_json: dict):
    """Validate all RIDs in Pipeline JSON."""
    
    snapshot = pipeline_json['snapshot']
    
    # Test dataset RIDs
    for dataset in snapshot.get('datasets', []):
        rid = dataset.get('rid')
        assert test_rid_format(rid, 'dataset'), f"Invalid dataset RID: {rid}"
    
    # Test output RIDs
    for output in snapshot.get('outputs', []):
        rid = output.get('datasetRid')
        assert test_rid_format(rid, 'dataset'), f"Invalid output RID: {rid}"
    
    # Test transform input/output RIDs
    for transform in snapshot.get('transforms', []):
        for input_rid in transform.get('inputs', []):
            assert test_rid_format(input_rid, 'dataset'), f"Invalid input RID: {input_rid}"
        for output_rid in transform.get('outputs', []):
            assert test_rid_format(output_rid, 'dataset'), f"Invalid output RID: {output_rid}"
    
    print(f"✅ All RIDs valid")

# Test
with open("pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json") as f:
    pipeline_data = json.load(f)
test_all_rids(pipeline_data)
```

---

## Test 5: Cross-Reference Integrity

**Purpose**: Ensure all referenced RIDs exist in datasets

```python
def test_cross_references(pipeline_json: dict):
    """Validate all referenced RIDs exist."""
    
    snapshot = pipeline_json['snapshot']
    
    # Collect all dataset RIDs
    dataset_rids = {ds['rid'] for ds in snapshot.get('datasets', [])}
    print(f"📋 Found {len(dataset_rids)} unique datasets")
    
    # Collect all referenced RIDs
    referenced_rids = set()
    
    for transform in snapshot.get('transforms', []):
        referenced_rids.update(transform.get('inputs', []))
        referenced_rids.update(transform.get('outputs', []))
    
    for output in snapshot.get('outputs', []):
        referenced_rids.add(output.get('datasetRid'))
    
    print(f"🔗 Found {len(referenced_rids)} referenced datasets")
    
    # Find missing RIDs
    missing_rids = referenced_rids - dataset_rids
    
    if missing_rids:
        print(f"❌ Missing dataset definitions:")
        for rid in missing_rids:
            print(f"   - {rid}")
        raise AssertionError(f"{len(missing_rids)} referenced datasets missing definitions")
    
    print(f"✅ All referenced datasets have definitions")

# Test
with open("pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json") as f:
    pipeline_data = json.load(f)
test_cross_references(pipeline_data)
```

---

## Test 6: Primary Key Validation

**Purpose**: Verify primary keys are defined for all outputs

```python
def test_primary_keys(pipeline_json: dict):
    """Validate primary keys are defined."""
    
    snapshot = pipeline_json['snapshot']
    outputs = snapshot.get('outputs', [])
    
    missing_pk = []
    
    for output in outputs:
        rid = output.get('datasetRid')
        primary_key = output.get('primaryKey', [])
        
        if not primary_key:
            missing_pk.append(rid)
        else:
            print(f"✅ {rid}: PK = {primary_key}")
    
    if missing_pk:
        print(f"⚠️  Warning: {len(missing_pk)} outputs missing primary keys:")
        for rid in missing_pk:
            print(f"   - {rid}")
    else:
        print(f"✅ All {len(outputs)} outputs have primary keys")

# Test
with open("pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json") as f:
    pipeline_data = json.load(f)
test_primary_keys(pipeline_data)
```

---

## Test 7: Schema Completeness

**Purpose**: Check if dataset schemas are included

```python
def test_schema_completeness(pipeline_json: dict):
    """Check for dataset schema information."""
    
    snapshot = pipeline_json['snapshot']
    datasets = snapshot.get('datasets', [])
    
    with_schema = 0
    without_schema = 0
    
    for dataset in datasets:
        rid = dataset.get('rid')
        schema = dataset.get('schema') or dataset.get('columns')
        
        if schema:
            with_schema += 1
            print(f"✅ {rid}: {len(schema)} columns")
        else:
            without_schema += 1
            print(f"⚠️  {rid}: No schema")
    
    print(f"\nSchema Coverage: {with_schema}/{len(datasets)} datasets")
    
    if without_schema > 0:
        print(f"⚠️  Warning: {without_schema} datasets missing schema information")

# Test
with open("pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json") as f:
    pipeline_data = json.load(f)
test_schema_completeness(pipeline_data)
```

---

## Pytest Test Suite

**File**: `tests/test_metadata_extraction.py`

```python
"""Pytest test suite for metadata extraction."""

import pytest
import json
from pathlib import Path

@pytest.fixture
def pipeline_json():
    """Load pipeline JSON fixture."""
    with open("pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json") as f:
        return json.load(f)

@pytest.fixture
def contour_json():
    """Load contour JSON fixture."""
    with open("pipeline_builder/DBX_Conversion/jsonexports/contour_latest.json") as f:
        return json.load(f)

def test_pipeline_has_snapshot(pipeline_json):
    """Test pipeline has snapshot section."""
    assert 'snapshot' in pipeline_json

def test_pipeline_has_transforms(pipeline_json):
    """Test pipeline has transforms."""
    assert len(pipeline_json['snapshot']['transforms']) > 0

def test_all_transforms_have_code(pipeline_json):
    """Test all transforms have Python code."""
    for transform in pipeline_json['snapshot']['transforms']:
        assert 'pythonCode' in transform or 'code' in transform

def test_all_outputs_have_dataset_rid(pipeline_json):
    """Test all outputs have datasetRid."""
    for output in pipeline_json['snapshot']['outputs']:
        assert 'datasetRid' in output
        assert output['datasetRid'].startswith('ri.foundry.main.dataset.')

def test_contour_has_snapshots(contour_json):
    """Test contour has snapshots."""
    assert 'snapshots' in contour_json
    assert len(contour_json['snapshots']) > 0

def test_contour_starting_board_has_dataset(contour_json):
    """Test starting board references a dataset."""
    starting_boards = [
        s for s in contour_json['snapshots']
        if s['boardType'] == 'starting'
    ]
    
    if starting_boards:
        board = starting_boards[0]
        assert 'boardState' in board
        assert 'startingSetDescription' in board['boardState']
        assert 'identifier' in board['boardState']['startingSetDescription']
```

**Run tests**:
```bash
pytest tests/test_metadata_extraction.py -v
```

---

## Validation Report

Generate a validation report after extraction:

```python
def generate_validation_report(pipeline_json: dict, output_file: str = "metadata_validation_report.txt"):
    """Generate validation report."""
    
    snapshot = pipeline_json['snapshot']
    
    report = []
    report.append("=" * 80)
    report.append("Metadata Extraction Validation Report")
    report.append("=" * 80)
    report.append("")
    
    # Summary
    report.append("Summary:")
    report.append(f"  Transforms: {len(snapshot.get('transforms', []))}")
    report.append(f"  Datasets: {len(snapshot.get('datasets', []))}")
    report.append(f"  Outputs: {len(snapshot.get('outputs', []))}")
    report.append("")
    
    # Transform details
    report.append("Transforms:")
    for t in snapshot.get('transforms', []):
        code_lines = len(t.get('pythonCode', '').split('\n'))
        report.append(f"  - {t['name']}: {code_lines} lines of code")
    report.append("")
    
    # Primary keys
    report.append("Primary Keys:")
    for out in snapshot.get('outputs', []):
        pk = out.get('primaryKey', [])
        report.append(f"  - {out['datasetRid']}: {pk or 'NOT DEFINED'}")
    report.append("")
    
    # Save report
    with open(output_file, 'w') as f:
        f.write('\n'.join(report))
    
    print(f"✅ Validation report saved: {output_file}")

# Generate report
with open("pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json") as f:
    pipeline_data = json.load(f)
generate_validation_report(pipeline_data)
```

---

## Checklist

- [ ] JSON syntax is valid
- [ ] All required sections present (snapshot, transforms, datasets, outputs)
- [ ] All RIDs follow correct format
- [ ] All referenced RIDs have dataset definitions
- [ ] Primary keys defined for all outputs (or documented as missing)
- [ ] Schema information included (or documented as missing)
- [ ] Pytest test suite passes

---

**End of Test Workflow**
