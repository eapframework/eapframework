---
description: Extract pipeline and analysis metadata from Palantir Foundry APIs
glyphEnabled: true
glyph: scaffold
---

User input: $ARGUMENTS

## Parse Input

Extract from $ARGUMENTS:
- **metadata_type**: "pipeline" or "contour"
- **identifier**: Pipeline RID or pipeline_name (from config) OR Contour ref_rid + node_id
- **output_name**: Optional custom name for output file (default: extracted from identifier)
- **environment**: "prod" or "dev" (default: from config `default_environment`)

**Examples**:
```
Extract Pipeline Builder metadata for netaudit
Extract Contour metadata ref: ri.contour.main.ref.xxx node: yyy-zzz
Extract Pipeline ri.eddie.main.pipeline.xxx as "site_master"
```

---

## Prerequisites Validation

### 1. Check Configuration File

**File**: `.windsurf/workflows/palantir-migration-config.yaml`

```python
import yaml
from pathlib import Path

config_path = Path(".windsurf/workflows/palantir-migration-config.yaml")
if not config_path.exists():
    raise FileNotFoundError(f"Config file not found: {config_path}")

with open(config_path) as f:
    config = yaml.safe_load(f)

# Validate required sections
required_keys = ['api', 'auth', 'output']
for key in required_keys:
    if key not in config:
        raise ValueError(f"Missing required config section: {key}")
```

### 2. Validate Authentication

```python
import os

# Check for bearer token
token_env_var = config['auth'].get('token_env_var', 'PALANTIR_TOKEN')
token = os.getenv(token_env_var)

if not token:
    print(f"❌ Error: {token_env_var} environment variable not set")
    print("\nTo fix:")
    print("  1. Log into Palantir Foundry")
    print("  2. Open Developer Console (F12) → Application → Cookies")
    print("  3. Copy 'multipass' cookie value")
    print(f"  4. Run: export {token_env_var}='<token_value>'")
    raise ValueError("Authentication token not found")

print(f"✅ Authentication token found ({len(token)} chars)")
```

### 3. Validate Output Directory

```python
from pathlib import Path

output_dir = Path(config['output']['json_dir'])
output_dir.mkdir(parents=True, exist_ok=True)
print(f"✅ Output directory: {output_dir}")
```

---

## Metadata Extraction: Pipeline Builder

### Step 1: Resolve Pipeline RID

```python
# Option 1: From config by name
if args.pipeline_name in config.get('pipelines', {}):
    pipeline_rid = config['pipelines'][args.pipeline_name]['rid']
    print(f"📋 Resolved pipeline '{args.pipeline_name}' → {pipeline_rid}")

# Option 2: Direct RID provided
elif args.pipeline_rid:
    pipeline_rid = args.pipeline_rid
    print(f"📋 Using pipeline RID: {pipeline_rid}")

else:
    raise ValueError("Must provide --pipeline-name OR --pipeline-rid")

# Validate RID format
if not pipeline_rid.startswith('ri.eddie.main.pipeline.'):
    print(f"⚠️  Warning: RID format unexpected: {pipeline_rid}")
```

### Step 2: Fetch Sandboxes

**API Endpoint**: `GET /eddie/api/pipelines-v2/{pipeline_rid}/sandboxes/get/all`

```python
import urllib.request
import json
import ssl
from typing import Dict, Any

def fetch_with_retry(url: str, headers: Dict, retries: int = 3, delay: int = 5) -> Any:
    """Fetch with exponential backoff retry."""
    import time
    
    # SSL bypass for corporate proxy
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, context=ssl_context, timeout=60) as response:
                return json.loads(response.read().decode())
        except Exception as e:
            if attempt < retries - 1:
                wait_time = delay * (2 ** attempt)  # Exponential backoff
                print(f"⚠️  Attempt {attempt + 1} failed: {e}. Retrying in {wait_time}s...")
                time.sleep(wait_time)
            else:
                raise

# Configuration
base_url = config['api']['base_url']
pipeline_path = config['api']['pipeline_path']
token = os.getenv(config['auth']['token_env_var'])

# Fetch sandboxes
sandboxes_url = f"{base_url}{pipeline_path}/{pipeline_rid}/sandboxes/get/all"
headers = {
    'Authorization': f'Bearer {token}',
    'Accept': 'application/json'
}

print(f"🔍 Fetching sandboxes from: {sandboxes_url}")
sandboxes_response = fetch_with_retry(sandboxes_url, headers)

# Extract sandbox ID (prefer published sandbox)
sandbox_id = None
for sandbox in sandboxes_response.get('sandboxes', []):
    if sandbox.get('isPublished', False):
        sandbox_id = sandbox['id']
        print(f"✅ Found published sandbox: {sandbox_id} ({sandbox.get('name', 'Unknown')})")
        break

if not sandbox_id and sandboxes_response.get('sandboxes'):
    # Use first sandbox if no published sandbox
    sandbox_id = sandboxes_response['sandboxes'][0]['id']
    print(f"⚠️  No published sandbox. Using: {sandbox_id}")

if not sandbox_id:
    raise ValueError("No sandboxes found for pipeline")
```

### Step 3: Fetch All Information

**API Endpoint**: `GET /eddie/api/pipelines-v2/{pipeline_rid}/all-information?sandboxId={sandbox_id}`

```python
# Fetch complete pipeline definition
all_info_url = f"{base_url}{pipeline_path}/{pipeline_rid}/all-information?sandboxId={sandbox_id}"
print(f"🔍 Fetching pipeline information from: {all_info_url}")

pipeline_data = fetch_with_retry(all_info_url, headers)

# Validate response
required_sections = ['snapshot']
for section in required_sections:
    if section not in pipeline_data:
        raise ValueError(f"Missing required section in response: {section}")

print(f"✅ Pipeline data fetched successfully")
print(f"   - Transforms: {len(pipeline_data['snapshot'].get('transforms', []))}")
print(f"   - Datasets: {len(pipeline_data['snapshot'].get('datasets', []))}")
print(f"   - Outputs: {len(pipeline_data['snapshot'].get('outputs', []))}")
```

### Step 4: Save Pipeline JSON

```python
from datetime import datetime

# Generate output filenames
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_name = args.output_name or args.pipeline_name or "pipeline"

versioned_file = output_dir / f"{output_name}_{timestamp}.json"
latest_file = output_dir / f"{output_name}_latest.json"

# Save versioned copy
with open(versioned_file, 'w') as f:
    json.dump(pipeline_data, f, indent=2)
print(f"✅ Saved: {versioned_file}")

# Save latest copy
with open(latest_file, 'w') as f:
    json.dump(pipeline_data, f, indent=2)
print(f"✅ Saved: {latest_file}")

# Extract and save metadata summary
metadata = {
    'pipeline_rid': pipeline_rid,
    'sandbox_id': sandbox_id,
    'extracted_at': datetime.now().isoformat(),
    'transform_count': len(pipeline_data['snapshot'].get('transforms', [])),
    'dataset_rids': [ds['rid'] for ds in pipeline_data['snapshot'].get('datasets', [])],
    'output_rids': [out['datasetRid'] for out in pipeline_data['snapshot'].get('outputs', [])],
    'primary_keys': {
        out['datasetRid']: out.get('primaryKey', [])
        for out in pipeline_data['snapshot'].get('outputs', [])
    }
}

metadata_file = output_dir / f"{output_name}_metadata.json"
with open(metadata_file, 'w') as f:
    json.dump(metadata, f, indent=2)
print(f"✅ Saved metadata: {metadata_file}")
```

---

## Metadata Extraction: Contour

### Step 1: Resolve Ref RID and Node ID

```python
# From arguments or config defaults
ref_rid = args.ref_rid or config.get('contour', {}).get('default_ref_rid')
node_id = args.node_id or config.get('contour', {}).get('default_node_id')

if not ref_rid or not node_id:
    raise ValueError("Must provide --ref-rid and --node-id for Contour extraction")

# Validate RID format
if not ref_rid.startswith('ri.contour.main.ref.'):
    print(f"⚠️  Warning: Ref RID format unexpected: {ref_rid}")

print(f"📊 Contour Ref: {ref_rid}")
print(f"📊 Node ID: {node_id}")
```

### Step 2: Fetch Contour Board

**API Endpoint**: `GET /contour/api/refs/{ref_rid}/nodes/{node_id}/board`

```python
contour_path = config['api']['contour_path']
contour_url = f"{base_url}{contour_path}/{ref_rid}/nodes/{node_id}/board"

headers = {
    'Authorization': f'Bearer {token}',
    'Accept': 'application/json'
}

print(f"🔍 Fetching Contour board from: {contour_url}")
contour_data = fetch_with_retry(contour_url, headers)

# Validate response
if 'snapshots' not in contour_data:
    raise ValueError("Missing 'snapshots' section in Contour response")

print(f"✅ Contour data fetched successfully")
print(f"   - Snapshots: {len(contour_data.get('snapshots', []))}")
```

### Step 3: Save Contour JSON

```python
from datetime import datetime

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_name = args.output_name or "contour"

# Use jsonexports directory for Contour
contour_dir = Path("pipeline_builder/DBX_Conversion/jsonexports/")
contour_dir.mkdir(parents=True, exist_ok=True)

versioned_file = contour_dir / f"{output_name}_{timestamp}.json"
latest_file = contour_dir / f"{output_name}_latest.json"

# Save versioned copy
with open(versioned_file, 'w') as f:
    json.dump(contour_data, f, indent=2)
print(f"✅ Saved: {versioned_file}")

# Save latest copy
with open(latest_file, 'w') as f:
    json.dump(contour_data, f, indent=2)
print(f"✅ Saved: {latest_file}")
```

---

## CLI Script Template

**File**: `tools/extract_metadata.py`

```python
#!/usr/bin/env python3
"""Extract metadata from Palantir Foundry APIs."""

import argparse
import os
import sys
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Extract Palantir metadata")
    parser.add_argument('--type', choices=['pipeline', 'contour'], required=True)
    
    # Pipeline arguments
    parser.add_argument('--pipeline-name', help='Pipeline name from config')
    parser.add_argument('--pipeline-rid', help='Pipeline RID')
    parser.add_argument('--sandbox-id', help='Specific sandbox ID')
    
    # Contour arguments
    parser.add_argument('--ref-rid', help='Contour reference RID')
    parser.add_argument('--node-id', help='Contour node ID')
    
    # Common arguments
    parser.add_argument('--output-name', help='Custom output filename')
    parser.add_argument('--config', default='.windsurf/workflows/palantir-migration-config.yaml')
    parser.add_argument('--dry-run', action='store_true', help='Show URLs without fetching')
    
    args = parser.parse_args()
    
    # Load config and execute extraction
    # ... (implementation from steps above)

if __name__ == '__main__':
    main()
```

---

## Execution Examples

```bash
# Pipeline Builder extraction
python tools/extract_metadata.py \
    --type pipeline \
    --pipeline-name netaudit

# Contour extraction
python tools/extract_metadata.py \
    --type contour \
    --ref-rid "ri.contour.main.ref.xxx" \
    --node-id "yyy-zzz" \
    --output-name "site_analysis"

# Dry run (show URLs only)
python tools/extract_metadata.py \
    --type pipeline \
    --pipeline-rid "ri.eddie.main.pipeline.xxx" \
    --dry-run
```

---

## Output Validation

After extraction, validate the JSON files:

```bash
# Check JSON syntax
python -m json.tool pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json > /dev/null
echo "✅ JSON is valid"

# Check required sections
python -c "
import json
with open('pipeline_builder/DBX_Conversion/pipeline_json/netaudit_latest.json') as f:
    data = json.load(f)
    
required = ['snapshot']
for key in required:
    assert key in data, f'Missing key: {key}'
    
print('✅ All required sections present')
"
```

---

## Next Steps

Chain to downstream archetypes:

1. **pipeline-generator**: Generate PySpark code from Pipeline JSON
   ```
   /scaffold-pipeline-generator Generate PySpark from netaudit_latest.json
   ```

2. **transform-converter**: Convert individual transforms
   ```
   /scaffold-transform-converter Convert transform CleanSiteData from pipeline JSON
   ```

3. **data-validator**: Validate migrated data against source schema
   ```
   /scaffold-data-validator Validate using schema from netaudit_latest.json
   ```

---

**End of Scaffold Workflow**
