---
description: Run Palantir→Databricks migration for OTIS datasets - Complete end-to-end automation
---

# Migrate OTIS Datasets

**One-command migration**: Fetch Palantir transforms, convert to Databricks notebooks, upload to workspace.

## What This Does

1. ✅ Loads manifest configuration
2. ✅ Connects to Palantir and fetches transform code
3. ✅ Converts transforms to Databricks PySpark notebooks
4. ✅ Uploads notebooks to Databricks workspace
5. ✅ Generates migration log

## Configuration

All datasets defined in:

```
.windsurf/workflows/palantir-migration-manifest.yaml
```

Currently enabled:
- `x_site_general_info` (merge key: usid)
- `X_ERIC_5GNR_CELL_RRH` (merge key: cell_id, rrh_id)

## Execution

Run the migration script with venv Python:

```powershell
h:\DEEP\apm0047153-deep-otis\venv\Scripts\python.exe scripts\otis_demo.py
```

## Expected Output

```
🚀 PALANTIR → DATABRICKS MIGRATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚙️  Loading configuration...
   ✓ Manifest loaded
   ✓ Output directory: scripts/output/demo

📡 Connecting to Palantir...
   ✓ Connected

DATASET 1/2: x_site_general_info
   ✓ Transform code fetched
   ✓ Notebook generated
   ✓ Uploaded to Databricks

DATASET 2/2: X_ERIC_5GNR_CELL_RRH
   ✓ Transform code fetched
   ✓ Notebook generated
   ✓ Uploaded to Databricks

✅ MIGRATION COMPLETED
   • 2 datasets processed
   • 2 notebooks generated
   • Location: /Shared/deep-blueprint-test/
```

## Output Files

Generated in: `scripts/output/demo/`

- `x_site_general_info_databricks.py` - Python source
- `x_site_general_info_databricks.ipynb` - Jupyter notebook
- `X_ERIC_5GNR_CELL_RRH_databricks.py` - Python source
- `X_ERIC_5GNR_CELL_RRH_databricks.ipynb` - Jupyter notebook
- `migration.log` - Detailed execution log

## Databricks Location

Notebooks uploaded to:
```
/Shared/deep-blueprint-test/
```

View in browser:
- https://adb-3138568880081167.7.azuredatabricks.net#notebook/Shared/deep-blueprint-test/x_site_general_info_databricks
- https://adb-3138568880081167.7.azuredatabricks.net#notebook/Shared/deep-blueprint-test/X_ERIC_5GNR_CELL_RRH_databricks

## Adding More Datasets

Edit `.windsurf/workflows/palantir-migration-manifest.yaml` and add:

```yaml
datasets:
  - name: "your_dataset_name"
    dataset_rid: "ri.foundry.main.dataset.YOUR-RID"
    transform_rid: "ri.foundry.main.dataset.YOUR-TRANSFORM-RID"
    enabled: true
    merge_key: "your_key"
```

Then run `/migrate-otis` again.

## Troubleshooting

**Issue**: Upload fails with SSL error  
**Solution**: Corporate proxy blocking - use API upload workaround (already implemented)

**Issue**: Transform code not found  
**Solution**: Check transform_rid in manifest or use local transform file

**Issue**: Databricks connection fails  
**Solution**: Verify credentials in `.env` file (DATABRICKS_TOKEN, DATABRICKS_URL)

## Technical Details

- **Palantir Connection**: Uses FOUNDRY_TOKEN from .env
- **Databricks Connection**: Uses DATABRICKS_TOKEN from .env
- **Transform Conversion**: Automatic Palantir→PySpark syntax conversion
- **Upload Method**: Direct API calls (bypasses CLI SSL issues)
