description: Migrate Palantir Pipeline JSON export to PySpark Databricks notebook
User input: $ARGUMENTS

Configuration
Config File: .windsurf/workflows/palantir-migration-config.yaml

Load settings from config:

storage:
  prod:
    account: "datalakeeastus2prd"
    container: "otis-poc"
    base_path: "abfss://otis-poc@datalakeeastus2prd.dfs.core.windows.net"

input_tables:
  x_ndr_nokia_lcell_rrh: "x_ndr_nokia_lcell_rrh"
  x_ndr_nokia_enb: "x_ndr_nokia_enb"
  # ... more tables

guardrails:
  hard_stops: ["dbutils.fs.ls", "hardcoded_credentials", "delta_overwrite"]
  auto_fix:
    duplicate_columns: true
Prerequisites
Option A: Fetch JSON via API (recommended) Run /fetch-palantir-pipeline-json first to download the pipeline definition:

/fetch-palantir-pipeline-json Fetch pipeline: ri.eddie.main.pipeline.19f85d48-afd4-44f7-xxxx
Output: pipeline_builder/DBX_Conversion/pipeline_json/{name}_latest.json

Option B: Manual JSON Export Export JSON manually from Palantir Pipeline Builder UI and place in workspace.

Execution Steps
1. Parse Input
Extract from $ARGUMENTS: - json_file: Path to pipeline JSON (e.g., netaudit_latest.json) - environment: prod or dev (loads storage config from YAML) - output_folder: Override default output folder (optional)

Request clarification if json_file is missing.

2. Load Configuration
import yaml
with open(".windsurf/workflows/palantir-migration-config.yaml") as f:
    config = yaml.safe_load(f)

env = config["storage"][environment]
storage_account = env["account"]
container = env["container"]
input_tables = config["input_tables"]
guardrails = config["guardrails"]
3. Load JSON Pipeline Definition
Read Palantir pipeline JSON export file
Parse sandboxSnapshotWithVersion.snapshot for transforms, datasets, outputs
4. Extract from JSON Structure
JSON Path	Extract
snapshot.transforms[].arguments[].primitive.dataset.rid	Input dataset RIDs (NOT from datasets array)
snapshot.transforms[].outputDef.object	Output names, primary keys, properties (columns)
snapshot.transforms[]	Transform logic: select, join, filter, cast, dropDuplicates
Critical: Input datasets are discovered from transform arguments, not the datasets array. Use RID resolver to map RIDs to actual dataset names.

Transform Types to Parse:
Transform Type	PySpark Equivalent
selectColumns	df.select([...])
complexLeftJoin	df.join(df2, condition, "left")
dropDuplicates	df.dropDuplicates([key])
applyExpression	df.withColumn(name, expr)
filter	df.filter(condition)
aggregate	df.agg(F.max(...))
4. Validate Constraints
Check against guardrails.hard_stops from config: - ✘ Refuse dbutils.fs.ls() for folder discovery (permission errors) - ✘ Refuse hardcoded credentials or connection strings - ✘ Refuse Delta format writes to existing Delta folders - ✘ Refuse joins without duplicate column handling - ✘ Refuse case-mismatched column references (JSON uses exact case) - ✘ Refuse VOID data types in Parquet output If violated, explain clearly and suggest compliant alternative.

4a. Dataset Mapping & Alias Strategy
Critical: Discovered dataset names often differ from transform references. Implement comprehensive alias mapping:

# Build INPUT_TABLES from discovered datasets
INPUT_TABLES = {}
for ds in discovered.get("datasets", []):
    name = ds["name"]
    folder = fuzzy_match_to_folder(name, adls_folders, FUZZY_THRESHOLD)
    key = name.lower().replace(".", "_")
    INPUT_TABLES[key] = folder

# Add comprehensive alias mappings for commonly referenced datasets
for ds in discovered.get("datasets", []):
    name = ds["name"]
    folder = fuzzy_match_to_folder(name, adls_folders, FUZZY_THRESHOLD)
    name_lower = name.lower()
    
    # Site master mappings
    if "site" in name_lower and "master" in name_lower:
        INPUT_TABLES["levo_site_master_brd"] = folder
    
    # Ericsson LTE NRCellDU mappings
    if "ericssonlte" in name_lower and "nrcell" in name_lower:
        INPUT_TABLES["ericssonlte_nrcelldu"] = folder
    
    # Nokia mappings
    if "nokia" in name_lower:
        INPUT_TABLES["nokialte_nrcell"] = folder
    
    # FIPS mappings (use known Azure folder if not discovered)
    if "fips" in name_lower or "pea" in name_lower or "cma" in name_lower:
        INPUT_TABLES["fips_peas_cmas_table1"] = folder
    else:
        INPUT_TABLES["fips_peas_cmas_table1"] = "FIPS_PEAs_CMAs_Table1"  # Fallback

# Ensure all expected keys exist
expected_keys = ["ericssonlte_nrcelldu", "nokialte_nrcell", "fips_peas_cmas_table1", "levo_site_master_brd"]
for key in expected_keys:
    if key not in INPUT_TABLES:
        INPUT_TABLES[key] = ""
5. Generate PySpark Notebook
Create Databricks notebook with structure: - Cell 1: Configuration (storage account, container, output folder, input table mappings) - Cell 2: Helper functions - Cell 3: Load all input tables + initialize empty output DataFrames - Cell 4-N: Transformations (one cell per output) - Cell N+1: Write outputs as Parquet - Cell N+2: Validation summary

Required helper functions:

safe_select(df, columns)         # Select only existing columns
drop_duplicate_columns(df)       # Rename duplicates with _dup suffix after joins
cast_to_string(df, col_name)     # Cast column to string
construct_geo_point(df, lat, lon) # Build geo point struct from lat/lon (VOID-safe)
load_table(name)                  # Load input table from ADLS with error handling
Apply mandatory patterns: - Direct parquet reads using abfss:// paths - drop_duplicate_columns() after every join - Column prefixing instead of dropping to preserve data lineage - Rename conflicting columns before join to avoid ambiguity - Write Parquet with overwrite mode - Delete existing output folder before write - Initialize all output DataFrames at start to prevent NameError - Drop construct_geo_point before Parquet write (VOID type not supported)

6. Conversion Patterns
JSON Transform	PySpark
selectColumns: ["A", "B"]	safe_select(df, ["A", "B"])
applyExpression: cast(X, int, string)	df.withColumn("X", F.col("X").cast(IntegerType()).cast(StringType()))
applyExpression: construct_geo_point	df.withColumn("geo", F.struct(F.col("lon"), F.col("lat")))
applyExpression: uuid()	df.withColumn("uuid", F.expr("uuid()"))
complexLeftJoin	df.join(df2, df["A"] == df2["B"], "left") then drop_duplicate_columns()
dropDuplicates: [KEY]	df.dropDuplicates(["KEY"])
filter: col > 0	df.filter(F.col("col") > 0)
aggregate: max(loaddate_)	df.agg(F.max("loaddate_")).collect()[0][0]
6a. Dynamic Column Detection for Joins
Critical: Column names may differ between expected and actual. Implement dynamic detection:

# Dynamic FIPS join with column detection
fips_table = inputs["fips_peas_cmas_table1"]
if fips_table.count() > 0:
    logger.info(f"FIPS table columns: {fips_table.columns}")
    logger.info(f"df_nr_erc columns: {df_nr_erc.columns}")
    
    # Find FIPS columns dynamically
    fips_col = next((col for col in fips_table.columns if "fips" in col.lower()), None)
    df_fips_col = next((col for col in df_nr_erc.columns if "fips" in col.lower()), None)
    
    if fips_col and df_fips_col:
        # Add prefix to avoid conflicts
        fips_pea = fips_table.withColumn(fips_col, F.col(fips_col).cast(StringType()))
        for col in fips_pea.columns:
            if col != fips_col:
                fips_pea = fips_pea.withColumnRenamed(col, f"fips_{col}")
        
        df_nr_erc = df_nr_erc.join(
            fips_pea,
            df_nr_erc[df_fips_col] == fips_pea[fips_col],
            "left"
        ).drop(fips_pea[fips_col])
7. Column Case Handling
Critical: Palantir JSON preserves exact column case. When joining tables: 1. Check actual column case in source parquet files 2. Use uppercase for columns from source tables (e.g., ENBNAME, FIPS, CMA) 3. Rename conflicting columns before join:

enb_cols = enb_cols.withColumnRenamed("PULLDATE", "enb_pulldate")
8. Validate and Report
Report completion with: - Generated notebook path - Input tables summary (count per table) - Output summary (name, row count, column count) - Applied guardrails - Testing commands

Error Handling
Permission Errors: Use dual-path reading (workspace + DBFS), never dbutils.fs.ls().

def read_json_file(json_path: str) -> dict:
    try:
        with open(json_path) as f:
            return json.load(f)
    except FileNotFoundError:
        pass
    
    # Try dbutils for Databricks workspace files
    try:
        if json_path.startswith("/Workspace"):
            content = dbutils.fs.head(json_path.replace("/Workspace", "dbfs:/Workspace"), 10000000)
            return json.loads(content)
        elif json_path.startswith("/dbfs/"):
            content = dbutils.fs.head(json_path, 10000000)
            return json.loads(content)
    except Exception as e:
        logger.warning(f"dbutils read failed for {json_path}: {e}")
    
    return None
Ambiguous Columns: Apply column prefixing instead of dropping to preserve data lineage.

Case Sensitivity: Use dynamic column detection with case-insensitive matching.

Delta Conflict: Write to new folder or delete existing folder before write.

Missing Inputs: Create empty DataFrame, log warning, continue processing.

NameError on Outputs: Initialize all output DataFrames to empty at start of Cell 3.

Parquet VOID Type Error: Drop construct_geo_point columns before writing:

# Drop problematic construct_geo_point column before writing to Parquet
if "construct_geo_point" in df.columns:
    df = df.drop("construct_geo_point")
    logger.info(f"Dropped construct_geo_point column from {name}")
Incomplete Input: List missing information, provide example invocation.

Examples
End-to-End Flow (Fetch + Migrate):

# Step 1: Fetch JSON
/fetch-palantir-pipeline-json Fetch NetAudit: ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043

# Step 2: Migrate to PySpark
/migrate--palantir-json-to-pyspark Migrate netaudit_latest.json, storage: datalakeeastus2prd, container: otis-poc
Basic Migration (JSON already exists):

/migrate--palantir-json-to-pyspark Migrate palantir_pipeline_1.json to PySpark, storage: datalakeeastus2prd, container: otis-poc
Custom Output Folder:

/migrate--palantir-json-to-pyspark Migrate netaudit.json, output folder: netaudit_outputs_v2
Production Validation Checklist
[ ] All expression boards translated
[ ] RID resolution successful or fallback documented
[ ] Sort columns present in DataFrame
[ ] Output path configured correctly
[ ] No Palantir-specific imports
[ ] DBFS permission handling implemented
[ ] Column case sensitivity resolved
[ ] Parquet format compatibility ensured
[ ] Dataset alias mappings configured
[ ] Dynamic column detection for joins
[ ] VOID type columns handled before write
[ ] All expected output keys mapped
References
Config File: .windsurf/workflows/palantir-migration-config.yaml
Fetch Script: pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py
Reference Implementation: pipeline_builder/DBX_Conversion/netaudit_pipeline_from_json.py
Test Results: Successfully processed 3.4M+ rows across 4 outputs in production
Fetch Workflow: /fetch-palantir-pipeline-json
JSON Template: pipeline_builder/palantir pipeline 1.json
Production Example: pipeline_builder/DBX_Conversion/netaudit_pipeline_from_json.py
Config Pattern: pipeline_builder/DBX_Conversion/pipeline_builder_transform_prod.py
Version History
Version	Date	Changes
1.1.0	2026-02-04	Production-tested updates: DBFS permission handling, dynamic column detection, alias mappings, Parquet VOID fixes
1.0.0	2026-02-02	Initial production release with YAML config support
JSON Structure Reference
{
  "pipeline": {"rid": "ri.eddie.main.pipeline.xxx", "name": "NetAudit_project"},
  "sandbox": {"id": "572070d8-f0bf-43eb-bca4-2c8fcca177c7", "name": "Main"},
  "snapshot": {
    "datasets": [
      {"name": "x_ndr_nokia_enb", "rid": "ri.foundry..."}
    ],
    "outputs": [
      {
        "pluralDisplayName": "LTE_NOK_NetAudit",
        "primaryKey": ["cellname"],
        "properties": [
          {"name": "CELLNAME", "type": "STRING"},
          {"name": "LATITUDE", "type": "DOUBLE"}
        ]
      }
    ],
    "transforms": [
      {"type": "selectColumns", "columns": ["A", "B"]},
      {"type": "complexLeftJoin", "left": "...", "right": "...", "on": "..."},
      {"type": "dropDuplicates", "keys": ["KEY"]}
    ]
  }
}