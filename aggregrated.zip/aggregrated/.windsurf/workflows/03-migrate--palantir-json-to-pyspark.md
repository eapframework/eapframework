---
description: Migrate Palantir Pipeline JSON export to PySpark Databricks notebook
---

User input: $ARGUMENTS

## Configuration

**Config File**: `.windsurf/workflows/palantir-migration-config.yaml`

Load settings from config:
```yaml
storage:
  prod:
    account: "datalakeeastus2prd"
    container: "otis-poc"
    base_path: "abfss://otis-poc@datalakeeastus2prd.dfs.core.windows.net"

input_tables:
  x_ndr_nokia_lcell_rrh: "x_ndr_nokia_lcell_rrh"
  x_ndr_nokia_enb: "x_ndr_nokia_enb"
  # ... more tables

guardrails:
  hard_stops: ["dbutils.fs.ls", "hardcoded_credentials", "delta_overwrite"]
  auto_fix:
    duplicate_columns: true
```

---

## Prerequisites

**Option A: Fetch JSON via API** (recommended)
Run `/fetch-palantir-pipeline-json` first to download the pipeline definition:
```
/fetch-palantir-pipeline-json Fetch pipeline: ri.eddie.main.pipeline.19f85d48-afd4-44f7-xxxx
```
Output: `pipeline_builder/DBX_Conversion/pipeline_json/{name}_latest.json`

**Option B: Manual JSON Export**
Export JSON manually from Palantir Pipeline Builder UI and place in workspace.

---

## Execution Steps

### 1. Parse Input
Extract from $ARGUMENTS:
- **json_file**: Path to pipeline JSON (e.g., `netaudit_latest.json`)
- **environment**: `prod` or `dev` (loads storage config from YAML)
- **output_folder**: Override default output folder (optional)

Request clarification if json_file is missing.

### 2. Load Configuration
```python
import yaml
with open(".windsurf/workflows/palantir-migration-config.yaml") as f:
    config = yaml.safe_load(f)

env = config["storage"][environment]
storage_account = env["account"]
container = env["container"]
input_tables = config["input_tables"]
guardrails = config["guardrails"]
```

### 3. Load JSON Pipeline Definition
- Read Palantir pipeline JSON export file
- Parse `sandboxSnapshotWithVersion.snapshot` for transforms, datasets, outputs

### 4. Extract from JSON Structure

| JSON Path | Extract |
|-----------|---------|
| `snapshot.datasets[]` | Input table names and RIDs |
| `snapshot.outputs[]` | Output names, primary keys, properties (columns) |
| `snapshot.transforms[]` | Transform logic: select, join, filter, cast, dropDuplicates |

#### Transform Types to Parse:
| Transform Type | PySpark Equivalent |
|----------------|-------------------|
| `selectColumns` | `df.select([...])` |
| `complexLeftJoin` | `df.join(df2, condition, "left")` |
| `dropDuplicates` | `df.dropDuplicates([key])` |
| `applyExpression` | `df.withColumn(name, expr)` |
| `filter` | `df.filter(condition)` |
| `aggregate` | `df.agg(F.max(...))` |

### 4. Validate Constraints
Check against `guardrails.hard_stops` from config:
- ✘ Refuse `dbutils.fs.ls()` for folder discovery (permission errors)
- ✘ Refuse hardcoded credentials or connection strings
- ✘ Refuse Delta format writes to existing Delta folders
- ✘ Refuse joins without duplicate column handling
- ✘ Refuse case-mismatched column references (JSON uses exact case)
If violated, explain clearly and suggest compliant alternative.

### 5. Generate PySpark Notebook

Create Databricks notebook with structure:
- **Cell 1**: Configuration (storage account, container, output folder, input table mappings)
- **Cell 2**: Helper functions
- **Cell 3**: Load all input tables + initialize empty output DataFrames
- **Cell 4-N**: Transformations (one cell per output)
- **Cell N+1**: Write outputs as Parquet
- **Cell N+2**: Validation summary

Required helper functions:
```python
safe_select(df, columns)         # Select only existing columns
drop_duplicate_columns(df)       # Rename duplicates with _dup suffix after joins
cast_to_string(df, col_name)     # Cast column to string
construct_geo_point(df, lat, lon) # Build geo point struct from lat/lon
load_table(name)                  # Load input table from ADLS with error handling
```

Apply mandatory patterns:
- Direct parquet reads using `abfss://` paths
- `drop_duplicate_columns()` after every join
- Rename conflicting columns before join to avoid ambiguity
- Write Parquet with overwrite mode
- Delete existing output folder before write
- Initialize all output DataFrames at start to prevent NameError

### 6. Conversion Patterns

| JSON Transform | PySpark |
|----------------|---------|
| `selectColumns: ["A", "B"]` | `safe_select(df, ["A", "B"])` |
| `applyExpression: cast(X, int, string)` | `df.withColumn("X", F.col("X").cast(IntegerType()).cast(StringType()))` |
| `applyExpression: construct_geo_point` | `df.withColumn("geo", F.struct(F.col("lon"), F.col("lat")))` |
| `applyExpression: uuid()` | `df.withColumn("uuid", F.expr("uuid()"))` |
| `complexLeftJoin` | `df.join(df2, df["A"] == df2["B"], "left")` then `drop_duplicate_columns()` |
| `dropDuplicates: [KEY]` | `df.dropDuplicates(["KEY"])` |
| `filter: col > 0` | `df.filter(F.col("col") > 0)` |
| `aggregate: max(loaddate_)` | `df.agg(F.max("loaddate_")).collect()[0][0]` |

### 7. Column Case Handling

**Critical**: Palantir JSON preserves exact column case. When joining tables:
1. Check actual column case in source parquet files
2. Use uppercase for columns from source tables (e.g., `ENBNAME`, `FIPS`, `CMA`)
3. Rename conflicting columns before join:
```python
enb_cols = enb_cols.withColumnRenamed("PULLDATE", "enb_pulldate")
```

### 8. Validate and Report

Report completion with:
- Generated notebook path
- Input tables summary (count per table)
- Output summary (name, row count, column count)
- Applied guardrails
- Testing commands

## Error Handling

**Permission Errors**: Use direct `abfss://` paths, never `dbutils.fs.ls()`.

**Ambiguous Columns**: Apply `drop_duplicate_columns()` after joins OR rename columns before join.

**Case Sensitivity**: Match exact column case from source tables; JSON column names may differ.

**Delta Conflict**: Write to new folder or delete existing folder before write.

**Missing Inputs**: Create empty DataFrame, log warning, continue processing.

**NameError on Outputs**: Initialize all output DataFrames to empty at start of Cell 3.

**Incomplete Input**: List missing information, provide example invocation.

## Examples

**End-to-End Flow (Fetch + Migrate)**:
```
# Step 1: Fetch JSON
/fetch-palantir-pipeline-json Fetch NetAudit: ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043

# Step 2: Migrate to PySpark
/migrate--palantir-json-to-pyspark Migrate netaudit_latest.json, storage: datalakeeastus2prd, container: otis-poc
```

**Basic Migration** (JSON already exists):
```
/migrate--palantir-json-to-pyspark Migrate palantir_pipeline_1.json to PySpark, storage: datalakeeastus2prd, container: otis-poc
```

**Custom Output Folder**:
```
/migrate--palantir-json-to-pyspark Migrate netaudit.json, output folder: netaudit_outputs_v2
```

## References

- **Config File**: `.windsurf/workflows/palantir-migration-config.yaml`
- **Fetch Script**: `pipeline_builder/DBX_Conversion/fetch_palantir_pipeline.py`
- **Fetch Workflow**: `/fetch-palantir-pipeline-json`
- **JSON Template**: `pipeline_builder/palantir pipeline 1.json`
- **Production Example**: `pipeline_builder/DBX_Conversion/netaudit_pipeline_from_json.py`
- **Config Pattern**: `pipeline_builder/DBX_Conversion/pipeline_builder_transform_prod.py`

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02-02 | Initial production release with YAML config support |

## JSON Structure Reference

```json
{
  "pipeline": {"rid": "ri.eddie.main.pipeline.xxx", "name": "NetAudit_project"},
  "sandbox": {"id": "572070d8-f0bf-43eb-bca4-2c8fcca177c7", "name": "Main"},
  "snapshot": {
    "datasets": [
      {"name": "x_ndr_nokia_enb", "rid": "ri.foundry..."}
    ],
    "outputs": [
      {
        "pluralDisplayName": "LTE_NOK_NetAudit",
        "primaryKey": ["cellname"],
        "properties": [
          {"name": "CELLNAME", "type": "STRING"},
          {"name": "LATITUDE", "type": "DOUBLE"}
        ]
      }
    ],
    "transforms": [
      {"type": "selectColumns", "columns": ["A", "B"]},
      {"type": "complexLeftJoin", "left": "...", "right": "...", "on": "..."},
      {"type": "dropDuplicates", "keys": ["KEY"]}
    ]
  }
}
```
