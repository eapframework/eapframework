---
description: IBM Databand service archetype - pipeline observability, alerting, metrics, and tracking
---

# IBM Databand Observability Service Archetype

## Overview

Databand provides data pipeline observability including tracking, alerting, anomaly detection, and operational metrics.

**Base URL:** `https://databand.{region}.cloud.ibm.com`

---

## Core Endpoints

### Pipelines

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/pipelines` | List pipelines |
| GET | `/api/v1/pipelines/{id}` | Get pipeline |
| GET | `/api/v1/pipelines/{id}/runs` | List pipeline runs |
| GET | `/api/v1/pipelines/{id}/metrics` | Get pipeline metrics |

### Runs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/runs` | List all runs |
| GET | `/api/v1/runs/{run_id}` | Get run details |
| GET | `/api/v1/runs/{run_id}/tasks` | Get run tasks |
| GET | `/api/v1/runs/{run_id}/logs` | Get run logs |
| GET | `/api/v1/runs/{run_id}/metrics` | Get run metrics |

### Datasets

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/datasets` | List tracked datasets |
| GET | `/api/v1/datasets/{id}` | Get dataset details |
| GET | `/api/v1/datasets/{id}/operations` | Get dataset operations |
| GET | `/api/v1/datasets/{id}/schema_history` | Get schema changes |

### Alerts

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/alerts` | List alerts |
| POST | `/api/v1/alerts` | Create alert |
| GET | `/api/v1/alerts/{id}` | Get alert |
| PATCH | `/api/v1/alerts/{id}` | Update alert |
| DELETE | `/api/v1/alerts/{id}` | Delete alert |
| GET | `/api/v1/alerts/{id}/history` | Get alert history |

### Metrics

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/metrics` | Push custom metrics |
| GET | `/api/v1/metrics/query` | Query metrics |
| GET | `/api/v1/metrics/anomalies` | Get anomalies |

### Tracking

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/tracking/init` | Initialize tracking |
| POST | `/api/v1/tracking/log` | Log event |
| POST | `/api/v1/tracking/dataset` | Log dataset operation |
| POST | `/api/v1/tracking/metric` | Log metric |

---

## Python Client

```python
import requests
import os
from typing import List, Dict, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta

@dataclass
class PipelineRun:
    run_id: str
    pipeline_name: str
    state: str
    started_at: datetime
    ended_at: Optional[datetime]
    duration_seconds: Optional[int]
    error: Optional[str]

@dataclass
class DatasetOperation:
    dataset_path: str
    operation: str  # read, write
    row_count: int
    schema: Dict
    timestamp: datetime

class DatabandClient:
    """IBM Databand Observability API Client."""
    
    def __init__(self, tracker_url: str = None, api_key: str = None):
        self.base_url = tracker_url or os.environ.get('DATABAND_TRACKER_URL')
        self.api_key = api_key or os.environ.get('DATABAND_API_KEY')
    
    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
    
    # --- Pipelines ---
    
    def list_pipelines(self, limit: int = 100) -> List[Dict]:
        """List all tracked pipelines."""
        response = requests.get(
            f"{self.base_url}/api/v1/pipelines",
            headers=self._headers(),
            params={"limit": limit}
        )
        response.raise_for_status()
        return response.json().get('pipelines', [])
    
    def get_pipeline(self, pipeline_id: str) -> Dict:
        """Get pipeline details."""
        response = requests.get(
            f"{self.base_url}/api/v1/pipelines/{pipeline_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def get_pipeline_runs(self, pipeline_id: str, 
                         since: datetime = None) -> List[PipelineRun]:
        """Get pipeline runs."""
        params = {}
        if since:
            params['since'] = since.isoformat()
        
        response = requests.get(
            f"{self.base_url}/api/v1/pipelines/{pipeline_id}/runs",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        
        runs = []
        for r in response.json().get('runs', []):
            runs.append(PipelineRun(
                run_id=r['run_id'],
                pipeline_name=r['pipeline_name'],
                state=r['state'],
                started_at=datetime.fromisoformat(r['started_at']),
                ended_at=datetime.fromisoformat(r['ended_at']) if r.get('ended_at') else None,
                duration_seconds=r.get('duration_seconds'),
                error=r.get('error')
            ))
        return runs
    
    # --- Runs ---
    
    def get_run(self, run_id: str) -> Dict:
        """Get run details."""
        response = requests.get(
            f"{self.base_url}/api/v1/runs/{run_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def get_run_tasks(self, run_id: str) -> List[Dict]:
        """Get tasks for a run."""
        response = requests.get(
            f"{self.base_url}/api/v1/runs/{run_id}/tasks",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('tasks', [])
    
    def get_run_logs(self, run_id: str) -> List[Dict]:
        """Get logs for a run."""
        response = requests.get(
            f"{self.base_url}/api/v1/runs/{run_id}/logs",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('logs', [])
    
    def get_run_metrics(self, run_id: str) -> Dict:
        """Get metrics for a run."""
        response = requests.get(
            f"{self.base_url}/api/v1/runs/{run_id}/metrics",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    # --- Datasets ---
    
    def list_datasets(self, limit: int = 100) -> List[Dict]:
        """List tracked datasets."""
        response = requests.get(
            f"{self.base_url}/api/v1/datasets",
            headers=self._headers(),
            params={"limit": limit}
        )
        response.raise_for_status()
        return response.json().get('datasets', [])
    
    def get_dataset(self, dataset_id: str) -> Dict:
        """Get dataset details."""
        response = requests.get(
            f"{self.base_url}/api/v1/datasets/{dataset_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def get_dataset_operations(self, dataset_id: str,
                               since: datetime = None) -> List[DatasetOperation]:
        """Get dataset operations."""
        params = {}
        if since:
            params['since'] = since.isoformat()
        
        response = requests.get(
            f"{self.base_url}/api/v1/datasets/{dataset_id}/operations",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        
        ops = []
        for o in response.json().get('operations', []):
            ops.append(DatasetOperation(
                dataset_path=o['path'],
                operation=o['operation'],
                row_count=o['row_count'],
                schema=o.get('schema', {}),
                timestamp=datetime.fromisoformat(o['timestamp'])
            ))
        return ops
    
    def get_schema_history(self, dataset_id: str) -> List[Dict]:
        """Get dataset schema change history."""
        response = requests.get(
            f"{self.base_url}/api/v1/datasets/{dataset_id}/schema_history",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('changes', [])
    
    # --- Alerts ---
    
    def list_alerts(self, state: str = None) -> List[Dict]:
        """List alerts."""
        params = {}
        if state:
            params['state'] = state
        
        response = requests.get(
            f"{self.base_url}/api/v1/alerts",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        return response.json().get('alerts', [])
    
    def create_alert(self, name: str, condition: dict,
                    channels: List[str]) -> Dict:
        """Create an alert."""
        response = requests.post(
            f"{self.base_url}/api/v1/alerts",
            headers=self._headers(),
            json={
                "name": name,
                "condition": condition,
                "channels": channels,
                "enabled": True
            }
        )
        response.raise_for_status()
        return response.json()
    
    def update_alert(self, alert_id: str, updates: dict) -> Dict:
        """Update an alert."""
        response = requests.patch(
            f"{self.base_url}/api/v1/alerts/{alert_id}",
            headers=self._headers(),
            json=updates
        )
        response.raise_for_status()
        return response.json()
    
    def delete_alert(self, alert_id: str) -> None:
        """Delete an alert."""
        response = requests.delete(
            f"{self.base_url}/api/v1/alerts/{alert_id}",
            headers=self._headers()
        )
        response.raise_for_status()
    
    # --- Metrics ---
    
    def push_metrics(self, run_id: str, metrics: Dict[str, float]) -> None:
        """Push custom metrics."""
        response = requests.post(
            f"{self.base_url}/api/v1/metrics",
            headers=self._headers(),
            json={
                "run_id": run_id,
                "metrics": metrics,
                "timestamp": datetime.now().isoformat()
            }
        )
        response.raise_for_status()
    
    def query_metrics(self, metric_name: str,
                     start: datetime, end: datetime) -> List[Dict]:
        """Query metrics over time range."""
        response = requests.get(
            f"{self.base_url}/api/v1/metrics/query",
            headers=self._headers(),
            params={
                "metric": metric_name,
                "start": start.isoformat(),
                "end": end.isoformat()
            }
        )
        response.raise_for_status()
        return response.json().get('data', [])
    
    def get_anomalies(self, since: datetime = None) -> List[Dict]:
        """Get detected anomalies."""
        params = {}
        if since:
            params['since'] = since.isoformat()
        
        response = requests.get(
            f"{self.base_url}/api/v1/metrics/anomalies",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        return response.json().get('anomalies', [])
    
    # --- Tracking ---
    
    def init_tracking(self, pipeline_name: str, run_id: str = None) -> str:
        """Initialize tracking for a run."""
        response = requests.post(
            f"{self.base_url}/api/v1/tracking/init",
            headers=self._headers(),
            json={
                "pipeline_name": pipeline_name,
                "run_id": run_id
            }
        )
        response.raise_for_status()
        return response.json()['run_id']
    
    def log_event(self, run_id: str, event_type: str,
                 message: str, metadata: dict = None) -> None:
        """Log an event."""
        response = requests.post(
            f"{self.base_url}/api/v1/tracking/log",
            headers=self._headers(),
            json={
                "run_id": run_id,
                "event_type": event_type,
                "message": message,
                "metadata": metadata or {},
                "timestamp": datetime.now().isoformat()
            }
        )
        response.raise_for_status()
    
    def log_dataset_operation(self, run_id: str, path: str,
                             operation: str, row_count: int,
                             schema: dict = None) -> None:
        """Log a dataset operation."""
        response = requests.post(
            f"{self.base_url}/api/v1/tracking/dataset",
            headers=self._headers(),
            json={
                "run_id": run_id,
                "path": path,
                "operation": operation,
                "row_count": row_count,
                "schema": schema,
                "timestamp": datetime.now().isoformat()
            }
        )
        response.raise_for_status()
```

---

## Alert Conditions

```python
# Row count threshold
row_count_alert = {
    "type": "row_count",
    "dataset": "sales_daily",
    "operator": "less_than",
    "threshold": 1000
}

# Duration threshold
duration_alert = {
    "type": "duration",
    "pipeline": "etl_daily",
    "operator": "greater_than",
    "threshold_minutes": 60
}

# Failure alert
failure_alert = {
    "type": "run_state",
    "pipeline": "etl_daily",
    "state": "failed"
}

# Schema change
schema_alert = {
    "type": "schema_change",
    "dataset": "customers",
    "change_types": ["column_added", "column_removed", "type_changed"]
}

# Anomaly detection
anomaly_alert = {
    "type": "anomaly",
    "metric": "row_count",
    "dataset": "transactions",
    "sensitivity": "medium"
}
```

---

## Example: Pipeline Tracking

```python
from databand import DatabandClient

client = DatabandClient()

# Initialize tracking
run_id = client.init_tracking(
    pipeline_name="daily_sales_etl"
)
print(f"Tracking run: {run_id}")

try:
    # Log start
    client.log_event(run_id, "info", "Pipeline started")
    
    # Track dataset read
    client.log_dataset_operation(
        run_id=run_id,
        path="s3://raw/sales/2024-01-15/",
        operation="read",
        row_count=150000,
        schema={"order_id": "string", "amount": "decimal", "date": "date"}
    )
    
    # Push custom metrics
    client.push_metrics(run_id, {
        "records_processed": 150000,
        "records_filtered": 12500,
        "records_written": 137500,
        "processing_time_seconds": 342
    })
    
    # Track dataset write
    client.log_dataset_operation(
        run_id=run_id,
        path="s3://curated/sales_daily/",
        operation="write",
        row_count=137500
    )
    
    client.log_event(run_id, "info", "Pipeline completed successfully")
    
except Exception as e:
    client.log_event(run_id, "error", f"Pipeline failed: {str(e)}")
    raise
```

---

## Example: Create Alerts

```python
client = DatabandClient()

# Alert on pipeline failure
client.create_alert(
    name="ETL Failure Alert",
    condition={
        "type": "run_state",
        "pipeline": "daily_sales_etl",
        "state": "failed"
    },
    channels=["slack", "email"]
)

# Alert on low row count
client.create_alert(
    name="Low Sales Volume Alert",
    condition={
        "type": "row_count",
        "dataset": "sales_daily",
        "operator": "less_than",
        "threshold": 50000
    },
    channels=["pagerduty"]
)

# Alert on schema changes
client.create_alert(
    name="Schema Drift Alert",
    condition={
        "type": "schema_change",
        "dataset": "customers",
        "change_types": ["column_removed", "type_changed"]
    },
    channels=["slack", "email"]
)

# Anomaly detection
client.create_alert(
    name="Transaction Anomaly",
    condition={
        "type": "anomaly",
        "metric": "row_count",
        "dataset": "transactions",
        "sensitivity": "high"
    },
    channels=["slack"]
)
```

---

## Notification Channels

| Channel | Configuration |
|---------|---------------|
| `slack` | `webhook_url` |
| `email` | `recipients[]` |
| `pagerduty` | `integration_key` |
| `teams` | `webhook_url` |
| `webhook` | `url`, `method`, `headers` |
