---
description: IBM Knowledge Catalog service archetype - asset management, governance, data classification, lineage
---

# IBM Knowledge Catalog Service Archetype

## Overview

IBM Knowledge Catalog (WKC) provides data governance, quality, and cataloging capabilities.

**Base URL:** `https://api.dataplatform.cloud.ibm.com`

---

## Core Endpoints

### Catalogs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v2/catalogs` | List all catalogs |
| GET | `/v2/catalogs/{catalog_id}` | Get catalog details |
| POST | `/v2/catalogs` | Create catalog |
| DELETE | `/v2/catalogs/{catalog_id}` | Delete catalog |

### Assets

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v2/assets` | Search assets |
| GET | `/v2/assets/{asset_id}` | Get asset |
| POST | `/v2/assets` | Create asset |
| PATCH | `/v2/assets/{asset_id}` | Update asset |
| DELETE | `/v2/assets/{asset_id}` | Delete asset |
| GET | `/v2/assets/{asset_id}/attributes` | Get attributes |
| POST | `/v2/assets/{asset_id}/publish` | Publish to catalog |

### Data Classes

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v3/data_classes` | List data classes |
| POST | `/v3/data_classes` | Create data class |
| GET | `/v3/data_classes/{id}` | Get data class |
| PATCH | `/v3/data_classes/{id}` | Update data class |

### Governance Policies

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v3/policy_rules` | List policies |
| POST | `/v3/policy_rules` | Create policy |
| GET | `/v3/policy_rules/{id}` | Get policy |
| DELETE | `/v3/policy_rules/{id}` | Delete policy |

### Categories

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v3/categories` | List categories |
| POST | `/v3/categories` | Create category |
| GET | `/v3/categories/{id}` | Get category |

### Glossary Terms

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v3/glossary_terms` | List terms |
| POST | `/v3/glossary_terms` | Create term |
| GET | `/v3/glossary_terms/{id}` | Get term |
| POST | `/v3/glossary_terms/{id}/relationships` | Add relationship |

---

## Python Client

```python
import requests
import os
from typing import List, Dict, Optional

class KnowledgeCatalogClient:
    """IBM Knowledge Catalog API Client."""
    
    BASE_URL = "https://api.dataplatform.cloud.ibm.com"
    
    def __init__(self, catalog_id: str = None, auth = None):
        self.catalog_id = catalog_id or os.environ.get('WKC_CATALOG_ID')
        self.auth = auth or IBMIAMAuth()
    
    def _headers(self) -> dict:
        return self.auth.get_headers()
    
    # --- Catalogs ---
    
    def list_catalogs(self) -> List[Dict]:
        response = requests.get(
            f"{self.BASE_URL}/v2/catalogs",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('catalogs', [])
    
    def get_catalog(self, catalog_id: str = None) -> Dict:
        cid = catalog_id or self.catalog_id
        response = requests.get(
            f"{self.BASE_URL}/v2/catalogs/{cid}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def create_catalog(self, name: str, description: str = "") -> Dict:
        response = requests.post(
            f"{self.BASE_URL}/v2/catalogs",
            headers=self._headers(),
            json={"name": name, "description": description}
        )
        response.raise_for_status()
        return response.json()
    
    # --- Assets ---
    
    def search_assets(self, query: str, catalog_id: str = None, 
                     limit: int = 100) -> List[Dict]:
        cid = catalog_id or self.catalog_id
        response = requests.post(
            f"{self.BASE_URL}/v2/asset_searches",
            headers=self._headers(),
            params={"catalog_id": cid, "limit": limit},
            json={"query": query}
        )
        response.raise_for_status()
        return response.json().get('results', [])
    
    def get_asset(self, asset_id: str, catalog_id: str = None) -> Dict:
        cid = catalog_id or self.catalog_id
        response = requests.get(
            f"{self.BASE_URL}/v2/assets/{asset_id}",
            headers=self._headers(),
            params={"catalog_id": cid}
        )
        response.raise_for_status()
        return response.json()
    
    def create_asset(self, name: str, asset_type: str, 
                    metadata: dict, catalog_id: str = None) -> Dict:
        cid = catalog_id or self.catalog_id
        payload = {
            "metadata": {
                "name": name,
                "asset_type": asset_type,
                **metadata
            }
        }
        response = requests.post(
            f"{self.BASE_URL}/v2/assets",
            headers=self._headers(),
            params={"catalog_id": cid},
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def publish_asset(self, asset_id: str, project_id: str,
                     catalog_id: str = None) -> Dict:
        cid = catalog_id or self.catalog_id
        response = requests.post(
            f"{self.BASE_URL}/v2/assets/{asset_id}/publish",
            headers=self._headers(),
            params={"project_id": project_id},
            json={"catalog_id": cid}
        )
        response.raise_for_status()
        return response.json()
    
    # --- Data Classes ---
    
    def list_data_classes(self, limit: int = 100) -> List[Dict]:
        response = requests.get(
            f"{self.BASE_URL}/v3/data_classes",
            headers=self._headers(),
            params={"limit": limit}
        )
        response.raise_for_status()
        return response.json().get('resources', [])
    
    def create_data_class(self, name: str, description: str,
                         parent_id: str = None) -> Dict:
        payload = {
            "name": name,
            "description": description
        }
        if parent_id:
            payload["parent_category_id"] = parent_id
        
        response = requests.post(
            f"{self.BASE_URL}/v3/data_classes",
            headers=self._headers(),
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def assign_data_class(self, asset_id: str, column_name: str,
                         data_class_id: str, catalog_id: str = None) -> Dict:
        cid = catalog_id or self.catalog_id
        response = requests.post(
            f"{self.BASE_URL}/v2/assets/{asset_id}/attributes/{column_name}/data_class",
            headers=self._headers(),
            params={"catalog_id": cid},
            json={"data_class_id": data_class_id}
        )
        response.raise_for_status()
        return response.json()
    
    # --- Governance Policies ---
    
    def list_policies(self) -> List[Dict]:
        response = requests.get(
            f"{self.BASE_URL}/v3/policy_rules",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('resources', [])
    
    def create_policy(self, name: str, description: str,
                     governance_type_id: str, rules: list) -> Dict:
        payload = {
            "name": name,
            "description": description,
            "governance_type_id": governance_type_id,
            "rules": rules
        }
        response = requests.post(
            f"{self.BASE_URL}/v3/policy_rules",
            headers=self._headers(),
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    # --- Glossary Terms ---
    
    def list_glossary_terms(self, category_id: str = None) -> List[Dict]:
        params = {}
        if category_id:
            params["parent_category_id"] = category_id
        
        response = requests.get(
            f"{self.BASE_URL}/v3/glossary_terms",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        return response.json().get('resources', [])
    
    def create_glossary_term(self, name: str, description: str,
                            category_id: str) -> Dict:
        payload = {
            "name": name,
            "description": description,
            "parent_category_id": category_id
        }
        response = requests.post(
            f"{self.BASE_URL}/v3/glossary_terms",
            headers=self._headers(),
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    # --- Categories ---
    
    def list_categories(self) -> List[Dict]:
        response = requests.get(
            f"{self.BASE_URL}/v3/categories",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('resources', [])
    
    def create_category(self, name: str, description: str,
                       parent_id: str = None) -> Dict:
        payload = {
            "name": name,
            "description": description
        }
        if parent_id:
            payload["parent_category_id"] = parent_id
        
        response = requests.post(
            f"{self.BASE_URL}/v3/categories",
            headers=self._headers(),
            json=payload
        )
        response.raise_for_status()
        return response.json()
```

---

## Asset Types

| Type | Description |
|------|-------------|
| `data_asset` | Tables, files, datasets |
| `connection` | Database connections |
| `notebook` | Jupyter notebooks |
| `model` | ML models |
| `script` | Python/R scripts |
| `dashboard` | BI dashboards |
| `report` | Reports |
| `policy` | Governance policies |

---

## Example: Catalog Management

```python
client = KnowledgeCatalogClient()

# List catalogs
catalogs = client.list_catalogs()
print(f"Found {len(catalogs)} catalogs")

# Search for assets
assets = client.search_assets("sales")
for asset in assets:
    print(f"  - {asset['metadata']['name']} ({asset['metadata']['asset_type']})")

# Create data class
data_class = client.create_data_class(
    name="PII - Email",
    description="Personally identifiable email addresses"
)

# Create glossary term
term = client.create_glossary_term(
    name="Customer ID",
    description="Unique identifier for customers",
    category_id="category_123"
)

# Create governance policy
policy = client.create_policy(
    name="PII Masking Policy",
    description="Mask PII data in non-production",
    governance_type_id="AccessPolicyType",
    rules=[{
        "name": "mask_pii",
        "condition": {"data_class": "PII"},
        "action": {"type": "mask", "method": "redact"}
    }]
)
```

---

## Data Classification

```python
def auto_classify_columns(client, asset_id: str):
    """Auto-classify columns based on patterns."""
    
    asset = client.get_asset(asset_id)
    columns = asset.get('columns', [])
    
    classifications = {
        'email': 'PII - Email',
        'ssn': 'PII - SSN',
        'phone': 'PII - Phone',
        'address': 'PII - Address',
        'credit_card': 'PCI - Card Number',
        'dob': 'PII - Date of Birth'
    }
    
    for col in columns:
        col_name = col['name'].lower()
        for pattern, data_class in classifications.items():
            if pattern in col_name:
                client.assign_data_class(
                    asset_id=asset_id,
                    column_name=col['name'],
                    data_class_id=data_class
                )
                print(f"Classified {col['name']} as {data_class}")
```
