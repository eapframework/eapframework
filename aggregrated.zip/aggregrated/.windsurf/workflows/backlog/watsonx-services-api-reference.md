---
description: Comprehensive API endpoint reference for all IBM watsonx services
---

# IBM watsonx Services API Reference

Complete API endpoint reference for IBM watsonx services callable from an IDE: **Manta**, **Data Product Hub (DPH)**, **Databand**, **DataStage**, and **Knowledge Catalog**.

---

## Table of Contents

1. [Authentication](#authentication)
2. [Base URLs](#base-urls)
3. [DataStage API](#datastage-api)
4. [Knowledge Catalog API](#knowledge-catalog-api)
5. [Manta Data Lineage API](#manta-data-lineage-api)
6. [Data Product Hub (DPH) API](#data-product-hub-dph-api)
7. [Databand Observability API](#databand-observability-api)
8. [Common Patterns](#common-patterns)

---

## Authentication

### IBM Cloud IAM Token

```http
POST https://iam.cloud.ibm.com/identity/token
Content-Type: application/x-www-form-urlencoded

grant_type=urn:ibm:params:oauth:grant-type:apikey&apikey={API_KEY}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJ...",
  "refresh_token": "...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "expiration": 1699999999
}
```

### Cloud Pak for Data Token

```http
POST {CPD_URL}/icp4d-api/v1/authorize
Content-Type: application/json

{
  "username": "{username}",
  "password": "{password}"
}
```

### Zen API Key Authentication

```http
GET {BASE_URL}/v2/assets
Authorization: ZenApiKey {zen_api_key}
```

### Service ID Authentication

```bash
# Header format
Authorization: Bearer {access_token}
X-IBM-Service-Instance-Id: {service_instance_id}
```

---

## Base URLs

### IBM Cloud Regions

| Service | Dallas (us-south) | Frankfurt (eu-de) | Tokyo (jp-tok) | London (eu-gb) |
|---------|-------------------|-------------------|----------------|----------------|
| **DataStage** | `https://us-south.dataplatform.cloud.ibm.com` | `https://eu-de.dataplatform.cloud.ibm.com` | `https://jp-tok.dataplatform.cloud.ibm.com` | `https://eu-gb.dataplatform.cloud.ibm.com` |
| **Knowledge Catalog** | `https://us-south.dataplatform.cloud.ibm.com` | `https://eu-de.dataplatform.cloud.ibm.com` | `https://jp-tok.dataplatform.cloud.ibm.com` | `https://eu-gb.dataplatform.cloud.ibm.com` |
| **Manta** | `https://manta.us-south.dataplatform.cloud.ibm.com` | `https://manta.eu-de.dataplatform.cloud.ibm.com` | `https://manta.jp-tok.dataplatform.cloud.ibm.com` | `https://manta.eu-gb.dataplatform.cloud.ibm.com` |
| **DPH** | `https://us-south.dataplatform.cloud.ibm.com` | `https://eu-de.dataplatform.cloud.ibm.com` | `https://jp-tok.dataplatform.cloud.ibm.com` | `https://eu-gb.dataplatform.cloud.ibm.com` |
| **Databand** | `https://databand.us-south.dataplatform.cloud.ibm.com` | `https://databand.eu-de.dataplatform.cloud.ibm.com` | - | - |

### Azure Deployment

```
DataStage:         https://dataintegration.azure.ibm.com
Knowledge Catalog: https://catalog.azure.ibm.com
Manta:             https://manta.azure.ibm.com
DPH:               https://dph.azure.ibm.com
Databand:          https://databand.azure.ibm.com
```

### Cloud Pak for Data (On-Premises)

```
Base:              https://{cpd-route}
DataStage:         https://{cpd-route}/v3/ds_jobs
Knowledge Catalog: https://{cpd-route}/v3/catalogs
Manta:             https://{cpd-route}/manta/api
DPH:               https://{cpd-route}/data_product_hub/api
Databand:          https://{cpd-route}/databand/api
```

---

## DataStage API

### Jobs

#### List Jobs
```http
GET {BASE_URL}/v3/ds_jobs
Authorization: Bearer {token}
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `project_id` | string | Filter by project |
| `limit` | integer | Max results (default: 100) |
| `offset` | integer | Pagination offset |

#### Get Job
```http
GET {BASE_URL}/v3/ds_jobs/{job_id}
Authorization: Bearer {token}
```

#### Create Job
```http
POST {BASE_URL}/v3/ds_jobs
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "job_name",
  "project_id": "project-uuid",
  "description": "Job description",
  "job_type": "parallel"
}
```

#### Update Job
```http
PATCH {BASE_URL}/v3/ds_jobs/{job_id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "updated_name",
  "description": "Updated description"
}
```

#### Delete Job
```http
DELETE {BASE_URL}/v3/ds_jobs/{job_id}
Authorization: Bearer {token}
```

#### Import Job (DSX/ISX)
```http
POST {BASE_URL}/v3/ds_jobs/import
Authorization: Bearer {token}
Content-Type: multipart/form-data

file: @{dsx_file}
project_id: {project_id}
conflict_resolution: replace|rename|skip
```

#### Export Job
```http
GET {BASE_URL}/v3/ds_jobs/{job_id}/export?format=dsx
Authorization: Bearer {token}
Accept: application/octet-stream
```

#### Compile Job
```http
POST {BASE_URL}/v3/ds_jobs/{job_id}/compile
Authorization: Bearer {token}
```

### Job Runs

#### Run Job
```http
POST {BASE_URL}/v3/ds_jobs/{job_id}/runs
Authorization: Bearer {token}
Content-Type: application/json

{
  "job_run": {
    "job_id": "{job_id}",
    "job_run_name": "run_001"
  },
  "job_run_parameters": [
    { "name": "PARAM_NAME", "value": "param_value" }
  ]
}
```

#### Get Run Status
```http
GET {BASE_URL}/v3/ds_jobs/{job_id}/runs/{run_id}
Authorization: Bearer {token}
```

**Response States:** `Queued`, `Starting`, `Running`, `Completed`, `Failed`, `Cancelled`

#### Get Run Logs
```http
GET {BASE_URL}/v3/ds_jobs/{job_id}/runs/{run_id}/logs
Authorization: Bearer {token}
```

#### Cancel Run
```http
POST {BASE_URL}/v3/ds_jobs/{job_id}/runs/{run_id}/cancel
Authorization: Bearer {token}
```

### Connections

#### List Connections
```http
GET {BASE_URL}/v3/connections
Authorization: Bearer {token}
```

#### Create Connection
```http
POST {BASE_URL}/v3/connections
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "ADLS_Connection",
  "connection_type": "azuredatalakestoragegen2",
  "properties": {
    "storage_account_name": "mystorageaccount",
    "authentication_type": "ServicePrincipal",
    "tenant_id": "{tenant_id}",
    "client_id": "{client_id}",
    "client_secret": "{client_secret}"
  }
}
```

#### Test Connection
```http
POST {BASE_URL}/v3/connections/{connection_id}/test
Authorization: Bearer {token}
```

### Flows

#### List Flows
```http
GET {BASE_URL}/v3/data_intg/flows
Authorization: Bearer {token}
```

#### Create Flow
```http
POST {BASE_URL}/v3/data_intg/flows
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "flow_name",
  "project_id": "project-uuid",
  "pipeline_type": "parallel"
}
```

#### Run Flow
```http
POST {BASE_URL}/v3/data_intg/flows/{flow_id}/runs
Authorization: Bearer {token}
```

---

## Knowledge Catalog API

### Catalogs

#### List Catalogs
```http
GET {BASE_URL}/v2/catalogs
Authorization: Bearer {token}
```

#### Get Catalog
```http
GET {BASE_URL}/v2/catalogs/{catalog_id}
Authorization: Bearer {token}
```

#### Create Catalog
```http
POST {BASE_URL}/v2/catalogs
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Enterprise Data Catalog",
  "description": "Central data catalog",
  "generator": "default"
}
```

### Assets

#### List Assets
```http
GET {BASE_URL}/v2/assets
Authorization: Bearer {token}
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `catalog_id` | string | Filter by catalog |
| `project_id` | string | Filter by project |
| `asset_type` | string | Filter by type |
| `limit` | integer | Max results |

#### Get Asset
```http
GET {BASE_URL}/v2/assets/{asset_id}
Authorization: Bearer {token}
```

#### Create Asset
```http
POST {BASE_URL}/v2/assets
Authorization: Bearer {token}
Content-Type: application/json

{
  "metadata": {
    "name": "customer_data",
    "asset_type": "data_asset",
    "catalog_id": "catalog-uuid"
  },
  "entity": {
    "data_asset": {
      "mime_type": "application/parquet"
    }
  }
}
```

#### Update Asset
```http
PATCH {BASE_URL}/v2/assets/{asset_id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "metadata": {
    "description": "Updated description"
  }
}
```

#### Delete Asset
```http
DELETE {BASE_URL}/v2/assets/{asset_id}
Authorization: Bearer {token}
```

### Asset Types

#### List Asset Types
```http
GET {BASE_URL}/v2/asset_types
Authorization: Bearer {token}
```

#### Get Asset Type
```http
GET {BASE_URL}/v2/asset_types/{type_name}
Authorization: Bearer {token}
```

### Data Classes

#### List Data Classes
```http
GET {BASE_URL}/v3/data_classes
Authorization: Bearer {token}
```

#### Get Data Class
```http
GET {BASE_URL}/v3/data_classes/{data_class_id}
Authorization: Bearer {token}
```

#### Create Data Class
```http
POST {BASE_URL}/v3/data_classes
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Email Address",
  "description": "Valid email format",
  "data_class_type": "regex",
  "regex_pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
}
```

### Business Terms (Glossary)

#### List Glossary Terms
```http
GET {BASE_URL}/v3/glossary_terms
Authorization: Bearer {token}
```

#### Get Term
```http
GET {BASE_URL}/v3/glossary_terms/{term_id}
Authorization: Bearer {token}
```

#### Create Term
```http
POST {BASE_URL}/v3/glossary_terms
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Customer ID",
  "short_description": "Unique identifier for a customer",
  "long_description": "Primary key used to identify customers across all systems",
  "abbreviations": ["CID", "CUST_ID"],
  "status": "PUBLISHED"
}
```

### Categories

#### List Categories
```http
GET {BASE_URL}/v3/categories
Authorization: Bearer {token}
```

#### Create Category
```http
POST {BASE_URL}/v3/categories
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Customer Data",
  "description": "All customer-related data assets",
  "parent_category_id": "parent-uuid"
}
```

### Data Protection Rules

#### List Rules
```http
GET {BASE_URL}/v3/rules
Authorization: Bearer {token}
```

#### Create Rule
```http
POST {BASE_URL}/v3/rules
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Mask SSN",
  "description": "Mask Social Security Numbers",
  "governance_type_id": "data_protection",
  "rule_type": "MASK",
  "action": {
    "mask_type": "HASH"
  },
  "criteria": {
    "data_class_id": "ssn-data-class-id"
  }
}
```

### Search

#### Global Search
```http
POST {BASE_URL}/v3/search
Authorization: Bearer {token}
Content-Type: application/json

{
  "query": "customer",
  "filters": {
    "asset_type": ["data_asset", "connection"]
  },
  "limit": 50,
  "sort": "-relevance"
}
```

#### Metadata Search (IGC)
```http
POST {BASE_URL}/iis/igc-rest/v1/search
Authorization: Bearer {token}
Content-Type: application/json

{
  "types": ["data_file_field", "database_column"],
  "where": {
    "conditions": [
      { "property": "name", "operator": "like", "value": "%customer%" }
    ]
  }
}
```

---

## Manta Data Lineage API

### Lineage Graphs

#### Get Asset Lineage
```http
GET {MANTA_URL}/api/v1/lineage/{asset_id}
Authorization: Bearer {token}
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `direction` | string | `upstream`, `downstream`, `both` |
| `depth` | integer | Max hops (default: 3) |
| `include_transformations` | boolean | Include transformation details |

#### Get Full Lineage Graph
```http
POST {MANTA_URL}/api/v1/lineage/graph
Authorization: Bearer {token}
Content-Type: application/json

{
  "asset_ids": ["asset-1", "asset-2"],
  "direction": "both",
  "depth": 5,
  "filters": {
    "asset_types": ["table", "column", "file"],
    "connections": ["conn-1", "conn-2"]
  }
}
```

### Lineage Nodes

#### Get Node Details
```http
GET {MANTA_URL}/api/v1/nodes/{node_id}
Authorization: Bearer {token}
```

#### List Node Connections
```http
GET {MANTA_URL}/api/v1/nodes/{node_id}/connections
Authorization: Bearer {token}
```

### Transformations

#### Get Transformation Details
```http
GET {MANTA_URL}/api/v1/transformations/{transformation_id}
Authorization: Bearer {token}
```

**Response:**
```json
{
  "transformation_id": "uuid",
  "type": "filter|aggregate|join|expression",
  "expression": "SUM(sales_amount)",
  "source_columns": ["col1", "col2"],
  "target_column": "total_sales"
}
```

### Data Flow Analysis

#### Analyze Data Flow
```http
POST {MANTA_URL}/api/v1/analyze/dataflow
Authorization: Bearer {token}
Content-Type: application/json

{
  "source_asset_id": "source-asset-uuid",
  "target_asset_id": "target-asset-uuid",
  "include_intermediate": true
}
```

#### Get Impact Analysis
```http
POST {MANTA_URL}/api/v1/analyze/impact
Authorization: Bearer {token}
Content-Type: application/json

{
  "asset_id": "asset-uuid",
  "change_type": "delete|modify|rename",
  "scope": "direct|transitive"
}
```

### Scan & Discovery

#### Trigger Lineage Scan
```http
POST {MANTA_URL}/api/v1/scans
Authorization: Bearer {token}
Content-Type: application/json

{
  "connection_id": "connection-uuid",
  "scan_type": "full|incremental",
  "include_technical_lineage": true,
  "include_business_lineage": true
}
```

#### Get Scan Status
```http
GET {MANTA_URL}/api/v1/scans/{scan_id}
Authorization: Bearer {token}
```

#### List Scans
```http
GET {MANTA_URL}/api/v1/scans
Authorization: Bearer {token}
```

### Export

#### Export Lineage
```http
GET {MANTA_URL}/api/v1/lineage/{asset_id}/export
Authorization: Bearer {token}
Accept: application/json|text/csv|image/png
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `format` | string | `json`, `csv`, `png`, `svg` |
| `depth` | integer | Lineage depth |

---

## Data Product Hub (DPH) API

### Data Products

#### List Data Products
```http
GET {BASE_URL}/data_product_hub/api/v1/data_products
Authorization: Bearer {token}
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `state` | string | `draft`, `published`, `retired` |
| `owner_id` | string | Filter by owner |
| `domain_id` | string | Filter by domain |
| `limit` | integer | Max results |

#### Get Data Product
```http
GET {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}
Authorization: Bearer {token}
```

#### Create Data Product
```http
POST {BASE_URL}/data_product_hub/api/v1/data_products
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Customer 360 Product",
  "description": "Unified customer view",
  "domain_id": "domain-uuid",
  "owner_id": "owner-uuid",
  "type": "dataset|api|report",
  "tags": ["customer", "analytics"],
  "contracts": {
    "data_quality": {
      "completeness_threshold": 0.95,
      "freshness_sla_hours": 24
    }
  }
}
```

#### Update Data Product
```http
PATCH {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "description": "Updated description",
  "tags": ["customer", "analytics", "v2"]
}
```

#### Publish Data Product
```http
POST {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/publish
Authorization: Bearer {token}
```

#### Retire Data Product
```http
POST {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/retire
Authorization: Bearer {token}
```

### Data Product Versions

#### List Versions
```http
GET {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/versions
Authorization: Bearer {token}
```

#### Create Version
```http
POST {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/versions
Authorization: Bearer {token}
Content-Type: application/json

{
  "version": "2.0.0",
  "release_notes": "Added new fields",
  "schema_changes": {
    "added_fields": ["new_field_1"],
    "deprecated_fields": ["old_field_1"]
  }
}
```

### Domains

#### List Domains
```http
GET {BASE_URL}/data_product_hub/api/v1/domains
Authorization: Bearer {token}
```

#### Create Domain
```http
POST {BASE_URL}/data_product_hub/api/v1/domains
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Customer Domain",
  "description": "All customer-related data products",
  "owner_id": "owner-uuid",
  "stewards": ["steward-1", "steward-2"]
}
```

### Contracts & SLAs

#### Get Data Contract
```http
GET {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/contract
Authorization: Bearer {token}
```

#### Update Data Contract
```http
PUT {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/contract
Authorization: Bearer {token}
Content-Type: application/json

{
  "schema": {
    "fields": [
      { "name": "customer_id", "type": "string", "required": true },
      { "name": "email", "type": "string", "pii": true }
    ]
  },
  "quality": {
    "completeness": 0.99,
    "accuracy": 0.95,
    "timeliness_hours": 1
  },
  "access": {
    "classification": "confidential",
    "retention_days": 365
  }
}
```

### Subscriptions

#### List Subscriptions
```http
GET {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/subscriptions
Authorization: Bearer {token}
```

#### Subscribe to Data Product
```http
POST {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/subscriptions
Authorization: Bearer {token}
Content-Type: application/json

{
  "subscriber_id": "consumer-app-uuid",
  "purpose": "analytics",
  "requested_access_level": "read"
}
```

#### Approve Subscription
```http
POST {BASE_URL}/data_product_hub/api/v1/subscriptions/{subscription_id}/approve
Authorization: Bearer {token}
```

### Metrics

#### Get Product Metrics
```http
GET {BASE_URL}/data_product_hub/api/v1/data_products/{data_product_id}/metrics
Authorization: Bearer {token}
```

**Response:**
```json
{
  "usage": {
    "total_queries": 15000,
    "unique_users": 45,
    "avg_daily_queries": 500
  },
  "quality": {
    "completeness": 0.98,
    "freshness_hours": 2,
    "error_rate": 0.001
  },
  "popularity_score": 85
}
```

---

## Databand Observability API

### Pipelines

#### List Pipelines
```http
GET {DATABAND_URL}/api/v1/pipelines
Authorization: Bearer {token}
```

#### Get Pipeline
```http
GET {DATABAND_URL}/api/v1/pipelines/{pipeline_id}
Authorization: Bearer {token}
```

#### Register Pipeline
```http
POST {DATABAND_URL}/api/v1/pipelines
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "customer_etl_pipeline",
  "description": "Daily customer data ETL",
  "source": "airflow|databricks|datastage|custom",
  "schedule": "0 6 * * *",
  "owner": "data-team@company.com"
}
```

### Pipeline Runs

#### List Runs
```http
GET {DATABAND_URL}/api/v1/pipelines/{pipeline_id}/runs
Authorization: Bearer {token}
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | string | `running`, `success`, `failed` |
| `start_date` | datetime | Filter by start date |
| `end_date` | datetime | Filter by end date |
| `limit` | integer | Max results |

#### Get Run Details
```http
GET {DATABAND_URL}/api/v1/runs/{run_id}
Authorization: Bearer {token}
```

#### Report Run Start
```http
POST {DATABAND_URL}/api/v1/runs
Authorization: Bearer {token}
Content-Type: application/json

{
  "pipeline_id": "pipeline-uuid",
  "run_id": "external-run-id",
  "start_time": "2025-01-28T06:00:00Z",
  "parameters": {
    "date": "2025-01-27",
    "mode": "incremental"
  }
}
```

#### Report Run End
```http
PATCH {DATABAND_URL}/api/v1/runs/{run_id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "status": "success|failed",
  "end_time": "2025-01-28T06:30:00Z",
  "metrics": {
    "rows_processed": 1500000,
    "duration_seconds": 1800
  }
}
```

### Tasks

#### List Tasks
```http
GET {DATABAND_URL}/api/v1/runs/{run_id}/tasks
Authorization: Bearer {token}
```

#### Report Task Metrics
```http
POST {DATABAND_URL}/api/v1/tasks/{task_id}/metrics
Authorization: Bearer {token}
Content-Type: application/json

{
  "metrics": [
    { "name": "rows_read", "value": 1000000, "type": "counter" },
    { "name": "processing_time_ms", "value": 5000, "type": "gauge" },
    { "name": "error_count", "value": 0, "type": "counter" }
  ]
}
```

### Datasets

#### List Datasets
```http
GET {DATABAND_URL}/api/v1/datasets
Authorization: Bearer {token}
```

#### Get Dataset
```http
GET {DATABAND_URL}/api/v1/datasets/{dataset_id}
Authorization: Bearer {token}
```

#### Report Dataset Operation
```http
POST {DATABAND_URL}/api/v1/datasets/{dataset_id}/operations
Authorization: Bearer {token}
Content-Type: application/json

{
  "run_id": "run-uuid",
  "task_id": "task-uuid",
  "operation_type": "read|write",
  "row_count": 1500000,
  "schema": {
    "fields": [
      { "name": "id", "type": "integer" },
      { "name": "name", "type": "string" }
    ]
  },
  "path": "abfss://container@storage.dfs.core.windows.net/data/"
}
```

### Data Quality

#### Report Quality Metrics
```http
POST {DATABAND_URL}/api/v1/datasets/{dataset_id}/quality
Authorization: Bearer {token}
Content-Type: application/json

{
  "run_id": "run-uuid",
  "metrics": {
    "row_count": 1500000,
    "null_count": { "email": 150, "phone": 5000 },
    "duplicate_count": 25,
    "schema_valid": true,
    "custom_checks": [
      { "name": "email_format_valid", "passed": true, "value": 0.998 }
    ]
  }
}
```

#### Get Quality History
```http
GET {DATABAND_URL}/api/v1/datasets/{dataset_id}/quality/history
Authorization: Bearer {token}
```

### Alerts

#### List Alerts
```http
GET {DATABAND_URL}/api/v1/alerts
Authorization: Bearer {token}
```

#### Create Alert Rule
```http
POST {DATABAND_URL}/api/v1/alert_rules
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Pipeline Failure Alert",
  "pipeline_id": "pipeline-uuid",
  "condition": {
    "type": "pipeline_status",
    "status": "failed"
  },
  "notification": {
    "channels": ["email", "slack"],
    "recipients": ["data-ops@company.com"],
    "slack_webhook": "https://hooks.slack.com/..."
  }
}
```

#### Create SLA Alert
```http
POST {DATABAND_URL}/api/v1/alert_rules
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "SLA Breach Alert",
  "pipeline_id": "pipeline-uuid",
  "condition": {
    "type": "sla_breach",
    "expected_completion_time": "08:00:00",
    "timezone": "America/Chicago"
  },
  "notification": {
    "channels": ["pagerduty"],
    "severity": "critical"
  }
}
```

### Anomaly Detection

#### Get Anomalies
```http
GET {DATABAND_URL}/api/v1/anomalies
Authorization: Bearer {token}
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `pipeline_id` | string | Filter by pipeline |
| `dataset_id` | string | Filter by dataset |
| `severity` | string | `low`, `medium`, `high`, `critical` |
| `start_date` | datetime | Filter by date |

#### Acknowledge Anomaly
```http
POST {DATABAND_URL}/api/v1/anomalies/{anomaly_id}/acknowledge
Authorization: Bearer {token}
Content-Type: application/json

{
  "comment": "Investigated - expected spike due to end of quarter",
  "resolution": "expected_behavior|fixed|false_positive"
}
```

### Reports

#### Get Pipeline Health Report
```http
GET {DATABAND_URL}/api/v1/reports/pipeline_health
Authorization: Bearer {token}
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `pipeline_ids` | string[] | Pipeline IDs |
| `period` | string | `day`, `week`, `month` |

#### Get Data Quality Report
```http
GET {DATABAND_URL}/api/v1/reports/data_quality
Authorization: Bearer {token}
```

---

## Common Patterns

### Pagination

```http
GET {endpoint}?limit=50&offset=100
```

**Response:**
```json
{
  "results": [...],
  "total_count": 500,
  "limit": 50,
  "offset": 100,
  "next": "{endpoint}?limit=50&offset=150"
}
```

### Filtering

```http
GET {endpoint}?filter[field]=value&filter[status]=active
```

### Sorting

```http
GET {endpoint}?sort=name        # Ascending
GET {endpoint}?sort=-created_at # Descending
```

### Error Response Format

```json
{
  "trace": "request-trace-id",
  "errors": [
    {
      "code": "error_code",
      "message": "Human readable error message",
      "more_info": "https://docs.ibm.com/...",
      "target": { "type": "field", "name": "field_name" }
    }
  ]
}
```

### Common Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `unauthorized` | 401 | Invalid or expired token |
| `forbidden` | 403 | Insufficient permissions |
| `not_found` | 404 | Resource not found |
| `conflict` | 409 | Resource already exists |
| `invalid_parameter` | 400 | Invalid request parameter |
| `rate_limit_exceeded` | 429 | Too many requests |

### Rate Limits

| Service | Limit |
|---------|-------|
| DataStage | 100 requests/minute |
| Knowledge Catalog | 100 requests/minute |
| Manta | 50 requests/minute |
| DPH | 100 requests/minute |
| Databand | 200 requests/minute |

---

## SDK Examples

### Python

```python
import requests

class WatsonxClient:
    def __init__(self, api_key, region="us-south"):
        self.base_url = f"https://{region}.dataplatform.cloud.ibm.com"
        self.token = self._get_token(api_key)
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
    
    def _get_token(self, api_key):
        resp = requests.post(
            "https://iam.cloud.ibm.com/identity/token",
            data=f"grant_type=urn:ibm:params:oauth:grant-type:apikey&apikey={api_key}",
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        return resp.json()["access_token"]
    
    def list_datastage_jobs(self, project_id):
        return requests.get(
            f"{self.base_url}/v3/ds_jobs",
            params={"project_id": project_id},
            headers=self.headers
        ).json()
    
    def get_lineage(self, asset_id, depth=3):
        return requests.get(
            f"{self.base_url}/manta/api/v1/lineage/{asset_id}",
            params={"depth": depth, "direction": "both"},
            headers=self.headers
        ).json()
```

### cURL Template

```bash
#!/bin/bash
API_KEY="${IBM_API_KEY}"
BASE_URL="https://us-south.dataplatform.cloud.ibm.com"

# Get token
TOKEN=$(curl -s -X POST "https://iam.cloud.ibm.com/identity/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=urn:ibm:params:oauth:grant-type:apikey&apikey=${API_KEY}" \
  | jq -r '.access_token')

# Example: List DataStage jobs
curl -X GET "${BASE_URL}/v3/ds_jobs?project_id=${PROJECT_ID}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json"
```

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `IBM_API_KEY` | IBM Cloud API key |
| `IBM_REGION` | IBM Cloud region (us-south, eu-de, etc.) |
| `CPD_URL` | Cloud Pak for Data URL (on-prem) |
| `CPD_USERNAME` | CP4D username |
| `CPD_PASSWORD` | CP4D password |
| `DATASTAGE_PROJECT_ID` | Default project ID |
| `MANTA_API_URL` | Manta service URL |
| `DATABAND_API_URL` | Databand service URL |

---

## References

- [IBM DataStage API Docs](https://cloud.ibm.com/apidocs/datastage)
- [IBM Knowledge Catalog API Docs](https://cloud.ibm.com/apidocs/watson-data-api)
- [Manta Documentation](https://docs.getmanta.com)
- [Databand Documentation](https://docs.databand.ai)
- [Data Product Hub Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.8.x?topic=hub-data-product)
