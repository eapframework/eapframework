---
description: Extract Palantir Foundry pipelines via API and deploy to IBM DataStage on Azure
---

# Palantir Foundry to IBM DataStage on Azure Migration

End-to-end workflow to extract pipeline definitions from Palantir Foundry API, normalize the JSON structure, convert to DataStage-compatible stages and job flows, and generate deployment artifacts for watsonx.data integration IBM DataStage on Azure.

## Input

**Required**: Palantir Foundry pipeline RID or name

```
/palantir-to-datastage-azure <pipeline_rid_or_name>
```

Example: `/palantir-to-datastage-azure ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043`

---

## Phase 1: Extract Pipeline from Palantir Foundry API

### 1.1 Authentication

**Foundry API Token Required**: Store in environment variable or secure vault.

```bash
export FOUNDRY_TOKEN="<your_foundry_api_token>"
export FOUNDRY_HOST="https://<your-stack>.palantirfoundry.com"
```

### 1.2 API Endpoints

#### Get Pipeline Definition
```http
GET {FOUNDRY_HOST}/eddie/api/pipelines/{pipeline_rid}
Authorization: Bearer {FOUNDRY_TOKEN}
Content-Type: application/json
```

#### Get Pipeline Snapshot (Full Transform Details)
```http
GET {FOUNDRY_HOST}/eddie/api/pipelines/{pipeline_rid}/versions/{version_id}/snapshot
Authorization: Bearer {FOUNDRY_TOKEN}
Content-Type: application/json
```

#### Get Pipeline Inputs/Outputs
```http
GET {FOUNDRY_HOST}/eddie/api/pipelines/{pipeline_rid}/io
Authorization: Bearer {FOUNDRY_TOKEN}
Content-Type: application/json
```

#### List All Pipelines (Search)
```http
GET {FOUNDRY_HOST}/eddie/api/pipelines?query={search_term}
Authorization: Bearer {FOUNDRY_TOKEN}
Content-Type: application/json
```

### 1.3 API Response Structure

```json
{
  "pipeline": {
    "rid": "ri.eddie.main.pipeline.XXX",
    "name": "Pipeline_Name",
    "attribution": {
      "time": "2025-05-12T22:27:39.723Z",
      "user": "user-uuid"
    }
  },
  "sandbox": {
    "id": "sandbox-uuid",
    "name": "Main",
    "backingBranch": "master",
    "isPublished": true
  },
  "version": {
    "id": "version-uuid",
    "message": "Saved version from Pipeline Builder",
    "backend": "Spark"
  },
  "snapshot": {
    "transforms": [ ... ],
    "inputs": [ ... ],
    "outputs": [ ... ],
    "parameters": [ ... ]
  }
}
```

### 1.4 Extraction Script

```python
import requests
import json
import os

FOUNDRY_HOST = os.environ.get("FOUNDRY_HOST")
FOUNDRY_TOKEN = os.environ.get("FOUNDRY_TOKEN")

def extract_pipeline(pipeline_rid: str) -> dict:
    """Extract full pipeline definition from Foundry API."""
    headers = {
        "Authorization": f"Bearer {FOUNDRY_TOKEN}",
        "Content-Type": "application/json"
    }
    
    # Get pipeline metadata
    response = requests.get(
        f"{FOUNDRY_HOST}/eddie/api/pipelines/{pipeline_rid}",
        headers=headers
    )
    response.raise_for_status()
    pipeline_data = response.json()
    
    # Get latest version snapshot
    version_id = pipeline_data.get("version", {}).get("id")
    if version_id:
        snapshot_response = requests.get(
            f"{FOUNDRY_HOST}/eddie/api/pipelines/{pipeline_rid}/versions/{version_id}/snapshot",
            headers=headers
        )
        snapshot_response.raise_for_status()
        pipeline_data["snapshot"] = snapshot_response.json()
    
    return pipeline_data

# Save extracted pipeline
pipeline = extract_pipeline("ri.eddie.main.pipeline.XXX")
with open("extracted_pipeline.json", "w") as f:
    json.dump(pipeline, f, indent=2)
```

---

## Phase 2: Normalize JSON Structure

### 2.1 Normalization Goals

Transform raw Palantir JSON into a canonical intermediate format:

| Raw Palantir | Normalized |
|--------------|------------|
| Nested expression trees | Flat derivation list |
| UUID-based transform IDs | Sequential stage numbering |
| RID-based dataset references | Resolved dataset names |
| Implicit column lineage | Explicit source→target mapping |

### 2.2 Normalized Schema

```json
{
  "pipeline_name": "string",
  "pipeline_rid": "string",
  "sources": [
    {
      "stage_id": "src_001",
      "dataset_rid": "ri.foundry.main.dataset.XXX",
      "dataset_name": "x_ndr_nokia_enb",
      "schema": [
        { "name": "COLUMN_A", "type": "string", "nullable": true }
      ]
    }
  ],
  "targets": [
    {
      "stage_id": "tgt_001",
      "dataset_rid": "ri.foundry.main.dataset.YYY",
      "dataset_name": "nr_nok_netaudit_output",
      "write_mode": "overwrite"
    }
  ],
  "stages": [
    {
      "stage_id": "tx_001",
      "stage_type": "transformer|join|aggregator|filter|sort|funnel|remove_duplicates",
      "inputs": ["src_001"],
      "outputs": ["tx_002"],
      "derivations": [
        { "output": "NEW_COL", "expression": "(Int32)In.OLD_COL", "type": "int32" }
      ],
      "config": { }
    }
  ],
  "links": [
    { "from": "src_001", "to": "tx_001", "link_name": "lnk_src_001_tx_001" }
  ]
}
```

### 2.3 Normalization Script

```python
def normalize_pipeline(raw_pipeline: dict) -> dict:
    """Convert Palantir JSON to normalized format."""
    normalized = {
        "pipeline_name": raw_pipeline["pipeline"]["name"],
        "pipeline_rid": raw_pipeline["pipeline"]["rid"],
        "sources": [],
        "targets": [],
        "stages": [],
        "links": []
    }
    
    snapshot = raw_pipeline.get("snapshot", {})
    
    # Process inputs → sources
    for idx, inp in enumerate(snapshot.get("inputs", [])):
        normalized["sources"].append({
            "stage_id": f"src_{idx+1:03d}",
            "dataset_rid": inp.get("datasetRid"),
            "dataset_name": resolve_rid_to_name(inp.get("datasetRid")),
            "alias": inp.get("alias"),
            "schema": []  # Infer from first transform
        })
    
    # Process outputs → targets
    for idx, out in enumerate(snapshot.get("outputs", [])):
        normalized["targets"].append({
            "stage_id": f"tgt_{idx+1:03d}",
            "dataset_rid": out.get("datasetRid"),
            "dataset_name": resolve_rid_to_name(out.get("datasetRid")),
            "alias": out.get("alias"),
            "write_mode": "overwrite"
        })
    
    # Process transforms → stages
    for idx, transform in enumerate(snapshot.get("transforms", [])):
        stage = convert_transform_to_stage(transform, idx)
        normalized["stages"].append(stage)
    
    # Build links from stage dependencies
    normalized["links"] = build_links(normalized)
    
    return normalized

def resolve_rid_to_name(rid: str) -> str:
    """Look up RID in rid_mapping.csv to get dataset name."""
    # Implementation: read from .cdo-aifc/data/rid_mapping.csv
    pass

def convert_transform_to_stage(transform: dict, idx: int) -> dict:
    """Convert Palantir transform to normalized stage."""
    transform_id = transform.get("transformId")
    stage_type_map = {
        "applyExpression": "transformer",
        "project": "transformer",
        "join": "join",
        "leftJoin": "join",
        "rightJoin": "join",
        "fullOuterJoin": "join",
        "aggregate": "aggregator",
        "filter": "filter",
        "dropDuplicates": "remove_duplicates",
        "union": "funnel",
        "sort": "sort"
    }
    
    return {
        "stage_id": f"tx_{idx+1:03d}",
        "stage_type": stage_type_map.get(transform_id, "transformer"),
        "original_id": transform.get("id"),
        "derivations": flatten_expressions(transform.get("arguments", {})),
        "config": extract_stage_config(transform)
    }
```

---

## Phase 3: Convert to DataStage Stages and Job Flows

### 3.1 Stage Type Mapping

| Normalized Type | DataStage Stage | OSH Stage Type |
|-----------------|-----------------|----------------|
| `transformer` | Transformer | `PxTransformer` |
| `join` | Join | `PxJoin` |
| `aggregator` | Aggregator | `PxAggregator` |
| `filter` | Filter | `PxFilter` |
| `sort` | Sort | `PxSort` |
| `funnel` | Funnel | `PxFunnel` |
| `remove_duplicates` | Remove Duplicates | `PxRemDup` |
| `source` | Sequential File / Cloud Object Storage | `PxSequentialFile` / `GCCOS` |
| `target` | Sequential File / Cloud Object Storage | `PxSequentialFile` / `GCCOS` |

### 3.2 DataStage Job Flow Structure

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Source 1   │────▶│ Transformer │────▶│   Join      │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                               │
┌─────────────┐                                │
│  Source 2   │────────────────────────────────┘
└─────────────┘                                │
                                               ▼
                                        ┌─────────────┐
                                        │   Target    │
                                        └─────────────┘
```

### 3.3 Expression Conversion Rules

| Normalized Expression | DataStage Derivation |
|----------------------|----------------------|
| `In.column_name` | `In.column_name` |
| `(Int32)In.col` | `(Int32)In.col` |
| `(VarChar(50))In.col` | `(VarChar(50))In.col` |
| `In.a + In.b` | `In.a + In.b` |
| `In.a : In.b` | `In.a : In.b` (string concat) |
| `If cond Then v1 Else v2` | `If cond Then v1 Else v2` |
| `IsNull(In.col)` | `IsNull(In.col)` |
| `NullToValue(In.col, def)` | `NullToValue(In.col, def)` |
| `Max(In.col)` | `Max(In.col)` |
| `TimestampFromSecondsSince(...)` | `TimestampFromSecondsSince(In.epoch/1000, 1970-01-01)` |

### 3.4 Join Configuration

```yaml
# Normalized join config
stage_type: join
join_type: left_outer  # inner | left_outer | right_outer | full_outer
left_input: tx_001
right_input: tx_002
join_keys:
  - left: "KEY_COL"
    right: "KEY_COL"
```

```
# DataStage Join Stage
Join Type: Left Outer
Left Link: lnk_tx_001_join_001
Right Link: lnk_tx_002_join_001
Key Expression: Left.KEY_COL = Right.KEY_COL
```

### 3.5 Aggregator Configuration

```yaml
# Normalized aggregator config
stage_type: aggregator
group_by:
  - "MARKET"
  - "REGION"
aggregations:
  - output: "total_count"
    function: "count"
    input: "*"
  - output: "max_date"
    function: "max"
    input: "LOADDATE"
```

```
# DataStage Aggregator Stage
Group By: MARKET, REGION
Derivations:
  total_count = Count(*)
  max_date = Max(In.LOADDATE)
```

---

## Phase 4: Generate Deployment Artifacts for watsonx.data IBM DataStage on Azure

### 4.1 Target Environment

**Platform**: IBM watsonx.data Integration (DataStage as a Service)
**Cloud**: Microsoft Azure
**Storage**: Azure Data Lake Storage Gen2 (ADLS)

### 4.2 Required Artifacts

| Artifact | Format | Purpose |
|----------|--------|---------|
| `{job_name}.dsx` | DSX (XML) | DataStage job export for import |
| `{job_name}.isx` | ISX (Binary) | Compiled job package |
| `{job_name}_params.json` | JSON | Runtime parameters |
| `{job_name}_connections.json` | JSON | Azure/ADLS connection definitions |
| `{job_name}_schema.json` | JSON | Column metadata per stage |
| `{job_name}_lineage.md` | Markdown | Data lineage documentation |
| `deploy_manifest.yaml` | YAML | Deployment configuration |

### 4.3 DSX Job Template

```xml
<?xml version="1.0" encoding="UTF-8"?>
<DSExport>
  <Header
    Name="{pipeline_name}"
    Description="Migrated from Palantir Foundry: {pipeline_rid}"
    ServerVersion="11.7"
    Locale="en_US"/>
  
  <Job Identifier="{job_id}" Type="Parallel">
    <Record Identifier="{job_id}" Type="JobDefn">
      <Property Name="Name" Value="{pipeline_name}"/>
      <Property Name="Category" Value="\\Jobs\\Migrated"/>
      <Property Name="JobType" Value="Parallel"/>
    </Record>
    
    <!-- Stage Definitions -->
    {{#each stages}}
    <Record Identifier="{{stage_id}}" Type="CustomStage">
      <Property Name="Name" Value="{{stage_id}}"/>
      <Property Name="StageType" Value="{{datastage_type}}"/>
      <Collection Name="Properties">
        {{#each properties}}
        <SubRecord>
          <Property Name="Name" Value="{{name}}"/>
          <Property Name="Value" Value="{{value}}"/>
        </SubRecord>
        {{/each}}
      </Collection>
    </Record>
    {{/each}}
    
    <!-- Link Definitions -->
    {{#each links}}
    <Record Identifier="{{link_name}}" Type="Link">
      <Property Name="Name" Value="{{link_name}}"/>
      <Property Name="SourceStage" Value="{{from}}"/>
      <Property Name="TargetStage" Value="{{to}}"/>
      <Collection Name="Columns">
        {{#each columns}}
        <SubRecord>
          <Property Name="Name" Value="{{name}}"/>
          <Property Name="SqlType" Value="{{sql_type}}"/>
          <Property Name="Precision" Value="{{precision}}"/>
          <Property Name="Scale" Value="{{scale}}"/>
          <Property Name="Nullable" Value="{{nullable}}"/>
        </SubRecord>
        {{/each}}
      </Collection>
    </Record>
    {{/each}}
    
  </Job>
</DSExport>
```

### 4.4 Azure ADLS Connection Configuration

```json
{
  "connection_name": "ADLS_{{environment}}",
  "connection_type": "AzureDataLakeStorageGen2",
  "properties": {
    "storage_account_name": "{{AZURE_STORAGE_ACCOUNT}}",
    "container_name": "{{AZURE_CONTAINER}}",
    "authentication_type": "ServicePrincipal",
    "tenant_id": "{{AZURE_TENANT_ID}}",
    "client_id": "{{AZURE_CLIENT_ID}}",
    "client_secret_vault_key": "azure-sp-secret",
    "endpoint_suffix": "dfs.core.windows.net"
  },
  "paths": {
    "input_base": "abfss://{{container}}@{{storage_account}}.dfs.core.windows.net/input",
    "output_base": "abfss://{{container}}@{{storage_account}}.dfs.core.windows.net/output"
  }
}
```

### 4.5 Runtime Parameters

```json
{
  "job_name": "{{pipeline_name}}",
  "parameters": [
    {
      "name": "STORAGE_ACCOUNT",
      "type": "string",
      "default": "datalakeeastus2prd",
      "description": "Azure Storage Account name"
    },
    {
      "name": "CONTAINER",
      "type": "string",
      "default": "otis-poc",
      "description": "Azure Blob container name"
    },
    {
      "name": "INPUT_PATH",
      "type": "string",
      "default": "/input",
      "description": "Input folder path in ADLS"
    },
    {
      "name": "OUTPUT_PATH",
      "type": "string",
      "default": "/output",
      "description": "Output folder path in ADLS"
    },
    {
      "name": "PROCESSING_DATE",
      "type": "date",
      "default": "$CURRENT_DATE",
      "description": "Processing date for incremental loads"
    }
  ]
}
```

### 4.6 Deployment Manifest

```yaml
# deploy_manifest.yaml
apiVersion: datastage.ibm.com/v1
kind: DataStageJob
metadata:
  name: {{pipeline_name}}
  namespace: watsonx-data
  labels:
    migrated-from: palantir-foundry
    source-rid: {{pipeline_rid}}
    
spec:
  job:
    file: {{pipeline_name}}.dsx
    category: /Jobs/Migrated/Palantir
    
  connections:
    - name: ADLS_Production
      type: AzureDataLakeStorageGen2
      configRef: adls-connection-config
      
  parameters:
    - name: STORAGE_ACCOUNT
      valueFrom:
        configMapKeyRef:
          name: azure-config
          key: storage_account
    - name: CONTAINER
      value: otis-poc
      
  schedule:
    enabled: false
    cron: "0 6 * * *"  # Daily at 6 AM UTC
    
  resources:
    parallelism: 4
    memory: "8Gi"
    
  notifications:
    onFailure:
      - type: email
        recipients: ["data-ops@company.com"]
```

### 4.7 Deployment Script

```bash
#!/bin/bash
# deploy_to_datastage.sh

# Environment variables required:
# DATASTAGE_HOST, DATASTAGE_USER, DATASTAGE_PASSWORD
# AZURE_TENANT_ID, AZURE_CLIENT_ID, AZURE_CLIENT_SECRET

JOB_NAME="${1:-migrated_pipeline}"
DSX_FILE="${JOB_NAME}.dsx"

echo "Deploying ${JOB_NAME} to IBM DataStage on Azure..."

# 1. Authenticate to DataStage
TOKEN=$(curl -s -X POST "${DATASTAGE_HOST}/v3/auth/token" \
  -H "Content-Type: application/json" \
  -d '{"username":"'${DATASTAGE_USER}'","password":"'${DATASTAGE_PASSWORD}'"}' \
  | jq -r '.token')

# 2. Import DSX job
curl -X POST "${DATASTAGE_HOST}/v3/ds_jobs/import" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@${DSX_FILE}" \
  -F "conflict_resolution=replace"

# 3. Configure connections
curl -X PUT "${DATASTAGE_HOST}/v3/connections/ADLS_Production" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d @${JOB_NAME}_connections.json

# 4. Set runtime parameters
curl -X PUT "${DATASTAGE_HOST}/v3/ds_jobs/${JOB_NAME}/parameters" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d @${JOB_NAME}_params.json

# 5. Compile job
curl -X POST "${DATASTAGE_HOST}/v3/ds_jobs/${JOB_NAME}/compile" \
  -H "Authorization: Bearer ${TOKEN}"

echo "Deployment complete: ${JOB_NAME}"
```

---

## Phase 5: Validation and Testing

### 5.1 Pre-Deployment Validation

```yaml
validation_checks:
  - name: Schema Compatibility
    check: All source schemas match ADLS parquet schemas
    
  - name: Connection Test
    check: ADLS connection successful with service principal
    
  - name: Expression Syntax
    check: All DataStage derivations compile without errors
    
  - name: Join Key Existence
    check: All join keys exist in both input schemas
    
  - name: Type Compatibility
    check: No implicit type conversions that lose precision
```

### 5.2 Test Run Configuration

```json
{
  "test_mode": true,
  "sample_size": 1000,
  "validate_outputs": true,
  "compare_with_source": {
    "enabled": true,
    "tolerance": {
      "row_count_diff_percent": 0.01,
      "column_value_match_percent": 99.99
    }
  }
}
```

---

## Configuration Files

| File | Purpose |
|------|---------|
| `.cdo-aifc/data/rid_mapping.csv` | Palantir RID → dataset name mapping |
| `.cdo-aifc/templates/datastage/connection-config.yaml` | Azure ADLS connection template |
| `.cdo-aifc/templates/datastage/job-template.dsx` | DSX job template |
| `ontology/pipeline.json` | Local copy of extracted pipeline (optional) |

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `FOUNDRY_HOST` | Palantir Foundry stack URL |
| `FOUNDRY_TOKEN` | Palantir API bearer token |
| `DATASTAGE_HOST` | IBM DataStage API endpoint |
| `DATASTAGE_USER` | DataStage username |
| `DATASTAGE_PASSWORD` | DataStage password |
| `AZURE_TENANT_ID` | Azure AD tenant ID |
| `AZURE_CLIENT_ID` | Azure service principal client ID |
| `AZURE_CLIENT_SECRET` | Azure service principal secret |
| `AZURE_STORAGE_ACCOUNT` | ADLS storage account name |
| `AZURE_CONTAINER` | ADLS container name |

---

## Example Usage

```
/palantir-to-datastage-azure ri.eddie.main.pipeline.19f85d48-afd4-44f7-81d9-c3e95c3e1043
```

**Outputs:**
```
datastage_deploy/
├── netaudit_project.dsx              # DataStage job export
├── netaudit_project_params.json      # Runtime parameters
├── netaudit_project_connections.json # Azure ADLS connections
├── netaudit_project_schema.json      # Column schemas
├── netaudit_project_lineage.md       # Data lineage docs
├── deploy_manifest.yaml              # K8s deployment manifest
└── deploy_to_datastage.sh            # Deployment script
```

---

## Validation Checklist

- [ ] Palantir API authentication successful
- [ ] Pipeline JSON extracted and saved locally
- [ ] JSON normalized to intermediate format
- [ ] All transforms mapped to DataStage stages
- [ ] All expressions converted to DataStage derivations
- [ ] DSX job file generated and validated
- [ ] Azure ADLS connections configured
- [ ] Runtime parameters defined
- [ ] Deployment manifest created
- [ ] Test run completed successfully
- [ ] Row counts match between Palantir and DataStage outputs
