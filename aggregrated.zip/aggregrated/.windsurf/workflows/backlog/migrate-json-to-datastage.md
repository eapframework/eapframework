---
description: Convert Palantir Pipeline Builder JSON to IBM Watson DataStage jobs
---

# Palantir Pipeline JSON to Watson DataStage Migration

Convert Palantir Pipeline Builder JSON exports to IBM Watson DataStage parallel jobs by parsing the structured transform definitions.

## Input

**Required**: Path to Palantir Pipeline Builder JSON export file
# put the endpoint here
```
/migrate-json-to-datastage <path_to_pipeline.json>
```

Example: `/migrate-json-to-datastage ontology/pipeline.json`

## JSON Structure Overview

```json
{
  "pipeline": {
    "rid": "ri.eddie.main.pipeline.XXX",
    "name": "Pipeline_Name"
  },
  "sandbox": {
    "id": "...",
    "name": "Main",
    "backingBranch": "master"
  },
  "version": {
    "id": "...",
    "message": "Saved version from Pipeline Builder",
    "backend": "Spark"
  },
  "snapshot": {
    "transforms": [
      {
        "id": "uuid",
        "transformId": "applyExpression|join|project|aggregate|filter|...",
        "transformVersion": { "major": 1 },
        "arguments": {
          "expression": { ... },
          "dataset": { "parameterId": "..." }
        }
      }
    ],
    "inputs": [
      {
        "datasetRid": "ri.foundry.main.dataset.XXX",
        "alias": "input_alias"
      }
    ],
    "outputs": [
      {
        "datasetRid": "ri.foundry.main.dataset.YYY",
        "alias": "output_alias"
      }
    ]
  }
}
```

## Execution Steps

### 1. Extract Pipeline Metadata
```
Pipeline Name: snapshot.pipeline.name
Pipeline RID: snapshot.pipeline.rid
Backend: snapshot.version.backend (should be "Spark")
```

### 2. Parse Inputs → DataStage Source Stages
For each entry in `snapshot.inputs`:
```
Stage Name: ds_{alias}
Stage Type: Sequential File / Dataset / DB2 Connector
Dataset RID: {datasetRid}
Resolved Path: Look up RID in rid_mapping.csv → ADLS path or table name
```

### 3. Parse Outputs → DataStage Target Stages
For each entry in `snapshot.outputs`:
```
Stage Name: tgt_{alias}
Stage Type: Sequential File / Dataset / DB2 Connector
Dataset RID: {datasetRid}
Write Mode: Overwrite
```

### 4. Parse Transforms → DataStage Stages

Iterate `snapshot.transforms` array in order and map each `transformId`:

#### Transform ID → DataStage Stage Mapping

| Palantir transformId | DataStage Stage | Description |
|---------------------|-----------------|-------------|
| `applyExpression` | **Transformer** | Column derivation/transformation |
| `project` | **Transformer** | Column selection (passthrough) |
| `join` | **Join** | Inner join |
| `leftJoin` | **Join** | Left outer join |
| `rightJoin` | **Join** | Right outer join |
| `fullOuterJoin` | **Join** | Full outer join |
| `aggregate` | **Aggregator** | Group by with aggregation functions |
| `filter` | **Filter** | Row filtering based on condition |
| `dropDuplicates` | **Remove Duplicates** | Deduplication on key columns |
| `union` | **Funnel** | Combine multiple inputs |
| `sort` | **Sort** | Order by columns |
| `limit` | **Sample** | Limit row count |

### 5. Parse Expression Trees → DataStage Derivations

Each transform's `arguments.expression` contains nested expression trees:

#### Expression ID → DataStage Expression Mapping

| Palantir expressionId | DataStage Expression | Example |
|----------------------|----------------------|---------|
| `alias` | Column rename | `Out.new_col = In.old_col` |
| `cast` | Type conversion | `Out.col = (Int32)In.col` |
| `literal` | Constant value | `Out.col = "value"` or `Out.col = 123` |
| `column` | Column reference | `In.column_name` |
| `add` | Addition | `In.a + In.b` |
| `subtract` | Subtraction | `In.a - In.b` |
| `multiply` | Multiplication | `In.a * In.b` |
| `divide` | Division | `In.a / In.b` |
| `concat` | String concatenation | `In.a : In.b` |
| `when` / `otherwise` | Conditional | `If In.cond Then val1 Else val2` |
| `and` | Logical AND | `In.a And In.b` |
| `or` | Logical OR | `In.a Or In.b` |
| `not` | Logical NOT | `Not(In.a)` |
| `isNull` | Null check | `IsNull(In.col)` |
| `isNotNull` | Not null check | `IsNotNull(In.col)` |
| `coalesce` | Null coalesce | `NullToValue(In.col, default)` |
| `equals` | Equality | `In.a = In.b` |
| `notEquals` | Inequality | `In.a <> In.b` |
| `greaterThan` | Greater than | `In.a > In.b` |
| `lessThan` | Less than | `In.a < In.b` |
| `between` | Range check | `In.col >= low And In.col <= high` |
| `max` | Maximum | `Max(In.col)` |
| `min` | Minimum | `Min(In.col)` |
| `sum` | Sum | `Sum(In.col)` |
| `avg` | Average | `Mean(In.col)` |
| `count` | Count | `Count(In.col)` |
| `countDistinct` | Distinct count | `Count(Distinct In.col)` |

### 6. Type Mapping (Palantir → DataStage)

| Palantir Type | DataStage Type |
|---------------|----------------|
| `string` | `VarChar(n)` / `String` |
| `integer` | `Int32` |
| `long` | `Int64` |
| `double` | `Double` |
| `float` | `Float` |
| `boolean` | `Int8` (0/1) |
| `timestamp` | `Timestamp` |
| `date` | `Date` |
| `decimal` | `Decimal(p,s)` |
| `binary` | `Binary` |

### 7. Generate DataStage Job Components

#### 7.1 Source Stage Template
```
BEGIN DSRECORD
   Identifier "ds_{input_alias}"
   OLEType "CTransformerStage"
   StageType "PxSequentialFile"
   FileName "{resolved_path}"
   Schema: {inferred_from_first_transform}
END DSRECORD
```

#### 7.2 Transformer Stage Template
```
BEGIN DSRECORD
   Identifier "tx_{transform_id}"
   OLEType "CTransformerStage"
   StageType "PxTransformer"
   Derivations:
      {column}: {expression}
END DSRECORD
```

#### 7.3 Join Stage Template
```
BEGIN DSRECORD
   Identifier "join_{id}"
   OLEType "CTransformerStage"
   StageType "PxJoin"
   JoinType "{inner|left_outer|right_outer|full_outer}"
   JoinKeys: {key_columns}
END DSRECORD
```

#### 7.4 Aggregator Stage Template
```
BEGIN DSRECORD
   Identifier "agg_{id}"
   OLEType "CTransformerStage"
   StageType "PxAggregator"
   GroupBy: {group_columns}
   Aggregations:
      {output_col}: {AggFunc}({input_col})
END DSRECORD
```

#### 7.5 Target Stage Template
```
BEGIN DSRECORD
   Identifier "tgt_{output_alias}"
   OLEType "CTransformerStage"
   StageType "PxSequentialFile"
   FileName "{resolved_path}"
   WriteMode "Overwrite"
END DSRECORD
```

## Output Artifacts

| Artifact | Description |
|----------|-------------|
| `{pipeline_name}.dsx` | DataStage job export file |
| `{pipeline_name}_schema.json` | Column schemas per stage |
| `{pipeline_name}_mapping.md` | Source→Target column lineage |
| `{pipeline_name}_stages.yaml` | Stage inventory with types |

## Configuration Files

| File | Purpose |
|------|---------|
| `ontology/pipeline.json` | Palantir Pipeline Builder JSON export |
| `.cdo-aifc/data/rid_mapping.csv` | RID to dataset path/table mapping |
| `.cdo-aifc/templates/03-data-engineering/datastage/connection-config.yaml` | DataStage connection settings |

## DataStage-Specific Considerations

1. **Schema Propagation**: DataStage requires explicit schemas; infer from expression types
2. **Null Handling**: Use `IsNull()` / `SetNull()` / `NullToValue()` functions
3. **Date/Timestamp Conversion**:
   - Epoch millis → `TimestampFromSecondsSince(In.col/1000, 1970-01-01)`
   - Date formatting → `DateToString(In.col, "%Y%m%d")`
4. **Geo Point**: Store as separate LAT/LON columns or `In.LONGITUDE:":":In.LATITUDE`
5. **Partitioning**: Configure hash partitioning on join keys for performance
6. **Link Naming**: Use `lnk_{source}_{target}` convention

## Common Expression Patterns

### Conditional (when/otherwise)
```json
// Palantir JSON
{
  "expressionId": "when",
  "arguments": {
    "condition": { "type": "column", "column": { "columnName": "STATUS" } },
    "value": { "type": "literal", "literal": { "string": { "value": "ACTIVE" } } },
    "otherwise": { "type": "literal", "literal": { "string": { "value": "INACTIVE" } } }
  }
}
```
```
// DataStage Transformer
If In.STATUS Then "ACTIVE" Else "INACTIVE"
```

### Type Cast
```json
// Palantir JSON
{
  "expressionId": "cast",
  "arguments": {
    "expression": { "type": "column", "column": { "columnName": "CMA" } },
    "type": { "type": "string" }
  }
}
```
```
// DataStage Transformer
(VarChar(50))In.CMA
```

### Aggregation
```json
// Palantir JSON
{
  "transformId": "aggregate",
  "arguments": {
    "groupBy": [],
    "aggregations": [
      { "expressionId": "max", "column": "loaddate_", "alias": "loaddate_max" }
    ]
  }
}
```
```
// DataStage Aggregator
Group By: (none)
Aggregation: loaddate_max = Max(loaddate_)
```

## Example Usage

```
/migrate-json-to-datastage ontology/pipeline.json
```

Outputs for `NetAudit_project` pipeline:
- `datastage_jobs/netaudit_project.dsx`
- `datastage_jobs/netaudit_project_schema.json`
- `datastage_jobs/netaudit_project_mapping.md`
- `datastage_jobs/netaudit_project_stages.yaml`

## Validation Checklist

- [ ] All `snapshot.inputs` mapped to Source stages
- [ ] All `snapshot.outputs` mapped to Target stages
- [ ] All `snapshot.transforms` converted to appropriate DataStage stages
- [ ] Expression trees fully traversed and converted
- [ ] Type casts applied correctly
- [ ] Join keys and types preserved
- [ ] Aggregation functions mapped correctly
- [ ] Column lineage documented in mapping file
- [ ] Schemas defined for all stage links
