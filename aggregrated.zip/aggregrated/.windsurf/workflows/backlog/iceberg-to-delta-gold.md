description: Reusable Databricks pipeline pattern to move data from Iceberg raw to Delta gold

# Iceberg → Delta (Gold) Workflow

This workflow provides a reusable pattern and a Databricks pipeline template to move CDC-style data from Iceberg (raw) into a Delta-based Bronze→Silver→Gold logical pipeline.

Key features
- Read from Iceberg raw tables (stream or batch)
- Bronze: cleansing, dedupe, Delta merge for CDC
- Silver: enrichment, SCD Type 2 handling
- Gold: analytic aggregates / materialised views

Outputs
- Databricks pipeline script: `databricks/pipelines/iceberg_to_delta_template.py`
- Job snippet for Databricks Jobs UI (see file header comments)

How to use
1. Copy `databricks/pipelines/iceberg_to_delta_template.py` into your Databricks workspace (as a notebook or workspace file).
2. Configure inputs via Databricks widgets or job parameters: `raw_table`, `bronze_table`, `silver_table`, `gold_tables` and schedule as required.
3. Create 3 jobs or a single orchestrator job with tasks for: Raw→Bronze (streaming or frequent batch), Bronze→Silver (hourly), Silver→Gold (daily).

Notes
- The template uses `DeltaTable` merges for idempotent CDC handling and Liquid clustering / OPTIMIZE suggestions for BI tables.
- Adjust schema, join logic and SCD conditions to match your domain model.
