# Ingestion Specialist Archetype

## Overview

The **Ingestion Specialist** is a configuration-driven PySpark archetype that extracts data from any source system and writes schema-preserving Parquet files to the Azure ADLS Gen2 Raw zone (Bronze layer).

**Key Principle**: Zero transformations. This archetype preserves source schemas exactly, appending only metadata columns for lineage tracking.

---

## Quick Start

### 1. Scaffold New Ingestion Pipeline

```bash
/scaffold source=snowflake_sales dataset=fact_orders load_type=incremental watermark_column=updated_at
```

**What It Does**:
- Generates `generated/ingest_raw/ingest_raw.py` (PySpark ingestion script)
- Generates `generated/ingest_raw/config.py` (connection configuration)
- Generates `generated/ingest_raw/README.md` (deployment guide)

### 2. Test Configuration

```bash
/test config_file=config.yaml
```

**What It Does**:
- Validates YAML schema
- Tests connection to source system
- Verifies watermark column exists (for incremental)
- Checks ADLS write permissions

### 3. Compare Strategies

```bash
/compare source=oracle_hr dataset=employees
```

**What It Does**:
- Compares JDBC vs Spark Reader adapters
- Analyzes full vs incremental trade-offs
- Recommends partitioning strategy

### 4. Debug Failures

```bash
/debug error="Connection refused" source=snowflake
```

**What It Does**:
- Diagnoses connection, permission, schema errors
- Suggests resolution steps
- Provides runnable validation queries

### 5. Document Pipeline

```bash
/document dataset=fact_orders output=runbook.md
```

**What It Does**:
- Generates operational runbook
- Documents connection setup
- Includes troubleshooting guide

### 6. Refactor Code

```bash
/refactor target=config consolidation=True
```

**What It Does**:
- Consolidates duplicate connection configs
- Extracts reusable adapter functions
- Optimizes JDBC partitioning

---

## Adapter Families

### JDBC (Generic Database Connector)

**Supported Systems**: Snowflake, Oracle, Postgres, SQL Server, DB2, MySQL, Teradata

**Configuration Example**:
```yaml
source:
  adapter: jdbc
  system: snowflake_sales
  connection:
    name: snowflake_prod
    options:
      url: "jdbc:snowflake://<account>.snowflakecomputing.com"
      user: "${SNOWFLAKE_USER}"
      password: "${SNOWFLAKE_PASSWORD}"
      warehouse: "COMPUTE_WH"
      database: "SALES_DB"
      schema: "PUBLIC"
  read:
    mode: table
    table: "SALES_DB.PUBLIC.FACT_ORDERS"
    options:
      fetchSize: 10000
    partitioning:
      enabled: true
      column: "ORDER_ID"
      lower_bound: 1
      upper_bound: 1000000
      num_partitions: 16
```

### Spark Reader (File-Based Connector)

**Supported Formats**: Parquet, CSV, JSON, Avro, Delta, ADLS, S3

**Configuration Example**:
```yaml
source:
  adapter: spark_reader
  system: adls_landing
  read:
    mode: path
    path: "abfss://landing@storage.dfs.core.windows.net/employees/*.parquet"
    options:
      format: parquet
      mergeSchema: true
```

### Custom (Specialized Connectors)

**Use Cases**: Kafka, REST APIs, SaaS connectors requiring custom logic

**Configuration Example**:
```yaml
source:
  adapter: custom
  system: palantir_api
  connection:
    name: palantir_prod
    options:
      base_url: "https://palantir.company.com/api"
      auth_token: "${PALANTIR_TOKEN}"
  read:
    mode: query
    query: "/datasets/ri.foundry.dataset.xyz/files"
```

---

## Load Types

### Full Load

**When to Use**:
- Initial data load (day 0)
- Small datasets (< 10M rows)
- No reliable watermark column
- Source data changes are unpredictable

**Configuration**:
```yaml
load:
  type: full
```

**Behavior**:
- Reads entire source table/file
- Overwrites existing Raw data (`write_mode: overwrite`)
- No filtering applied

### Incremental Load

**When to Use**:
- Large datasets (> 10M rows)
- Reliable watermark column exists (`updated_at`, `created_at`, `load_date`)
- Daily/hourly refresh cadence
- Cost optimization required

**Configuration**:
```yaml
load:
  type: incremental
  watermark_column: "updated_at"
  start_value: "2026-01-01T00:00:00Z"
```

**Behavior**:
- Reads only new/changed rows: `WHERE updated_at >= '2026-01-01T00:00:00Z'`
- Appends to existing Raw data (`write_mode: append`)
- Stores watermark value for next run

---

## Output Schema

### Metadata Columns

Every ingested dataset has these columns appended:

| Column | Type | Description |
|--------|------|-------------|
| `_ingested_at` | `timestamp` | UTC timestamp when ingestion ran |
| `_source_system` | `string` | Logical source system name (e.g., `snowflake_sales`) |

**Example Output Schema**:
```
root
 |-- order_id: long (nullable = true)
 |-- customer_id: long (nullable = true)
 |-- order_date: date (nullable = true)
 |-- total_amount: decimal(18,2) (nullable = true)
 |-- _ingested_at: timestamp (nullable = false)
 |-- _source_system: string (nullable = false)
```

---

## Output Path Convention

All ingested data writes to:
```
abfss://raw@<storage>.dfs.core.windows.net/raw/<dataset_name>/
```

**Examples**:
- `raw/fact_orders/` (Snowflake sales table)
- `raw/employees/` (Oracle HR table)
- `raw/customer_events/` (Kafka stream)

**File Structure**:
```
raw/
  fact_orders/
    part-00000-<uuid>.snappy.parquet
    part-00001-<uuid>.snappy.parquet
    ...
  employees/
    part-00000-<uuid>.snappy.parquet
```

---

## Workflows

### scaffold-ingestion-specialist
**Trigger**: `/scaffold`  
**Purpose**: Generate PySpark ingestion code and configuration  
**Output**: `generated/ingest_raw/` with Python scripts, config files, README

### test-ingestion-specialist
**Trigger**: `/test`  
**Purpose**: Validate configuration and test connections  
**Output**: pytest results, connection validation report

### compare-ingestion-specialist
**Trigger**: `/compare`  
**Purpose**: Compare ingestion strategies (adapter, load type, partitioning)  
**Output**: Decision table with trade-offs and recommendations

### debug-ingestion-specialist
**Trigger**: `/debug`  
**Purpose**: Diagnose ingestion failures (connection, schema, permissions)  
**Output**: Root cause analysis, resolution steps, validation queries

### document-ingestion-specialist
**Trigger**: `/document`  
**Purpose**: Generate operational documentation and runbooks  
**Output**: Markdown guides with examples and troubleshooting

### refactor-ingestion-specialist
**Trigger**: `/refactor`  
**Purpose**: Improve existing ingestion code (consolidate configs, optimize performance)  
**Output**: Refactored code with improvement report

---

## Common Use Cases

### Use Case 1: Onboard New Snowflake Table

```bash
# 1. Scaffold pipeline
/scaffold source=snowflake_sales dataset=fact_orders adapter=jdbc load_type=incremental watermark_column=updated_at

# 2. Test connection
/test config_file=generated/ingest_raw/config.yaml

# 3. Run ingestion (manually in Databricks)
spark-submit generated/ingest_raw/ingest_raw.py --config generated/ingest_raw/config.yaml
```

### Use Case 2: Debug Connection Failure

```bash
# Error: java.sql.SQLException: Connection refused
/debug error="Connection refused" source=snowflake adapter=jdbc

# Agent provides:
# - JDBC URL validation
# - Firewall rule checklist
# - Service principal permission verification
# - Test query to run in SQL client
```

### Use Case 3: Optimize JDBC Partitioning

```bash
# Current: Single partition (slow)
/compare source=oracle_hr dataset=employees current_partitions=1

# Agent recommends:
# - Enable partitioning on ORDER_ID
# - Set num_partitions=16 (based on data volume)
# - Provides optimized config.yaml
```

---

## Troubleshooting

### Connection Refused

**Symptom**:
```
java.sql.SQLException: Connection refused
```

**Resolution**:
1. Verify JDBC URL format: `jdbc:snowflake://<account>.snowflakecomputing.com`
2. Check firewall rules (allow Databricks IP ranges)
3. Confirm service principal has network access
4. Test connection from SQL client on same network

### Schema Mismatch

**Symptom**:
```
pyspark.sql.utils.AnalysisException: cannot resolve 'order_id'
```

**Resolution**:
1. Query source schema: `DESCRIBE TABLE SALES_DB.PUBLIC.FACT_ORDERS`
2. Check case sensitivity (Snowflake is case-insensitive, Spark is case-sensitive)
3. Verify column exists in source
4. Update config.yaml with correct column names

### Watermark Column Missing

**Symptom**:
```
AttributeError: 'NoneType' object has no attribute 'cast'
```

**Resolution**:
1. Verify watermark column exists: `SELECT updated_at FROM table LIMIT 1`
2. Check data type (must be date/timestamp)
3. Confirm column name spelling
4. Ensure load type is `incremental` in config.yaml

### Permission Denied

**Symptom**:
```
403 Forbidden: This request is not authorized
```

**Resolution**:
1. Grant Storage Blob Data Contributor role to service principal
2. Verify ABFS path format: `abfss://raw@storage.dfs.core.windows.net`
3. Check Azure AD token expiration
4. Confirm storage account firewall rules

---

## Performance Tuning

### JDBC Partitioning

**Problem**: Single-partition read is slow (> 30 minutes)

**Solution**:
```yaml
partitioning:
  enabled: true
  column: "ORDER_ID"  # Numeric column with uniform distribution
  lower_bound: 1
  upper_bound: 1000000
  num_partitions: 16  # = cluster cores * 2
```

**Impact**: Read time reduced from 45 min → 8 min

### File Size Optimization

**Problem**: Too many small files (< 10MB each)

**Solution**:
```python
df.coalesce(16).write.parquet(output_path)
```

**Impact**: Reduced 10,000 files → 16 files (50-100MB each)

---

## Templates

### env-config.yaml (Production)

Complete configuration with production settings, connection pools, error handling.

### dev.yaml (Development)

Lightweight configuration with reduced partitioning, debug logging, sample data limits.

---

**End of README**
