---
description: Validate ingestion configuration and test source connections
glyphEnabled: true
glyph: test
---

User input: $ARGUMENTS

## Context

You are validating a **PySpark ingestion pipeline configuration** before executing data extraction. This workflow prevents runtime failures by catching configuration errors, connection issues, and schema mismatches early.

**Core Validations**:
- YAML schema validation
- Source connection testing
- Watermark column verification (incremental loads)
- ADLS write permission checks
- JDBC driver availability (JDBC adapter)

---

## Expected User Input

The user will provide:
1. **Configuration file**: `config_file=config.yaml` or `config=generated/ingest_raw/config.yaml`
2. **Interactive mode**: `/test` (searches for config.yaml in current directory)

---

## Step 1: Locate Configuration File

### Search Strategy

1. If `config_file` or `config` parameter provided, use that path
2. Otherwise, search in order:
   - `generated/ingest_raw/config.yaml`
   - `config.yaml` (current directory)
   - `configs/ingest/<dataset>/config.yaml`

**If not found**:
```
❌ Configuration file not found.

Please provide config file path:
   /test config_file=path/to/config.yaml

Or scaffold a new pipeline first:
   /scaffold source=<source> dataset=<dataset>
```

---

## Step 2: Validate YAML Schema

### Load and Parse YAML

```python
import yaml
from jsonschema import validate, ValidationError

def load_config(config_path: str) -> dict:
    """Load and validate YAML configuration."""
    try:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML syntax: {e}")
    
    return config
```

### Schema Validation

Required fields by adapter type:

#### JDBC Adapter Schema
```json
{
  "type": "object",
  "required": ["source", "load", "target"],
  "properties": {
    "source": {
      "type": "object",
      "required": ["adapter", "system", "connection", "read"],
      "properties": {
        "adapter": {"enum": ["jdbc"]},
        "system": {"type": "string"},
        "connection": {
          "type": "object",
          "required": ["name", "options"],
          "properties": {
            "options": {
              "type": "object",
              "required": ["url", "user", "password"]
            }
          }
        },
        "read": {
          "type": "object",
          "required": ["mode"],
          "properties": {
            "mode": {"enum": ["table", "query"]},
            "table": {"type": "string"},
            "query": {"type": "string"}
          }
        }
      }
    },
    "load": {
      "type": "object",
      "required": ["type"],
      "properties": {
        "type": {"enum": ["full", "incremental"]},
        "watermark_column": {"type": "string"},
        "start_value": {"type": "string"}
      }
    },
    "target": {
      "type": "object",
      "required": ["raw_base_path", "dataset_name", "file_format", "write_mode"],
      "properties": {
        "raw_base_path": {"type": "string", "pattern": "^abfss://"},
        "dataset_name": {"type": "string"},
        "file_format": {"enum": ["parquet"]},
        "write_mode": {"enum": ["append", "overwrite"]}
      }
    }
  }
}
```

#### Spark Reader Adapter Schema
```json
{
  "source": {
    "adapter": {"enum": ["spark_reader"]},
    "read": {
      "required": ["mode", "path", "options"],
      "properties": {
        "mode": {"enum": ["path"]},
        "path": {"type": "string"},
        "options": {
          "required": ["format"],
          "properties": {
            "format": {"enum": ["parquet", "csv", "json", "avro", "delta"]}
          }
        }
      }
    }
  }
}
```

### Validation Function

```python
def validate_schema(config: dict):
    """Validate configuration against schema."""
    adapter = config['source']['adapter']
    
    # Check adapter-specific requirements
    if adapter == 'jdbc':
        assert 'url' in config['source']['connection']['options'], \
            "JDBC adapter requires 'url' in connection.options"
        assert 'user' in config['source']['connection']['options'], \
            "JDBC adapter requires 'user' in connection.options"
        assert 'password' in config['source']['connection']['options'], \
            "JDBC adapter requires 'password' in connection.options"
        
        read_mode = config['source']['read']['mode']
        if read_mode == 'table':
            assert 'table' in config['source']['read'], \
                "JDBC table mode requires 'table' field"
        elif read_mode == 'query':
            assert 'query' in config['source']['read'], \
                "JDBC query mode requires 'query' field"
    
    elif adapter == 'spark_reader':
        assert 'path' in config['source']['read'], \
            "Spark reader requires 'path' field"
        assert 'format' in config['source']['read']['options'], \
            "Spark reader requires 'format' in options"
    
    # Check incremental load requirements
    if config['load']['type'] == 'incremental':
        assert 'watermark_column' in config['load'], \
            "Incremental load requires 'watermark_column'"
        assert config['load']['watermark_column'], \
            "watermark_column cannot be empty"
    
    print("✅ Schema validation passed")
```

---

## Step 3: Test Source Connection

### JDBC Connection Test

```python
def test_jdbc_connection(config: dict):
    """Test JDBC connection without reading data."""
    from pyspark.sql import SparkSession
    
    spark = SparkSession.builder.appName("ConnectionTest").getOrCreate()
    
    conn_opts = config['source']['connection']['options']
    
    # Test query: SELECT 1
    test_options = {
        "url": conn_opts['url'],
        "user": conn_opts['user'],
        "password": conn_opts['password'],
        "query": "SELECT 1 AS test_connection"
    }
    
    try:
        df = spark.read.format("jdbc").options(**test_options).load()
        result = df.collect()
        
        if result[0]['test_connection'] == 1:
            print(f"✅ JDBC connection successful: {conn_opts['url']}")
            return True
        else:
            print(f"❌ JDBC connection returned unexpected result")
            return False
    
    except Exception as e:
        print(f"❌ JDBC connection failed: {str(e)}")
        print(f"\n🔍 Troubleshooting:")
        print(f"   - Verify URL format: {conn_opts['url']}")
        print(f"   - Check credentials (user: {conn_opts['user']})")
        print(f"   - Confirm firewall rules allow Databricks IP")
        print(f"   - Test from SQL client on same network")
        return False
```

### Spark Reader Path Test

```python
def test_spark_reader_path(config: dict):
    """Test if file path is accessible."""
    from pyspark.sql import SparkSession
    
    spark = SparkSession.builder.appName("PathTest").getOrCreate()
    
    path = config['source']['read']['path']
    
    try:
        # List files at path
        files = spark._jvm.org.apache.hadoop.fs.FileSystem.get(
            spark._jsc.hadoopConfiguration()
        ).listStatus(
            spark._jvm.org.apache.hadoop.fs.Path(path)
        )
        
        file_count = len(files)
        print(f"✅ Path accessible: {path}")
        print(f"   Files found: {file_count}")
        return True
    
    except Exception as e:
        print(f"❌ Path not accessible: {path}")
        print(f"   Error: {str(e)}")
        print(f"\n🔍 Troubleshooting:")
        print(f"   - Verify path format (abfss://, s3://, etc.)")
        print(f"   - Check storage account permissions")
        print(f"   - Confirm path exists")
        return False
```

---

## Step 4: Verify Watermark Column (Incremental Loads)

### Watermark Column Existence Test

```python
def test_watermark_column(config: dict, spark: SparkSession):
    """Verify watermark column exists and has correct type."""
    if config['load']['type'] != 'incremental':
        print("⏭️  Skipping watermark test (full load)")
        return True
    
    watermark_col = config['load']['watermark_column']
    adapter = config['source']['adapter']
    
    if adapter == 'jdbc':
        # Query source schema
        conn_opts = config['source']['connection']['options']
        read_config = config['source']['read']
        
        if read_config['mode'] == 'table':
            table_name = read_config['table']
            test_query = f"SELECT {watermark_col} FROM {table_name} WHERE 1=0"
        else:
            # For query mode, wrap in subquery
            test_query = f"SELECT {watermark_col} FROM ({read_config['query']}) AS subq WHERE 1=0"
        
        test_options = {
            "url": conn_opts['url'],
            "user": conn_opts['user'],
            "password": conn_opts['password'],
            "query": test_query
        }
        
        try:
            df = spark.read.format("jdbc").options(**test_options).load()
            schema = df.schema
            
            # Find watermark column
            watermark_field = next(
                (f for f in schema.fields if f.name == watermark_col),
                None
            )
            
            if watermark_field is None:
                print(f"❌ Watermark column not found: {watermark_col}")
                print(f"\n🔍 Available columns: {[f.name for f in schema.fields]}")
                return False
            
            # Check data type
            valid_types = ['timestamp', 'date', 'long', 'int']
            if watermark_field.dataType.simpleString() not in valid_types:
                print(f"❌ Invalid watermark column type: {watermark_field.dataType}")
                print(f"   Expected: timestamp, date, long, or int")
                return False
            
            print(f"✅ Watermark column valid: {watermark_col} ({watermark_field.dataType})")
            return True
        
        except Exception as e:
            print(f"❌ Watermark column test failed: {str(e)}")
            return False
    
    elif adapter == 'spark_reader':
        # Read schema from file
        path = config['source']['read']['path']
        file_format = config['source']['read']['options']['format']
        
        try:
            df = spark.read.format(file_format).load(path)
            schema = df.schema
            
            watermark_field = next(
                (f for f in schema.fields if f.name == watermark_col),
                None
            )
            
            if watermark_field is None:
                print(f"❌ Watermark column not found: {watermark_col}")
                print(f"\n🔍 Available columns: {[f.name for f in schema.fields]}")
                return False
            
            print(f"✅ Watermark column valid: {watermark_col} ({watermark_field.dataType})")
            return True
        
        except Exception as e:
            print(f"❌ Watermark column test failed: {str(e)}")
            return False
```

---

## Step 5: Check ADLS Write Permissions

### Write Permission Test

```python
def test_adls_write_permissions(config: dict, spark: SparkSession):
    """Test write permissions to Raw zone."""
    target = config['target']
    test_path = f"{target['raw_base_path']}/raw/_test_write_{int(time.time())}"
    
    try:
        # Create test DataFrame
        test_df = spark.createDataFrame([(1, "test")], ["id", "value"])
        
        # Try to write
        test_df.write.mode("overwrite").parquet(test_path)
        
        # Verify write
        verify_df = spark.read.parquet(test_path)
        row_count = verify_df.count()
        
        # Cleanup
        spark._jvm.org.apache.hadoop.fs.FileSystem.get(
            spark._jsc.hadoopConfiguration()
        ).delete(
            spark._jvm.org.apache.hadoop.fs.Path(test_path),
            True  # recursive
        )
        
        if row_count == 1:
            print(f"✅ ADLS write permissions verified")
            return True
        else:
            print(f"❌ Write verification failed (row count mismatch)")
            return False
    
    except Exception as e:
        print(f"❌ ADLS write test failed: {str(e)}")
        print(f"\n🔍 Troubleshooting:")
        print(f"   - Grant Storage Blob Data Contributor role")
        print(f"   - Verify ABFS path format")
        print(f"   - Check Azure AD token expiration")
        return False
```

---

## Step 6: Generate Test Report

### Summary Output

```
================================================================================
🧪 Ingestion Pipeline Test Report
================================================================================

Configuration: generated/ingest_raw/config.yaml
Source: snowflake_sales
Dataset: fact_orders
Adapter: jdbc
Load Type: incremental

Tests:
------
✅ YAML schema validation
✅ JDBC connection test (jdbc:snowflake://account.snowflakecomputing.com)
✅ Watermark column verification (updated_at: timestamp)
✅ ADLS write permissions (abfss://raw@storage.dfs.core.windows.net)

Result: ALL TESTS PASSED ✅

Next steps:
-----------
1. Run ingestion:
   spark-submit ingest_raw.py config.yaml

2. Validate output:
   /validate dataset=fact_orders expected_rows=1000000

3. Debug failures (if any):
   /debug error="<error_message>"

================================================================================
```

---

## Step 7: pytest Test Suite (Optional)

### Unit Tests for Configuration Validation

Create `tests/test_config.py`:

```python
import pytest
import yaml
from ingest_raw import load_config, substitute_env_vars


def test_load_valid_config():
    """Test loading valid configuration file."""
    config = load_config("tests/fixtures/valid_config.yaml")
    assert config['source']['adapter'] == 'jdbc'
    assert config['load']['type'] == 'incremental'


def test_load_invalid_yaml():
    """Test loading invalid YAML syntax."""
    with pytest.raises(ValueError, match="Invalid YAML syntax"):
        load_config("tests/fixtures/invalid_syntax.yaml")


def test_substitute_env_vars(monkeypatch):
    """Test environment variable substitution."""
    monkeypatch.setenv("SNOWFLAKE_USER", "test_user")
    
    config = {
        "connection": {
            "user": "${SNOWFLAKE_USER}",
            "password": "${SNOWFLAKE_PASSWORD}"
        }
    }
    
    result = substitute_env_vars(config)
    assert result['connection']['user'] == "test_user"


def test_incremental_requires_watermark():
    """Test incremental load validation."""
    config = {
        "load": {
            "type": "incremental"
            # Missing watermark_column
        }
    }
    
    with pytest.raises(AssertionError, match="watermark_column"):
        validate_schema(config)


def test_jdbc_requires_connection_details():
    """Test JDBC adapter validation."""
    config = {
        "source": {
            "adapter": "jdbc",
            "connection": {
                "options": {
                    # Missing 'url'
                    "user": "test",
                    "password": "test"
                }
            }
        }
    }
    
    with pytest.raises(AssertionError, match="url"):
        validate_schema(config)
```

### Run Tests

```bash
# Install pytest
pip install pytest pytest-cov

# Run tests with coverage
pytest tests/test_config.py -v --cov=ingest_raw --cov-report=term-missing

# Expected output:
# tests/test_config.py::test_load_valid_config PASSED
# tests/test_config.py::test_load_invalid_yaml PASSED
# tests/test_config.py::test_substitute_env_vars PASSED
# tests/test_config.py::test_incremental_requires_watermark PASSED
# tests/test_config.py::test_jdbc_requires_connection_details PASSED
#
# Coverage: 85%
```

---

## Validation Checklist

Before completing, verify:

- [x] Configuration file loaded successfully
- [x] YAML schema validation passed
- [x] Source connection tested (JDBC or path accessible)
- [x] Watermark column verified (incremental loads)
- [x] ADLS write permissions confirmed
- [x] Test report generated with clear pass/fail status
- [x] Troubleshooting guidance provided for failures

---

**End of Test Workflow**
