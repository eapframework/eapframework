---
description: Generate operational documentation, runbooks, and troubleshooting guides for ingestion pipelines
glyphEnabled: true
glyph: document
---

User input: $ARGUMENTS

## Context

You are creating **operational documentation** for data ingestion pipelines, including runbooks, connection setup guides, troubleshooting playbooks, and deployment instructions.

**Documentation Types**:
1. **Deployment Runbook**: Step-by-step pipeline deployment
2. **Connection Setup Guide**: Credentials, firewall, permissions
3. **Troubleshooting Playbook**: Common errors and resolutions
4. **Performance Tuning Guide**: Partitioning, file size optimization
5. **Monitoring Guide**: Metrics, alerts, logs

---

## Expected User Input

The user will provide one of:
1. **Documentation type**: `type=runbook` or `type=troubleshooting`
2. **Dataset context**: `dataset=fact_orders source=snowflake`
3. **Output format**: `format=markdown` or `format=confluence`
4. **Interactive mode**: `/document` (prompt for details)

---

## Documentation Templates

### Template 1: Deployment Runbook

**Filename**: `runbook-deploy-{{dataset}}.md`

**Content**:

```markdown
# Deployment Runbook: {{dataset}} Ingestion Pipeline

**Dataset**: {{dataset}}  
**Source**: {{source}}  
**Adapter**: {{adapter}}  
**Load Type**: {{load_type}}  
**Owner**: {{team_name}}  
**Last Updated**: {{current_date}}

---

## Prerequisites

### 1. Azure Resources

- [x] **Storage Account**: `{{storage_account}}`
  - Container created: `raw`
  - Service principal has Storage Blob Data Contributor role
  - Firewall allows Databricks subnet

- [x] **Databricks Workspace**: `{{databricks_workspace}}`
  - Cluster created: {{cluster_name}}
  - Runtime: DBR 11.3+ (Spark 3.3+)
  {% if adapter == 'jdbc' %}
  - JDBC driver installed: {{jdbc_driver}}
  {% endif %}
  - Libraries: PyYAML

- [x] **Key Vault**: `{{key_vault_name}}`
  - Secrets stored:
    - `{{source|upper}}-USER`
    - `{{source|upper}}-PASSWORD`
  - Databricks service principal has Secret Get permissions

### 2. Source System Access

{% if adapter == 'jdbc' %}
- [x] Database firewall allows Databricks IP ranges
- [x] Service account created: `{{service_account_name}}`
- [x] Permissions granted:
  ```sql
  GRANT USAGE ON DATABASE {{database}} TO USER {{service_account_name}};
  GRANT USAGE ON SCHEMA {{schema}} TO USER {{service_account_name}};
  GRANT SELECT ON TABLE {{table}} TO USER {{service_account_name}};
  ```
{% elif adapter == 'spark_reader' %}
- [x] Files accessible from Databricks
- [x] Path validated: `{{file_path}}`
{% endif %}

### 3. Environment Variables

Set in Databricks cluster configuration:
```bash
AZURE_STORAGE_ACCOUNT={{storage_account}}
{{source|upper}}_USER=<from Key Vault>
{{source|upper}}_PASSWORD=<from Key Vault>
```

---

## Deployment Steps

### Step 1: Clone Repository

```bash
git clone https://github.com/company/otis-migration.git
cd otis-migration/generated/ingest_raw
```

### Step 2: Review Configuration

Edit `config.yaml`:

```yaml
source:
  adapter: {{adapter}}
  system: {{source}}
  connection:
    options:
      url: "{{jdbc_url}}"
      user: "${{{source|upper}}_USER}"
      password: "${{{source|upper}}_PASSWORD}"
  read:
    mode: table
    table: "{{table}}"
{% if load_type == 'incremental' %}
load:
  type: incremental
  watermark_column: "{{watermark_column}}"
  start_value: "{{start_value}}"  # Adjust for initial load
{% endif %}
target:
  raw_base_path: "abfss://raw@{{storage_account}}.dfs.core.windows.net"
  dataset_name: "{{dataset}}"
```

**Validation Checklist**:
- [x] Connection URL is correct
- [x] Credentials reference Key Vault secrets
- [x] Table name matches source exactly (case-sensitive)
{% if load_type == 'incremental' %}
- [x] Watermark column exists in source
- [x] Start value is appropriate (e.g., 30 days ago for daily loads)
{% endif %}

### Step 3: Test Configuration

```bash
# Run configuration tests
/test config_file=config.yaml
```

**Expected Output**:
```
✅ YAML schema validation
✅ JDBC connection test
✅ Watermark column verification
✅ ADLS write permissions
```

### Step 4: Deploy to Databricks

#### Option A: Databricks Notebook

1. Upload files to Databricks workspace:
   ```
   /Workspace/ingestion/{{dataset}}/
     ├── ingest_raw.py
     └── config.yaml
   ```

2. Create notebook cell:
   ```python
   %run /Workspace/ingestion/{{dataset}}/ingest_raw.py config.yaml
   ```

#### Option B: Databricks Job

1. Create job in Databricks UI:
   - **Name**: `Ingest_{{dataset}}`
   - **Task type**: Python script
   - **Script path**: `/Workspace/ingestion/{{dataset}}/ingest_raw.py`
   - **Parameters**: `["config.yaml"]`
   - **Cluster**: {{cluster_name}}
   - **Schedule**: {% if load_type == 'incremental' %}Daily at 2 AM UTC{% else %}Manual (one-time){% endif %}

2. Set job permissions:
   - Data Engineers: Can Manage
   - Data Analysts: Can View

### Step 5: Run Initial Load

```bash
# Trigger job manually
databricks jobs run-now --job-id {{job_id}}

# Monitor progress
databricks runs get --run-id {{run_id}}
```

**Expected Duration**: {{expected_duration}} minutes

### Step 6: Validate Output

```python
# Check output path
dbutils.fs.ls("abfss://raw@{{storage_account}}.dfs.core.windows.net/raw/{{dataset}}/")

# Verify row count
df = spark.read.parquet("abfss://raw@{{storage_account}}.dfs.core.windows.net/raw/{{dataset}}")
print(f"Rows ingested: {df.count()}")
print(f"Expected rows: {{expected_row_count}}")

# Inspect schema (should include _ingested_at, _source_system)
df.printSchema()
```

### Step 7: Enable Monitoring

Create Databricks job alert:
- **Condition**: Job fails
- **Notification**: Email to {{team_email}}
- **Webhook**: Slack channel #data-alerts

---

## Rollback Procedure

If ingestion fails or produces incorrect data:

### Option 1: Revert to Previous Data

```python
# List versions (if versioned)
dbutils.fs.ls("abfss://raw@{{storage_account}}.dfs.core.windows.net/raw/{{dataset}}/_versions/")

# Restore previous version
dbutils.fs.cp(
  "abfss://raw@storage.dfs.core.windows.net/raw/{{dataset}}/_versions/2026-02-04/",
  "abfss://raw@storage.dfs.core.windows.net/raw/{{dataset}}/",
  recurse=True
)
```

### Option 2: Delete Bad Data and Re-run

```python
# Delete current data
dbutils.fs.rm("abfss://raw@storage.dfs.core.windows.net/raw/{{dataset}}/", recurse=True)

# Re-run ingestion job
databricks jobs run-now --job-id {{job_id}}
```

---

## Post-Deployment Checklist

- [x] Initial load completed successfully
- [x] Row count validated (matches source within 0.1%)
- [x] Schema validated (all source columns present)
- [x] Metadata columns added (_ingested_at, _source_system)
- [x] Job scheduled (for incremental loads)
- [x] Monitoring alerts configured
- [x] Documentation updated in Confluence
- [x] Runbook reviewed by team

---

## Contacts

| Role | Name | Email | Slack |
|------|------|-------|-------|
| Owner | {{owner_name}} | {{owner_email}} | @{{owner_slack}} |
| Backup | {{backup_name}} | {{backup_email}} | @{{backup_slack}} |
| Platform Team | Data Engineering | data-eng@company.com | #data-engineering |

---

**End of Deployment Runbook**
```

---

### Template 2: Connection Setup Guide

**Filename**: `connection-setup-{{source}}.md`

**Content**:

```markdown
# Connection Setup Guide: {{source}}

**Source System**: {{source}}  
**Adapter**: {{adapter}}  
**Protocol**: {{protocol}}  
**Last Updated**: {{current_date}}

---

## Overview

This guide covers end-to-end connection setup for {{source}}, including:
- Service account creation
- Permission grants
- Firewall configuration
- Credential storage in Azure Key Vault
- Connection testing

---

## Step 1: Create Service Account

{% if adapter == 'jdbc' and source == 'snowflake' %}

### Snowflake Service Account

```sql
-- Create user
CREATE USER svc_databricks_ingest
  PASSWORD = '<generate_strong_password>'
  DEFAULT_ROLE = INGESTION_ROLE
  DEFAULT_WAREHOUSE = COMPUTE_WH
  MUST_CHANGE_PASSWORD = FALSE;

-- Create role
CREATE ROLE INGESTION_ROLE;

-- Grant warehouse usage
GRANT USAGE ON WAREHOUSE COMPUTE_WH TO ROLE INGESTION_ROLE;

-- Grant database access
GRANT USAGE ON DATABASE SALES_DB TO ROLE INGESTION_ROLE;
GRANT USAGE ON SCHEMA SALES_DB.PUBLIC TO ROLE INGESTION_ROLE;

-- Grant table read permissions
GRANT SELECT ON ALL TABLES IN SCHEMA SALES_DB.PUBLIC TO ROLE INGESTION_ROLE;
GRANT SELECT ON FUTURE TABLES IN SCHEMA SALES_DB.PUBLIC TO ROLE INGESTION_ROLE;

-- Assign role to user
GRANT ROLE INGESTION_ROLE TO USER svc_databricks_ingest;
```

{% elif adapter == 'jdbc' and source == 'oracle' %}

### Oracle Service Account

```sql
-- Create user
CREATE USER svc_databricks_ingest IDENTIFIED BY "<strong_password>";

-- Grant basic permissions
GRANT CREATE SESSION TO svc_databricks_ingest;
GRANT SELECT ANY TABLE TO svc_databricks_ingest;  -- Or grant per table

-- Grant table-specific permissions (recommended)
GRANT SELECT ON HR.EMPLOYEES TO svc_databricks_ingest;
GRANT SELECT ON HR.DEPARTMENTS TO svc_databricks_ingest;
```

{% elif adapter == 'jdbc' and source == 'postgres' %}

### PostgreSQL Service Account

```sql
-- Create user
CREATE USER svc_databricks_ingest WITH PASSWORD '<strong_password>';

-- Grant database access
GRANT CONNECT ON DATABASE sales_db TO svc_databricks_ingest;

-- Grant schema usage
GRANT USAGE ON SCHEMA public TO svc_databricks_ingest;

-- Grant table read permissions
GRANT SELECT ON ALL TABLES IN SCHEMA public TO svc_databricks_ingest;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO svc_databricks_ingest;
```

{% endif %}

---

## Step 2: Configure Firewall Rules

{% if adapter == 'jdbc' %}

### Add Databricks IP Ranges

1. **Get Databricks IP ranges** for your Azure region:
   - East US 2: `20.62.132.160/27`, `20.62.132.192/27`
   - West Europe: `20.61.100.128/27`, `20.61.100.160/27`

2. **Add to source database firewall**:

   {% if source == 'snowflake' %}
   ```sql
   -- Snowflake network policy
   CREATE NETWORK POLICY databricks_ingestion_policy
     ALLOWED_IP_LIST = ('20.62.132.160/27', '20.62.132.192/27');
   
   ALTER USER svc_databricks_ingest SET NETWORK_POLICY = databricks_ingestion_policy;
   ```
   {% else %}
   - Navigate to database firewall settings
   - Add IP ranges: `20.62.132.160/27`, `20.62.132.192/27`
   - Save changes
   {% endif %}

3. **Test connectivity from Databricks**:
   ```python
   import socket
   host = "{{db_host}}"
   port = {{db_port}}
   
   try:
       sock = socket.create_connection((host, port), timeout=5)
       sock.close()
       print(f"✅ Connection to {host}:{port} successful")
   except Exception as e:
       print(f"❌ Connection failed: {e}")
   ```

{% endif %}

---

## Step 3: Store Credentials in Azure Key Vault

### Create Secrets

```bash
# Azure CLI
az keyvault secret set \
  --vault-name {{key_vault_name}} \
  --name "{{source|upper}}-USER" \
  --value "svc_databricks_ingest"

az keyvault secret set \
  --vault-name {{key_vault_name}} \
  --name "{{source|upper}}-PASSWORD" \
  --value "<service_account_password>"
```

### Grant Databricks Access

```bash
# Get Databricks service principal object ID
databricks_sp_id=$(az ad sp list --display-name "{{databricks_workspace}}" --query "[0].objectId" -o tsv)

# Grant Secret Get permission
az keyvault set-policy \
  --name {{key_vault_name}} \
  --object-id $databricks_sp_id \
  --secret-permissions get list
```

### Reference Secrets in Config

```yaml
source:
  connection:
    options:
      user: "${{{source|upper}}_USER}"
      password: "${{{source|upper}}_PASSWORD}"
```

---

## Step 4: Test Connection

### JDBC Connection Test

```python
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("ConnectionTest").getOrCreate()

# JDBC URL
jdbc_url = "{{jdbc_url}}"

# Credentials from environment variables
import os
user = os.getenv("{{source|upper}}_USER")
password = os.getenv("{{source|upper}}_PASSWORD")

# Test connection
try:
    test_df = spark.read.format("jdbc").options(
        url=jdbc_url,
        user=user,
        password=password,
        query="SELECT 1 AS test_connection"
    ).load()
    
    result = test_df.collect()
    if result[0]['test_connection'] == 1:
        print("✅ JDBC connection successful")
    else:
        print("❌ Unexpected result")
except Exception as e:
    print(f"❌ Connection failed: {e}")
```

---

## Troubleshooting

### Issue: Connection Refused

**Symptom**: `java.sql.SQLException: Connection refused`

**Resolution**:
1. Verify JDBC URL format: `{{jdbc_url}}`
2. Check firewall allows Databricks IPs
3. Confirm {{source}} service is running
4. Test from SQL client on same network

### Issue: Authentication Failed

**Symptom**: `Login failed for user 'svc_databricks_ingest'`

**Resolution**:
1. Verify credentials in Key Vault
2. Confirm service account not locked
3. Check password expiration policy
4. Test login from SQL client

### Issue: Permission Denied

**Symptom**: `Access denied for user to database`

**Resolution**:
1. Re-run permission grants (Step 1)
2. Verify role assignment
3. Check table-level permissions
4. Test query: `SELECT * FROM {{table}} LIMIT 1`

---

**End of Connection Setup Guide**
```

---

### Template 3: Troubleshooting Playbook

**Filename**: `troubleshooting-{{dataset}}.md`

**Content**:

```markdown
# Troubleshooting Playbook: {{dataset}} Ingestion

**Dataset**: {{dataset}}  
**Source**: {{source}}  
**Adapter**: {{adapter}}  
**Last Updated**: {{current_date}}

---

## Quick Diagnostics

| Symptom | Likely Cause | Resolution |
|---------|--------------|------------|
| Connection refused | Firewall blocking Databricks | Add Databricks IPs to firewall whitelist |
| Authentication failed | Wrong credentials | Verify Key Vault secrets |
| Schema mismatch | Column name case | Match exact column names from source |
| Watermark column missing | Typo in config | Verify column exists: `SELECT {{watermark_column}} FROM {{table}} LIMIT 1` |
| Zero rows written | Watermark filter too restrictive | Adjust `start_value` to past date |
| Slow ingestion (>30 min) | Partitioning disabled | Enable partitioning for datasets > 10M rows |
| Out of memory | Too few partitions | Increase `num_partitions` to 32+ |
| Permission denied (ADLS) | Missing RBAC role | Grant Storage Blob Data Contributor |

---

## Detailed Troubleshooting

### Error 1: JDBC Connection Refused

**Error Message**:
```
java.sql.SQLException: Connection refused
```

**Root Cause**: Database firewall blocking Databricks cluster IP

**Resolution Steps**:
1. Get cluster IP:
   ```python
   import socket
   print(socket.gethostname())
   print(socket.gethostbyname(socket.gethostname()))
   ```

2. Add IP to {{source}} firewall (see Connection Setup Guide)

3. Test connection:
   ```bash
   nc -zv {{db_host}} {{db_port}}
   ```

4. Re-run ingestion

---

### Error 2: Zero Rows Written

**Error Message**:
```
✅ Ingestion complete
   Rows written: 0
```

**Root Cause**: Watermark filter excludes all rows

**Resolution Steps**:
1. Check source row count:
   ```sql
   SELECT COUNT(*) FROM {{table}};
   ```

2. Check filtered count:
   ```sql
   SELECT COUNT(*) FROM {{table}} WHERE {{watermark_column}} >= '{{start_value}}';
   ```

3. If filtered count is 0, adjust `start_value` in config.yaml:
   ```yaml
   load:
     start_value: "2026-01-01T00:00:00Z"  # Older date
   ```

4. Re-run ingestion

---

### Error 3: Schema Mismatch

**Error Message**:
```
pyspark.sql.utils.AnalysisException: cannot resolve 'order_id'
```

**Root Cause**: Column name case mismatch

**Resolution Steps**:
1. Query source schema:
   ```sql
   DESCRIBE TABLE {{table}};
   ```

2. Compare with config.yaml:
   ```yaml
   load:
     watermark_column: "order_id"  # ❌ Lowercase
   # Fix: Use exact case from source
     watermark_column: "ORDER_ID"  # ✅ Uppercase (Snowflake)
   ```

3. Update config.yaml with exact column names

4. Re-run ingestion

---

**End of Troubleshooting Playbook**
```

---

## Documentation Generation Workflow

### Step 1: Gather Context

Extract from config.yaml:
- Source system details
- Adapter type
- Load type
- Watermark column (if incremental)
- Table/query information

### Step 2: Select Template

Based on user request:
- `type=runbook` → Deployment Runbook template
- `type=connection` → Connection Setup Guide template
- `type=troubleshooting` → Troubleshooting Playbook template
- `type=all` → Generate all three

### Step 3: Populate Template

Replace placeholders:
- `{{dataset}}` → config['target']['dataset_name']
- `{{source}}` → config['source']['system']
- `{{adapter}}` → config['source']['adapter']
- `{{jdbc_url}}` → config['source']['connection']['options']['url']
- `{{watermark_column}}` → config['load']['watermark_column']

### Step 4: Output Documentation

Save to:
- `docs/runbooks/deploy-{{dataset}}.md`
- `docs/guides/connection-{{source}}.md`
- `docs/playbooks/troubleshoot-{{dataset}}.md`

---

## Validation Checklist

Before completing, verify:

- [x] Documentation includes all required sections
- [x] Code examples are complete and runnable
- [x] Placeholders replaced with actual values
- [x] Troubleshooting covers common errors
- [x] Contact information included
- [x] Rollback procedures documented

---

**End of Document Workflow**
