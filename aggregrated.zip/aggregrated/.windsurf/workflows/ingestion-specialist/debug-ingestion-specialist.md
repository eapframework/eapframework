---
description: Diagnose and resolve ingestion failures (connection errors, schema mismatches, permissions)
glyphEnabled: true
glyph: debug
---

User input: $ARGUMENTS

## Context

You are troubleshooting a **failed ingestion pipeline** by diagnosing connection errors, permission issues, schema mismatches, watermark problems, and performance bottlenecks.

**Common Failure Categories**:
1. **Connection failures** (JDBC, ADLS, API)
2. **Permission errors** (Azure RBAC, firewall rules)
3. **Schema mismatches** (column names, data types)
4. **Watermark issues** (missing column, wrong type)
5. **Performance problems** (slow reads, OOM errors)

---

## Expected User Input

The user will provide one of:
1. **Error message**: `error="Connection refused"` or `error="403 Forbidden"`
2. **Symptom**: `symptom="ingestion takes 2 hours"` or `symptom="0 rows written"`
3. **Stack trace**: Paste full PySpark error
4. **Interactive mode**: `/debug` (prompt for error details)

---

## Diagnostic Framework

### Step 1: Extract Error Signature

Parse the error message to identify:
- **Error type**: `java.sql.SQLException`, `PermissionError`, `AnalysisException`
- **Root cause keywords**: "Connection refused", "403 Forbidden", "cannot resolve"
- **Component**: JDBC driver, Spark executor, ADLS client

---

## Common Issues & Resolutions

### Issue 1: JDBC Connection Refused

**Error Signature**:
```
java.sql.SQLException: Connection refused
Caused by: java.net.ConnectException: Connection refused: connect
```

**Root Causes**:
1. Incorrect JDBC URL format
2. Firewall blocking Databricks IP ranges
3. Source database unavailable
4. Wrong port number

**Diagnostic Steps**:

1. **Validate JDBC URL Format**:
   ```python
   # Snowflake format
   jdbc:snowflake://<account>.snowflakecomputing.com/?warehouse=COMPUTE_WH&db=SALES_DB
   
   # Oracle format
   jdbc:oracle:thin:@//<host>:<port>/<service_name>
   
   # Postgres format
   jdbc:postgresql://<host>:<port>/<database>
   ```

2. **Check Firewall Rules**:
   ```bash
   # Get Databricks cluster IP
   import socket
   cluster_ip = socket.gethostbyname(socket.gethostname())
   print(f"Cluster IP: {cluster_ip}")
   
   # Verify firewall allows this IP to connect to source database
   ```

3. **Test Connection from SQL Client**:
   ```bash
   # From same Azure region, test connection
   psql -h <host> -p <port> -U <user> -d <database>
   # OR
   sqlplus <user>/<password>@<host>:<port>/<service>
   ```

4. **Verify Port Accessibility**:
   ```bash
   # Test TCP connection
   nc -zv <host> <port>
   # Expected: Connection succeeded
   ```

**Resolution**:
- Fix JDBC URL format
- Add Databricks IP ranges to database firewall whitelist
- Confirm database is running: `SELECT 1` test query
- Use correct port: Snowflake (443), Oracle (1521), Postgres (5432)

---

### Issue 2: JDBC Authentication Failure

**Error Signature**:
```
java.sql.SQLException: Login failed for user 'service_account'
Access denied for user 'service_account'@'%' to database 'SALES_DB'
```

**Root Causes**:
1. Incorrect username/password
2. Password expired
3. Service account lacks database permissions
4. Environment variable not set

**Diagnostic Steps**:

1. **Verify Credentials**:
   ```python
   import os
   user = os.getenv("SNOWFLAKE_USER")
   password = os.getenv("SNOWFLAKE_PASSWORD")
   
   print(f"User: {user}")
   print(f"Password set: {password is not None}")
   ```

2. **Test Login from SQL Client**:
   ```bash
   # Manually test credentials
   snowsql -a <account> -u <user> -p <password>
   ```

3. **Check Service Account Permissions**:
   ```sql
   -- In source database, verify grants
   SHOW GRANTS TO USER service_account;
   
   -- Expected grants:
   -- USAGE ON DATABASE SALES_DB
   -- USAGE ON SCHEMA PUBLIC
   -- SELECT ON TABLE FACT_ORDERS
   ```

**Resolution**:
- Update config.yaml with correct credentials (use environment variables)
- Reset service account password if expired
- Grant required permissions:
  ```sql
  GRANT USAGE ON DATABASE SALES_DB TO USER service_account;
  GRANT USAGE ON SCHEMA PUBLIC TO USER service_account;
  GRANT SELECT ON TABLE FACT_ORDERS TO USER service_account;
  ```

---

### Issue 3: ADLS Permission Denied

**Error Signature**:
```
shaded.abfs.org.apache.hadoop.fs.azurebfs.contracts.exceptions.AbfsRestOperationException: 
Operation failed: "This request is not authorized to perform this operation.", 403, Forbidden
```

**Root Causes**:
1. Service principal lacks Storage Blob Data Contributor role
2. Incorrect ABFS path format
3. Storage account firewall blocking access
4. Azure AD token expired

**Diagnostic Steps**:

1. **Verify ABFS Path Format**:
   ```python
   # Correct format
   abfss://raw@storageaccount.dfs.core.windows.net/raw/dataset_name
   
   # Common mistakes:
   # ❌ abfs:// (not abfss://)
   # ❌ .blob.core.windows.net (should be .dfs.core.windows.net)
   # ❌ Missing container name
   ```

2. **Check Service Principal Permissions**:
   ```bash
   # Azure CLI: List role assignments
   az role assignment list \
     --assignee <service_principal_app_id> \
     --scope /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage>
   
   # Expected role: "Storage Blob Data Contributor"
   ```

3. **Test Write Permissions**:
   ```python
   from pyspark.sql import SparkSession
   spark = SparkSession.builder.getOrCreate()
   
   # Try to write test file
   test_df = spark.createDataFrame([(1, "test")], ["id", "value"])
   test_df.write.mode("overwrite").parquet(
       "abfss://raw@storage.dfs.core.windows.net/raw/_test"
   )
   ```

4. **Verify Storage Account Firewall**:
   ```bash
   # Check firewall rules
   az storage account show \
     --name <storage_account> \
     --query "networkRuleSet"
   
   # If firewall enabled, add Databricks subnet
   ```

**Resolution**:
- Grant Storage Blob Data Contributor role:
  ```bash
  az role assignment create \
    --assignee <service_principal_app_id> \
    --role "Storage Blob Data Contributor" \
    --scope /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage>
  ```
- Fix ABFS path format in config.yaml
- Add Databricks subnet to storage firewall allowlist
- Refresh Azure AD token if expired

---

### Issue 4: Schema Mismatch

**Error Signature**:
```
pyspark.sql.utils.AnalysisException: cannot resolve 'order_id' given input columns: [ORDER_ID, CUSTOMER_ID, ...]
```

**Root Causes**:
1. Column name case mismatch (Spark is case-sensitive)
2. Column renamed in source
3. Watermark column doesn't exist
4. Typo in config.yaml

**Diagnostic Steps**:

1. **Query Source Schema**:
   ```sql
   -- Snowflake
   DESCRIBE TABLE SALES_DB.PUBLIC.FACT_ORDERS;
   
   -- Oracle
   SELECT column_name, data_type 
   FROM all_tab_columns 
   WHERE table_name = 'FACT_ORDERS';
   
   -- Postgres
   \d fact_orders
   ```

2. **Compare with Config**:
   ```python
   # Expected columns from source
   source_columns = ["ORDER_ID", "CUSTOMER_ID", "ORDER_DATE", "TOTAL_AMOUNT"]
   
   # Config references
   watermark_column = "order_id"  # ❌ Case mismatch
   
   # Fix: Use exact column name from source
   watermark_column = "ORDER_ID"  # ✅
   ```

3. **Check Case Sensitivity**:
   ```python
   # Snowflake: Case-insensitive by default (stores as uppercase)
   # Oracle: Case-insensitive (stores as uppercase)
   # Postgres: Case-sensitive (stores as defined)
   
   # Spark: ALWAYS case-sensitive
   # Solution: Match exact case from source
   ```

**Resolution**:
- Update config.yaml with exact column names (match case)
- If source column renamed, update both:
  - `watermark_column` in config.yaml
  - `partitioning.column` in config.yaml
- Use `SELECT *` query to verify available columns:
  ```yaml
  read:
    mode: query
    query: "SELECT * FROM SALES_DB.PUBLIC.FACT_ORDERS WHERE 1=0"
  ```

---

### Issue 5: Watermark Column Missing

**Error Signature**:
```
AttributeError: 'NoneType' object has no attribute 'cast'
KeyError: 'watermark_column'
```

**Root Causes**:
1. Watermark column not in source schema
2. Watermark column name typo
3. Incremental load configured but watermark missing

**Diagnostic Steps**:

1. **Verify Column Exists**:
   ```sql
   -- Check if watermark column exists
   SELECT updated_at FROM SALES_DB.PUBLIC.FACT_ORDERS LIMIT 1;
   ```

2. **Check Data Type**:
   ```sql
   -- Watermark must be date/timestamp/numeric
   DESCRIBE TABLE SALES_DB.PUBLIC.FACT_ORDERS;
   -- Look for updated_at: TIMESTAMP_NTZ
   ```

3. **Validate Config**:
   ```yaml
   load:
     type: incremental
     watermark_column: "updated_at"  # ❌ Does this match source?
   ```

**Resolution**:
- Confirm watermark column exists in source
- Fix column name spelling in config.yaml
- If no watermark column exists, switch to full load:
  ```yaml
  load:
    type: full  # Fallback when watermark unavailable
  ```

---

### Issue 6: Partitioning Performance Issues

**Error Signature**:
```
Task 0 in stage 1.0 failed after 300 seconds
OutOfMemoryError: Java heap space
```

**Root Causes**:
1. Partitioning column has skewed distribution
2. Too few partitions (data skew per partition)
3. Too many partitions (scheduler overhead)
4. Partitioning column is string (inefficient)

**Diagnostic Steps**:

1. **Check Data Distribution**:
   ```sql
   -- Verify partitioning column distribution
   SELECT 
     MIN(ORDER_ID) as min_id,
     MAX(ORDER_ID) as max_id,
     COUNT(*) as total_rows,
     COUNT(DISTINCT ORDER_ID) as distinct_ids
   FROM SALES_DB.PUBLIC.FACT_ORDERS;
   
   -- Check for skew
   SELECT ORDER_ID, COUNT(*) as cnt
   FROM SALES_DB.PUBLIC.FACT_ORDERS
   GROUP BY ORDER_ID
   ORDER BY cnt DESC
   LIMIT 10;
   ```

2. **Analyze Partition Sizes**:
   ```python
   # After ingestion, check partition file sizes
   dbutils.fs.ls("abfss://raw@storage.dfs.core.windows.net/raw/fact_orders/")
   
   # Expected: Uniform file sizes (50MB - 1GB)
   # Problem: One file is 10GB, others are 10MB (skew)
   ```

3. **Review Partitioning Config**:
   ```yaml
   partitioning:
     enabled: true
     column: "ORDER_STATUS"  # ❌ String column (only 5 values)
     # Better: Use ORDER_ID (numeric, uniform distribution)
   ```

**Resolution**:
- Choose numeric column with uniform distribution:
  ```yaml
  partitioning:
    column: "ORDER_ID"  # Auto-increment, evenly distributed
  ```
- Adjust partition count based on data volume:
  - 10M rows → 8 partitions
  - 100M rows → 32 partitions
  - 1B rows → 128 partitions
- Disable partitioning if dataset < 10M rows:
  ```yaml
  partitioning:
    enabled: false
  ```

---

### Issue 7: Zero Rows Written

**Error Signature**:
```
✅ Ingestion complete: abfss://raw@storage.dfs.core.windows.net/raw/fact_orders
   Rows written: 0
```

**Root Causes**:
1. Watermark filter excludes all rows
2. Source table is empty
3. Incremental load with future `start_value`
4. Query syntax error (returns empty result)

**Diagnostic Steps**:

1. **Verify Source Row Count**:
   ```sql
   SELECT COUNT(*) FROM SALES_DB.PUBLIC.FACT_ORDERS;
   -- Expected: > 0
   ```

2. **Check Watermark Filter**:
   ```sql
   -- Simulate Spark filter
   SELECT COUNT(*) 
   FROM SALES_DB.PUBLIC.FACT_ORDERS
   WHERE updated_at >= '2026-02-05T00:00:00Z';
   -- Expected: > 0
   ```

3. **Validate Start Value**:
   ```yaml
   load:
     watermark_column: "updated_at"
     start_value: "2027-01-01T00:00:00Z"  # ❌ Future date
   ```

4. **Test Query Syntax**:
   ```yaml
   read:
     mode: query
     query: "SELECT * FROM SALES_DB.PUBLIC.FACT_ORDERS WHERE 1=1"
     # ❌ Syntax error? Test in SQL client first
   ```

**Resolution**:
- Adjust `start_value` to reasonable past date:
  ```yaml
  start_value: "2026-01-01T00:00:00Z"  # Last month
  ```
- Verify source table has data
- Test query in source database before using in config.yaml
- Use full load to bypass watermark filtering:
  ```yaml
  load:
    type: full
  ```

---

## Debugging Workflow

### Step 1: Reproduce Error

1. **Run ingestion with debug logging**:
   ```bash
   spark-submit \
     --conf "spark.sql.debug.maxToStringFields=1000" \
     --conf "spark.eventLog.enabled=true" \
     ingest_raw.py config.yaml 2>&1 | tee ingestion.log
   ```

2. **Capture full stack trace**:
   ```python
   import traceback
   try:
       main(config_path)
   except Exception as e:
       traceback.print_exc()
   ```

---

### Step 2: Isolate Component

1. **Test connection only**:
   ```python
   # JDBC connection test
   test_df = spark.read.format("jdbc").options(
       url=jdbc_url,
       user=user,
       password=password,
       query="SELECT 1 AS test"
   ).load()
   print(test_df.collect())  # Expected: [Row(test=1)]
   ```

2. **Test schema read**:
   ```python
   # Read schema without data
   schema_df = spark.read.format("jdbc").options(
       url=jdbc_url,
       user=user,
       password=password,
       query=f"SELECT * FROM {table} WHERE 1=0"
   ).load()
   schema_df.printSchema()
   ```

3. **Test watermark filter**:
   ```python
   # Read with watermark filter
   filtered_df = spark.read.format("jdbc").options(
       url=jdbc_url,
       user=user,
       password=password,
       query=f"SELECT * FROM {table} WHERE {watermark_col} >= '{start_value}'"
   ).load()
   print(f"Rows matching filter: {filtered_df.count()}")
   ```

---

### Step 3: Generate Diagnostic Report

**Output Template**:

```
================================================================================
🔧 Ingestion Debugging Report
================================================================================

Timestamp: {{timestamp}}
Dataset: {{dataset}}
Source: {{source}}
Adapter: {{adapter}}

Error:
------
{{error_message}}

Stack Trace:
------------
{{stack_trace}}

Diagnostics:
------------

1. Connection Test:
   Status: {{connection_status}}
   URL: {{jdbc_url}}
   Message: {{connection_message}}

2. Schema Verification:
   Source Columns: {{source_columns}}
   Watermark Column: {{watermark_column}} (exists: {{watermark_exists}})

3. Watermark Filter:
   Filter: {{watermark_col}} >= '{{start_value}}'
   Rows Matching: {{filtered_row_count}}

4. Permissions:
   ADLS Write Test: {{adls_write_status}}
   JDBC Read Test: {{jdbc_read_status}}

Root Cause:
-----------
{{root_cause}}

Resolution:
-----------
{{resolution_steps}}

Suggested Config Changes:
-------------------------
{{config_diff}}

Next Steps:
-----------
1. {{step_1}}
2. {{step_2}}
3. {{step_3}}

================================================================================
```

---

## Validation Checklist

Before completing, verify:

- [x] Error signature identified
- [x] Root cause diagnosed
- [x] Resolution steps provided
- [x] Config changes suggested (if applicable)
- [x] Runnable test queries included
- [x] User can reproduce fix independently

---

**End of Debug Workflow**
