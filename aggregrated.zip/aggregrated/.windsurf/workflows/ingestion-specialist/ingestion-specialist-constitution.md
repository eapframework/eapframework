---
description: Generic data ingestion from any source to Azure ADLS Raw zone with schema preservation
---

User input: $ARGUMENTS

## Execution Steps

### 0. Set ARCHETYPES_BASEDIR

**SUCCESS CRITERIA**:
- Search for directory: "00-core-orchestration"
- Set variable `${ARCHETYPES_BASEDIR}` to immediate parent of this directory

**HALT IF**:
- Directory "00-core-orchestration" is not found
- `${ARCHETYPES_BASEDIR}` is not set

---

# Ingestion Specialist Workflow

**Archetype**: Ingestion Specialist
**Purpose**: Ingest data from any source to Azure ADLS Raw zone without transformations
**Complexity**: Low to Medium
**Expected Duration**: 5-20 minutes per dataset

---

## When to Use This Workflow

Use `/ingestion-specialist` when you encounter:
- New data source needs onboarding to Raw zone
- Existing ingestion pipeline requires modification
- Schema-preserving data extraction from Oracle, Snowflake, files, or APIs
- Full or incremental data loads to Bronze layer
- Connection configuration testing
- Debugging ingestion failures or data quality issues

---

## What This Workflow Does

**Core Capabilities:**
- Schema-preserving ingestion (no transformations)
- Multi-adapter support (JDBC, Spark Reader, Custom)
- Full and incremental load modes
- Watermark-based filtering for incremental loads
- Metadata column injection (`_ingested_at`, `_source_system`)
- Parquet output to ADLS Gen2 Raw zone

**Supported Sources:**
- **JDBC**: Snowflake, Oracle, Postgres, SQL Server, DB2, MySQL, Teradata
- **Spark Reader**: Parquet, CSV, JSON, Avro, Delta, ADLS, S3
- **Custom**: Kafka, REST APIs, SaaS connectors

---

## Output Contract

All ingestions write to:
```
abfss://raw@<storage>.dfs.core.windows.net/raw/<dataset_name>/
```

**Format**: Parquet  
**Schema**: Source-defined (unchanged, metadata appended)  
**Metadata Columns**:
- `_ingested_at`: Ingestion timestamp (UTC)
- `_source_system`: Logical source system name

---

## Strict Rules

- ❌ NO joins
- ❌ NO column renames
- ❌ NO filters (except watermark for incremental)
- ❌ NO transformations
- ❌ NO business logic
- ✅ Preserve source schema exactly
- ✅ Append metadata columns only
- ✅ Configuration-driven system onboarding

---

## Available Workflows

### 1. scaffold-ingestion-specialist
**When**: Generating new ingestion pipeline code  
**What**: Creates PySpark ingestion scripts, configuration files, and connection templates  
**Output**: `generated/ingest_raw/` with ingest_raw.py, config.py, README.md  
**Triggers**: `/scaffold`, user requests "create ingestion pipeline"

### 2. test-ingestion-specialist
**When**: Validating ingestion logic before deployment  
**What**: Runs unit tests for configuration parsing, connection validation, watermark filtering  
**Output**: pytest results, coverage reports  
**Triggers**: `/test`, user requests "test ingestion pipeline"

### 3. compare-ingestion-specialist
**When**: Choosing between ingestion strategies  
**What**: Compares JDBC vs Spark Reader, full vs incremental, partitioned vs non-partitioned  
**Output**: Decision table with trade-offs  
**Triggers**: `/compare`, user asks "which adapter should I use?"

### 4. debug-ingestion-specialist
**When**: Troubleshooting ingestion failures  
**What**: Diagnoses connection errors, permissions, schema mismatches, watermark issues  
**Output**: Root cause analysis, resolution steps  
**Triggers**: `/debug`, user reports "ingestion failed"

### 5. document-ingestion-specialist
**When**: Creating operational documentation  
**What**: Generates runbooks, connection guides, troubleshooting playbooks  
**Output**: Markdown documentation with examples  
**Triggers**: `/document`, user requests "document ingestion pipeline"

### 6. refactor-ingestion-specialist
**When**: Improving existing ingestion code  
**What**: Consolidates configurations, extracts reusable adapters, optimizes performance  
**Output**: Refactored code with improvement report  
**Triggers**: `/refactor`, user requests "clean up ingestion code"

---

## Dependencies

**Required Before Execution**:
- Azure ADLS Gen2 storage account configured
- Service principal with Storage Blob Data Contributor role
- Source system credentials (stored in Azure Key Vault)
- Databricks cluster with required libraries (JDBC drivers)

**Integration Points**:
- **metadata-extractor**: Provides dataset schema discovery
- **transform-converter**: Consumes Raw zone data for Silver transformations
- **data-validator**: Validates ingestion row counts
- **migration-orchestrator**: Sequences ingestion across multiple datasets

---

## Success Criteria

**Configuration Valid**:
- ✅ Adapter family specified (`jdbc`, `spark_reader`, `custom`)
- ✅ Connection details complete (name or inline options)
- ✅ Read mode defined (`table`, `query`, `path`)
- ✅ Load type specified (`full`, `incremental`)
- ✅ Target dataset name provided

**Ingestion Complete**:
- ✅ Parquet files written to `raw/<dataset_name>/`
- ✅ Schema matches source (all columns preserved)
- ✅ Metadata columns appended (`_ingested_at`, `_source_system`)
- ✅ Row count matches source (within tolerance)
- ✅ No data loss or corruption

**Quality Checks Passed**:
- ✅ Zero null values in primary key columns
- ✅ Watermark column values monotonically increasing (incremental)
- ✅ Partition distribution balanced (if partitioning enabled)
- ✅ File sizes within acceptable range (50MB-1GB per file)

---

## Common Failure Modes

### Connection Failures
- **Symptom**: `java.sql.SQLException: Connection refused`
- **Resolution**: Verify firewall rules, service principal permissions, JDBC URL format

### Schema Mismatches
- **Symptom**: `pyspark.sql.utils.AnalysisException: cannot resolve column`
- **Resolution**: Confirm source schema, check case sensitivity, verify column names

### Watermark Issues
- **Symptom**: `AttributeError: 'NoneType' object has no attribute 'cast'`
- **Resolution**: Validate watermark column exists, check data type compatibility

### Permission Errors
- **Symptom**: `403 Forbidden: This request is not authorized`
- **Resolution**: Grant Storage Blob Data Contributor role, verify ABFS path format

---

## Environment Variables

```yaml
AZURE_STORAGE_ACCOUNT: "<storage_account_name>"
AZURE_TENANT_ID: "<tenant_id>"
AZURE_CLIENT_ID: "<service_principal_app_id>"
AZURE_CLIENT_SECRET: "<service_principal_password>"  # from Key Vault
JDBC_DRIVER_PATH: "/dbfs/drivers/<jdbc_driver>.jar"
RAW_BASE_PATH: "abfss://raw@<storage>.dfs.core.windows.net"
```

---

## Templates

**Available Templates**:
- `env-config.yaml`: Production environment configuration (storage paths, connection pools)
- `dev.yaml`: Development environment overrides (reduced partitioning, debug logging)

**Template Usage**:
```bash
# Generate ingestion pipeline with dev config
/scaffold source=oracle_hr dataset=employees config=dev.yaml
```

---

**End of Constitution**
