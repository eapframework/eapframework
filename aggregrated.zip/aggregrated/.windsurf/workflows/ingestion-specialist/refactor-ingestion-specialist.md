---
description: Improve ingestion code quality through configuration consolidation, adapter extraction, and performance optimization
glyphEnabled: true
glyph: refactor
---

User input: $ARGUMENTS

## Context

You are refactoring **existing ingestion pipeline code** to improve maintainability, performance, and reusability by consolidating configurations, extracting reusable adapters, and optimizing JDBC partitioning.

**Refactoring Goals**:
1. **Consolidate duplicate configurations** (merge similar source configs)
2. **Extract reusable adapter functions** (JDBC, Spark Reader, Custom)
3. **Optimize JDBC partitioning** (fix skewed distributions)
4. **Improve error handling** (add retries, better logging)
5. **Migrate Python configs to YAML** (deprecate hard-coded configs)

---

## Expected User Input

The user will provide one of:
1. **Refactoring target**: `target=config` or `target=code` or `target=performance`
2. **Specific issue**: `issue="duplicate configs"` or `issue="slow JDBC reads"`
3. **File path**: `file=generated/ingest_raw/ingest_raw.py`
4. **Interactive mode**: `/refactor` (analyze codebase and suggest improvements)

---

## Refactoring Patterns

### Pattern 1: Consolidate Duplicate Configurations

**Problem**: Multiple config.yaml files with 90% identical content

**Before** (5 separate files):
```yaml
# config_snowflake_orders.yaml
source:
  adapter: jdbc
  system: snowflake_sales
  connection:
    options:
      url: "jdbc:snowflake://account.snowflakecomputing.com"
      user: "${SNOWFLAKE_USER}"
      password: "${SNOWFLAKE_PASSWORD}"
      warehouse: "COMPUTE_WH"
  read:
    mode: table
    table: "SALES_DB.PUBLIC.FACT_ORDERS"

# config_snowflake_customers.yaml (90% duplicate)
source:
  adapter: jdbc
  system: snowflake_sales
  connection:
    options:
      url: "jdbc:snowflake://account.snowflakecomputing.com"  # DUPLICATE
      user: "${SNOWFLAKE_USER}"  # DUPLICATE
      password: "${SNOWFLAKE_PASSWORD}"  # DUPLICATE
      warehouse: "COMPUTE_WH"  # DUPLICATE
  read:
    mode: table
    table: "SALES_DB.PUBLIC.DIM_CUSTOMERS"  # ONLY DIFFERENCE
```

**After** (1 base config + overrides):

**Base Config**: `configs/base/snowflake_sales.yaml`
```yaml
# Base configuration for Snowflake Sales database
source:
  adapter: jdbc
  system: snowflake_sales
  connection:
    options:
      url: "jdbc:snowflake://account.snowflakecomputing.com"
      user: "${SNOWFLAKE_USER}"
      password: "${SNOWFLAKE_PASSWORD}"
      warehouse: "COMPUTE_WH"
      database: "SALES_DB"
      schema: "PUBLIC"
  read:
    mode: table
    options:
      fetchSize: 10000

load:
  type: incremental
  
target:
  raw_base_path: "abfss://raw@${AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net"
  file_format: parquet
  write_mode: append
```

**Dataset-Specific Config**: `configs/datasets/fact_orders.yaml`
```yaml
# Inherits from: configs/base/snowflake_sales.yaml
extends: configs/base/snowflake_sales.yaml

# Override only dataset-specific values
source:
  read:
    table: "SALES_DB.PUBLIC.FACT_ORDERS"
    partitioning:
      enabled: true
      column: "ORDER_ID"
      lower_bound: 1
      upper_bound: 100000000
      num_partitions: 32

load:
  watermark_column: "UPDATED_AT"
  start_value: "${LAST_RUN_TIMESTAMP}"

target:
  dataset_name: "fact_orders"
```

**Config Merging Logic**:
```python
def load_config_with_inheritance(config_path: str) -> dict:
    """Load config with base config inheritance."""
    import yaml
    
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Check for 'extends' key
    if 'extends' in config:
        base_config_path = config.pop('extends')
        base_config = load_config_with_inheritance(base_config_path)
        
        # Deep merge: dataset config overrides base config
        merged_config = deep_merge(base_config, config)
        return merged_config
    
    return config


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base."""
    merged = base.copy()
    
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    
    return merged
```

**Benefits**:
- ✅ Reduced duplication: 5 configs → 1 base + 5 overrides (60% smaller)
- ✅ Single source of truth for connection details
- ✅ Easier credential rotation (update base config once)
- ✅ Consistent defaults across datasets

---

### Pattern 2: Extract Reusable Adapter Functions

**Problem**: JDBC adapter logic duplicated across multiple ingest scripts

**Before** (monolithic ingest_raw.py):
```python
def read_source(spark, config):
    """Read from source (inline adapter logic)."""
    adapter = config['source']['adapter']
    
    if adapter == 'jdbc':
        # 50 lines of JDBC logic (duplicated in every ingest script)
        conn_opts = config['source']['connection']['options']
        jdbc_options = {
            "url": conn_opts['url'],
            "user": conn_opts['user'],
            "password": conn_opts['password'],
        }
        
        if 'partitioning' in config['source']['read']:
            part = config['source']['read']['partitioning']
            jdbc_options['partitionColumn'] = part['column']
            # ... 20 more lines
        
        df = spark.read.format("jdbc").options(**jdbc_options).load()
        
        if config['load']['type'] == 'incremental':
            # ... 15 more lines
        
        return df
```

**After** (extracted adapters library):

**Adapters Library**: `lib/adapters.py`
```python
"""Reusable data source adapters for ingestion pipelines."""

from pyspark.sql import SparkSession, DataFrame
from typing import Dict, Any


class JDBCAdapter:
    """Generic JDBC adapter with partitioning and incremental support."""
    
    def __init__(self, spark: SparkSession, config: Dict[str, Any]):
        self.spark = spark
        self.config = config
    
    def read(self) -> DataFrame:
        """Read from JDBC source with partitioning and filtering."""
        conn_opts = self.config['source']['connection']['options']
        read_opts = self.config['source']['read'].get('options', {})
        
        # Base JDBC options
        jdbc_options = {
            "url": conn_opts['url'],
            "user": conn_opts['user'],
            "password": conn_opts['password'],
            **{k: v for k, v in conn_opts.items() if k not in ['url', 'user', 'password']},
            **read_opts
        }
        
        # Table or query mode
        read_config = self.config['source']['read']
        if read_config['mode'] == 'table':
            jdbc_options['dbtable'] = read_config['table']
        elif read_config['mode'] == 'query':
            jdbc_options['query'] = read_config['query']
        
        # Partitioning
        if self._is_partitioning_enabled():
            jdbc_options.update(self._get_partition_options())
        
        # Read data
        df = self.spark.read.format("jdbc").options(**jdbc_options).load()
        
        # Apply incremental filter
        if self._is_incremental():
            df = self._apply_watermark_filter(df)
        
        return df
    
    def _is_partitioning_enabled(self) -> bool:
        """Check if partitioning is enabled."""
        return self.config['source']['read'].get('partitioning', {}).get('enabled', False)
    
    def _get_partition_options(self) -> Dict[str, Any]:
        """Get JDBC partitioning options."""
        part = self.config['source']['read']['partitioning']
        return {
            'partitionColumn': part['column'],
            'lowerBound': part['lower_bound'],
            'upperBound': part['upper_bound'],
            'numPartitions': part['num_partitions']
        }
    
    def _is_incremental(self) -> bool:
        """Check if incremental load."""
        return self.config['load']['type'] == 'incremental'
    
    def _apply_watermark_filter(self, df: DataFrame) -> DataFrame:
        """Apply watermark filter for incremental loads."""
        watermark_col = self.config['load']['watermark_column']
        start_value = self.config['load']['start_value']
        return df.filter(f"{watermark_col} >= '{start_value}'")


class SparkReaderAdapter:
    """Spark-native file reader adapter."""
    
    def __init__(self, spark: SparkSession, config: Dict[str, Any]):
        self.spark = spark
        self.config = config
    
    def read(self) -> DataFrame:
        """Read from files (Parquet, CSV, JSON, etc.)."""
        read_config = self.config['source']['read']
        path = read_config['path']
        options = read_config['options']
        file_format = options.pop('format', 'parquet')
        
        df = self.spark.read.format(file_format).options(**options).load(path)
        
        # Apply incremental filter
        if self.config['load']['type'] == 'incremental':
            watermark_col = self.config['load']['watermark_column']
            start_value = self.config['load']['start_value']
            df = df.filter(f"{watermark_col} >= '{start_value}'")
        
        return df


def get_adapter(spark: SparkSession, config: Dict[str, Any]):
    """Factory function to get appropriate adapter."""
    adapter_type = config['source']['adapter']
    
    adapters = {
        'jdbc': JDBCAdapter,
        'spark_reader': SparkReaderAdapter,
    }
    
    if adapter_type not in adapters:
        raise ValueError(f"Unsupported adapter: {adapter_type}")
    
    return adapters[adapter_type](spark, config)
```

**Refactored ingest_raw.py**:
```python
from lib.adapters import get_adapter

def read_source(spark, config):
    """Read from source using adapter."""
    adapter = get_adapter(spark, config)
    return adapter.read()  # 1 line (was 50+ lines)
```

**Benefits**:
- ✅ Reduced code duplication: 50 lines → 1 line per script
- ✅ Centralized adapter logic (fix bugs once)
- ✅ Unit testable (mock adapters easily)
- ✅ Extensible (add new adapters without modifying scripts)

---

### Pattern 3: Optimize JDBC Partitioning

**Problem**: JDBC reads are slow due to skewed partitioning

**Before** (skewed distribution):
```yaml
partitioning:
  enabled: true
  column: "ORDER_STATUS"  # ❌ String column with 5 values
  # Result: All data goes to 1-2 partitions (skew)
```

**Diagnostic Query**:
```sql
-- Check distribution of ORDER_STATUS
SELECT ORDER_STATUS, COUNT(*) as cnt
FROM SALES_DB.PUBLIC.FACT_ORDERS
GROUP BY ORDER_STATUS
ORDER BY cnt DESC;

-- Results:
-- 'COMPLETED': 90,000,000 rows (90%)
-- 'PENDING': 8,000,000 rows (8%)
-- 'CANCELLED': 1,500,000 rows (1.5%)
-- 'RETURNED': 500,000 rows (0.5%)
```

**After** (uniform distribution):
```yaml
partitioning:
  enabled: true
  column: "ORDER_ID"  # ✅ Auto-increment integer
  lower_bound: 1
  upper_bound: 100000000
  num_partitions: 32
  # Result: Each partition gets ~3.125M rows (evenly distributed)
```

**Partition Distribution Check**:
```python
# After refactoring, verify partition balance
df = spark.read.format("jdbc").options(**jdbc_options).load()

# Count rows per partition
partition_counts = df.rdd.glom().map(len).collect()

print("Partition distribution:")
for idx, count in enumerate(partition_counts):
    print(f"  Partition {idx}: {count:,} rows")

# Expected: All partitions have similar row counts (±10%)
# Bad: Partition 0: 90M rows, others: 0 rows (skew)
```

**Performance Impact**:
- **Before**: 1 executor processes 90M rows, others idle → 60 minutes
- **After**: 32 executors each process ~3M rows → 5 minutes (12x faster)

---

### Pattern 4: Improve Error Handling

**Problem**: Ingestion fails with cryptic errors, no retries

**Before** (no error handling):
```python
def read_source(spark, config):
    """Read from source (fails immediately on error)."""
    adapter = config['source']['adapter']
    
    if adapter == 'jdbc':
        df = spark.read.format("jdbc").options(**jdbc_options).load()
        # If connection fails, entire job fails (no retry)
    
    return df
```

**After** (retry logic + detailed logging):
```python
import time
import logging

logger = logging.getLogger(__name__)


def read_source_with_retry(spark, config, max_retries=3, backoff_seconds=30):
    """Read from source with exponential backoff retry."""
    adapter_type = config['source']['adapter']
    
    for attempt in range(1, max_retries + 1):
        try:
            logger.info(f"Reading from {adapter_type} (attempt {attempt}/{max_retries})")
            
            adapter = get_adapter(spark, config)
            df = adapter.read()
            
            row_count = df.count()
            logger.info(f"✅ Successfully read {row_count:,} rows from {adapter_type}")
            
            return df
        
        except Exception as e:
            logger.error(f"❌ Attempt {attempt} failed: {str(e)}")
            
            if attempt < max_retries:
                wait_time = backoff_seconds * (2 ** (attempt - 1))  # Exponential backoff
                logger.info(f"⏳ Retrying in {wait_time} seconds...")
                time.sleep(wait_time)
            else:
                logger.error(f"❌ All {max_retries} attempts failed. Aborting.")
                raise
```

**Benefits**:
- ✅ Transient network errors automatically retried
- ✅ Detailed logging for debugging
- ✅ Exponential backoff prevents overwhelming source
- ✅ Clear error messages for permanent failures

---

### Pattern 5: Migrate Python Configs to YAML

**Problem**: Hard-coded configuration in Python files (not reusable)

**Before** (`pipeline-builder-config.py`):
```python
# Hard-coded configuration (deprecated)
CONFIG = {
    "source": {
        "adapter": "jdbc",
        "url": "jdbc:snowflake://account.snowflakecomputing.com",  # Hard-coded
        "user": "svc_databricks",  # Hard-coded
        "password": "P@ssw0rd123",  # ❌ Plain-text password in Git
    },
    "target": {
        "path": "abfss://raw@storage.dfs.core.windows.net/raw/fact_orders",  # Hard-coded
    }
}
```

**After** (YAML configuration):

**Config File**: `configs/fact_orders.yaml`
```yaml
source:
  adapter: jdbc
  connection:
    options:
      url: "jdbc:snowflake://${SNOWFLAKE_ACCOUNT}.snowflakecomputing.com"
      user: "${SNOWFLAKE_USER}"  # From environment or Key Vault
      password: "${SNOWFLAKE_PASSWORD}"  # From Key Vault (secure)

target:
  raw_base_path: "abfss://raw@${AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net"
  dataset_name: "fact_orders"
```

**Migration Script**: `migrate_config.py`
```python
"""Migrate hard-coded Python configs to YAML."""

import yaml

# Old Python config
from pipeline_builder_config import CONFIG

# Convert to YAML format
yaml_config = {
    "source": {
        "adapter": CONFIG["source"]["adapter"],
        "connection": {
            "options": {
                "url": CONFIG["source"]["url"].replace(
                    "account.snowflakecomputing.com",
                    "${SNOWFLAKE_ACCOUNT}.snowflakecomputing.com"
                ),
                "user": "${SNOWFLAKE_USER}",  # Externalize
                "password": "${SNOWFLAKE_PASSWORD}",  # Externalize
            }
        }
    },
    "target": {
        "raw_base_path": CONFIG["target"]["path"].rsplit('/', 1)[0],
        "dataset_name": CONFIG["target"]["path"].rsplit('/', 1)[1],
    }
}

# Write YAML
with open('configs/fact_orders.yaml', 'w') as f:
    yaml.dump(yaml_config, f, default_flow_style=False, sort_keys=False)

print("✅ Migrated pipeline-builder-config.py → configs/fact_orders.yaml")
print("⚠️  Delete pipeline-builder-config.py after validation")
```

**Benefits**:
- ✅ No hard-coded credentials (use environment variables)
- ✅ Configuration versioned separately from code
- ✅ Environment-specific configs (dev, prod)
- ✅ Secrets managed in Key Vault

---

## Refactoring Workflow

### Step 1: Analyze Current Code

Scan codebase for:
- Duplicate configurations
- Inline adapter logic
- Hard-coded values
- Missing error handling
- Suboptimal partitioning

### Step 2: Prioritize Improvements

Rank by impact:
1. **High**: Security issues (plain-text passwords)
2. **High**: Performance issues (slow JDBC reads)
3. **Medium**: Code duplication (maintainability)
4. **Low**: Code style improvements

### Step 3: Apply Refactoring Patterns

For each issue:
- Apply appropriate pattern (consolidation, extraction, optimization)
- Update tests
- Validate behavior unchanged

### Step 4: Generate Refactoring Report

**Output Template**:

```
================================================================================
🔧 Ingestion Pipeline Refactoring Report
================================================================================

Date: {{current_date}}
Target: {{refactoring_target}}

Issues Identified:
------------------
1. ❌ Duplicate configurations (5 files, 90% identical)
2. ❌ Inline adapter logic (50 lines duplicated across 10 scripts)
3. ❌ Skewed JDBC partitioning (90% data in 1 partition)
4. ❌ Hard-coded credentials (plain-text passwords in Git)

Refactoring Applied:
--------------------
1. ✅ Consolidated configs: 5 files → 1 base + 5 overrides (60% reduction)
2. ✅ Extracted adapters: Created lib/adapters.py (50 lines → 1 line per script)
3. ✅ Optimized partitioning: Changed column from ORDER_STATUS → ORDER_ID
4. ✅ Migrated to YAML: Removed pipeline-builder-config.py, added configs/*.yaml

Performance Impact:
-------------------
Before: 60 minutes (single partition)
After: 5 minutes (32 partitions, 12x faster)

Code Quality Metrics:
---------------------
- Lines of code: 2,500 → 1,200 (52% reduction)
- Code duplication: 60% → 5%
- Config files: 5 → 6 (1 base + 5 overrides)
- Unit test coverage: 40% → 85%

Security Improvements:
----------------------
- ✅ Removed plain-text passwords
- ✅ Credentials externalized to environment variables
- ✅ Secrets referenced from Azure Key Vault

Next Steps:
-----------
1. Delete deprecated pipeline-builder-config.py
2. Update documentation (runbooks, connection guides)
3. Deploy refactored code to dev environment
4. Run regression tests
5. Deploy to production

Files Modified:
---------------
- generated/ingest_raw/ingest_raw.py
- lib/adapters.py (new)
- configs/base/snowflake_sales.yaml (new)
- configs/datasets/fact_orders.yaml (new)
- pipeline-builder-config.py (deprecated, delete after validation)

================================================================================
```

---

## Validation Checklist

Before completing, verify:

- [x] Refactored code produces identical output (regression tests pass)
- [x] Performance improvements validated (benchmarks run)
- [x] Security issues resolved (no plain-text credentials)
- [x] Code duplication reduced (< 10% duplication)
- [x] Unit test coverage increased (> 80%)
- [x] Documentation updated (runbooks, READMEs)

---

**End of Refactor Workflow**
