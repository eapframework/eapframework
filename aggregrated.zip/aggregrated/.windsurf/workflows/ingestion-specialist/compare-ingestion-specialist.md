---
description: Compare ingestion strategies and choose optimal adapter, load type, and partitioning
glyphEnabled: true
glyph: compare
---

User input: $ARGUMENTS

## Context

You are helping the user choose the **optimal ingestion strategy** for their data source by comparing adapters, load types, partitioning approaches, and performance trade-offs.

**Decision Factors**:
- Data volume (rows, size)
- Source system type (database, files, API)
- Update frequency (batch, streaming, CDC)
- Network bandwidth
- Cost sensitivity

---

## Expected User Input

The user will provide one of:
1. **Source details**: `source=snowflake_sales dataset=fact_orders rows=50000000`
2. **Current strategy**: `current_adapter=jdbc current_load=full`
3. **Performance problem**: `issue="ingestion takes 2 hours"`
4. **Interactive mode**: `/compare` (prompt for details)

---

## Comparison Framework

### Dimension 1: Adapter Selection

#### JDBC vs Spark Reader vs Custom

| Factor | JDBC | Spark Reader | Custom |
|--------|------|--------------|--------|
| **Use Case** | Relational databases (Oracle, Snowflake, Postgres) | Files (Parquet, CSV, JSON, Delta) | APIs, Kafka, SaaS |
| **Complexity** | Low | Low | High |
| **Performance** | Medium (network bottleneck) | High (parallel file reads) | Varies |
| **Partitioning** | Yes (column-based) | Yes (file-based) | Manual implementation |
| **Cost** | Medium (compute for JDBC driver) | Low (native Spark) | High (custom code maintenance) |
| **Failure Handling** | Built-in retries | Built-in | Custom implementation |

**Decision Tree**:
```
Is source a relational database?
├─ Yes → Use JDBC adapter
│  ├─ > 10M rows? → Enable partitioning
│  └─ < 10M rows? → Single partition
│
└─ No → Is source file-based?
   ├─ Yes → Use Spark Reader adapter
   │  ├─ Files in ADLS/S3? → Use abfss:// or s3:// paths
   │  └─ Files local? → Use file:// paths
   │
   └─ No → Use Custom adapter
      └─ Implement API/Kafka connector
```

---

### Dimension 2: Load Type

#### Full Load vs Incremental Load

| Factor | Full Load | Incremental Load |
|--------|-----------|------------------|
| **When to Use** | Initial load, small datasets, no watermark column | Large datasets, reliable watermark column exists |
| **Data Volume** | All rows | Only new/changed rows |
| **Write Mode** | Overwrite | Append |
| **Performance** | Slow (reads entire table) | Fast (reads filtered subset) |
| **Complexity** | Low | Medium (requires watermark management) |
| **Cost** | High (full table scan) | Low (delta scan only) |
| **Data Freshness** | Complete snapshot | Delta updates |
| **Failure Recovery** | Re-run from start | Resume from last watermark |

**Decision Criteria**:

**Use Full Load When**:
- ✅ Dataset < 10M rows
- ✅ No reliable watermark column (e.g., `updated_at`, `created_at`)
- ✅ Source data changes unpredictably (no incremental pattern)
- ✅ One-time migration (not recurring)
- ✅ Overwrite is acceptable

**Use Incremental Load When**:
- ✅ Dataset > 10M rows
- ✅ Reliable watermark column exists and is indexed
- ✅ Daily/hourly refresh cadence
- ✅ Cost optimization required (avoid scanning entire table)
- ✅ Append-only workload (no deletes/updates)

**Hybrid Approach**:
- **Weekly full load** + **daily incremental** (reconcile data drift)

---

### Dimension 3: Partitioning Strategy

#### JDBC Partitioning (Column-Based)

**When to Enable**:
- Dataset > 10M rows
- Numeric partitioning column exists with uniform distribution
- Multiple executor cores available (16+)

**Configuration Example**:
```yaml
partitioning:
  enabled: true
  column: "ORDER_ID"  # Integer column, evenly distributed
  lower_bound: 1
  upper_bound: 100000000
  num_partitions: 32  # = cluster_cores * 2
```

**How It Works**:
- Spark divides `ORDER_ID` range into 32 equal slices
- Each executor reads one slice in parallel
- Example: Executor 1 reads `ORDER_ID BETWEEN 1 AND 3125000`

**Performance Impact**:
- **Before partitioning**: 1 executor, 60 minutes
- **After partitioning (32 partitions)**: 32 executors, 5 minutes
- **Speedup**: 12x (theoretical 32x, reduced by overhead)

**Pitfalls**:
- ❌ Non-uniform distribution (e.g., `ORDER_ID` skewed toward recent values)
- ❌ Partitioning on string columns (inefficient)
- ❌ Too many partitions (> 100) causes scheduler overhead
- ❌ Too few partitions (< cluster_cores) underutilizes cluster

**Partitioning Column Selection**:

| Column Type | Suitability | Example | Notes |
|-------------|-------------|---------|-------|
| **Auto-increment ID** | ✅ Excellent | `ORDER_ID`, `CUSTOMER_ID` | Uniform distribution, numeric |
| **Timestamp** | ⚠️ Conditional | `CREATED_AT` | Works if converted to Unix epoch |
| **Date** | ⚠️ Conditional | `ORDER_DATE` | Works if converted to integer (YYYYMMDD) |
| **String** | ❌ Poor | `ORDER_STATUS` | Non-numeric, hash-based partitioning inefficient |
| **UUID** | ❌ Poor | `TRANSACTION_ID` | Non-sequential, skewed distribution |

---

### Dimension 4: File Format Optimization

#### Parquet Compression

**Compression Codecs**:

| Codec | Compression Ratio | Speed | CPU Usage | Use Case |
|-------|-------------------|-------|-----------|----------|
| **snappy** | 3-4x | Fast | Low | Default (balanced) |
| **gzip** | 5-7x | Slow | High | Archival, infrequent access |
| **lz4** | 2-3x | Very Fast | Very Low | Streaming, high throughput |
| **zstd** | 4-6x | Medium | Medium | Modern default (better than snappy) |

**Recommendation**: Use `snappy` for Raw zone (good compression + fast reads in Silver transformations).

---

### Dimension 5: File Size Optimization

#### Records Per File

**Target File Size**: 50MB - 1GB per Parquet file

**Configuration**:
```yaml
target:
  options:
    maxRecordsPerFile: 1000000  # Adjust based on row size
```

**Trade-offs**:

| File Size | Files Count | Read Performance | Listing Overhead |
|-----------|-------------|------------------|------------------|
| **10MB** | 10,000 | Slow (small file problem) | High |
| **100MB** | 1,000 | Good | Medium |
| **500MB** | 200 | Optimal | Low |
| **2GB** | 50 | Slow (can't parallelize) | Very Low |

**Small File Problem**:
- Symptom: Ingestion creates 50,000 files of 2MB each
- Impact: Silver transformations list files for 10 minutes before reading
- Solution: Use `coalesce()` to reduce files:
  ```python
  df.coalesce(16).write.parquet(output_path)
  ```

---

## Decision Matrix

### Scenario 1: Small Dataset (< 10M rows)

**Input**:
- Source: Oracle HR database
- Dataset: `EMPLOYEES` table
- Rows: 500,000
- Update frequency: Daily

**Recommendation**:
```yaml
source:
  adapter: jdbc  # Relational database
  
load:
  type: full  # Small dataset, full load acceptable
  
partitioning:
  enabled: false  # < 10M rows, single partition sufficient
  
target:
  write_mode: overwrite  # Full load overwrites
  options:
    maxRecordsPerFile: 500000  # Single file (small dataset)
```

**Expected Performance**: 2-3 minutes

---

### Scenario 2: Large Dataset (> 100M rows)

**Input**:
- Source: Snowflake Sales database
- Dataset: `FACT_ORDERS` table
- Rows: 250,000,000
- Update frequency: Hourly
- Watermark column: `UPDATED_AT` (indexed)

**Recommendation**:
```yaml
source:
  adapter: jdbc
  read:
    partitioning:
      enabled: true
      column: "ORDER_ID"  # Auto-increment, uniform distribution
      lower_bound: 1
      upper_bound: 250000000
      num_partitions: 64  # 32-core cluster * 2
  
load:
  type: incremental  # Only read new/changed rows
  watermark_column: "UPDATED_AT"
  start_value: "${LAST_RUN_TIMESTAMP}"  # From orchestrator
  
target:
  write_mode: append  # Incremental appends
  options:
    maxRecordsPerFile: 2000000  # ~100MB files (assuming 50 bytes/row)
```

**Expected Performance**:
- Full load: 60 minutes (250M rows / 64 partitions)
- Incremental load: 3 minutes (500K new rows / 64 partitions)

---

### Scenario 3: File-Based Source

**Input**:
- Source: ADLS landing zone
- Dataset: CSV exports from legacy system
- Files: 1,000 CSV files, 500MB each
- Update frequency: Daily batch

**Recommendation**:
```yaml
source:
  adapter: spark_reader  # Files, not database
  read:
    mode: path
    path: "abfss://landing@storage.dfs.core.windows.net/exports/*.csv"
    options:
      format: csv
      header: true
      inferSchema: false  # Provide explicit schema (faster)
      schema: ${EXPLICIT_SCHEMA}
  
load:
  type: full  # Batch files, overwrite daily
  
target:
  write_mode: overwrite
  options:
    compression: snappy
    maxRecordsPerFile: 1000000  # ~50-100MB Parquet files
```

**Performance Optimization**:
- Spark automatically parallelizes across 1,000 CSV files
- No partitioning needed (file-level parallelism)
- **Expected Performance**: 10-15 minutes for 500GB

---

### Scenario 4: API Source (Custom Adapter)

**Input**:
- Source: Palantir Foundry API
- Dataset: Pipeline metadata JSON
- Volume: 10,000 API calls (paginated)
- Update frequency: Weekly

**Recommendation**:
```yaml
source:
  adapter: custom  # REST API
  connection:
    options:
      base_url: "https://palantir.company.com/api"
      auth_token: "${PALANTIR_TOKEN}"
      pagination:
        enabled: true
        page_size: 100
  
load:
  type: full  # API snapshots, no watermark
  
target:
  write_mode: overwrite
  options:
    compression: snappy
```

**Custom Implementation Required**:
```python
def read_custom(spark, config):
    """Custom Palantir API reader."""
    import requests
    
    base_url = config['source']['connection']['options']['base_url']
    auth_token = config['source']['connection']['options']['auth_token']
    
    # Fetch all pages
    all_records = []
    page = 1
    while True:
        response = requests.get(
            f"{base_url}/datasets",
            headers={"Authorization": f"Bearer {auth_token}"},
            params={"page": page, "pageSize": 100}
        )
        data = response.json()
        all_records.extend(data['results'])
        
        if not data['hasMore']:
            break
        page += 1
    
    # Convert to DataFrame
    return spark.createDataFrame(all_records)
```

**Expected Performance**: 5-10 minutes (network-bound)

---

## Comparison Output Template

When user runs `/compare`, generate:

```
================================================================================
🔍 Ingestion Strategy Comparison
================================================================================

Dataset: {{dataset}}
Source: {{source}}
Rows: {{row_count}}
Update Frequency: {{frequency}}

--------------------------------------------------------------------------------
Adapter Comparison
--------------------------------------------------------------------------------

Current: {{current_adapter}}
Alternatives:

1. JDBC
   ✅ Best for: Relational databases
   Performance: Medium (network-bound)
   Complexity: Low
   Cost: Medium

2. Spark Reader
   ✅ Best for: Files (Parquet, CSV, JSON)
   Performance: High (parallel file reads)
   Complexity: Low
   Cost: Low

3. Custom
   ⚠️  Best for: APIs, Kafka, SaaS
   Performance: Varies
   Complexity: High
   Cost: High (maintenance)

Recommendation: {{recommended_adapter}}
Reason: {{reason}}

--------------------------------------------------------------------------------
Load Type Comparison
--------------------------------------------------------------------------------

Current: {{current_load_type}}
Alternatives:

1. Full Load
   Data Volume: All rows ({{row_count}})
   Write Mode: Overwrite
   Performance: {{full_load_time}} minutes
   Cost: ${{full_load_cost}}

2. Incremental Load
   Data Volume: Delta only (~{{delta_rows}} rows/day)
   Write Mode: Append
   Performance: {{incremental_load_time}} minutes
   Cost: ${{incremental_load_cost}}
   Requirement: Watermark column ({{watermark_column}})

Recommendation: {{recommended_load_type}}
Savings: ${{cost_savings}}/month ({{time_savings}}% faster)

--------------------------------------------------------------------------------
Partitioning Comparison
--------------------------------------------------------------------------------

Current: {{current_partitions}} partitions
Alternatives:

1. No Partitioning (1 partition)
   Performance: {{single_partition_time}} minutes
   Best for: < 10M rows

2. Moderate Partitioning (16 partitions)
   Performance: {{moderate_partition_time}} minutes
   Best for: 10M - 100M rows

3. High Partitioning (64 partitions)
   Performance: {{high_partition_time}} minutes
   Best for: > 100M rows

Recommendation: {{recommended_partitions}} partitions on {{recommended_column}}
Speedup: {{speedup}}x faster

--------------------------------------------------------------------------------
Summary
--------------------------------------------------------------------------------

Recommended Configuration:

adapter: {{recommended_adapter}}
load_type: {{recommended_load_type}}
partitions: {{recommended_partitions}}
watermark_column: {{watermark_column}}

Expected Performance:
- Full load: {{optimized_full_load_time}} minutes
- Incremental load: {{optimized_incremental_time}} minutes

Cost Savings: ${{monthly_savings}}/month

Next Steps:
1. Update config.yaml with recommended settings
2. Test configuration: /test config_file=config.yaml
3. Run benchmark: /scaffold benchmark=True
4. Compare actual vs expected performance

================================================================================
```

---

## Validation Checklist

Before completing, verify:

- [x] Adapter comparison includes JDBC, Spark Reader, Custom
- [x] Load type comparison includes full vs incremental with cost analysis
- [x] Partitioning recommendations based on data volume
- [x] Performance estimates provided (time, cost)
- [x] Recommendations are actionable (include config snippets)
- [x] Trade-offs clearly explained

---

**End of Compare Workflow**
