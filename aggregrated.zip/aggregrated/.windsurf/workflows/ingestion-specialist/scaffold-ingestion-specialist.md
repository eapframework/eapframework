---
description: Generate PySpark ingestion code and configuration for any data source
glyphEnabled: true
glyph: scaffold
---

User input: $ARGUMENTS

## Context

You are creating a **schema-preserving PySpark ingestion pipeline** that reads from any source system and writes raw Parquet files to Azure ADLS Gen2.

**Core Requirements**:
- NO transformations (preserve source schema exactly)
- Support JDBC, Spark Reader, and Custom adapters
- Handle full and incremental loads
- Append metadata columns: `_ingested_at`, `_source_system`
- Configuration-driven (no hard-coded connections)

---

## Expected User Input

The user will provide one of:
1. **Source details**: `source=snowflake_sales dataset=fact_orders load_type=incremental`
2. **Configuration file**: `config=config.yaml`
3. **Interactive mode**: `/scaffold` (prompt for details)

---

## Step 1: Extract Requirements

### Parse User Input

Extract these parameters:

| Parameter | Required | Default | Example |
|-----------|----------|---------|---------|
| `source` | Yes | - | `snowflake_sales` |
| `dataset` | Yes | - | `fact_orders` |
| `adapter` | No | `jdbc` | `jdbc`, `spark_reader`, `custom` |
| `load_type` | No | `full` | `full`, `incremental` |
| `watermark_column` | Conditional | - | `updated_at` (required if `load_type=incremental`) |
| `start_value` | No | - | `2026-01-01T00:00:00Z` |
| `output_path` | No | `generated/ingest_raw` | Custom path for generated files |
| `config` | No | - | Path to existing config.yaml |

### Validation Rules

**If `load_type=incremental`**:
- MUST provide `watermark_column`
- Watermark column MUST be date/timestamp type
- SHOULD provide `start_value` (defaults to 30 days ago if missing)

**If `adapter=jdbc`**:
- MUST provide connection details (URL, user, password)
- SHOULD provide table name or query
- MAY provide partitioning configuration

**If `adapter=spark_reader`**:
- MUST provide file path or path pattern
- MUST specify file format (parquet, csv, json, avro)

**If `adapter=custom`**:
- MUST provide custom reader implementation or API details

---

## Step 2: Generate Configuration File

Create `config.yaml` with the following structure:

### Template: JDBC Adapter

```yaml
# Source configuration
source:
  adapter: jdbc
  system: {{source}}
  connection:
    name: {{source}}_prod
    options:
      url: "jdbc:{{driver}}://{{host}}:{{port}}/{{database}}"
      user: "${{{source|upper}}_USER}"
      password: "${{{source|upper}}_PASSWORD}"
      # Driver-specific options
      {% if driver == 'snowflake' %}
      warehouse: "COMPUTE_WH"
      schema: "PUBLIC"
      {% elif driver == 'oracle' %}
      driver: "oracle.jdbc.driver.OracleDriver"
      {% elif driver == 'postgres' %}
      driver: "org.postgresql.Driver"
      {% endif %}
  
  read:
    mode: table  # or 'query'
    table: "{{database}}.{{schema}}.{{table_name}}"
    options:
      fetchSize: 10000
    
    # Partitioning (optional, recommended for > 10M rows)
    partitioning:
      enabled: false
      column: ""  # Numeric column with uniform distribution
      lower_bound: null
      upper_bound: null
      num_partitions: 8  # cluster_cores * 2

# Load configuration
load:
  type: {{load_type}}
  {% if load_type == 'incremental' %}
  watermark_column: "{{watermark_column}}"
  start_value: "{{start_value}}"
  {% endif %}

# Target configuration
target:
  raw_base_path: "abfss://raw@${AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net"
  dataset_name: "{{dataset}}"
  file_format: parquet
  write_mode: {% if load_type == 'full' %}overwrite{% else %}append{% endif %}
  options:
    compression: snappy
    maxRecordsPerFile: 1000000

# Metadata columns
metadata:
  columns:
    - name: "_ingested_at"
      type: timestamp
      value: "current_timestamp()"
    - name: "_source_system"
      type: string
      value: "{{source}}"
```

### Template: Spark Reader Adapter

```yaml
source:
  adapter: spark_reader
  system: {{source}}
  
  read:
    mode: path
    path: "{{file_path}}"
    options:
      format: {{file_format}}  # parquet, csv, json, avro, delta
      {% if file_format == 'csv' %}
      header: true
      inferSchema: true
      {% elif file_format == 'json' %}
      multiLine: false
      {% endif %}
      mergeSchema: true

load:
  type: {{load_type}}
  {% if load_type == 'incremental' %}
  watermark_column: "{{watermark_column}}"
  start_value: "{{start_value}}"
  {% endif %}

target:
  raw_base_path: "abfss://raw@${AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net"
  dataset_name: "{{dataset}}"
  file_format: parquet
  write_mode: {% if load_type == 'full' %}overwrite{% else %}append{% endif %}
  options:
    compression: snappy
```

---

## Step 3: Generate PySpark Ingestion Script

Create `ingest_raw.py`:

```python
"""
Generic PySpark Ingestion Script
Reads from any source and writes schema-preserving Parquet to Raw zone.
"""

import sys
import yaml
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, lit
from datetime import datetime, timedelta


def load_config(config_path: str) -> dict:
    """Load YAML configuration file."""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Substitute environment variables
    config = substitute_env_vars(config)
    return config


def substitute_env_vars(config: dict) -> dict:
    """Replace ${VAR} with environment variable values."""
    import os
    import re
    
    def replace_vars(obj):
        if isinstance(obj, dict):
            return {k: replace_vars(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [replace_vars(v) for v in obj]
        elif isinstance(obj, str):
            pattern = r'\$\{([^}]+)\}'
            matches = re.findall(pattern, obj)
            for match in matches:
                value = os.getenv(match, f"${{{match}}}")
                obj = obj.replace(f"${{{match}}}", value)
            return obj
        return obj
    
    return replace_vars(config)


def create_spark_session(config: dict) -> SparkSession:
    """Create Spark session with required configurations."""
    builder = SparkSession.builder.appName(f"Ingest_{config['target']['dataset_name']}")
    
    # Add JDBC driver if needed
    if config['source']['adapter'] == 'jdbc':
        jdbc_driver = config['source']['connection']['options'].get('driver')
        if jdbc_driver:
            # Driver JAR should be pre-loaded in cluster libraries
            pass
    
    return builder.getOrCreate()


def read_source(spark: SparkSession, config: dict):
    """Read data from source based on adapter type."""
    adapter = config['source']['adapter']
    
    if adapter == 'jdbc':
        return read_jdbc(spark, config)
    elif adapter == 'spark_reader':
        return read_spark_native(spark, config)
    elif adapter == 'custom':
        return read_custom(spark, config)
    else:
        raise ValueError(f"Unsupported adapter: {adapter}")


def read_jdbc(spark: SparkSession, config: dict):
    """Read from JDBC source."""
    conn_opts = config['source']['connection']['options']
    read_opts = config['source']['read']['options']
    
    # Base JDBC options
    jdbc_options = {
        "url": conn_opts['url'],
        "user": conn_opts['user'],
        "password": conn_opts['password'],
        **{k: v for k, v in conn_opts.items() if k not in ['url', 'user', 'password']},
        **read_opts
    }
    
    # Read mode: table or query
    read_config = config['source']['read']
    if read_config['mode'] == 'table':
        jdbc_options['dbtable'] = read_config['table']
    elif read_config['mode'] == 'query':
        jdbc_options['query'] = read_config['query']
    
    # Partitioning
    if read_config.get('partitioning', {}).get('enabled', False):
        part_config = read_config['partitioning']
        jdbc_options['partitionColumn'] = part_config['column']
        jdbc_options['lowerBound'] = part_config['lower_bound']
        jdbc_options['upperBound'] = part_config['upper_bound']
        jdbc_options['numPartitions'] = part_config['num_partitions']
    
    df = spark.read.format("jdbc").options(**jdbc_options).load()
    
    # Apply incremental filter if needed
    if config['load']['type'] == 'incremental':
        watermark_col = config['load']['watermark_column']
        start_value = config['load']['start_value']
        df = df.filter(f"{watermark_col} >= '{start_value}'")
    
    return df


def read_spark_native(spark: SparkSession, config: dict):
    """Read from Spark-native sources (Parquet, CSV, JSON, etc.)."""
    read_config = config['source']['read']
    path = read_config['path']
    options = read_config['options']
    file_format = options.pop('format', 'parquet')
    
    df = spark.read.format(file_format).options(**options).load(path)
    
    # Apply incremental filter if needed
    if config['load']['type'] == 'incremental':
        watermark_col = config['load']['watermark_column']
        start_value = config['load']['start_value']
        df = df.filter(f"{watermark_col} >= '{start_value}'")
    
    return df


def read_custom(spark: SparkSession, config: dict):
    """Read from custom sources (Kafka, REST API, etc.)."""
    # Placeholder: Implement custom logic based on config
    raise NotImplementedError("Custom adapter requires implementation")


def add_metadata_columns(df, config: dict):
    """Append metadata columns to DataFrame."""
    metadata_cols = config.get('metadata', {}).get('columns', [])
    
    for col_config in metadata_cols:
        col_name = col_config['name']
        col_value = col_config['value']
        
        if col_value == 'current_timestamp()':
            df = df.withColumn(col_name, current_timestamp())
        else:
            df = df.withColumn(col_name, lit(col_value))
    
    return df


def write_to_raw(df, config: dict):
    """Write DataFrame to Raw zone as Parquet."""
    target = config['target']
    output_path = f"{target['raw_base_path']}/raw/{target['dataset_name']}"
    
    write_mode = target['write_mode']
    write_options = target.get('options', {})
    
    df.write.mode(write_mode).options(**write_options).parquet(output_path)
    
    print(f"✅ Ingestion complete: {output_path}")
    print(f"   Rows written: {df.count()}")
    print(f"   Write mode: {write_mode}")


def main(config_path: str):
    """Main ingestion pipeline."""
    # Load configuration
    config = load_config(config_path)
    
    # Create Spark session
    spark = create_spark_session(config)
    
    try:
        # Read from source
        print(f"📖 Reading from {config['source']['system']}...")
        df = read_source(spark, config)
        print(f"   Rows read: {df.count()}")
        
        # Add metadata columns
        df = add_metadata_columns(df, config)
        
        # Write to Raw zone
        print(f"💾 Writing to Raw zone...")
        write_to_raw(df, config)
        
    finally:
        spark.stop()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: spark-submit ingest_raw.py <config.yaml>")
        sys.exit(1)
    
    config_path = sys.argv[1]
    main(config_path)
```

---

## Step 4: Generate README

Create `README.md`:

```markdown
# Ingestion Pipeline: {{dataset}}

**Generated**: {{current_date}}  
**Source**: {{source}}  
**Adapter**: {{adapter}}  
**Load Type**: {{load_type}}

---

## Prerequisites

1. **Azure Resources**:
   - ADLS Gen2 storage account configured
   - Service principal with Storage Blob Data Contributor role
   - Raw zone container created: `raw`

2. **Databricks Cluster**:
   - Runtime: DBR 11.3+ (Spark 3.3+)
   {% if adapter == 'jdbc' %}
   - JDBC driver installed: {{jdbc_driver}}
   {% endif %}
   - Libraries: PyYAML

3. **Environment Variables**:
   ```bash
   export AZURE_STORAGE_ACCOUNT="<storage_account_name>"
   export {{source|upper}}_USER="<username>"
   export {{source|upper}}_PASSWORD="<password>"
   ```

---

## Configuration

Edit `config.yaml` to customize:

- **Connection**: Update URL, credentials (use environment variables)
- **Partitioning**: Enable for datasets > 10M rows
- **Watermark**: Adjust `start_value` for incremental loads

---

## Run Ingestion

### Local Databricks Notebook

```python
%run ./ingest_raw.py config.yaml
```

### Spark Submit (Cluster)

```bash
spark-submit \
  --conf spark.hadoop.fs.azure.account.key.${AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net=${AZURE_STORAGE_KEY} \
  ingest_raw.py config.yaml
```

---

## Validation

1. **Check Output Path**:
   ```python
   dbutils.fs.ls("abfss://raw@${AZURE_STORAGE_ACCOUNT}.dfs.core.windows.net/raw/{{dataset}}")
   ```

2. **Verify Row Count**:
   ```python
   df = spark.read.parquet("abfss://raw@storage.dfs.core.windows.net/raw/{{dataset}}")
   print(f"Rows ingested: {df.count()}")
   ```

3. **Inspect Schema**:
   ```python
   df.printSchema()
   # Should include _ingested_at and _source_system columns
   ```

---

## Troubleshooting

### Connection Refused
- Verify JDBC URL format
- Check firewall rules (allow Databricks IP)
- Test connection from SQL client

### Permission Denied
- Grant Storage Blob Data Contributor role
- Verify ABFS path format
- Check Azure AD token expiration

### Watermark Column Missing
- Confirm column exists in source
- Check data type (must be date/timestamp)
- Update config.yaml with correct column name

---

**End of README**
```

---

## Step 5: Output Summary

Print completion message:

```
✅ Ingestion pipeline scaffolded successfully!

📁 Generated files:
   - generated/ingest_raw/config.yaml
   - generated/ingest_raw/ingest_raw.py
   - generated/ingest_raw/README.md

📋 Next steps:
   1. Review config.yaml (update connection details)
   2. Set environment variables (credentials)
   3. Test configuration: /test config_file=generated/ingest_raw/config.yaml
   4. Run ingestion: spark-submit ingest_raw.py config.yaml

📊 Expected output:
   - Path: abfss://raw@storage.dfs.core.windows.net/raw/{{dataset}}
   - Format: Parquet
   - Schema: Source + metadata columns
```

---

## Validation Checklist

Before completing, verify:

- [x] `config.yaml` has valid YAML syntax
- [x] Adapter type matches user input (`jdbc`, `spark_reader`, `custom`)
- [x] Incremental loads have `watermark_column` defined
- [x] JDBC connections have URL, user, password placeholders
- [x] `ingest_raw.py` imports all required libraries
- [x] Metadata columns include `_ingested_at` and `_source_system`
- [x] Output path follows convention: `raw/<dataset_name>/`
- [x] README includes prerequisites, run instructions, troubleshooting

---

**End of Scaffold Workflow**
