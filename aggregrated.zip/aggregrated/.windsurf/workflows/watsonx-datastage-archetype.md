---
description: IBM DataStage service archetype - job management, flows, connections, and execution APIs
---

# IBM DataStage Service Archetype

## Overview

DataStage is IBM's enterprise ETL platform for designing, developing, and running data integration jobs.

**Base URL:** `https://api.dataplatform.cloud.ibm.com`

---

## Authentication

```python
from watsonx_security import IBMIAMAuth

auth = IBMIAMAuth()
headers = auth.get_headers()
headers['X-IBM-Project-ID'] = os.environ['DATASTAGE_PROJECT_ID']
```

---

## Core Endpoints

### Projects

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v2/projects` | List all projects |
| GET | `/v2/projects/{project_id}` | Get project details |
| POST | `/v2/projects` | Create new project |

### DataStage Flows

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v3/ds_codegen/flows` | List all flows |
| GET | `/v3/ds_codegen/flows/{flow_id}` | Get flow details |
| POST | `/v3/ds_codegen/flows` | Create flow |
| PUT | `/v3/ds_codegen/flows/{flow_id}` | Update flow |
| DELETE | `/v3/ds_codegen/flows/{flow_id}` | Delete flow |
| POST | `/v3/ds_codegen/flows/{flow_id}/compile` | Compile flow |
| GET | `/v3/ds_codegen/flows/{flow_id}/compile/{compile_id}` | Get compile status |

### Jobs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v2/jobs` | List jobs |
| GET | `/v2/jobs/{job_id}` | Get job details |
| POST | `/v2/jobs` | Create job |
| DELETE | `/v2/jobs/{job_id}` | Delete job |

### Job Runs

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v2/jobs/{job_id}/runs` | List job runs |
| POST | `/v2/jobs/{job_id}/runs` | Start job run |
| GET | `/v2/jobs/{job_id}/runs/{run_id}` | Get run status |
| DELETE | `/v2/jobs/{job_id}/runs/{run_id}` | Cancel run |
| GET | `/v2/jobs/{job_id}/runs/{run_id}/logs` | Get run logs |

### Connections

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v2/connections` | List connections |
| GET | `/v2/connections/{connection_id}` | Get connection |
| POST | `/v2/connections` | Create connection |
| PATCH | `/v2/connections/{connection_id}` | Update connection |
| DELETE | `/v2/connections/{connection_id}` | Delete connection |
| POST | `/v2/connections/{connection_id}/actions/test` | Test connection |

### Table Definitions

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v3/ds_codegen/table_definitions` | List table definitions |
| POST | `/v3/ds_codegen/table_definitions` | Create table definition |
| GET | `/v3/ds_codegen/table_definitions/{id}` | Get table definition |

---

## Python Client

```python
import requests
import os
from typing import Optional, List, Dict
from dataclasses import dataclass

@dataclass
class JobRun:
    run_id: str
    status: str
    started_at: str
    ended_at: Optional[str]
    duration: Optional[int]

class DataStageClient:
    """IBM DataStage API Client."""
    
    BASE_URL = "https://api.dataplatform.cloud.ibm.com"
    
    def __init__(self, project_id: str = None, auth = None):
        self.project_id = project_id or os.environ.get('DATASTAGE_PROJECT_ID')
        self.auth = auth or IBMIAMAuth()
    
    def _headers(self) -> dict:
        headers = self.auth.get_headers()
        headers['X-IBM-Project-ID'] = self.project_id
        return headers
    
    # --- Flows ---
    
    def list_flows(self) -> List[Dict]:
        """List all DataStage flows in the project."""
        response = requests.get(
            f"{self.BASE_URL}/v3/ds_codegen/flows",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.json().get('resources', [])
    
    def get_flow(self, flow_id: str) -> Dict:
        """Get flow details."""
        response = requests.get(
            f"{self.BASE_URL}/v3/ds_codegen/flows/{flow_id}",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.json()
    
    def create_flow(self, name: str, pipeline_flow: dict) -> Dict:
        """Create a new DataStage flow."""
        payload = {
            "name": name,
            "pipeline_flow": pipeline_flow
        }
        response = requests.post(
            f"{self.BASE_URL}/v3/ds_codegen/flows",
            headers=self._headers(),
            params={"project_id": self.project_id},
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def compile_flow(self, flow_id: str) -> str:
        """Compile a flow, returns compile_id."""
        response = requests.post(
            f"{self.BASE_URL}/v3/ds_codegen/flows/{flow_id}/compile",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.json()['compile_id']
    
    def get_compile_status(self, flow_id: str, compile_id: str) -> Dict:
        """Get compilation status."""
        response = requests.get(
            f"{self.BASE_URL}/v3/ds_codegen/flows/{flow_id}/compile/{compile_id}",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.json()
    
    # --- Jobs ---
    
    def list_jobs(self, asset_ref_type: str = "ds_job") -> List[Dict]:
        """List all jobs."""
        response = requests.get(
            f"{self.BASE_URL}/v2/jobs",
            headers=self._headers(),
            params={
                "project_id": self.project_id,
                "asset_ref_type": asset_ref_type
            }
        )
        response.raise_for_status()
        return response.json().get('results', [])
    
    def create_job(self, name: str, flow_id: str, schedule: dict = None) -> Dict:
        """Create a job from a flow."""
        payload = {
            "job": {
                "asset_ref": flow_id,
                "asset_ref_type": "ds_job",
                "name": name
            }
        }
        if schedule:
            payload["job"]["schedule"] = schedule
        
        response = requests.post(
            f"{self.BASE_URL}/v2/jobs",
            headers=self._headers(),
            params={"project_id": self.project_id},
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def run_job(self, job_id: str, parameters: dict = None) -> JobRun:
        """Start a job run."""
        payload = {"job_run": {}}
        if parameters:
            payload["job_run"]["job_parameters"] = parameters
        
        response = requests.post(
            f"{self.BASE_URL}/v2/jobs/{job_id}/runs",
            headers=self._headers(),
            params={"project_id": self.project_id},
            json=payload
        )
        response.raise_for_status()
        data = response.json()
        return JobRun(
            run_id=data['metadata']['asset_id'],
            status=data['entity']['job_run']['state'],
            started_at=data['metadata']['created_at'],
            ended_at=None,
            duration=None
        )
    
    def get_run_status(self, job_id: str, run_id: str) -> JobRun:
        """Get job run status."""
        response = requests.get(
            f"{self.BASE_URL}/v2/jobs/{job_id}/runs/{run_id}",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        data = response.json()
        entity = data['entity']['job_run']
        return JobRun(
            run_id=run_id,
            status=entity['state'],
            started_at=data['metadata']['created_at'],
            ended_at=entity.get('ended_at'),
            duration=entity.get('duration')
        )
    
    def wait_for_completion(self, job_id: str, run_id: str, 
                           timeout: int = 3600, poll_interval: int = 10) -> JobRun:
        """Wait for job run to complete."""
        import time
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            run = self.get_run_status(job_id, run_id)
            if run.status in ['Completed', 'Failed', 'Canceled']:
                return run
            time.sleep(poll_interval)
        
        raise TimeoutError(f"Job run {run_id} did not complete within {timeout}s")
    
    def get_run_logs(self, job_id: str, run_id: str) -> str:
        """Get job run logs."""
        response = requests.get(
            f"{self.BASE_URL}/v2/jobs/{job_id}/runs/{run_id}/logs",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.json().get('results', [])
    
    # --- Connections ---
    
    def list_connections(self) -> List[Dict]:
        """List all connections."""
        response = requests.get(
            f"{self.BASE_URL}/v2/connections",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.json().get('resources', [])
    
    def create_connection(self, name: str, datasource_type: str, 
                         properties: dict) -> Dict:
        """Create a new connection."""
        payload = {
            "name": name,
            "datasource_type": datasource_type,
            "properties": properties
        }
        response = requests.post(
            f"{self.BASE_URL}/v2/connections",
            headers=self._headers(),
            params={"project_id": self.project_id},
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def test_connection(self, connection_id: str) -> Dict:
        """Test a connection."""
        response = requests.post(
            f"{self.BASE_URL}/v2/connections/{connection_id}/actions/test",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.json()
    
    # --- Import/Export ---
    
    def import_flow(self, isx_content: bytes, conflict_resolution: str = "rename") -> Dict:
        """Import a flow from ISX file."""
        response = requests.post(
            f"{self.BASE_URL}/v3/ds_codegen/imports",
            headers={
                **self._headers(),
                "Content-Type": "application/octet-stream"
            },
            params={
                "project_id": self.project_id,
                "conflict_resolution": conflict_resolution
            },
            data=isx_content
        )
        response.raise_for_status()
        return response.json()
    
    def export_flow(self, flow_id: str) -> bytes:
        """Export a flow to ISX format."""
        response = requests.get(
            f"{self.BASE_URL}/v3/ds_codegen/flows/{flow_id}/export",
            headers=self._headers(),
            params={"project_id": self.project_id}
        )
        response.raise_for_status()
        return response.content
```

---

## Connection Types

| Type | datasource_type | Required Properties |
|------|-----------------|---------------------|
| **SQL Server** | `sqlserver` | `host`, `port`, `database`, `username`, `password` |
| **PostgreSQL** | `postgresql` | `host`, `port`, `database`, `username`, `password` |
| **Oracle** | `oracle` | `host`, `port`, `service_name`, `username`, `password` |
| **Db2** | `db2` | `host`, `port`, `database`, `username`, `password` |
| **MySQL** | `mysql` | `host`, `port`, `database`, `username`, `password` |
| **Snowflake** | `snowflake` | `account`, `warehouse`, `database`, `username`, `password` |
| **S3** | `amazons3` | `bucket`, `region`, `access_key`, `secret_key` |
| **Azure Blob** | `azureblob` | `account_name`, `account_key`, `container` |
| **ADLS Gen2** | `adlsgen2` | `account_name`, `account_key`, `filesystem` |
| **Kafka** | `kafka` | `bootstrap_servers`, `security_protocol` |

---

## Example: Create and Run Job

```python
# Initialize client
client = DataStageClient()

# Create a connection
conn = client.create_connection(
    name="sales_db",
    datasource_type="postgresql",
    properties={
        "host": "db.example.com",
        "port": 5432,
        "database": "sales",
        "username": "etl_user",
        "password": "${SALES_DB_PASSWORD}"  # Use parameter
    }
)
print(f"Connection created: {conn['asset_id']}")

# List flows
flows = client.list_flows()
for flow in flows:
    print(f"  - {flow['metadata']['name']} ({flow['metadata']['asset_id']})")

# Create job from flow
job = client.create_job(
    name="daily_sales_etl",
    flow_id=flows[0]['metadata']['asset_id'],
    schedule={
        "repeat": {
            "type": "cron",
            "cron": "0 2 * * *"  # Daily at 2 AM
        }
    }
)
print(f"Job created: {job['metadata']['asset_id']}")

# Run job immediately
run = client.run_job(
    job_id=job['metadata']['asset_id'],
    parameters={"run_date": "2024-01-15"}
)
print(f"Job run started: {run.run_id}")

# Wait for completion
final_run = client.wait_for_completion(
    job_id=job['metadata']['asset_id'],
    run_id=run.run_id,
    timeout=1800
)
print(f"Job completed with status: {final_run.status}")

# Get logs if failed
if final_run.status == 'Failed':
    logs = client.get_run_logs(job['metadata']['asset_id'], run.run_id)
    for log in logs:
        print(log)
```

---

## Error Handling

| Status | Error | Resolution |
|--------|-------|------------|
| 400 | Invalid request | Check payload format |
| 401 | Unauthorized | Refresh IAM token |
| 403 | Forbidden | Check project access |
| 404 | Not found | Verify resource ID |
| 409 | Conflict | Resource already exists |
| 429 | Rate limited | Implement backoff |
| 500 | Server error | Retry with backoff |
