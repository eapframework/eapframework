---
description: IBM Manta Data Lineage service archetype - lineage discovery, impact analysis, metadata extraction
---

# IBM Manta Data Lineage Service Archetype

## Overview

Manta provides automated data lineage discovery and visualization across enterprise data platforms.

**Base URL:** `https://manta.{region}.datalineage.cloud.ibm.com`

---

## Core Endpoints

### Lineage Discovery

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/lineage/scan` | Trigger lineage scan |
| GET | `/api/v1/lineage/scan/{scan_id}` | Get scan status |
| GET | `/api/v1/lineage/nodes` | List lineage nodes |
| GET | `/api/v1/lineage/nodes/{node_id}` | Get node details |
| GET | `/api/v1/lineage/nodes/{node_id}/upstream` | Get upstream lineage |
| GET | `/api/v1/lineage/nodes/{node_id}/downstream` | Get downstream lineage |

### Impact Analysis

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/impact/analyze` | Run impact analysis |
| GET | `/api/v1/impact/{analysis_id}` | Get analysis results |
| GET | `/api/v1/impact/{analysis_id}/affected` | List affected objects |

### Connections

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/connections` | List connections |
| POST | `/api/v1/connections` | Create connection |
| GET | `/api/v1/connections/{id}` | Get connection |
| DELETE | `/api/v1/connections/{id}` | Delete connection |
| POST | `/api/v1/connections/{id}/test` | Test connection |

### Metadata

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/metadata/objects` | List metadata objects |
| GET | `/api/v1/metadata/objects/{id}` | Get object metadata |
| GET | `/api/v1/metadata/objects/{id}/columns` | Get columns |
| GET | `/api/v1/metadata/schemas` | List schemas |
| GET | `/api/v1/metadata/databases` | List databases |

### Reports

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/reports/lineage` | Generate lineage report |
| POST | `/api/v1/reports/impact` | Generate impact report |
| GET | `/api/v1/reports/{report_id}` | Download report |

---

## Python Client

```python
import requests
import os
from typing import List, Dict, Optional
from dataclasses import dataclass

@dataclass
class LineageNode:
    node_id: str
    name: str
    node_type: str
    database: str
    schema: str
    columns: List[str]

@dataclass
class LineageEdge:
    source_id: str
    target_id: str
    transformation: str

class MantaClient:
    """IBM Manta Data Lineage API Client."""
    
    def __init__(self, instance_url: str = None, auth = None):
        self.base_url = instance_url or os.environ.get('MANTA_INSTANCE_URL')
        self.auth = auth or IBMIAMAuth()
    
    def _headers(self) -> dict:
        return self.auth.get_headers()
    
    # --- Lineage Scanning ---
    
    def trigger_scan(self, connection_id: str, scope: dict = None) -> str:
        """Trigger a lineage scan."""
        payload = {"connection_id": connection_id}
        if scope:
            payload["scope"] = scope
        
        response = requests.post(
            f"{self.base_url}/api/v1/lineage/scan",
            headers=self._headers(),
            json=payload
        )
        response.raise_for_status()
        return response.json()['scan_id']
    
    def get_scan_status(self, scan_id: str) -> Dict:
        """Get scan status."""
        response = requests.get(
            f"{self.base_url}/api/v1/lineage/scan/{scan_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def wait_for_scan(self, scan_id: str, timeout: int = 3600) -> Dict:
        """Wait for scan completion."""
        import time
        start = time.time()
        while time.time() - start < timeout:
            status = self.get_scan_status(scan_id)
            if status['state'] in ['completed', 'failed']:
                return status
            time.sleep(30)
        raise TimeoutError(f"Scan {scan_id} timed out")
    
    # --- Lineage Queries ---
    
    def get_upstream_lineage(self, node_id: str, depth: int = 5) -> Dict:
        """Get upstream lineage for a node."""
        response = requests.get(
            f"{self.base_url}/api/v1/lineage/nodes/{node_id}/upstream",
            headers=self._headers(),
            params={"depth": depth}
        )
        response.raise_for_status()
        return response.json()
    
    def get_downstream_lineage(self, node_id: str, depth: int = 5) -> Dict:
        """Get downstream lineage for a node."""
        response = requests.get(
            f"{self.base_url}/api/v1/lineage/nodes/{node_id}/downstream",
            headers=self._headers(),
            params={"depth": depth}
        )
        response.raise_for_status()
        return response.json()
    
    def get_column_lineage(self, node_id: str, column_name: str) -> Dict:
        """Get column-level lineage."""
        response = requests.get(
            f"{self.base_url}/api/v1/lineage/nodes/{node_id}/columns/{column_name}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def search_nodes(self, query: str, node_type: str = None) -> List[Dict]:
        """Search for lineage nodes."""
        params = {"q": query}
        if node_type:
            params["type"] = node_type
        
        response = requests.get(
            f"{self.base_url}/api/v1/lineage/nodes",
            headers=self._headers(),
            params=params
        )
        response.raise_for_status()
        return response.json().get('nodes', [])
    
    # --- Impact Analysis ---
    
    def analyze_impact(self, node_id: str, change_type: str = "delete") -> str:
        """Run impact analysis."""
        response = requests.post(
            f"{self.base_url}/api/v1/impact/analyze",
            headers=self._headers(),
            json={
                "node_id": node_id,
                "change_type": change_type
            }
        )
        response.raise_for_status()
        return response.json()['analysis_id']
    
    def get_impact_results(self, analysis_id: str) -> Dict:
        """Get impact analysis results."""
        response = requests.get(
            f"{self.base_url}/api/v1/impact/{analysis_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json()
    
    def get_affected_objects(self, analysis_id: str) -> List[Dict]:
        """Get list of affected objects."""
        response = requests.get(
            f"{self.base_url}/api/v1/impact/{analysis_id}/affected",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('affected_objects', [])
    
    # --- Connections ---
    
    def list_connections(self) -> List[Dict]:
        """List all connections."""
        response = requests.get(
            f"{self.base_url}/api/v1/connections",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.json().get('connections', [])
    
    def create_connection(self, name: str, conn_type: str, 
                         properties: dict) -> Dict:
        """Create a connection."""
        response = requests.post(
            f"{self.base_url}/api/v1/connections",
            headers=self._headers(),
            json={
                "name": name,
                "type": conn_type,
                "properties": properties
            }
        )
        response.raise_for_status()
        return response.json()
    
    # --- Reports ---
    
    def generate_lineage_report(self, node_id: str, 
                               format: str = "pdf") -> str:
        """Generate lineage report."""
        response = requests.post(
            f"{self.base_url}/api/v1/reports/lineage",
            headers=self._headers(),
            json={
                "node_id": node_id,
                "format": format,
                "include_columns": True,
                "depth": 10
            }
        )
        response.raise_for_status()
        return response.json()['report_id']
    
    def download_report(self, report_id: str) -> bytes:
        """Download generated report."""
        response = requests.get(
            f"{self.base_url}/api/v1/reports/{report_id}",
            headers=self._headers()
        )
        response.raise_for_status()
        return response.content
```

---

## Connection Types

| Type | Description | Properties |
|------|-------------|------------|
| `oracle` | Oracle Database | `host`, `port`, `service`, `user`, `password` |
| `sqlserver` | SQL Server | `host`, `port`, `database`, `user`, `password` |
| `postgresql` | PostgreSQL | `host`, `port`, `database`, `user`, `password` |
| `snowflake` | Snowflake | `account`, `warehouse`, `database`, `user`, `password` |
| `databricks` | Databricks | `workspace_url`, `token`, `cluster_id` |
| `datastage` | DataStage | `project_id`, `api_key` |
| `informatica` | Informatica | `domain`, `repository`, `user`, `password` |
| `talend` | Talend | `url`, `user`, `password` |

---

## Example: Lineage Discovery

```python
client = MantaClient()

# Create connection
conn = client.create_connection(
    name="prod_warehouse",
    conn_type="snowflake",
    properties={
        "account": "xy12345.us-east-1",
        "warehouse": "COMPUTE_WH",
        "database": "ANALYTICS",
        "user": "lineage_scanner",
        "password": "${SNOWFLAKE_PASSWORD}"
    }
)

# Trigger scan
scan_id = client.trigger_scan(
    connection_id=conn['id'],
    scope={
        "databases": ["ANALYTICS"],
        "schemas": ["PUBLIC", "STAGING"]
    }
)
print(f"Scan started: {scan_id}")

# Wait for completion
result = client.wait_for_scan(scan_id)
print(f"Scan completed: {result['objects_discovered']} objects found")

# Search for a table
nodes = client.search_nodes("fact_sales", node_type="table")
if nodes:
    table = nodes[0]
    print(f"Found: {table['name']}")
    
    # Get upstream lineage
    upstream = client.get_upstream_lineage(table['id'], depth=3)
    print(f"Upstream sources: {len(upstream['nodes'])}")
    
    # Get downstream lineage
    downstream = client.get_downstream_lineage(table['id'], depth=3)
    print(f"Downstream consumers: {len(downstream['nodes'])}")
```

---

## Example: Impact Analysis

```python
# Find table to analyze
nodes = client.search_nodes("dim_customer")
table = nodes[0]

# Run impact analysis
analysis_id = client.analyze_impact(
    node_id=table['id'],
    change_type="schema_change"
)

# Get results
results = client.get_impact_results(analysis_id)
print(f"Impact severity: {results['severity']}")
print(f"Affected objects: {results['affected_count']}")

# List affected objects
affected = client.get_affected_objects(analysis_id)
for obj in affected:
    print(f"  - {obj['name']} ({obj['type']}): {obj['impact_type']}")
```

---

## Lineage Visualization

```python
def export_lineage_to_graphviz(client, node_id: str) -> str:
    """Export lineage to Graphviz DOT format."""
    upstream = client.get_upstream_lineage(node_id, depth=5)
    downstream = client.get_downstream_lineage(node_id, depth=5)
    
    dot = ["digraph Lineage {", "  rankdir=LR;"]
    
    all_nodes = upstream.get('nodes', []) + downstream.get('nodes', [])
    all_edges = upstream.get('edges', []) + downstream.get('edges', [])
    
    for node in all_nodes:
        shape = "box" if node['type'] == 'table' else "ellipse"
        dot.append(f'  "{node["id"]}" [label="{node["name"]}" shape={shape}];')
    
    for edge in all_edges:
        dot.append(f'  "{edge["source"]}" -> "{edge["target"]}";')
    
    dot.append("}")
    return "\n".join(dot)
```
