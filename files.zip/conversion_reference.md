# NetAudit Pipeline – Palantir → Databricks Lakeflow Conversion Reference

## Source Table Mapping

Update the `source.` prefix in the SQL to match your Unity Catalog `catalog.schema.` path.

| SQL Reference Name | Palantir Dataset RID (suffix) | Screenshot Label | Columns |
|---|---|---|---|
| `source.e_ndr_erk_lce8_nrb` | `f15eed90` | e_ndr_erk_lce8_nrb | 26 selected |
| `source.e_ndr_nokia_lce8_nrb` | `c9c0b756` | e_ndr_nokia_lce8_nrb | 21 selected |
| `source.k_nok_5gnr_cell_nrb` | `8809dc10` | k_nok_5gnr_cell_nrb | 17 |
| `source.ERICSSONITE_NRCellBU` | `f8318cd1` | ERICSSONITE.NRCell(BU) | 27 selected |
| `source.ERICSSONITE_SSB` | `31e67c33` | ERICSSONITE_SSB (Join 3 source) | SSB params |
| `source.k_FBRC_SCNR_CELL` | `e46e1cf6` | k_FBRC_SCNR_CELL_98... | 107 |
| `source.RMS_PEAs_CMAs` | `8eb37d63` | RMS_PEAs_CMAs - Table... | 23 |
| `source.nodesite_NRCELL` | `7fbf8aba` | nodesite_NRCELL... | 228 |
| `source.LEVO_SITE_MASTER_BR` | `d2fe3b3d` | LEVO_SITE_MASTER_BR... | 120 |

> **Note**: `e_site_general_info` (RID `374bde99`) and one additional dataset (RID `9933c936`) appear on the Palantir canvas but are **not connected** to any output target. They have been omitted.

## Pipeline DAG Summary

```
PATH 1 – LTE_ERC_NetAudit:
  e_ndr_erk_lce8_nrb → lte_erc_base (select + dedup) → LTE_ERC_NetAudit (cast + geo)

PATH 2 – LTE_NOK_NetAudit:
  e_ndr_nokia_lce8_nrb → lte_nok_selected (select)
                              ↓
  k_nok_5gnr_cell_nrb ──→ lte_nok_joined (LEFT JOIN on ENBNAME)
                              ↓
                         LTE_NOK_NetAudit (cast + dedup + geo)

PATH 3 – NR_NOK_NetAudit:
  ERICSSONITE_NRCellBU → nr_nok_base (select + dedup)
                              ↓
                         nr_nok_casted (FIPS/CMA/LOADDATE casts + geo)
                              ↓
  nodesite_NRCELL ──────→ nr_nok_with_nodesite (JOIN 6 on NRCELL_NAME=cellname)
      ↑ filtered by           ↓
      max(loaddate_)     nr_nok_with_pea (JOIN 7 on FIPS with PEA ref)
                              ↓
                         NR_NOK_NetAudit (filter node_ NOT NULL + dedup)

PATH 4 – NR_ERC_NetAudit:
  k_FBRC_SCNR_CELL → nr_erc_source_casted (fips cast)
                          ↓
  RMS_PEAs_CMAs ────→ nr_erc_with_pea (PEA added JOIN on fips)
                          ↓
                     nr_erc_transformed (select + casts + concat_prim + geo)
                          ↓
  ERICSSONITE_SSB ──→ nr_erc_with_ssb (Addd SSB JOIN on nrcell_name=NRCELLDU_ID_)
      ↑ filtered by       ↓
      max(LOADDATE_) LEVO_SITE_MASTER_BR → nr_erc_with_levo (JOIN 4 on SOFT_SECTOR_NAME)
                          ↓                   ↑ filtered SOFT_SECTOR_ID > 0
                     NR_ERC_NetAudit (+ UUID primary key)
```

## Key Transformation Logic Mapping

| Palantir Operation | Databricks SQL Equivalent |
|---|---|
| `applyExpression` → `cast(col AS type)` | `CAST(col AS type)` |
| `applyExpression` → `alias(cast(fips, integer), "fips")` | `CAST(CAST(fips AS INT) AS STRING) AS fips` |
| `applyExpression` → `epochMillisToDate(LOADDATE)` | `FROM_UNIXTIME(LOADDATE / 1000)` |
| `applyExpression` → `dateToString(date)` | `CAST(date AS STRING)` or `DATE_FORMAT(...)` |
| `applyExpression` → `timestampToString(ts)` | `CAST(ts AS STRING)` |
| `applyExpression` → `constructGeoPoint(lat, lon)` | `ST_Point(longitude, latitude)` |
| `applyExpression` → `createOntologyGeopoint(pt)` | `ST_AsText(ST_Point(lon, lat))` |
| `applyExpression` → `concatStrings([a,b], sep)` | `CONCAT(COALESCE(a,''), sep, COALESCE(b,''))` |
| `applyExpression` → `uuid()` | `UUID()` |
| `dropDuplicates(col)` | `ROW_NUMBER() OVER (PARTITION BY col ...) = 1` |
| `filter(isNotNull(col), treatEmpty=true)` | `WHERE col IS NOT NULL AND TRIM(col) != ''` |
| `aggregate(MAX(col))` | `SELECT MAX(col)` |
| `complexLeftJoin` | `LEFT JOIN ... ON ...` |
| `select(columns)` | `SELECT col1, col2, ...` |

## Geo Point Handling

Palantir uses `constructGeoPoint` → `createOntologyGeopoint` for its ontology. For Databricks:

- If using **Delta Lake + GeoMesa** or **H3**: use `ST_Point(lon, lat)` or H3 indexing
- If storing as **string (WKT)**: use `ST_AsText(ST_Point(lon, lat))` → `'POINT(-73.9 40.7)'`
- If storing as **struct**: use `NAMED_STRUCT('latitude', lat, 'longitude', lon)`

The SQL uses `ST_AsText(ST_Point(...))` by default. Adjust to your preferred geo encoding.

## Notes

1. **INT→STRING cast pattern**: Palantir casts `fips`/`cma` to INT first (to strip non-numeric chars or normalize), then back to STRING. This pattern is preserved in the SQL.
2. **dropDuplicates**: Palantir's `dropDuplicates` keeps an arbitrary first row. The SQL uses `ROW_NUMBER()` which is deterministic but may pick a different row than Spark's default. Add an explicit `ORDER BY` column if row selection matters.
3. **LOADDATE conversion chain**: The Nokia NR path converts `LOADDATE` from epoch milliseconds → date → string via three chained `applyExpression` steps. This is collapsed into a single `DATE_FORMAT(FROM_UNIXTIME(...))` in SQL.
4. The pipeline uses **Natively accelerated – small** compute profile in Palantir. For Databricks, configure your cluster size accordingly.
