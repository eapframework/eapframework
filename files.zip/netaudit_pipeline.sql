-- ============================================================================
-- PIPELINE:  NetAudit_project
-- CONVERTED: Palantir Pipeline Builder → Databricks Lakeflow Designer (DLT SQL)
-- ============================================================================
-- This pipeline produces 4 output tables:
--   1. LTE_ERC_NetAudit   (Ericsson LTE cell audit)
--   2. LTE_NOK_NetAudit   (Nokia LTE cell audit)
--   3. NR_NOK_NetAudit     (Nokia NR cell audit)
--   4. NR_ERC_NetAudit     (Ericsson NR cell audit)
--
-- SOURCE TABLES (update catalog.schema to match your Unity Catalog):
--   source.e_ndr_erk_lce8_nrb      – Ericsson LTE cell config
--   source.e_ndr_nokia_lce8_nrb    – Nokia LTE cell config
--   source.k_nok_5gnr_cell_nrb     – Nokia 5G NR site/county info
--   source.ERICSSONITE_NRCellBU    – Ericsson NR Cell (Nokia-NOK path)
--   source.k_FBRC_SCNR_CELL        – Ericsson NR Cell (ERC path)
--   source.RMS_PEAs_CMAs           – PEA/CMA reference lookup
--   source.nodesite_NRCELL         – Node/BTS site data
--   source.ERICSSONITE_SSB         – Ericsson SSB parameters
--   source.LEVO_SITE_MASTER_BR     – LEVO site master (CLLI/sector)
-- ============================================================================


-- ############################################################################
-- SECTION 1: SHARED REFERENCE TABLES
-- ############################################################################

-- ---------------------------------------------------------------------------
-- 1A. PEA/CMA Reference – Cast FIPS to string for join compatibility
-- (Used by both NR_NOK and NR_ERC paths)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE pea_cma_reference
COMMENT 'PEA/CMA reference with FIPS cast to string for join compatibility'
AS
SELECT
  CAST(FIPS AS STRING)  AS FIPS,
  PEA_,
  PEA_Name
FROM source.RMS_PEAs_CMAs;


-- ############################################################################
-- SECTION 2: LTE_ERC_NetAudit PATH
-- Source: e_ndr_erk_lce8_nrb → Select → Dedup → Cast → Geo → Output
-- ############################################################################

-- ---------------------------------------------------------------------------
-- 2A. Select & deduplicate Ericsson LTE cells (Transform path 3 + dedup)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE lte_erc_base
COMMENT 'Ericsson LTE cells – selected columns, deduplicated on EUTRAN_CELL_FDD_ID'
AS
SELECT * EXCEPT(_rn)
FROM (
  SELECT
    EDMARKET,
    MARKET,
    BAND,
    BBU_FA_CODE,
    CALL_SIGN,
    CELL_TYPE,
    CMA,
    COUNTY,
    DSS_NRCELL,
    EARFCNDL,
    EARFCNUL,
    DUTYPE,
    EUTRAN_CELL_FDD_ID,
    FACE,
    FIPS,
    LATITUDE,
    LONGITUDE,
    ON_AIR,
    REMOTE_USID,
    RRU_LIST,
    TAC,
    USID,
    REFRESH_DATE,
    DL_CH_BW,
    CONFIGUREDMAXTXPOWER,
    MAXIMUMTRANSMISSIONPOWER,
    ROW_NUMBER() OVER (PARTITION BY EUTRAN_CELL_FDD_ID ORDER BY EUTRAN_CELL_FDD_ID) AS _rn
  FROM source.e_ndr_erk_lce8_nrb
) WHERE _rn = 1;

-- ---------------------------------------------------------------------------
-- 2B. Final LTE_ERC_NetAudit output
--     Apply type casts (FIPS, CMA clean via INT→STRING, DL_CH_BW to STRING)
--     and construct geo point
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE LTE_ERC_NetAudit
COMMENT 'LTE Ericsson Net Audit – final output'
AS
SELECT
  EDMARKET,
  MARKET,
  BAND,
  BBU_FA_CODE,
  CALL_SIGN,
  CELL_TYPE,
  CAST(CAST(CMA AS INT) AS STRING)       AS CMA,
  COUNTY,
  DSS_NRCELL,
  EARFCNDL,
  EARFCNUL,
  DUTYPE,
  EUTRAN_CELL_FDD_ID,
  FACE,
  CAST(CAST(FIPS AS INT) AS STRING)      AS FIPS,
  LATITUDE,
  LONGITUDE,
  ON_AIR,
  REMOTE_USID,
  RRU_LIST,
  TAC,
  USID,
  REFRESH_DATE,
  CAST(DL_CH_BW AS STRING)               AS DL_CH_BW,
  CONFIGUREDMAXTXPOWER,
  MAXIMUMTRANSMISSIONPOWER,
  ST_AsText(ST_Point(LONGITUDE, LATITUDE)) AS construct_geo_point
FROM LIVE.lte_erc_base;


-- ############################################################################
-- SECTION 3: LTE_NOK_NetAudit PATH
-- Source: e_ndr_nokia_lce8_nrb → Select → Join(k_nok_5gnr_cell) → Cast → Dedup → Geo → Output
-- ############################################################################

-- ---------------------------------------------------------------------------
-- 3A. Select Nokia LTE cell columns (Transform path 4)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE lte_nok_selected
COMMENT 'Nokia LTE cells – selected columns from source'
AS
SELECT
  EDMARKET,
  MARKET,
  USID,
  ENBNAME,
  BBU_CONFIG,
  REMOTE_USID,
  FACE,
  LATITUDE,
  LONGITUDE,
  CELLNAME,
  DSS_NRCELL,
  CELL_TYPE,
  ON_AIR,
  BAND,
  DL_CH_BW,
  RRHTYPE,
  EARFCNDL,
  EARFCNUL,
  TAC,
  PULLDATE,
  PMAX
FROM source.e_ndr_nokia_lce8_nrb;

-- ---------------------------------------------------------------------------
-- 3B. Join with 5G NR site/county data on ENBNAME (Join node)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE lte_nok_joined
COMMENT 'Nokia LTE cells joined with site/county info from k_nok_5gnr_cell_nrb'
AS
SELECT
  l.EDMARKET,
  l.MARKET,
  l.USID,
  l.ENBNAME,
  l.BBU_CONFIG,
  l.REMOTE_USID,
  l.FACE,
  l.LATITUDE,
  l.LONGITUDE,
  l.CELLNAME,
  l.DSS_NRCELL,
  l.CELL_TYPE,
  l.ON_AIR,
  l.BAND,
  l.DL_CH_BW,
  l.RRHTYPE,
  l.EARFCNDL,
  l.EARFCNUL,
  l.TAC,
  l.PMAX,
  r.county,
  r.fips,
  r.cma,
  r.pulldate
FROM LIVE.lte_nok_selected l
LEFT JOIN source.k_nok_5gnr_cell_nrb r
  ON l.ENBNAME = r.enbname;

-- ---------------------------------------------------------------------------
-- 3C. Final LTE_NOK_NetAudit output
--     Cast cma (INT→STRING), fips (INT→STRING), pulldate (timestamp→string)
--     Dedup on CELLNAME, construct geo point
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE LTE_NOK_NetAudit
COMMENT 'LTE Nokia Net Audit – final output'
AS
SELECT * EXCEPT(_rn)
FROM (
  SELECT
    EDMARKET,
    MARKET,
    USID,
    ENBNAME,
    BBU_CONFIG,
    REMOTE_USID,
    FACE,
    LATITUDE,
    LONGITUDE,
    CELLNAME,
    DSS_NRCELL,
    CELL_TYPE,
    ON_AIR,
    BAND,
    DL_CH_BW,
    RRHTYPE,
    EARFCNDL,
    EARFCNUL,
    TAC,
    PMAX,
    county,
    CAST(CAST(fips AS INT) AS STRING)          AS fips,
    CAST(CAST(cma AS INT) AS STRING)           AS cma,
    CAST(pulldate AS STRING)                   AS pulldate,
    ST_AsText(ST_Point(LONGITUDE, LATITUDE))   AS construct_geo_point,
    ROW_NUMBER() OVER (PARTITION BY CELLNAME ORDER BY CELLNAME) AS _rn
  FROM LIVE.lte_nok_joined
) WHERE _rn = 1;


-- ############################################################################
-- SECTION 4: NR_NOK_NetAudit PATH (Nokia NR)
-- Sources: ERICSSONITE_NRCellBU → Select → Dedup → Casts →
--          Join(6) with nodesite → Join(7) with PEA → Filter → Dedup → Output
-- ############################################################################

-- ---------------------------------------------------------------------------
-- 4A. Select & deduplicate Ericsson-sourced Nokia NR cells
--     (Select 27 cols from ERICSSONITE_NRCellBU, dedup on NRCELL_NAME)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_nok_base
COMMENT 'Nokia NR cells – selected columns, deduplicated on NRCELL_NAME'
AS
SELECT * EXCEPT(_rn)
FROM (
  SELECT
    MARKET,
    EDMARKET,
    NRCELL_NAME,
    DSS_LTECELL,
    CELL_TYPE,
    ON_AIR,
    BAND,
    BW_DL,
    RRH_PRODUCTNAME,
    NRARFCN,
    CELLBARRED,
    PHYSCELLID,
    LTE_CELLS_ON_SAME_RRH,
    FIPS,
    CMA,
    BBU_USID,
    CSS_SITE_NAME,
    BBU_CONFIG,
    GNB_NAME,
    REMOTE_USID,
    FACE,
    LATITUDE,
    LONGITUDE,
    PMAX,
    RFS_DSS_FEATURESTATE,
    CPRI_LINK_RATE,
    LOADDATE,
    ROW_NUMBER() OVER (PARTITION BY NRCELL_NAME ORDER BY NRCELL_NAME) AS _rn
  FROM source.ERICSSONITE_NRCellBU
) WHERE _rn = 1;

-- ---------------------------------------------------------------------------
-- 4B. Apply type casts and date conversions
--     CMA: INT→STRING, FIPS: INT→STRING
--     LOADDATE: epoch millis → date → string
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_nok_casted
COMMENT 'Nokia NR cells with standardized types and geo point'
AS
SELECT
  MARKET,
  EDMARKET,
  NRCELL_NAME,
  DSS_LTECELL,
  CELL_TYPE,
  ON_AIR,
  BAND,
  BW_DL,
  RRH_PRODUCTNAME,
  NRARFCN,
  CELLBARRED,
  PHYSCELLID,
  LTE_CELLS_ON_SAME_RRH,
  CAST(CAST(FIPS AS INT) AS STRING)                          AS FIPS,
  CAST(CAST(CMA AS INT) AS STRING)                           AS CMA,
  BBU_USID,
  CSS_SITE_NAME,
  BBU_CONFIG,
  GNB_NAME,
  REMOTE_USID,
  FACE,
  LATITUDE,
  LONGITUDE,
  PMAX,
  RFS_DSS_FEATURESTATE,
  CPRI_LINK_RATE,
  CAST(DATE_FORMAT(FROM_UNIXTIME(LOADDATE / 1000), 'yyyy-MM-dd') AS STRING) AS LOADDATE,
  ST_AsText(ST_Point(LONGITUDE, LATITUDE))                   AS construct_geo_point
FROM LIVE.nr_nok_base;

-- ---------------------------------------------------------------------------
-- 4C. Max load date from nodesite_NRCELL (for latest-record filter)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_nok_nodesite_max_loaddate
COMMENT 'Max loaddate_ from nodesite_NRCELL for latest-record filtering'
AS
SELECT
  MAX(loaddate_) AS loaddate_max
FROM source.nodesite_NRCELL;

-- ---------------------------------------------------------------------------
-- 4D. Filter nodesite_NRCELL to latest load date only (Join 5 + filter)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_nok_nodesite_latest
COMMENT 'nodesite_NRCELL filtered to latest load date'
AS
SELECT ns.*
FROM source.nodesite_NRCELL ns
INNER JOIN LIVE.nr_nok_nodesite_max_loaddate m
  ON ns.loaddate_ = m.loaddate_max;

-- ---------------------------------------------------------------------------
-- 4E. Join(6): Nokia NR cells + nodesite data on NRCELL_NAME = cellname
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_nok_with_nodesite
COMMENT 'Nokia NR cells enriched with node/BTS info from nodesite_NRCELL'
AS
SELECT
  l.*,
  r.node_,
  r.pid_,
  r.cellname,
  r.lcrid
FROM LIVE.nr_nok_casted l
LEFT JOIN LIVE.nr_nok_nodesite_latest r
  ON l.NRCELL_NAME = r.cellname;

-- ---------------------------------------------------------------------------
-- 4F. Join(7): Add PEA data on FIPS
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_nok_with_pea
COMMENT 'Nokia NR cells enriched with PEA reference data'
AS
SELECT
  l.*,
  r.PEA_,
  r.PEA_Name
FROM LIVE.nr_nok_with_nodesite l
LEFT JOIN LIVE.pea_cma_reference r
  ON l.FIPS = r.FIPS;

-- ---------------------------------------------------------------------------
-- 4G. Final NR_NOK_NetAudit output
--     Filter: node_ IS NOT NULL
--     Dedup on NRCELL_NAME
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE NR_NOK_NetAudit
COMMENT 'NR Nokia Net Audit – final output'
AS
SELECT * EXCEPT(_rn)
FROM (
  SELECT
    FIPS,
    CMA,
    MARKET,
    EDMARKET,
    NRCELL_NAME,
    DSS_LTECELL,
    CELL_TYPE,
    ON_AIR,
    BAND,
    BW_DL,
    RRH_PRODUCTNAME,
    NRARFCN,
    CELLBARRED,
    PHYSCELLID,
    LTE_CELLS_ON_SAME_RRH,
    BBU_USID,
    CSS_SITE_NAME,
    BBU_CONFIG,
    GNB_NAME,
    REMOTE_USID,
    FACE,
    LATITUDE,
    LONGITUDE,
    LOADDATE,
    PMAX,
    RFS_DSS_FEATURESTATE,
    CPRI_LINK_RATE,
    construct_geo_point,
    node_,
    pid_,
    PEA_,
    PEA_Name,
    cellname,
    lcrid,
    ROW_NUMBER() OVER (PARTITION BY NRCELL_NAME ORDER BY NRCELL_NAME) AS _rn
  FROM LIVE.nr_nok_with_pea
  WHERE node_ IS NOT NULL AND TRIM(node_) != ''
) WHERE _rn = 1;


-- ############################################################################
-- SECTION 5: NR_ERC_NetAudit PATH (Ericsson NR – most complex)
-- Sources: k_FBRC_SCNR_CELL → PEA join → Select → Casts → Concat →
--          Geo → Addd SSB join → Join(4) LEVO → UUID → Output
-- ############################################################################

-- ---------------------------------------------------------------------------
-- 5A. Cast fips on Ericsson NR source for PEA join (Transform path 7)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_source_casted
COMMENT 'Ericsson NR cell source with fips cast for PEA join'
AS
SELECT
  *,
  CAST(CAST(fips AS INT) AS STRING) AS fips_str
FROM source.k_FBRC_SCNR_CELL;

-- ---------------------------------------------------------------------------
-- 5B. PEA added: Join Ericsson NR source with PEA reference on fips
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_with_pea
COMMENT 'Ericsson NR cells enriched with PEA data'
AS
SELECT
  l.*,
  r.PEA_,
  r.PEA_Name
FROM LIVE.nr_erc_source_casted l
LEFT JOIN LIVE.pea_cma_reference r
  ON l.fips_str = r.FIPS;

-- ---------------------------------------------------------------------------
-- 5C. Select columns from PEA-joined result + apply casts
--     cma: INT→STRING, fips: INT→STRING, refresh_date: STRING
--     Construct concat_prim = nrcell_name || '-' || refresh_date
--     Construct geo point
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_transformed
COMMENT 'Ericsson NR cells – selected, cast, with concat key and geo point'
AS
SELECT
  edmarket,
  market,
  bbu_usid,
  bbu_fa_code,
  county,
  CAST(CAST(fips AS INT) AS STRING)             AS fips,
  CAST(CAST(cma AS INT) AS STRING)              AS cma,
  remote_usid,
  face,
  latitude,
  longitude,
  nrcell_name,
  cell_type,
  on_air,
  band,
  bw_dl,
  arfcndl,
  arfcnul,
  call_sign,
  CAST(refresh_date AS STRING)                  AS refresh_date,
  gnb_name,
  rru_name,
  lte_cells_on_same_rru,
  cpri_link_rate,
  sw_name,
  ems_name,
  dss_ltecell,
  cellbarred,
  configuredmaxtxpower,
  PEA_,
  PEA_Name,
  CONCAT(
    COALESCE(nrcell_name, ''),
    '-',
    COALESCE(CAST(refresh_date AS STRING), '')
  )                                              AS concat_prim,
  ST_AsText(ST_Point(longitude, latitude))       AS construct_geo_point
FROM LIVE.nr_erc_with_pea;

-- ---------------------------------------------------------------------------
-- 5D. Max load date from ERICSSONITE_SSB (for latest-SSB-record filter)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_ssb_max_loaddate
COMMENT 'Max LOADDATE_ from SSB source for latest-record filtering'
AS
SELECT
  MAX(LOADDATE_) AS LOADDATE_max
FROM source.ERICSSONITE_SSB;

-- ---------------------------------------------------------------------------
-- 5E. Join(3) + Filter: Get latest SSB records only
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_ssb_latest
COMMENT 'SSB parameters filtered to latest load date'
AS
SELECT ssb.*
FROM source.ERICSSONITE_SSB ssb
INNER JOIN LIVE.nr_erc_ssb_max_loaddate m
  ON ssb.LOADDATE_ = m.LOADDATE_max;

-- ---------------------------------------------------------------------------
-- 5F. "Addd SSB": Join Ericsson NR cells with SSB parameters
--     ON nrcell_name = NRCELLDU_ID_
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_with_ssb
COMMENT 'Ericsson NR cells enriched with SSB frequency/duration/offset'
AS
SELECT
  l.*,
  r.SSBFREQUENCY,
  r.SSBDURATION,
  r.SSBOFFSET
FROM LIVE.nr_erc_transformed l
LEFT JOIN LIVE.nr_erc_ssb_latest r
  ON l.nrcell_name = r.NRCELLDU_ID_;

-- ---------------------------------------------------------------------------
-- 5G. Filter LEVO site master to active sectors (SOFT_SECTOR_ID > 0)
--     (Transform path 11)
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_levo_active
COMMENT 'LEVO site master filtered to active sectors (SOFT_SECTOR_ID > 0)'
AS
SELECT *
FROM source.LEVO_SITE_MASTER_BR
WHERE SOFT_SECTOR_ID > 0;

-- ---------------------------------------------------------------------------
-- 5H. Join(4): Join with LEVO site data on nrcell_name = SOFT_SECTOR_NAME
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE nr_erc_with_levo
COMMENT 'Ericsson NR cells enriched with CLLI and site ID from LEVO'
AS
SELECT
  l.*,
  r.CLLI,
  r.SITE_ID_NAME_BBU
FROM LIVE.nr_erc_with_ssb l
LEFT JOIN LIVE.nr_erc_levo_active r
  ON l.nrcell_name = r.SOFT_SECTOR_NAME;

-- ---------------------------------------------------------------------------
-- 5I. Final NR_ERC_NetAudit output
--     Add UUID as primary key
-- ---------------------------------------------------------------------------
CREATE OR REFRESH LIVE TABLE NR_ERC_NetAudit
COMMENT 'NR Ericsson Net Audit – final output with UUID primary key'
AS
SELECT
  UUID()                   AS uuid,
  edmarket,
  market,
  bbu_usid,
  bbu_fa_code,
  county,
  fips,
  cma,
  remote_usid,
  face,
  latitude,
  longitude,
  nrcell_name,
  cell_type,
  on_air,
  band,
  bw_dl,
  arfcndl,
  arfcnul,
  call_sign,
  refresh_date,
  gnb_name,
  rru_name,
  lte_cells_on_same_rru,
  cpri_link_rate,
  sw_name,
  ems_name,
  dss_ltecell,
  cellbarred,
  configuredmaxtxpower,
  PEA_,
  PEA_Name,
  concat_prim,
  construct_geo_point,
  SSBFREQUENCY,
  SSBDURATION,
  SSBOFFSET,
  CLLI,
  SITE_ID_NAME_BBU
FROM LIVE.nr_erc_with_levo;
